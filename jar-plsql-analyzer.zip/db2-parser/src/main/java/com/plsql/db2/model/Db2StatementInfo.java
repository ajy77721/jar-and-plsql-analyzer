package com.plsql.db2.model;

/** One transaction-control statement (COMMIT / ROLLBACK / SAVEPOINT). */
public class Db2StatementInfo {
    private String type;            // COMMIT, ROLLBACK, SAVEPOINT
    private int line;
    private String savepointName;   // for SAVEPOINT / ROLLBACK TO SAVEPOINT <name>

    public Db2StatementInfo() {}
    public Db2StatementInfo(String type, int line) { this.type = type; this.line = line; }

    public String getType() { return type; }
    public void setType(String v) { this.type = v; }
    public int getLine() { return line; }
    public void setLine(int v) { this.line = v; }
    public String getSavepointName() { return savepointName; }
    public void setSavepointName(String v) { this.savepointName = v; }
}
