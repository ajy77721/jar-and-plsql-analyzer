package com.plsql.db2.model;

import java.util.ArrayList;
import java.util.List;

public class Db2RoutineInfo {

    public enum RoutineType { PROCEDURE, FUNCTION }

    private String       schema;
    private String       name;
    private RoutineType  type = RoutineType.PROCEDURE;
    private int          lineStart;
    private int          lineEnd;
    private List<Db2ParamInfo>      params     = new ArrayList<>();
    private List<Db2VariableInfo>   variables  = new ArrayList<>();
    private List<Db2CursorInfo>     cursors    = new ArrayList<>();
    private List<Db2CallInfo>       calls      = new ArrayList<>();
    private List<Db2TableOpInfo>    tableOps   = new ArrayList<>();
    private List<Db2DynamicSqlInfo> dynamicSql = new ArrayList<>();
    private List<Db2StatementInfo>  statements = new ArrayList<>();
    private List<String>            errors     = new ArrayList<>();
    private List<Db2SequenceInfo>   sequences  = new ArrayList<>();
    private List<Db2ExceptionHandlerInfo> exceptionHandlers = new ArrayList<>();

    /**
     * Whether the routine's compound statement is {@code BEGIN ATOMIC ... END} vs. plain
     * {@code BEGIN ... END} (implicitly NOT ATOMIC). DB2's ATOMIC/NOT ATOMIC affects whether a
     * failed statement partially rolls back just that compound block or the whole unit of work —
     * DB2's closest analogue to Oracle's autonomous-transaction pragma. Previously the grammar
     * accepted the ATOMIC token for parse-success only; nothing captured it.
     */
    private boolean atomic;

    public String      getSchema()     { return schema; }
    public void        setSchema(String schema)         { this.schema = schema; }
    public String      getName()       { return name; }
    public void        setName(String name)             { this.name = name; }
    public RoutineType getType()       { return type; }
    public void        setType(RoutineType type)        { this.type = type; }
    public int         getLineStart()  { return lineStart; }
    public void        setLineStart(int lineStart)      { this.lineStart = lineStart; }
    public int         getLineEnd()    { return lineEnd; }
    public void        setLineEnd(int lineEnd)          { this.lineEnd = lineEnd; }

    public List<Db2ParamInfo>      getParams()     { return params; }
    public List<Db2VariableInfo>   getVariables()  { return variables; }
    public List<Db2CursorInfo>     getCursors()    { return cursors; }
    public List<Db2CallInfo>       getCalls()      { return calls; }
    public List<Db2TableOpInfo>    getTableOps()   { return tableOps; }
    public List<Db2DynamicSqlInfo> getDynamicSql() { return dynamicSql; }
    public List<Db2StatementInfo>  getStatements() { return statements; }
    public List<String>            getErrors()     { return errors; }
    public boolean getAtomic() { return atomic; }
    public void    setAtomic(boolean atomic) { this.atomic = atomic; }

    public List<Db2SequenceInfo> getSequences() { return sequences; }
    public List<Db2ExceptionHandlerInfo> getExceptionHandlers() { return exceptionHandlers; }
}
