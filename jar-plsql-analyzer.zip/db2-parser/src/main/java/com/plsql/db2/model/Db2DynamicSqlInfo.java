package com.plsql.db2.model;

public class Db2DynamicSqlInfo {

    public enum Kind { PREPARE, EXECUTE, EXECUTE_IMMEDIATE }

    private Kind   kind;
    private String stmtName;
    private String sqlSource;
    private int    line;

    public Kind   getKind()      { return kind; }
    public void   setKind(Kind kind)         { this.kind = kind; }
    public String getStmtName()  { return stmtName; }
    public void   setStmtName(String stmtName) { this.stmtName = stmtName; }
    public String getSqlSource() { return sqlSource; }
    public void   setSqlSource(String sqlSource) { this.sqlSource = sqlSource; }
    public int    getLine()      { return line; }
    public void   setLine(int line)          { this.line = line; }
}
