package com.plsql.db2.visitor;

import com.plsql.db2.grammar.Db2Parser;
import com.plsql.db2.grammar.Db2ParserBaseVisitor;
import com.plsql.db2.model.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ANTLR4 visitor over the Db2Parser parse tree.
 *
 * Extracts:
 *   visitRoutineDefinition  → routine identity (name, schema, type, line range)
 *   visitParam              → parameter list (IN/OUT/INOUT, no @ prefix)
 *   visitDeclareVariableStmt → DECLARE variable
 *   visitDeclareCursorStmt  → DECLARE CURSOR [WITH HOLD] FOR select
 *   visitCallStatement      → CALL [schema.]name(args)
 *   visitInsertStatement    → INSERT table op
 *   visitUpdateStatement    → UPDATE table op
 *   visitDeleteStatement    → DELETE table op
 *   visitSelectStatement    → SELECT table op (scans stmtTail for FROM clause)
 *   visitPrepareStatement   → PREPARE stmt FROM source
 *   visitExecuteImmStmt     → EXECUTE IMMEDIATE source
 *   visitExecuteStatement   → EXECUTE stmt [USING args]
 */
public class Db2AnalysisVisitor extends Db2ParserBaseVisitor<Void> {

    private final Db2RoutineInfo result;

    /** CTE names declared via WITH — these are not base tables and must be skipped. */
    private final Set<String> cteNames = new HashSet<>();

    public Db2AnalysisVisitor(String objectName, String schema) {
        this.result = new Db2RoutineInfo();
        result.setName(objectName);
        result.setSchema(schema);
        result.setType(Db2RoutineInfo.RoutineType.PROCEDURE);
    }

    public Db2RoutineInfo getResult() {
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Routine identity
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitBodyBlock(Db2Parser.BodyBlockContext ctx) {
        if (ctx.ATOMIC() != null) result.setAtomic(true);
        return visitChildren(ctx);
    }

    @Override
    public Void visitRoutineDefinition(Db2Parser.RoutineDefinitionContext ctx) {
        // Routine type: PROCEDURE or FUNCTION
        if (ctx.FUNCTION() != null) {
            result.setType(Db2RoutineInfo.RoutineType.FUNCTION);
        } else {
            result.setType(Db2RoutineInfo.RoutineType.PROCEDURE);
        }

        // routineName: (id DOT)? id
        Db2Parser.RoutineNameContext rnCtx = ctx.routineName();
        if (rnCtx != null) {
            List<Db2Parser.IdContext> ids = rnCtx.id();
            if (ids.size() == 2) {
                // schema.name
                result.setSchema(cleanId(ids.get(0).getText()));
                result.setName(cleanId(ids.get(1).getText()));
            } else if (ids.size() == 1) {
                result.setName(cleanId(ids.get(0).getText()));
            }
        }

        // Line range
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null
                ? ctx.getStop().getLine()
                : ctx.getStart().getLine());

        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Parameters
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitParam(Db2Parser.ParamContext ctx) {
        Db2ParamInfo p = new Db2ParamInfo();

        // Direction: IN_KW / OUT_KW / INOUT
        if (ctx.INOUT() != null) {
            p.setDirection(Db2ParamInfo.Direction.INOUT);
        } else if (ctx.OUT_KW() != null) {
            p.setDirection(Db2ParamInfo.Direction.OUT);
        } else {
            p.setDirection(Db2ParamInfo.Direction.IN);
        }

        // Name (no @ prefix in DB2)
        p.setName(cleanId(ctx.id().getText()));

        // Data type
        p.setDataType(ctx.dataType().getText());

        p.setLine(ctx.getStart().getLine());
        result.getParams().add(p);
        return null; // don't recurse — no nested params
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE variable
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareVariableStmt(Db2Parser.DeclareVariableStmtContext ctx) {
        String name = cleanId(ctx.id().getText());
        String dataType = ctx.dataType().getText();

        // Filter out handler keywords (CONTINUE/EXIT/UNDO HANDLER is a different rule,
        // but be defensive)
        if ("CONTINUE".equalsIgnoreCase(name) || "EXIT".equalsIgnoreCase(name)
                || "UNDO".equalsIgnoreCase(name)) {
            return null;
        }

        // Filter out CURSOR type (those are handled by declareCursorStmt)
        if ("CURSOR".equalsIgnoreCase(dataType)) {
            return null;
        }

        Db2VariableInfo v = new Db2VariableInfo();
        v.setName(name);
        v.setDataType(dataType);
        if (ctx.expr() != null) {
            v.setDefaultValue(ctx.expr().getText());
        }
        v.setLine(ctx.getStart().getLine());
        result.getVariables().add(v);
        return null; // no nested declares
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE cursor
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareCursorStmt(Db2Parser.DeclareCursorStmtContext ctx) {
        Db2CursorInfo c = new Db2CursorInfo();
        c.setName(cleanId(ctx.id(0).getText()));
        boolean withHold = false;
        for (Db2Parser.CursorOptionContext opt : ctx.cursorOption()) {
            if (opt.HOLD() != null) { withHold = true; break; }
        }
        c.setWithHold(withHold);
        if (ctx.selectStatement() != null) {
            c.setSelectText(ctx.selectStatement().getText());
        }
        c.setLine(ctx.getStart().getLine());
        result.getCursors().add(c);
        // Visit children to catch table ops in the SELECT inside the cursor
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CALL statement
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitCallStatement(Db2Parser.CallStatementContext ctx) {
        Db2CallInfo call = new Db2CallInfo();
        Db2Parser.RoutineNameContext rnCtx = ctx.routineName();
        if (rnCtx != null) {
            List<Db2Parser.IdContext> ids = rnCtx.id();
            if (ids.size() == 2) {
                call.setSchema(cleanId(ids.get(0).getText()));
                call.setName(cleanId(ids.get(1).getText()));
            } else if (ids.size() == 1) {
                call.setName(cleanId(ids.get(0).getText()));
            }
        }
        call.setLine(ctx.getStart().getLine());
        result.getCalls().add(call);
        // Recurse into the argument list so nested function calls (e.g.
        // CALL PROC(FN(x))) are also captured as call edges via visitFunctionCall.
        // routineName itself is a distinct grammar rule (not functionCall), so this
        // does not re-record the outer CALL target.
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: INSERT
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitInsertStatement(Db2Parser.InsertStatementContext ctx) {
        Db2TableOpInfo op = new Db2TableOpInfo();
        op.setDmlType(Db2TableOpInfo.DmlType.INSERT);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: UPDATE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitUpdateStatement(Db2Parser.UpdateStatementContext ctx) {
        Db2TableOpInfo op = new Db2TableOpInfo();
        op.setDmlType(Db2TableOpInfo.DmlType.UPDATE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: DELETE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeleteStatement(Db2Parser.DeleteStatementContext ctx) {
        Db2TableOpInfo op = new Db2TableOpInfo();
        op.setDmlType(Db2TableOpInfo.DmlType.DELETE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SELECT — register CTE names up-front so their references are skipped, then
    // descend so FROM/JOIN contexts (incl. inside CTE bodies) are captured.
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitSelectStatement(Db2Parser.SelectStatementContext ctx) {
        // A nested SELECT that is a scalar subquery (exprAtom: LPAREN selectStatement RPAREN)
        // or a derived-table subquery in FROM (tableAtom #atomSubquery) is a SUBQUERY.
        // CTE bodies (cteDef), FOR-loop cursors (forStatement), declared cursors, and
        // top-level statement SELECTs are NOT subqueries and are excluded by parent type.
        org.antlr.v4.runtime.tree.ParseTree parent = ctx.getParent();
        if (parent instanceof Db2Parser.ExprAtomContext
                || parent instanceof Db2Parser.AtomSubqueryContext
                || parent instanceof Db2Parser.SelectRestTokenContext) {
            result.getStatements().add(new Db2StatementInfo("SUBQUERY", ctx.getStart().getLine()));
        }
        if (ctx.withClause() != null) {
            for (Db2Parser.CteDefContext cte : ctx.withClause().cteDef()) {
                if (cte.id() != null) {
                    cteNames.add(cleanId(cte.id().getText()).toUpperCase());
                }
                // Emit a common "CTE" statement per WITH factoring clause so it is captured
                // uniformly with the other dialects (visible in the UI construct breakdown).
                result.getStatements().add(new Db2StatementInfo("CTE", cte.getStart().getLine()));
            }
        }
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FROM clause — base tables + joins (grammar contexts only, no text scanning)
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitFromClause(Db2Parser.FromClauseContext ctx) {
        for (Db2Parser.TableReferenceContext tr : ctx.tableReference()) {
            processTableReference(tr);
        }
        return visitChildren(ctx);   // recurse for nested subquery SELECTs / CTEs
    }

    /**
     * Walk one {@code tableReference} (a base tableAtom followed by zero or more
     * joinClauses). The base atom becomes a SELECT table op; each JOINed atom
     * becomes its own SELECT table op AND a Db2JoinInfo attached to the base op.
     */
    private void processTableReference(Db2Parser.TableReferenceContext tr) {
        Db2TableOpInfo baseOp = tableOpForAtom(tr.tableAtom());

        java.util.Map<String, String> aliasMap = buildAliasMap(tr);
        int queryId = tr.getStart().getLine();

        for (Db2Parser.JoinClauseContext jc : tr.joinClause()) {
            Db2TableOpInfo joinedOp = tableOpForAtom(jc.tableAtom());
            if (baseOp == null) continue;

            if (jc.tableAtom() instanceof Db2Parser.AtomTableContext jat) {
                Db2Parser.TableRefContext jref = jat.tableRef();
                // A joined CTE ref yields no standalone table op (handled above) but the
                // JOIN relationship itself is still recorded on the base table.
                Db2JoinInfo j = new Db2JoinInfo();
                j.setJoinType(joinTypeText(jc.joinType()));
                j.setJoinedTable(extractTableName(jref));
                j.setJoinedTableSchema(extractTableSchema(jref));
                if (jat.id() != null) {
                    j.setJoinedTableAlias(cleanId(jat.id().getText()));
                }
                if (jc.expr() != null) {
                    j.setCondition(originalText(jc.expr()));
                }
                j.setLine(jc.getStart().getLine());
                j.setQueryId(queryId);
                resolveLeftSide(j, aliasMap);
                baseOp.getJoins().add(j);
            }
        }
    }

    /** Build alias->table (both upper-cased) for the base atom and each joined atom of a tableReference. */
    private java.util.Map<String, String> buildAliasMap(Db2Parser.TableReferenceContext tr) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        addAtomAlias(m, tr.tableAtom());
        for (Db2Parser.JoinClauseContext jc : tr.joinClause()) {
            addAtomAlias(m, jc.tableAtom());
        }
        return m;
    }

    private void addAtomAlias(java.util.Map<String, String> m, Db2Parser.TableAtomContext atom) {
        if (!(atom instanceof Db2Parser.AtomTableContext at)) return;
        String tbl = extractTableName(at.tableRef());
        if (tbl == null) return;
        tbl = tbl.toUpperCase();
        if (at.id() != null) m.put(cleanId(at.id().getText()).toUpperCase(), tbl);
        m.put(tbl, tbl);
    }

    /** Resolve leftTable/leftTableAlias from the ON-condition alias that is NOT the joined table. */
    private void resolveLeftSide(Db2JoinInfo j, java.util.Map<String, String> aliasMap) {
        if (j.getCondition() == null) return;
        String joinedAlias = j.getJoinedTableAlias() != null ? j.getJoinedTableAlias().toUpperCase() : null;
        java.util.regex.Matcher mt = java.util.regex.Pattern
                .compile("([A-Za-z_][A-Za-z0-9_$#]*)\\s*\\.").matcher(j.getCondition());
        java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();
        while (mt.find()) seen.add(mt.group(1).toUpperCase());
        for (String a : seen) {
            if (joinedAlias != null && a.equals(joinedAlias)) continue;
            String t = aliasMap.get(a);
            if (t != null) { j.setLeftTableAlias(a); j.setLeftTable(t); return; }
        }
    }

    /**
     * Adds a SELECT table op for the given tableAtom and returns it (null for a CTE
     * reference or a subquery atom, whose inner SELECT is handled by recursion).
     */
    private Db2TableOpInfo tableOpForAtom(Db2Parser.TableAtomContext atom) {
        if (atom instanceof Db2Parser.AtomTableContext at) {
            if (isCte(at.tableRef())) return null;
            Db2TableOpInfo op = new Db2TableOpInfo();
            op.setDmlType(Db2TableOpInfo.DmlType.SELECT);
            op.setTableName(extractTableName(at.tableRef()));
            op.setSchemaName(extractTableSchema(at.tableRef()));
            if (at.id() != null) op.setAlias(cleanId(at.id().getText()));
            op.setLine(at.getStart().getLine());
            // Without this a SELECT carried no SQL, so no column detail could be derived from it.
            op.setSqlText(enclosingStatementText(at));
            result.getTableOps().add(op);
            return op;
        }
        if (atom instanceof Db2Parser.AtomParenContext paren) {
            Db2TableOpInfo first = null;
            for (Db2Parser.TableReferenceContext tr : paren.tableReference()) {
                processTableReference(tr);
                if (first == null && !result.getTableOps().isEmpty()) {
                    first = result.getTableOps().get(result.getTableOps().size() - 1);
                }
            }
            return first;
        }
        return null;   // AtomSubquery — inner SELECT handled by visitChildren recursion
    }

    private boolean isCte(Db2Parser.TableRefContext tr) {
        if (tr == null) return false;
        String schema = extractTableSchema(tr);
        String name = extractTableName(tr);
        return schema == null && name != null && cteNames.contains(name.toUpperCase());
    }

    /** Render a joinType context as spaced upper-case text (e.g. "LEFT OUTER"), or "JOIN" if absent. */
    private String joinTypeText(Db2Parser.JoinTypeContext jt) {
        if (jt == null) return "JOIN";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < jt.getChildCount(); i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(jt.getChild(i).getText().toUpperCase());
        }
        return sb.length() == 0 ? "JOIN" : sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Function calls inside expressions — user-routine invocations (call-tree)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Authoritative catalog of IBM Db2 (LUW) engine built-in / scalar / aggregate / OLAP
     * function names (uppercase). A bare (non schema-qualified) function whose name is in
     * this set is an engine built-in and is NOT recorded as a user-routine call edge.
     * Schema-qualified calls (e.g. {@code MYSCHEMA.FOO(...)}) are always treated as
     * user-routine calls regardless of this set — see {@link #visitFunctionCall}.
     *
     * NOTE: the window/ranking functions ROW_NUMBER, RANK, DENSE_RANK and the formatting
     * function VARCHAR_FORMAT are DELIBERATELY EXCLUDED — they are higher-collision with
     * real user-routine names and were not observed as false-positive call nodes.
     */
    private static final Set<String> BUILTIN_FUNCTIONS = Set.of(
        // ── String / character ──────────────────────────────────────────────
        "LENGTH","LENGTH2","LENGTH4","CHARACTER_LENGTH","SUBSTR","SUBSTRING","LEFT","RIGHT",
        "LOCATE","LOCATE_IN_STRING","POSSTR","POSITION","INSTR","REPLACE","TRANSLATE","OVERLAY",
        "INSERT","REPEAT","LPAD","RPAD","LTRIM","RTRIM","TRIM","STRIP","UPPER","UCASE","LOWER",
        "LCASE","INITCAP","CONCAT","REVERSE","SOUNDEX","DIFFERENCE","ASCII","CHR","HEX","DIGITS",
        "SPACE","TO_CHAR","CHAR","GRAPHIC","VARGRAPHIC","VARCHAR","XMLCAST",
        // ── Numeric / math / cast ───────────────────────────────────────────
        "ABS","CEIL","CEILING","FLOOR","ROUND","TRUNC","TRUNCATE","MOD","POWER","POW","SQRT",
        "EXP","LN","LOG","LOG10","SIGN","RAND","ACOS","ASIN","ATAN","ATAN2","COS","COSH","COT",
        "SIN","SINH","TAN","TANH","DEGREES","RADIANS","DECFLOAT","INTEGER","INT","BIGINT",
        "SMALLINT","DECIMAL","DEC","DOUBLE","REAL","FLOAT",
        // ── Date / time ─────────────────────────────────────────────────────
        "CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP","DAY","DAYS","DAYOFWEEK",
        "DAYOFWEEK_ISO","DAYOFYEAR","DAYNAME","MONTH","MONTHNAME","YEAR","WEEK","WEEK_ISO",
        "HOUR","MINUTE","SECOND","MICROSECOND","QUARTER","MIDNIGHT_SECONDS","JULIAN_DAY",
        "LAST_DAY","NEXT_DAY","ADD_MONTHS","MONTHS_BETWEEN","TIMESTAMP_FORMAT","TO_DATE",
        "TO_TIMESTAMP","TIMESTAMPDIFF","TIMESTAMP_ISO","DATE","TIME","TIMESTAMP","EXTRACT",
        // ── Null / conditional ──────────────────────────────────────────────
        "COALESCE","VALUE","NULLIF","NVL","NVL2","IFNULL","DECODE","MAX","MIN","GREATEST","LEAST",
        // ── Aggregate ───────────────────────────────────────────────────────
        "COUNT","COUNT_BIG","SUM","AVG","STDDEV","STDDEV_SAMP","VARIANCE","VAR_SAMP",
        "CORRELATION","CORR","COVARIANCE","LISTAGG","XMLAGG","ARRAY_AGG",
        // ── OLAP / window ───────────────────────────────────────────────────
        "PERCENT_RANK","CUME_DIST","NTILE","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTH_VALUE",
        "RATIO_TO_REPORT",
        // ── Special registers / special built-ins ───────────────────────────
        "IDENTITY_VAL_LOCAL","LAST_INSERT_ID","GENERATE_UNIQUE","NEXTVAL","PREVVAL",
        "CURRENT_SCHEMA","CURRENT_USER","SESSION_USER","SYSTEM_USER","CURRENT_SERVER","HASH",
        "MAX_CARDINALITY","CARDINALITY","INTNAND","RAISE_ERROR",
        // ── Window / OLAP (added) ───────────────────────────────────────────
        "ROW_NUMBER","RANK","DENSE_RANK",
        // ── Aggregate / statistical (added) ─────────────────────────────────
        "MEDIAN","PERCENTILE_CONT","PERCENTILE_DISC","STDDEV_POP","VAR_POP","GROUPING",
        "REGR_SLOPE","REGR_INTERCEPT","REGR_COUNT","REGR_R2","REGR_AVGX","REGR_AVGY",
        // ── Numeric / bit (added) ───────────────────────────────────────────
        "WIDTH_BUCKET","BITAND","BITOR","BITXOR","BITNOT","BITANDNOT","MULTIPLY_ALT",
        "TO_NUMBER","QUANTIZE","NORMALIZE_DECFLOAT","COMPARE_DECFLOAT","TOTALORDER",
        // ── String / regexp / lob (added) ───────────────────────────────────
        "REGEXP_REPLACE","REGEXP_SUBSTR","REGEXP_INSTR","REGEXP_COUNT","REGEXP_LIKE",
        "TO_CLOB","CLOB","BLOB","DBCLOB","OVERLAY_ALT","INSTRB",
        // ── Date / time (added) ─────────────────────────────────────────────
        "TIMESTAMPADD","DAYOFMONTH","DAYS_BETWEEN","ROUND_TIMESTAMP","TRUNC_TIMESTAMP","FROM_UTC_TIMESTAMP","TO_UTC_TIMESTAMP",
        // ── XML / JSON (added) ──────────────────────────────────────────────
        "XMLELEMENT","XMLATTRIBUTES","XMLSERIALIZE","XMLPARSE","XMLQUERY","XMLNAMESPACES",
        "XMLCONCAT","XMLFOREST","XMLDOCUMENT","XMLTEXT","XMLROW","XMLGROUP",
        "JSON_VAL","JSON_TABLE","JSON_OBJECT","JSON_ARRAY","JSON_QUERY","JSON_VALUE","JSON_EXISTS",
        // ── Identity / catalog (added) ──────────────────────────────────────
        "TABLE_NAME","TABLE_SCHEMA","TYPE_NAME","TYPE_SCHEMA","DBPARTITIONNUM","HASHEDVALUE","RID","RID_BIT","GETHINT","ENCRYPT","DECRYPT");

    @Override
    public Void visitFunctionCall(Db2Parser.FunctionCallContext ctx) {
        List<Db2Parser.IdContext> ids = ctx.id();
        String schema = ids.size() > 1 ? cleanId(ids.get(0).getText()) : null;
        String name   = cleanId(ids.get(ids.size() - 1).getText());

        if (name != null && (schema != null || !BUILTIN_FUNCTIONS.contains(name.toUpperCase()))) {
            String qualified = (schema != null && !schema.isBlank()) ? schema + "." + name : name;
            boolean dup = result.getCalls().stream()
                    .anyMatch(c -> qualified.equalsIgnoreCase(c.qualifiedName()));
            if (!dup) {
                Db2CallInfo call = new Db2CallInfo();
                call.setName(name);
                call.setSchema(schema);
                call.setLine(ctx.getStart().getLine());
                result.getCalls().add(call);
            }
        }
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: PREPARE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitPrepareStatement(Db2Parser.PrepareStatementContext ctx) {
        Db2DynamicSqlInfo d = new Db2DynamicSqlInfo();
        d.setKind(Db2DynamicSqlInfo.Kind.PREPARE);

        // PREPARE id FROM (id | SQ_STRING)
        List<Db2Parser.IdContext> ids = ctx.id();
        if (!ids.isEmpty()) {
            d.setStmtName(cleanId(ids.get(0).getText()));
        }
        if (ids.size() > 1) {
            // Second id is the source variable
            d.setSqlSource(cleanId(ids.get(1).getText()));
        } else if (ctx.SQ_STRING() != null) {
            d.setSqlSource(ctx.SQ_STRING().getText());
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: EXECUTE IMMEDIATE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExecuteImmStmt(Db2Parser.ExecuteImmStmtContext ctx) {
        Db2DynamicSqlInfo d = new Db2DynamicSqlInfo();
        d.setKind(Db2DynamicSqlInfo.Kind.EXECUTE_IMMEDIATE);

        if (ctx.id() != null) {
            d.setSqlSource(cleanId(ctx.id().getText()));
        } else if (ctx.SQ_STRING() != null) {
            d.setSqlSource(ctx.SQ_STRING().getText());
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: EXECUTE stmt [USING ...]
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExecuteStatement(Db2Parser.ExecuteStatementContext ctx) {
        Db2DynamicSqlInfo d = new Db2DynamicSqlInfo();
        d.setKind(Db2DynamicSqlInfo.Kind.EXECUTE);

        if (ctx.id() != null) {
            d.setStmtName(cleanId(ctx.id().getText()));
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Transaction-control statements → StatementInfo (COMMIT / ROLLBACK / SAVEPOINT)
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitTxnCommit(Db2Parser.TxnCommitContext ctx) {
        result.getStatements().add(new Db2StatementInfo("COMMIT", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnRollback(Db2Parser.TxnRollbackContext ctx) {
        result.getStatements().add(new Db2StatementInfo("ROLLBACK", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnRollbackTo(Db2Parser.TxnRollbackToContext ctx) {
        Db2StatementInfo si = new Db2StatementInfo("ROLLBACK", ctx.getStart().getLine());
        si.setSavepointName(cleanId(ctx.id().getText()));
        result.getStatements().add(si);
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnSavepoint(Db2Parser.TxnSavepointContext ctx) {
        Db2StatementInfo si = new Db2StatementInfo("SAVEPOINT", ctx.getStart().getLine());
        si.setSavepointName(cleanId(ctx.id().getText()));
        result.getStatements().add(si);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Control-flow statements → StatementInfo (IF / CASE / loops)
    // Each override records ONE statement record per occurrence, then descends
    // (visitChildren) so nested statements / table ops / calls are still captured.
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitIfStatement(Db2Parser.IfStatementContext ctx) {
        result.getStatements().add(new Db2StatementInfo("IF", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitWhileStatement(Db2Parser.WhileStatementContext ctx) {
        result.getStatements().add(new Db2StatementInfo("WHILE_LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitForStatement(Db2Parser.ForStatementContext ctx) {
        result.getStatements().add(new Db2StatementInfo("FOR_LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitLoopStatement(Db2Parser.LoopStatementContext ctx) {
        result.getStatements().add(new Db2StatementInfo("LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitRepeatStatement(Db2Parser.RepeatStatementContext ctx) {
        result.getStatements().add(new Db2StatementInfo("REPEAT", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * CASE (expression or statement form) has no dedicated grammar rule — it appears
     * as {@code CASE … END} inside exprAtom / stmtToken / selectRestToken. Each such
     * context carries exactly one CASE token, and a given CASE keyword lives in exactly
     * one of those rules, so counting per-context yields one record per occurrence with
     * no double-counting (nested CASEs are distinct child contexts).
     */
    @Override
    public Void visitExprAtom(Db2Parser.ExprAtomContext ctx) {
        if (ctx.CASE() != null) {
            result.getStatements().add(new Db2StatementInfo("CASE", ctx.getStart().getLine()));
        }
        if (ctx.FOR() != null) {
            List<Db2Parser.IdContext> ids = ctx.id();
            if (ctx.NEXT() != null && ctx.VALUE() != null) {
                // NEXT VALUE FOR (id DOT)? id  — always a NEXTVAL reference
                recordSequenceRef("NEXTVAL", ids, ctx.getStart().getLine());
            } else if (!ids.isEmpty()) {
                // id FOR (id DOT)? id  — Oracle-compat NEXTVAL/PREVVAL FOR seq;
                // the first id is the operation keyword (not a real identifier here).
                String op = cleanId(ids.get(0).getText()).toUpperCase();
                if ("NEXTVAL".equals(op) || "PREVVAL".equals(op)) {
                    recordSequenceRef(op, ids.subList(1, ids.size()), ctx.getStart().getLine());
                }
            }
        }
        return visitChildren(ctx);
    }

    /** Records a NEXTVAL/PREVVAL sequence reference from a trailing (schema.)?name id list. */
    private void recordSequenceRef(String operation, List<Db2Parser.IdContext> seqIds, int line) {
        if (seqIds.isEmpty()) return;
        Db2SequenceInfo s = new Db2SequenceInfo();
        s.setOperation(operation);
        s.setSchema(seqIds.size() > 1 ? cleanId(seqIds.get(0).getText()) : null);
        s.setSequenceName(cleanId(seqIds.get(seqIds.size() - 1).getText()));
        s.setLine(line);
        result.getSequences().add(s);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE (CONTINUE|EXIT|UNDO) HANDLER FOR <conditions> <action>
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareHandlerStmt(Db2Parser.DeclareHandlerStmtContext ctx) {
        Db2ExceptionHandlerInfo h = new Db2ExceptionHandlerInfo();
        if (ctx.EXIT() != null) {
            h.setKind(Db2ExceptionHandlerInfo.Kind.EXIT);
        } else if (ctx.UNDO() != null) {
            h.setKind(Db2ExceptionHandlerInfo.Kind.UNDO);
        } else {
            h.setKind(Db2ExceptionHandlerInfo.Kind.CONTINUE);
        }
        List<String> conditions = new java.util.ArrayList<>();
        for (Db2Parser.HandlerCondContext hc : ctx.handlerCondList().handlerCond()) {
            conditions.add(handlerCondText(hc));
        }
        h.setConditions(conditions);
        h.setLine(ctx.getStart().getLine());
        result.getExceptionHandlers().add(h);
        return visitChildren(ctx);
    }

    private String handlerCondText(Db2Parser.HandlerCondContext hc) {
        if (hc.SQLEXCEPTION() != null) return "SQLEXCEPTION";
        if (hc.SQLWARNING() != null) return "SQLWARNING";
        if (hc.SQLSTATE() != null) {
            String val = hc.SQ_STRING() != null ? hc.SQ_STRING().getText() : "";
            return ("SQLSTATE " + val).trim();
        }
        if (hc.NOT() != null && hc.id() != null) {
            return "NOT " + cleanId(hc.id().getText());
        }
        if (hc.id() != null) {
            return cleanId(hc.id().getText());
        }
        return hc.getText();
    }

    @Override
    public Void visitStmtToken(Db2Parser.StmtTokenContext ctx) {
        if (ctx.CASE() != null) {
            result.getStatements().add(new Db2StatementInfo("CASE", ctx.getStart().getLine()));
        }
        return visitChildren(ctx);
    }

    @Override
    public Void visitSelectRestToken(Db2Parser.SelectRestTokenContext ctx) {
        if (ctx.CASE() != null) {
            result.getStatements().add(new Db2StatementInfo("CASE", ctx.getStart().getLine()));
        }
        return visitChildren(ctx);
    }

    /**
     * MERGE has no lexer keyword — it tokenizes as an identifier and is parsed by the
     * otherStatement catch-all. Detect it by the leading token text (visitor-only).
     */
    @Override
    public Void visitOtherStatement(Db2Parser.OtherStatementContext ctx) {
        if (ctx.getStart() != null && "MERGE".equalsIgnoreCase(ctx.getStart().getText())) {
            result.getStatements().add(new Db2StatementInfo("MERGE", ctx.getStart().getLine()));
        }
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String cleanId(String s) {
        if (s == null) return null;
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    private String extractTableName(Db2Parser.TableRefContext ctx) {
        if (ctx == null) return null;
        List<Db2Parser.IdContext> ids = ctx.id();
        if (ids.isEmpty()) return null;
        // Last id is the table name
        return cleanId(ids.get(ids.size() - 1).getText());
    }

    private String extractTableSchema(Db2Parser.TableRefContext ctx) {
        if (ctx == null) return null;
        List<Db2Parser.IdContext> ids = ctx.id();
        if (ids.size() > 1) {
            return cleanId(ids.get(0).getText());
        }
        return null;
    }

    /**
     * The full SQL of the statement starting at this context.
     *
     * <p>Extends to the statement terminator rather than to {@code ctx.getStop()}. This dialect's
     * grammar rule for a DML statement ends before the {@code SET}/{@code WHERE} clauses, so the
     * context's own interval yielded only {@code "UPDATE orders"} — which parses to nothing useful
     * and produced no column detail at all. Verified against the alternative: SQL Server's rule
     * does span the whole statement and worked, which is what made the truncation visible here.
     *
     * <p>Quotes are tracked so a semicolon inside a string literal does not end the statement
     * early.
     */

    /**
     * The source text of the statement enclosing {@code ctx}.
     *
     * <p>A SELECT's table op is built from a table reference inside the FROM clause, which knows
     * nothing about the statement around it — so it carried no SQL at all, and the column enricher
     * had nothing to work from. Measured before this: DB2 2,732 and PostgreSQL 2,392 statements with
     * no {@code sqlText}, every one a SELECT, which is why those two dialects showed almost no
     * column detail while MySQL (which already had this helper) showed 3,450.
     *
     * <p>Walks up to the nearest context whose name ends in {@code StatementContext} or
     * {@code StmtContext}, which is the naming convention every grammar here follows.
     */
    private String enclosingStatementText(org.antlr.v4.runtime.ParserRuleContext ctx) {
        org.antlr.v4.runtime.ParserRuleContext c = ctx;
        org.antlr.v4.runtime.ParserRuleContext bestSelect = null;
        org.antlr.v4.runtime.ParserRuleContext stmt = null;
        while (c != null) {
            String n = c.getClass().getSimpleName();
            // Prefer the outermost SELECT over the statement wrapping it.
            //
            // PL/pgSQL and SQL PL wrap reads in control flow — `FOR rec IN SELECT ... LOOP`. Walking
            // straight to the enclosing StatementContext captured the loop, so the text handed to
            // the ANSI parser ended in a bare `LOOP` and failed. Measured: 979 PostgreSQL statements
            // captured-but-unparseable, every one of that shape. Taking the outermost Select keeps
            // the joins and WHERE (which is where the column detail lives) and stops before the
            // control-flow keyword.
            if (n.contains("Select") || n.contains("QuerySpec")) bestSelect = c;
            else if (n.endsWith("StatementContext") || n.endsWith("StmtContext")) { stmt = c; break; }
            c = c.getParent();
        }
        org.antlr.v4.runtime.ParserRuleContext pick = bestSelect != null ? bestSelect : stmt;
        return pick != null ? cutAtStatementEnd(trimTrailingBlockKeyword(originalText(pick))) : null;
    }


    /**
     * Cuts the text at the first unquoted semicolon.
     *
     * <p>A grammar context can span more than one statement, and the captured text then reads
     * {@code SELECT COUNT(*) INTO v_n FROM erp.erp_product; CALL erp.erp_usp_write_audit_trail(...)}.
     * ANSI parsing sees two statements and yields nothing for either, so a read with perfectly
     * ordinary columns and predicates came back empty — 1,223 PostgreSQL statements of exactly that
     * shape, all of which had parsed "successfully" while producing no detail.
     *
     * <p>Quote-aware because a semicolon inside a literal is data, not a terminator; cutting there
     * would truncate mid-string and turn a parseable statement into an unparseable one.
     */
    private String cutAtStatementEnd(String sql) {
        if (sql == null) return null;
        char quote = 0;
        for (int i = 0; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0;
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (c == ';') {
                return sql.substring(0, i).stripTrailing();
            }
        }
        return sql;
    }
    /**
     * Strips a trailing block keyword the grammar may have included.
     *
     * <p>Belt and braces for the case above: even with the Select preferred, a grammar rule can end
     * on {@code LOOP}/{@code THEN}/{@code DO}, and one stray keyword makes the whole statement
     * unparseable — losing all of its column detail rather than part of it.
     */
    private String trimTrailingBlockKeyword(String sql) {
        if (sql == null) return null;
        String s = sql.stripTrailing();
        for (String kw : new String[]{"LOOP", "THEN", "DO", "BEGIN"}) {
            if (s.length() > kw.length()) {
                String tail = s.substring(s.length() - kw.length());
                if (tail.equalsIgnoreCase(kw)
                        && Character.isWhitespace(s.charAt(s.length() - kw.length() - 1))) {
                    s = s.substring(0, s.length() - kw.length()).stripTrailing();
                }
            }
        }
        return s;
    }

    /**
     * Delegates to {@link com.plsql.dialect.StatementTextCapture}.
     *
     * <p>This method used to be a byte-identical copy of the DB2/PostgreSQL sibling, and
     * both copies carried the same two defects — running into a loop body, and closing a
     * parenthesis never opened — which then had to be found and fixed twice. Sharing it is
     * the point: the next fix lands in one place.
     */
    private String originalText(org.antlr.v4.runtime.ParserRuleContext ctx) {
        return com.plsql.dialect.StatementTextCapture.capture(
                ctx, com.plsql.dialect.StatementTextCapture.DB2_BLOCK_KEYWORDS);
    }
}
