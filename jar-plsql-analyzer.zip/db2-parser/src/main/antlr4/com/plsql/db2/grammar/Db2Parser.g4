// ============================================================
// Db2Parser.g4
// Parser grammar for IBM DB2 SQL PL stored procedures / functions.
// Entry point: compilationUnit
// tokenVocab = Db2Lexer
// ============================================================
parser grammar Db2Parser;

options { tokenVocab = Db2Lexer; }

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

compilationUnit
    : routineDefinition? EOF
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Routine definition
// ─────────────────────────────────────────────────────────────────────────────

routineDefinition
    : CREATE (OR REPLACE)? (PROCEDURE | FUNCTION) routineName
      LPAREN paramList? RPAREN
      (RETURNS dataType)?
      routineCharacteristic*
      bodyBlock?
    ;

// NOTE: REPLACE must be defined in Db2Lexer.g4 as a keyword token.

// Permissive catch-all for routine characteristics that appear between
// the parameter list and BEGIN (e.g. LANGUAGE SQL, NOT DETERMINISTIC, etc.)
// Anything that is not BEGIN, EOF, or the start of another construct is consumed.
routineCharacteristic
    : ~(BEGIN | EOF)+
    ;

bodyBlock
    : BEGIN ATOMIC? body END SEMI?
    ;

routineName
    : (id DOT)? id
    ;

id
    : ID
    | DQ_ID
    // Allow selected non-structural keywords to be used as identifiers where the
    // parser expects an id. STRUCTURAL clause keywords (FROM, INTO, JOIN, ON,
    // WHERE, GROUP, ORDER, BY, HAVING, UNION, AS, SELECT, the join-type words,
    // ALL, DISTINCT, WHEN, THEN, ELSE, DO, …) are deliberately EXCLUDED so that
    // an expression stops at a clause boundary instead of swallowing it.
    | ATOMIC | CALL | CASE | CAST | CLOSE | CONDITION | CONTINUE | CREATE | CURRENT
    | CURSOR | DEFAULT | EXISTS | EXIT | FETCH | FUNCTION | HANDLER | HOLD
    | IMMEDIATE | INOUT | IN_KW | IS | LANGUAGE | LIKE | LOOP | NEXT | NULL_KW
    | OPEN | OR | OUT_KW | OVER | PARTITION | PREPARE | PROCEDURE | REPEAT
    | REPLACE | RESIGNAL | RETURNS | RETURN | SET | SIGNAL | SQL_KW
    | SQLEXCEPTION | SQLSTATE | SQLWARNING | UNDO | UNTIL | UPDATE | USING
    | VALUE | VALUES | WHILE | WITH
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Parameters
// ─────────────────────────────────────────────────────────────────────────────

paramList
    : param (COMMA param)*
    ;

// PROCEDURE params carry a mode (IN/OUT/INOUT); FUNCTION params carry none.
// The mode is therefore OPTIONAL so both forms parse.
param
    : (IN_KW | OUT_KW | INOUT)? id dataType (DEFAULT defaultVal)?
    ;

dataType
    : id (LPAREN INT_NUM (COMMA INT_NUM)? RPAREN)?
    ;

defaultVal
    : literal
    | id
    | MINUS INT_NUM
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Body
// ─────────────────────────────────────────────────────────────────────────────

body
    : statement*
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Statements
// ─────────────────────────────────────────────────────────────────────────────

statement
    : declareGlobalTempTable
    | declareVariableStmt
    | declareCursorStmt
    | declareHandlerStmt
    | callStatement
    | setStatement
    | insertStatement
    | updateStatement
    | deleteStatement
    | selectStatement
    | ifStatement
    | whileStatement
    | forStatement
    | loopStatement
    | repeatStatement
    | executeImmStmt
    | executeStatement
    | prepareStatement
    | openStatement
    | closeStatement
    | fetchStatement
    | returnStatement
    | transactionStatement
    | beginBlock
    | caseStatement
    | otherStatement
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Transaction-control statements (DB2 SQL PL)
//   COMMIT [WORK]
//   ROLLBACK [WORK] [TO SAVEPOINT name]
//   SAVEPOINT name [UNIQUE] ON ROLLBACK RETAIN CURSORS ...
//   RELEASE [TO] SAVEPOINT name
// ─────────────────────────────────────────────────────────────────────────────
transactionStatement
    : COMMIT WORK? SEMI?                        # txnCommit
    | ROLLBACK WORK? TO SAVEPOINT? id SEMI?     # txnRollbackTo
    | ROLLBACK WORK? SEMI?                      # txnRollback
    | SAVEPOINT id savepointOpt* SEMI?         # txnSavepoint
    | RELEASE TO? SAVEPOINT id SEMI?           # txnReleaseSavepoint
    ;

// Trailing options after SAVEPOINT name (UNIQUE / ON ROLLBACK RETAIN CURSORS / …)
savepointOpt
    : ~(SEMI | BEGIN | END | DECLARE | CALL | IF | WHILE | FOR | LOOP | REPEAT | PREPARE
        | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE | DELETE | SELECT | RETURN
        | SET | CREATE)
    ;

// DECLARE id dataType [DEFAULT expr] ;
// Note: must not match CURSOR declarations — we handle those separately
// DECLARE GLOBAL TEMPORARY TABLE SESSION.name (...) ON COMMIT … — consumed permissively to ';'
// DECLARE GLOBAL TEMPORARY TABLE [schema.]name ( … ) ON COMMIT …
// GLOBAL/TEMPORARY/TABLE are plain identifiers (not lexer tokens); the shape
// "DECLARE id id id [schema.]name (" is specific enough not to collide with a
// normal 2-id variable declaration.
declareGlobalTempTable
    : DECLARE id id id id (DOT id)? LPAREN (~SEMI)* SEMI
    ;

declareVariableStmt
    : DECLARE id dataType (DEFAULT expr)? SEMI
    ;

// DECLARE id CURSOR [WITH HOLD] FOR selectStatement
// Also: DECLARE id CURSOR [WITH HOLD] FOR <prepared-statement-name>
//   where the name is an identifier produced by a prior PREPARE statement.
declareCursorStmt
    : DECLARE id CURSOR cursorOption* FOR selectStatement SEMI?
    | DECLARE id CURSOR cursorOption* FOR id SEMI
    ;

// DB2 cursor options: WITH HOLD / WITH RETURN [TO CALLER|TO CLIENT] (CALLER/CLIENT are ids)
cursorOption
    : WITH HOLD
    | WITH RETURN (TO id)?
    ;

// DECLARE (CONTINUE|EXIT|UNDO) HANDLER FOR handlerCondList handlerAction
declareHandlerStmt
    : DECLARE (CONTINUE | EXIT | UNDO) HANDLER FOR handlerCondList handlerAction SEMI?
    ;

handlerCondList
    : handlerCond (COMMA handlerCond)*
    ;

handlerCond
    : NOT id       // NOT FOUND
    | SQLEXCEPTION
    | SQLWARNING
    | SQLSTATE VALUE? SQ_STRING
    | id           // condition name
    ;

handlerAction
    : statement
    ;

// CALL [schema.]name(args)
callStatement
    : CALL routineName LPAREN argList? RPAREN SEMI?
    ;

argList
    : expr (COMMA expr)*
    ;

setStatement
    : SET id EQ expr SEMI?
    ;

insertStatement
    : INSERT INTO? tableRef stmtTail SEMI?
    ;

updateStatement
    : UPDATE tableRef stmtTail SEMI?
    ;

deleteStatement
    : DELETE FROM? tableRef stmtTail SEMI?
    ;

// Structured SELECT: optional WITH (CTE), one or more UNIONed cores.
// Enough structure to expose FROM / JOIN / CTE via ANTLR contexts (no text scanning).
selectStatement
    : withClause? selectCore (UNION ALL? selectCore)* SEMI?
    ;

withClause
    : WITH cteDef (COMMA cteDef)*
    ;

cteDef
    : id (LPAREN idList RPAREN)? AS LPAREN selectStatement RPAREN
    ;

idList
    : id (COMMA id)*
    ;

selectCore
    : SELECT (ALL | DISTINCT)? selectList
      intoClause?
      fromClause?
      selectRest
    ;

selectList
    : selectItem (COMMA selectItem)*
    ;

selectItem
    : expr (AS? id)?
    ;

intoClause
    : INTO id (COMMA id)*
    ;

fromClause
    : FROM tableReference (COMMA tableReference)*
    ;

tableReference
    : tableAtom joinClause*
    ;

tableAtom
    : tableRef (AS? id)?                                  # atomTable
    | LPAREN selectStatement RPAREN (AS? id)?             # atomSubquery
    | LPAREN tableReference (COMMA tableReference)* RPAREN # atomParen
    ;

joinClause
    : joinType? JOIN tableAtom (ON expr)?
    ;

joinType
    : INNER
    | LEFT OUTER?
    | RIGHT OUTER?
    | FULL OUTER?
    | CROSS
    ;

// Permissive trailing clauses (WHERE / GROUP BY / HAVING / ORDER BY / fetch-first …).
// Stops at UNION, a nested SELECT, or a statement boundary.
selectRest
    : selectRestToken*
    ;

selectRestToken
    : LPAREN selectStatement RPAREN          // WHERE-clause subquery: IN/EXISTS/= (SELECT … FROM …)
    | LPAREN selectRestToken* RPAREN
    | CASE selectRestToken* END
    | ~(SEMI | BEGIN | END | CASE | UNION | SELECT | DECLARE | CALL | IF | WHILE
        | FOR | LOOP | REPEAT | PREPARE | EXECUTE | OPEN | CLOSE | FETCH | INSERT
        | UPDATE | DELETE | RETURN | SET | CREATE | LPAREN | RPAREN)
    ;

// IF expr THEN body [ELSEIF expr THEN body]* [ELSE body] END IF [;]
ifStatement
    : IF expr THEN body
      (ELSEIF expr THEN body)*
      (ELSE body)?
      END IF SEMI?
    ;

// ─────────────────────────────────────────────────────────────────────────────
// CASE as a STATEMENT.
//
//   CASE WHEN cond THEN stmts; [WHEN ...] [ELSE stmts;] END CASE;
//   CASE expr WHEN val  THEN stmts; [WHEN ...] [ELSE stmts;] END CASE;
//
// This grammar already handled CASE...END as an *expression* (see stmtToken and
// selectRestToken), which is a different thing and did not help here: a statement-level CASE
// matched no alternative, so the enclosing body failed and the WHOLE procedure yielded nothing —
// zero tables, zero operations, no error. Measured, not assumed.
//
// otherStatement could not absorb it either, and deliberately so: it stops at the first SEMI, which
// in a CASE lands *inside* the first THEN branch, leaving a dangling `ELSE ...` that no rule can
// start. ELSE/WHEN are excluded from otherStatement on purpose — letting the catch-all swallow a
// branch would silently drop every statement inside it, which is the same class of loss.
//
// So the branches are parsed as real bodies. DML inside a THEN or ELSE is found, rather than being
// skipped along with the construct that contains it.
// ─────────────────────────────────────────────────────────────────────────────
caseStatement
    : CASE expr? caseWhenClause+ (ELSE body)? END CASE SEMI?
    ;

caseWhenClause
    : WHEN expr THEN body
    ;

// WHILE expr DO body END WHILE [;]
whileStatement
    : WHILE expr DO body END WHILE SEMI?
    ;

// FOR var AS cursor DO body END FOR [;]
// Also: FOR label AS cursor-name CURSOR FOR select DO body END FOR
forStatement
    : FOR id AS selectStatement DO body END FOR SEMI?                              // FOR row AS <select> DO … END FOR
    | FOR id (AS id?)? CURSOR? FOR selectStatement DO body END FOR SEMI?
    ;

loopStatement
    : LOOP body END LOOP SEMI?
    ;

repeatStatement
    : REPEAT body UNTIL expr END REPEAT SEMI?
    ;

// EXECUTE IMMEDIATE must come BEFORE EXECUTE stmt (ANTLR takes first match)
executeImmStmt
    : EXECUTE IMMEDIATE (id | SQ_STRING) SEMI?
    ;

executeStatement
    : EXECUTE id (USING argList)? SEMI?
    ;

prepareStatement
    : PREPARE id FROM (id | SQ_STRING) SEMI?
    ;

openStatement
    : OPEN id SEMI?
    ;

closeStatement
    : CLOSE id SEMI?
    ;

fetchStatement
    : FETCH (NEXT? FROM)? id INTO argList SEMI?
    ;

returnStatement
    : RETURN expr? SEMI?
    ;

beginBlock
    : BEGIN ATOMIC? body END SEMI?
    ;

// Catch-all for unrecognized statements: consume tokens until semicolon or block boundary
otherStatement
    : ~(SEMI | BEGIN | END | DECLARE | CALL | IF | WHILE | FOR | LOOP | REPEAT | PREPARE
        | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE | DELETE | SELECT | RETURN
        | SET | CREATE
        // Block-continuation keywords never START a statement; excluding them keeps the
        // catch-all from swallowing an ELSE/ELSEIF/THEN/… branch of an enclosing IF/CASE/
        // loop (which would drop every CALL/DML inside that branch — see reserve_stock bug).
        | ELSE | ELSEIF | THEN | DO | UNTIL | WHEN)
      (~(SEMI | BEGIN | END))* SEMI?
    | SEMI
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Table reference  (schema.table or just table)
// ─────────────────────────────────────────────────────────────────────────────

tableRef
    : id (DOT id)?
    ;

// ─────────────────────────────────────────────────────────────────────────────
// stmtTail — permissive rule that eats tokens up to next statement boundary.
// Recursively handles balanced parentheses and CASE...END.
// ─────────────────────────────────────────────────────────────────────────────

stmtTail
    : stmtToken*
    ;

stmtToken
    : LPAREN stmtToken* RPAREN
    | CASE stmtToken* END
    | ~(SEMI | BEGIN | END | CASE | DECLARE | CALL | IF | WHILE | FOR | LOOP
        | REPEAT | PREPARE | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE
        | DELETE | SELECT | RETURN | SET | CREATE | LPAREN | RPAREN)
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Expression (simplified — enough to parse conditions and SET rhs)
// ─────────────────────────────────────────────────────────────────────────────

expr
    : exprAtom+
    ;

exprAtom
    : castExpr
    | NEXT VALUE FOR (id DOT)? id             // sequence: NEXT VALUE FOR seq
    | id FOR (id DOT)? id                     // sequence (Oracle-compat): NEXTVAL/PREVVAL FOR seq
    | functionCall
    | LPAREN selectStatement RPAREN          // scalar subquery:  SET v = (SELECT … FROM …)
    | LPAREN expr? RPAREN
    | CASE stmtToken* END
    | literal
    | id (DOT id)*
    | STAR
    | EQ | NEQ | LT | GT | LEQ | GEQ | PLUS | MINUS | SLASH | PERCENT
    | AND | OR | NOT | IN_KW | LIKE | IS | BETWEEN | EXISTS | NULL_KW
    | CURRENT
    | AMPERSAND | PIPE | CARET | TILDE | COLON
    ;

// CAST ( expr AS dataType ) — reuses the shared dataType rule for the target type.
castExpr
    : CAST LPAREN expr AS dataType RPAREN
    ;

// [schema.]name(args) — a function invocation in an expression.
functionCall
    : id (DOT id)? LPAREN functionArgs? RPAREN
    ;

functionArgs
    : STAR
    | expr (COMMA expr)*
    ;

literal
    : SQ_STRING
    | INT_NUM
    | DEC_NUM
    | NULL_KW
    ;
