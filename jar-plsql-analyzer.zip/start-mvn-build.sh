#!/usr/bin/env bash
set -e

# ═══════════════════════════════════════════════════════════════
#  Unified Analyzer — Build with Maven, then Start
#  Validates: Java, Maven, Claude CLI, builds JAR, launches app
#  (Mac/Linux equivalent of start-mvn-build.bat)
# ═══════════════════════════════════════════════════════════════

CONFIG_DIR="${CONFIG_DIR:-config}"
DATA_DIR="${DATA_DIR:-data}"
JAR_FILE="unified-web/target/unified-web-1.0.0-SNAPSHOT.jar"
PORT="${PORT:-8083}"
CLAUDE_OK=0

echo ""
echo "==============================================================="
echo "  UNIFIED ANALYZER — Build & Start"
echo "==============================================================="
echo ""

# ────────────────────────────────────────────────────────────────
# CHECK 1: Java
# ────────────────────────────────────────────────────────────────
echo "[1/4] Checking Java..."
if ! command -v java >/dev/null 2>&1; then
    echo ""
    echo "  ============================================================"
    echo ""
    echo "    JAVA NOT FOUND"
    echo ""
    echo "    Java 17+ is required to build and run."
    echo "    Install Java and add it to your PATH."
    echo ""
    echo "    Download: https://adoptium.net/"
    echo ""
    echo "  ============================================================"
    echo ""
    exit 1
fi
JAVA_VER=$(java -version 2>&1 | head -1 | awk -F'"' '{print $2}')
echo "       Java found: ${JAVA_VER}"

# ────────────────────────────────────────────────────────────────
# CHECK 2: Maven
# ────────────────────────────────────────────────────────────────
echo "[2/4] Checking Maven..."
if ! command -v mvn >/dev/null 2>&1; then
    echo ""
    echo "  ============================================================"
    echo ""
    echo "    MAVEN NOT FOUND"
    echo ""
    echo "    Maven is required to build the project."
    echo "    Install Maven 3.8+ and add it to your PATH."
    echo ""
    echo "    Download: https://maven.apache.org/download.cgi"
    echo ""
    echo "    Or use start.sh if the JAR is already built."
    echo ""
    echo "  ============================================================"
    echo ""
    exit 1
fi
MVN_VER=$(mvn --version 2>&1 | head -1 | awk '{print $3}')
echo "       Maven found: ${MVN_VER}"

# ────────────────────────────────────────────────────────────────
# CHECK 3: Claude CLI (optional — warn if missing)
# ────────────────────────────────────────────────────────────────
echo "[3/4] Checking Claude CLI..."
if ! command -v claude >/dev/null 2>&1; then
    CLAUDE_OK=0
    echo ""
    echo "  ============================================================"
    echo ""
    echo "    WARNING: Claude CLI not found in PATH"
    echo ""
    echo "    The following features will NOT work:"
    echo "      - Claude AI enrichment for JAR analysis"
    echo "      - Claude AI verification for PL/SQL analysis"
    echo "      - AI chatbot conversations"
    echo "      - Claude corrections and insights"
    echo ""
    echo "    Static analysis will work normally."
    echo ""
    echo "    To enable AI features, install Claude CLI:"
    echo "      npm install -g @anthropic-ai/claude-code"
    echo ""
    echo "  ============================================================"
    echo ""
else
    CLAUDE_OK=1
    CLAUDE_VER=$(claude --version 2>&1 | head -1)
    echo "       Claude found: ${CLAUDE_VER}"
fi

# ────────────────────────────────────────────────────────────────
# BUILD: Maven package
# ────────────────────────────────────────────────────────────────
echo "[4/4] Building with Maven..."
echo ""
echo "---------------------------------------------------------------"
echo "  mvn clean package -DskipTests"
echo "---------------------------------------------------------------"
echo ""

# Stop any running instance before rebuilding.
# A Spring Boot fat jar resolves nested classes lazily, so replacing it under a live JVM leaves
# that process unable to load any class it has not already touched — including the logging
# classes it needs to report the failure, so the real error is never printed. Same reasoning as
# start-mvn-build.bat's identical check on Windows.
if pgrep -f "unified-web-1.0.0-SNAPSHOT.jar" >/dev/null 2>&1; then
    echo "  NOTE: a java process running this jar is already active. If it is the analyzer,"
    echo "        stop it before building — rebuilding now would corrupt it rather than update it."
    echo "        Stop it with:  pkill -f unified-web-1.0.0-SNAPSHOT.jar"
    echo ""
    read -r -p "  Continue anyway? [y/N] " REPLY
    case "$REPLY" in
        [yY]*) ;;
        *) exit 1 ;;
    esac
fi

if ! mvn clean package -DskipTests; then
    echo ""
    echo "  ============================================================"
    echo ""
    echo "    BUILD FAILED"
    echo ""
    echo "    Maven build failed. Check the errors above."
    echo ""
    echo "    Common fixes:"
    echo "      - Check Java version (need 17+)"
    echo "      - Check internet for Maven dependencies"
    echo "      - Run: mvn clean package -DskipTests -X"
    echo "        for detailed debug output."
    echo ""
    echo "  ============================================================"
    echo ""
    exit 1
fi

# ── Verify JAR was produced ──
if [ ! -f "$JAR_FILE" ]; then
    echo ""
    echo "  ERROR: Build succeeded but JAR not found at $JAR_FILE"
    echo ""
    exit 1
fi

JAR_SIZE=$(stat -f%z "$JAR_FILE" 2>/dev/null || stat -c%s "$JAR_FILE" 2>/dev/null)
JAR_MB=$(( JAR_SIZE / 1048576 ))
echo ""
echo "  Build successful: $JAR_FILE (${JAR_MB} MB)"
echo ""

# ────────────────────────────────────────────────────────────────
# SETUP: Directories
# ────────────────────────────────────────────────────────────────
mkdir -p "${CONFIG_DIR}/prompts"
mkdir -p "${DATA_DIR}/jar"
mkdir -p "${DATA_DIR}/plsql"
mkdir -p "${DATA_DIR}/plsql-parse"
mkdir -p "${DATA_DIR}/cache-plsql"
mkdir -p "${DATA_DIR}/claude-chatbot"

# ────────────────────────────────────────────────────────────────
# JVM tuning
# ────────────────────────────────────────────────────────────────
JVM_OPTS="-Xms512m -Xmx4g -XX:MaxMetaspaceSize=256m -XX:+UseG1GC -XX:G1HeapRegionSize=4m -XX:+UseStringDeduplication -XX:ParallelGCThreads=4 -XX:ConcGCThreads=2 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${DATA_DIR}/heap-dump.hprof"

# ────────────────────────────────────────────────────────────────
# Application properties
# ────────────────────────────────────────────────────────────────
APP_OPTS="--server.port=${PORT} --app.config-dir=${CONFIG_DIR} --app.data-dir=${DATA_DIR}"

# ────────────────────────────────────────────────────────────────
# LAUNCH
# ────────────────────────────────────────────────────────────────
echo ""
echo "==============================================================="
echo "  UNIFIED ANALYZER — Starting"
echo "==============================================================="
echo ""
echo "  JAR:       $JAR_FILE"
echo "  Port:      $PORT"
echo "  Config:    $CONFIG_DIR"
echo "  Data:      $DATA_DIR"
echo "  Java:      $JAVA_VER"
echo "  Maven:     $MVN_VER"
if [ "$CLAUDE_OK" = "1" ]; then
    echo "  Claude:    $CLAUDE_VER"
else
    echo "  Claude:    NOT AVAILABLE — static analysis only"
fi
echo ""
echo "==============================================================="
echo ""
echo "  Home:      http://localhost:${PORT}/"
echo "  JAR:       http://localhost:${PORT}/jar/"
echo "  Parser:    http://localhost:${PORT}/parser/"
echo "  Manual:    http://localhost:${PORT}/  (User Manual card)"
echo ""
echo "==============================================================="
echo ""

exec java $JVM_OPTS -jar "$JAR_FILE" $APP_OPTS "$@"
