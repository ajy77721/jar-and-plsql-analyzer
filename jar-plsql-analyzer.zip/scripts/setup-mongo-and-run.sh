#!/usr/bin/env bash
set -e

# ═══════════════════════════════════════════════════════════════
# setup-mongo-and-run.sh — Get a local MongoDB ready, then build/start
# the Unified Analyzer against it, extending start-mongo-build.sh's style.
# ═══════════════════════════════════════════════════════════════
#
# SAFE-BY-DEFAULT: this script DEFAULTS TO DRY-RUN. It only checks state
# and prints what it WOULD do (install/start mongo, rebuild jar, launch
# app) unless you pass --apply. This is deliberate: on a machine where
# MongoDB is already installed and already running (as is normal for
# local dev), the script must never surprise you by re-installing,
# restarting, or rebuilding anything that's already fine.
#
#   ./scripts/setup-mongo-and-run.sh                 # dry run (default) — report only, zero changes
#   ./scripts/setup-mongo-and-run.sh --dry-run        # same as above, explicit
#   ./scripts/setup-mongo-and-run.sh --apply          # actually perform any steps found to be needed
#   ./scripts/setup-mongo-and-run.sh --apply --rebuild  # also force a rebuild even if jar looks current
#
# Every step below: (1) checks current state, (2) prints what it found,
# (3) only acts if genuinely needed and --apply was given, else prints
# what it would do. Schema/collection creation is intentionally NOT done
# here — the app's own SchemaInstaller / EntityIngestConfig eager-install
# logic handles that on boot; this script's job stops at "is MongoDB
# itself reachable".

# ── Flags ──
DRY_RUN=true
REBUILD=false
for arg in "$@"; do
    case "$arg" in
        --apply) DRY_RUN=false ;;
        --dry-run) DRY_RUN=true ;;
        --rebuild) REBUILD=true ;;
    esac
done

# ── Paths / config (override via env, same convention as start-mongo-build.sh) ──
CONFIG_DIR="${CONFIG_DIR:-config}"
DATA_DIR="${DATA_DIR:-data}"
JAR_FILE="unified-web/target/unified-web-1.0.0-SNAPSHOT.jar"
PORT="${PORT:-8083}"
MONGO_URI="${MONGO_URI:-mongodb://localhost:27017}"
MONGO_DATABASE="${MONGO_DATABASE:-analyzer}"
MONGO_PORT_DEFAULT=27017

echo "═══════════════════════════════════════════════════════════════"
echo " setup-mongo-and-run.sh — MongoDB + App bootstrap"
if $DRY_RUN; then
    echo " MODE: DRY RUN (default) — no changes will be made. Pass --apply to act."
else
    echo " MODE: APPLY — will perform any steps found to be needed."
fi
echo "═══════════════════════════════════════════════════════════════"
echo ""

would_or_do() {
    # $1 = description, rest = command (as array via "$@")
    local desc="$1"; shift
    if $DRY_RUN; then
        echo "       [DRY RUN] would run: $*"
    else
        echo "       running: $*"
        "$@"
    fi
}

# ── STEP 1: Is MongoDB installed? ──
echo "[1/5] Checking whether MongoDB is installed locally..."
MONGO_INSTALLED=false
if command -v mongod >/dev/null 2>&1; then
    MONGO_INSTALLED=true
    echo "       Found: $(mongod --version 2>&1 | head -1)"
elif command -v brew >/dev/null 2>&1 && brew list mongodb-community >/dev/null 2>&1; then
    MONGO_INSTALLED=true
    echo "       Found via Homebrew: mongodb-community is installed (mongod not on PATH)."
else
    echo "       Not found: no 'mongod' binary and no 'mongodb-community' brew formula installed."
fi

if $MONGO_INSTALLED; then
    echo "       -> Skipping install; MongoDB is already present."
else
    echo "       -> MongoDB is missing."
    if command -v brew >/dev/null 2>&1; then
        would_or_do "install mongodb-community via Homebrew" brew tap mongodb/brew
        would_or_do "install mongodb-community via Homebrew" brew install mongodb-community
    else
        echo "       ERROR: Homebrew not found and this script only automates the macOS/brew path."
        echo "              Install MongoDB manually: https://www.mongodb.com/docs/manual/installation/"
        if ! $DRY_RUN; then exit 1; fi
    fi
fi
echo ""

# ── STEP 2: Is mongod currently running / reachable? ──
echo "[2/5] Checking whether mongod is currently running..."
MONGO_RUNNING=false

MONGO_HOSTPORT=$(echo "$MONGO_URI" | sed -E 's#^mongodb://##; s#^.*@##; s#/.*$##; s#,.*$##')
MONGO_HOST=$(echo "$MONGO_HOSTPORT" | cut -d: -f1)
MONGO_PORT=$(echo "$MONGO_HOSTPORT" | cut -d: -f2)
MONGO_PORT=${MONGO_PORT:-$MONGO_PORT_DEFAULT}
MONGO_HOST=${MONGO_HOST:-localhost}

if command -v mongosh >/dev/null 2>&1; then
    if mongosh "$MONGO_URI" --eval "db.adminCommand('ping')" --quiet >/dev/null 2>&1; then
        MONGO_RUNNING=true
        echo "       'mongosh ping' succeeded against ${MONGO_HOST}:${MONGO_PORT}."
    fi
fi

if ! $MONGO_RUNNING && command -v nc >/dev/null 2>&1; then
    if nc -z -w2 "$MONGO_HOST" "$MONGO_PORT" 2>/dev/null; then
        MONGO_RUNNING=true
        echo "       Port ${MONGO_HOST}:${MONGO_PORT} is open (TCP check)."
    fi
fi

if ! $MONGO_RUNNING && command -v brew >/dev/null 2>&1; then
    if brew services list 2>/dev/null | grep -q "^mongodb-community.*started"; then
        MONGO_RUNNING=true
        echo "       'brew services list' reports mongodb-community as started."
    fi
fi

if $MONGO_RUNNING; then
    echo "       -> MongoDB is already running. Skipping start."
else
    echo "       -> MongoDB does not appear to be running."
    if command -v brew >/dev/null 2>&1; then
        would_or_do "start mongodb-community as a background service" brew services start mongodb-community
    else
        echo "       ERROR: no brew available to start mongod automatically."
        if ! $DRY_RUN; then exit 1; fi
    fi
fi
echo ""

# ── STEP 3: Confirm reachability; schema is the app's own job ──
echo "[3/5] Confirming MongoDB is reachable at ${MONGO_URI} (schema creation is NOT done here)..."
REACHABLE=false
if command -v nc >/dev/null 2>&1 && nc -z -w2 "$MONGO_HOST" "$MONGO_PORT" 2>/dev/null; then
    REACHABLE=true
fi
if $REACHABLE; then
    echo "       Reachable: ${MONGO_HOST}:${MONGO_PORT}."
    echo "       Database/collection setup is handled by the app itself on boot"
    echo "       (SchemaInstaller / EntityIngestConfig eager-schema-install) — nothing to do here."
else
    if $DRY_RUN; then
        echo "       [DRY RUN] Cannot confirm reachability yet (mongod not confirmed running above)."
        echo "                 Once steps 1-2 are applied for real, this check should pass."
    else
        echo "       ERROR: MongoDB still not reachable at ${MONGO_HOST}:${MONGO_PORT} after setup steps."
        exit 1
    fi
fi
echo ""

# ── STEP 4: Build (only if jar missing/stale or --rebuild) ──
echo "[4/5] Checking whether a build is needed..."
NEED_BUILD=false
if $REBUILD; then
    NEED_BUILD=true
    echo "       --rebuild passed: forcing a rebuild."
elif [ ! -f "$JAR_FILE" ]; then
    NEED_BUILD=true
    echo "       Jar not found at $JAR_FILE."
else
    # Compare jar mtime against newest source file (matches this repo's
    # "don't rebuild unnecessarily" discipline).
    NEWEST_SRC=$(find . -path ./target -prune -o -path '*/target' -prune -o \
        \( -name "*.java" -o -name "pom.xml" \) -newer "$JAR_FILE" -print 2>/dev/null | head -1 || true)
    if [ -n "$NEWEST_SRC" ]; then
        NEED_BUILD=true
        echo "       Source newer than jar detected (e.g. $NEWEST_SRC)."
    else
        echo "       Jar exists at $JAR_FILE and is newer than all sources."
    fi
fi

if $NEED_BUILD; then
    echo "       -> Build needed."
    would_or_do "build the project" mvn -pl unified-web -am package -DskipTests -q
else
    echo "       -> Skipping build; jar is up to date."
fi
echo ""

# ── STEP 5: Start the app (same JVM args pattern as start-mongo-build.sh) ──
echo "[5/5] Starting the app against local MongoDB..."
if [ ! -f "$JAR_FILE" ] && $DRY_RUN; then
    echo "       [DRY RUN] Jar does not exist yet (would have been built above in --apply mode)."
fi

mkdir_cmd_note() {
    echo "       [DRY RUN] would ensure directories exist: ${CONFIG_DIR}/prompts, ${DATA_DIR}/claude-chatbot"
}

if $DRY_RUN; then
    mkdir_cmd_note
else
    mkdir -p "${CONFIG_DIR}/prompts"
    mkdir -p "${DATA_DIR}/claude-chatbot"
fi

JVM_OPTS="-Xms512m -Xmx8g -XX:MaxMetaspaceSize=512m -XX:+UseG1GC -XX:G1HeapRegionSize=4m -XX:+UseStringDeduplication -XX:ParallelGCThreads=4 -XX:ConcGCThreads=2 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${DATA_DIR}/heap-dump.hprof"

APP_OPTS="--server.port=${PORT} --app.config-dir=${CONFIG_DIR} --app.data-dir=${DATA_DIR}"
APP_OPTS="${APP_OPTS} --app.storage.mode=mongodb"
APP_OPTS="${APP_OPTS} --app.storage.mongodb.uri=${MONGO_URI}"
APP_OPTS="${APP_OPTS} --app.storage.mongodb.database=${MONGO_DATABASE}"
APP_OPTS="${APP_OPTS} --app.storage.entity-ingest.enabled=true"
APP_OPTS="${APP_OPTS} --app.storage.entity-read.enabled=true"

echo ""
echo "       JAR:      $JAR_FILE"
echo "       Port:     $PORT"
echo "       Mongo:    $MONGO_URI / $MONGO_DATABASE"
echo "       JVM:      $JVM_OPTS"
echo ""

if $DRY_RUN; then
    echo "       [DRY RUN] would run: java \$JVM_OPTS -jar \"$JAR_FILE\" \$APP_OPTS"
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo " Dry run complete — no changes were made. Re-run with --apply to execute."
    echo "═══════════════════════════════════════════════════════════════"
else
    RUNNING_PID=$(lsof -ti:"$PORT" 2>/dev/null || true)
    if [ -n "$RUNNING_PID" ]; then
        echo "NOTE: a process is already listening on port ${PORT} (pid ${RUNNING_PID})."
        echo "      This script will not kill it automatically. Stop it manually first,"
        echo "      or choose a different PORT, then re-run."
        exit 1
    fi
    exec java $JVM_OPTS -jar "$JAR_FILE" $APP_OPTS "$@"
fi
