#!/usr/bin/env python3
"""
Full clean-up: wipes all analysis output (JAR + PL/SQL) and starts fresh.

Deletes, then recreates empty:
    data/cache
    data/jar
    data/logs
    data/plsql
    data/plsql-parse
    data/claude-chatbot

Deliberately NOT touched — these are configuration, not analysis output, and
deleting them would break the app's ability to even reconnect to the 5 demo
databases afterward:
    data/config      (plsql-config.yaml, domain-config.json, connection creds)
    data/prompts     (14 seeded Claude prompt templates)

Also drops the MongoDB "analyzer" database entirely (all am_* entity
collections, am_run version history, artifact blobs/GridFS) — it is
recreated automatically, empty, the next time the app writes to it.

Usage:
    python3 scripts/full_cleanup.py            # interactive confirm
    python3 scripts/full_cleanup.py --yes      # no prompt (e.g. from CI/automation)
    python3 scripts/full_cleanup.py --dry-run  # show what would happen, change nothing

The app must be stopped first (this script does NOT do that for you, since
which port/JVM args it was launched with is the caller's business) — deleting
files an already-running MongoDB-mode app has open handles to is harmless (it
doesn't read from local disk in that mode), but deleting jar/plsql-parse out
from under a still-running LOCAL/S3-mode app could surprise a concurrent read.
"""
import argparse
import shutil
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = REPO_ROOT / "data"

WIPE_DIRS = ["cache", "jar", "logs", "plsql", "plsql-parse", "claude-chatbot"]
KEEP_DIRS = ["config", "prompts"]

MONGO_URI = "mongodb://localhost:27017"
MONGO_DB = "analyzer"


def wipe_data_dirs(dry_run: bool) -> None:
    print(f"\n== Local disk: {DATA_DIR} ==")
    for name in WIPE_DIRS:
        target = DATA_DIR / name
        if target.exists():
            size = sum(f.stat().st_size for f in target.rglob("*") if f.is_file())
            print(f"  delete {target}  ({size / 1024:.0f} KB)")
            if not dry_run:
                shutil.rmtree(target)
        else:
            print(f"  (missing, skip) {target}")
        if not dry_run:
            target.mkdir(parents=True, exist_ok=True)
    for name in KEEP_DIRS:
        print(f"  KEEP   {DATA_DIR / name}")


def drop_mongo(dry_run: bool) -> None:
    print(f"\n== MongoDB: {MONGO_URI}/{MONGO_DB} ==")
    try:
        import pymongo
    except ImportError:
        print("  pymongo not installed — skipping Mongo drop.")
        print(f"  Run manually instead: mongosh {MONGO_URI}/{MONGO_DB} --eval 'db.dropDatabase()'")
        return

    client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    try:
        client.admin.command("ping")
    except Exception as e:
        print(f"  Could not reach MongoDB at {MONGO_URI}: {e}")
        print("  Skipping Mongo drop — is `mongod` running?")
        return

    names = client.list_database_names()
    if MONGO_DB not in names:
        print(f"  Database '{MONGO_DB}' does not exist — nothing to drop.")
        return

    coll_count = len(client[MONGO_DB].list_collection_names())
    print(f"  drop database '{MONGO_DB}' ({coll_count} collections)")
    if not dry_run:
        client.drop_database(MONGO_DB)
        print("  dropped. It will be recreated empty on the app's next write.")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--yes", action="store_true", help="skip the interactive confirmation")
    ap.add_argument("--dry-run", action="store_true", help="show what would be deleted, change nothing")
    args = ap.parse_args()

    print("This will PERMANENTLY delete all JAR + PL/SQL analysis output")
    print(f"({', '.join(WIPE_DIRS)} under {DATA_DIR}) and drop the entire")
    print(f"MongoDB '{MONGO_DB}' database. Config/connections/prompts are preserved.")

    if args.dry_run:
        print("\n[DRY RUN — nothing will actually be deleted]")
    elif not args.yes:
        reply = input("\nType 'yes' to proceed: ").strip().lower()
        if reply != "yes":
            print("Aborted.")
            return 1

    wipe_data_dirs(args.dry_run)
    drop_mongo(args.dry_run)

    print("\nDone." if not args.dry_run else "\nDry run complete — nothing changed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
