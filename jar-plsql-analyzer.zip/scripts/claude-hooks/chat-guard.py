#!/usr/bin/env python3
"""
chat-guard.py — the actual protection layer for the in-app Claude chatbot.

Why this exists: `--allowedTools` on the Claude CLI only says WHICH tools may be called
(Read/Write/Bash/...) — it says nothing about WHAT a Bash command or a Write's file content
actually does. Granting "Bash" at all means, by itself, the assistant can run `rm -rf`, `kill`,
`DROP TABLE`, overwrite real app files, etc. This is a Claude Code "PreToolUse" hook: the CLI runs
it before every tool call and pipes a JSON description of that call to this script's stdin. Exit
code 2 means "deny" (Claude sees the stderr text as the reason and does not run the tool); exit
code 0 means "allow".

Scope of what this blocks (deny-list, not allow-list — the assistant should still be able to read,
write ANALYSIS scripts, and run them):
  - Any Bash command containing a destructive verb/pattern (rm, kill/pkill, DROP/DELETE/TRUNCATE/
    UPDATE SQL, git push --force, chmod 777, sudo, mkfs, dd, shutdown/reboot, systemctl stop, etc.)
  - Any Write/Edit whose new file CONTENT contains the same destructive patterns (e.g. a generated
    Python script that calls os.remove/shutil.rmtree/subprocess(['rm',...])/pymongo delete_many) —
    this is the part `--allowedTools` alone can never catch, since the dangerous code only exists
    inside a file the assistant is about to create, not in the tool call itself.
  - When a Bash command runs a script file the assistant already wrote (`python3 foo.py`, `sh
    foo.sh`, ...), this hook also reads THAT file's on-disk content (if it exists yet) and re-scans
    it — catching a script that was written in a separate turn (already passed the Write-time
    check honestly, or was edited afterward) before it gets executed.

This is a deny-list, so it is not a perfect sandbox against a truly adversarial actor with shell
access — but the assistant only ever proposes commands via the CLI's own tool-call protocol, not
raw untraced shell, so a deny-list here is the actual, complete mediation point for everything it
can do. Combined with the dedicated sandbox working directory (data/claude-chatbot-workspace, set
up in ChatConfig.java / ClaudeProcessRunner), a blocked destructive command also has nothing
outside that sandbox to reach even if this list ever misses a pattern.
"""
import json
import re
import sys
import os

# Applied to: the raw Bash command string, Write/Edit new content, and any script file a Bash
# command references. Case-insensitive. Deliberately broad — a false-positive block (a legitimate
# read-only command that happens to contain one of these words) is a minor annoyance the user can
# rephrase around; a false negative is data loss.
DENY_PATTERNS = [
    # Filesystem destruction
    r'\brm\s+-[a-zA-Z]*r[a-zA-Z]*f\b',      # rm -rf, rm -fr, rm -Rf, ...
    r'\brm\s+-[a-zA-Z]*f[a-zA-Z]*r\b',
    r'\brm\s+-r\b', r'\brm\s+-f\b',
    r'\bshutil\.rmtree\b',
    r'\bos\.remove\b', r'\bos\.unlink\b',
    r'\.unlink\s*\(',                        # pathlib Path.unlink()
    r'\btruncate\s*\(',
    r'>\s*/dev/(sd|nvme|disk)',              # writing over a raw block device
    r'\bmkfs\b', r'\bdd\s+if=',

    # Process / system control
    r'\bkill\s+-?\d*\s*-?\d', r'\bkillall\b', r'\bpkill\b',
    r'\bshutdown\b', r'\breboot\b', r'\bhalt\b',
    r'\bsystemctl\s+(stop|disable|kill)\b',
    r'\bsudo\b',
    r'\bchmod\s+777\b', r'\bchmod\s+-R\s+777\b',
    r'\bchown\s+-R\b',

    # Version control destruction
    r'\bgit\s+push\s+.*--force\b', r'\bgit\s+push\s+.*-f\b',
    r'\bgit\s+reset\s+--hard\b',
    r'\bgit\s+clean\s+-[a-zA-Z]*f',
    r'\bgit\s+branch\s+-D\b',

    # SQL / database destruction (both raw SQL text and common driver method names)
    r'\bDROP\s+(TABLE|DATABASE|COLLECTION|INDEX|SCHEMA)\b',
    r'\bDELETE\s+FROM\b',
    r'\bTRUNCATE\s+(TABLE)?\b',
    r'\bUPDATE\s+\S+\s+SET\b',
    r'\.drop\s*\(', r'\.dropDatabase\s*\(', r'\.dropCollection\s*\(',
    r'\.delete_one\s*\(', r'\.delete_many\s*\(', r'\.deleteOne\s*\(', r'\.deleteMany\s*\(',
    r'\.remove\s*\(\s*\{', r'\.findOneAndDelete\s*\(',
    r'\.update_one\s*\(', r'\.update_many\s*\(', r'\.updateOne\s*\(', r'\.updateMany\s*\(',
    r'\breplace_one\s*\(', r'\.replaceOne\s*\(',

    # Overwriting/deleting the app's own source or config, regardless of verb used
    r'>\s*[\'"]?/?(unified-web|plsql-parser|jar-analyzer-core)/src/',
]

_COMPILED = [re.compile(p, re.IGNORECASE) for p in DENY_PATTERNS]

# When a Bash command's first real token looks like an interpreter invoking a script file, pull
# out that file path so its ON-DISK content can be scanned too (see module docstring).
_SCRIPT_RUN = re.compile(
    r'\b(?:python3?|sh|bash|node|ruby|perl)\s+([^\s;&|>]+\.(?:py|sh|js|rb|pl))\b',
    re.IGNORECASE,
)


def _violations(text):
    if not text:
        return []
    return [p.pattern for p in _COMPILED if p.search(text)]


def _scan_referenced_script(command, cwd):
    m = _SCRIPT_RUN.search(command or '')
    if not m:
        return []
    path = m.group(1)
    if not os.path.isabs(path) and cwd:
        path = os.path.join(cwd, path)
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return _violations(f.read())
    except OSError:
        return []  # file doesn't exist yet / not readable — nothing to scan


def _is_outside_sandbox(path, sandbox_root):
    """True if `path`, once resolved, is NOT inside sandbox_root. This is the actual filesystem
    jail: everything before this was a deny-list on WHAT a command does; this is a deny-list on
    WHERE it may look at all, closing the gap a deny-list alone can't — confirmed live: the
    assistant successfully Read an absolute path to the app's real DB-credentials config file
    (data/config/plsql-config.yaml, containing plaintext passwords) purely because nothing ever
    checked the path itself was inside the sandbox — the working directory was only ever a
    convention the model happened to follow for writes, never an enforced boundary for reads."""
    if not path:
        return False
    try:
        resolved = os.path.realpath(os.path.join(sandbox_root, path) if not os.path.isabs(path) else path)
        root = os.path.realpath(sandbox_root)
        return os.path.commonpath([resolved, root]) != root
    except (ValueError, OSError):
        return True  # different drive / unresolvable path — treat as escaping, not as safe


# Splits a Bash command into whitespace-separated tokens (respecting simple quoting), same as a
# shell would, so a WHOLE token can be checked — matching "/" anywhere inside a string (the first
# version of this check) falsely flagged a purely relative, in-sandbox path like
# "output/my_script.py" merely because it contains a "/" partway through, not at the start.
_TOKEN_SPLIT = re.compile(r'''[^\s"']+|"[^"]*"|'[^']*\'''')


def _bash_paths_outside_sandbox(command, sandbox_root):
    """Bash can read/write arbitrary files just as easily as the Read/Write tools can (cat, less,
    head, cp, scp, python -c "open(...)", a heredoc target, output redirection, ...) — so the same
    sandbox-containment check has to apply to any path-SHAPED whole token on the command line, not
    only to those tools' own structured file_path argument. A token only counts as path-shaped if
    it starts with "/" (absolute) or contains "../" (escapes upward) — a bare relative token like
    "output/my_script.py" is neither and is left alone; it's already anchored under the sandbox by
    construction, and _is_outside_sandbox would just re-confirm that harmlessly if checked anyway,
    but skipping it here keeps this function's job to "find candidates to check", nothing more.
    """
    hits = []
    for raw in _TOKEN_SPLIT.findall(command or ''):
        token = raw.strip('\'"')
        if token.startswith('/') or '../' in token:
            if _is_outside_sandbox(token, sandbox_root):
                hits.append(token)
    return hits


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        # Malformed hook input — fail OPEN on parsing (not a security decision) but log why, since
        # silently blocking every tool call on a hook bug would just look like the chatbot is dead.
        sys.exit(0)

    tool_name = payload.get('tool_name', '')
    tool_input = payload.get('tool_input') or {}
    cwd = payload.get('cwd') or os.getcwd()

    hits = []
    escapes = []

    if tool_name == 'Bash':
        command = tool_input.get('command', '')
        hits += _violations(command)
        hits += _scan_referenced_script(command, cwd)
        escapes += _bash_paths_outside_sandbox(command, cwd)
    elif tool_name in ('Write', 'Edit', 'NotebookEdit'):
        content = tool_input.get('content') or tool_input.get('new_string') or ''
        hits += _violations(content)
        path = tool_input.get('file_path') or tool_input.get('path')
        if path and _is_outside_sandbox(path, cwd):
            escapes.append(path)
    elif tool_name in ('Read', 'Glob', 'Grep'):
        path = tool_input.get('file_path') or tool_input.get('path') or ''
        if path and _is_outside_sandbox(path, cwd):
            escapes.append(path)

    if escapes:
        sys.stderr.write(
            'Blocked by chat-guard.py: this action reaches OUTSIDE the chatbot\'s sandboxed '
            'working directory (' + escapes[0] + '). The assistant can only read/write/run things '
            'inside its own workspace — real app config, credentials, and source files are not '
            'reachable, by design, no matter how the request is phrased.\n'
        )
        sys.exit(2)

    if hits:
        sys.stderr.write(
            'Blocked by chat-guard.py: this action matched a destructive-operation pattern and is '
            'not permitted for the chatbot (' + ', '.join(hits[:3]) + '). '
            'Read/list/analyze/export operations are fine — rephrase without delete/kill/drop/'
            'update/force-push style commands.\n'
        )
        sys.exit(2)

    sys.exit(0)


if __name__ == '__main__':
    main()
