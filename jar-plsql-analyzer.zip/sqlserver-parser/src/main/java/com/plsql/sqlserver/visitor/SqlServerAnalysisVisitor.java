package com.plsql.sqlserver.visitor;

import com.plsql.sqlserver.grammar.SqlServerParser;
import com.plsql.sqlserver.grammar.SqlServerParserBaseVisitor;
import com.plsql.sqlserver.model.*;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.misc.Interval;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ANTLR4 visitor over the SqlServerParser parse tree.
 *
 * Extracts:
 *   visitRoutineDefinition  → routine identity (name, schema, type, line range)
 *   visitParam              → parameter list
 *   visitDeclareStatement   → DECLARE @variable
 *   visitSetStatement       → SET @var = ... (dynamic SQL detection)
 *   visitExecStatement      → EXEC / EXECUTE outbound calls + sp_executesql detection
 *   visitInsertStatement    → INSERT table op
 *   visitUpdateStatement    → UPDATE table op
 *   visitDeleteStatement    → DELETE table op
 *   visitSelectStatement    → SELECT table op (scans stmtTail for FROM clause)
 */
public class SqlServerAnalysisVisitor extends SqlServerParserBaseVisitor<Void> {

    private static final Pattern FROM_PATTERN = Pattern.compile(
            "(?i)\\bFROM\\s+\\[?([\\w#$]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?");

    // Captures every table referenced in a FROM or JOIN clause (join parity).
    private static final Pattern TABLE_REF_PATTERN = Pattern.compile(
            "(?i)\\b(?:FROM|JOIN)\\s+\\[?([\\w#$@]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?");

    // Schema-qualified function/proc call:  schema.name(   →  proc→function / →TVF edges.
    // Built-ins (SUM, COUNT, ISNULL, CAST…) are unqualified, so they are naturally excluded.
    private static final Pattern QUALIFIED_CALL_PATTERN = Pattern.compile(
            "\\b([\\w#$]+)\\.([\\w#$]+)\\s*\\(");

    // Schema-qualified table in FROM/JOIN/MERGE/INTO/UPDATE — used to recover tables from
    // statements consumed by the generic otherStatement rule (WITH-CTEs, MERGE, …).
    // Qualified-only so CTE aliases / pseudo-tables (inserted, deleted, cte names) are skipped.
    private static final Pattern QUALIFIED_TABLE_PATTERN = Pattern.compile(
            "(?i)\\b(?:FROM|JOIN|MERGE|INTO|UPDATE)\\s+\\[?([\\w#$]+)\\]?\\.\\[?([\\w#$]+)\\]?");

    // JOIN clause:  <type> JOIN|APPLY schema.table [AS] alias  [ON <condition>]
    private static final Pattern JOIN_PATTERN = Pattern.compile(
            "(?i)\\b(INNER|LEFT\\s+OUTER|LEFT|RIGHT\\s+OUTER|RIGHT|FULL\\s+OUTER|FULL|CROSS|OUTER)\\s+(JOIN|APPLY)\\s+"
          + "\\[?([\\w#$]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?"          // schema.table
          + "(?:\\s+(?:AS\\s+)?([A-Za-z]\\w*))?"                    // optional alias
          + "(?:\\s+ON\\s+(.{0,200}?))?"                            // optional ON condition (bounded to avoid backtracking)
          + "(?=\\s+(?:INNER|LEFT|RIGHT|FULL|CROSS|OUTER|WHERE|GROUP|ORDER|HAVING|UNION|;|\\)|$))");

    // NEXT VALUE FOR schema.seq  →  sequence usage
    private static final Pattern SEQ_PATTERN = Pattern.compile(
            "(?i)\\bNEXT\\s+VALUE\\s+FOR\\s+\\[?([\\w#$]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?");

    // CREATE TABLE [schema.]name ( ... )  →  used to locate a table's column-def body so
    // IDENTITY columns (audit #8) can be scanned within it, scoped to the right table.
    private static final Pattern CREATE_TABLE_PATTERN = Pattern.compile(
            "(?i)\\bCREATE\\s+TABLE\\s+\\[?([\\w#$@]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?\\s*\\(");

    // A column definition ending in IDENTITY[(seed, increment)], e.g. "Id INT IDENTITY(1,1)".
    // Bare IDENTITY (no parens) defaults to seed=1, increment=1 per SQL Server semantics.
    private static final Pattern IDENTITY_PATTERN = Pattern.compile(
            "(?i)\\[?([A-Za-z_]\\w*)\\]?\\s+[A-Za-z_]+\\w*(?:\\s*\\([^)]*\\))?\\s+IDENTITY\\s*"
          + "(?:\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\))?");

    // Any DDL/DML keyword that precedes a table name → operation type. Multi-word
    // alternatives come first so "CREATE TABLE" wins over "CREATE", etc.
    private static final Pattern KEYWORD_OP_PATTERN = Pattern.compile(
            "(?i)\\b(CREATE\\s+TABLE|ALTER\\s+TABLE|DROP\\s+TABLE|TRUNCATE\\s+TABLE|MERGE\\s+INTO|MERGE|"
          + "INSERT\\s+INTO|DELETE\\s+FROM|UPDATE|FROM|JOIN|INTO)\\s+"
          + "\\[?([\\w#$]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?");

    // CTE name definition:  WITH x AS (   or   ), y AS (
    private static final Pattern CTE_PATTERN = Pattern.compile(
            "(?i)(?:\\bWITH|,)\\s+([A-Za-z_]\\w*)\\s+AS\\s*\\(");

    // CASE expression (simple or searched) — the grammar consumes CASE...END inside
    // stmtTail as tokens, so there is no dedicated context; recover each from body text.
    private static final Pattern CASE_PATTERN = Pattern.compile("(?i)\\bCASE\\b");

    // Nested SELECT (subquery) in an expression / FROM / WHERE / IN — a parenthesised
    // SELECT. One match == one subquery.
    private static final Pattern SUBQUERY_PATTERN = Pattern.compile("(?i)\\(\\s*SELECT\\b");

    // De-dupe outbound calls (name keyed) so the same target isn't emitted repeatedly.
    private final Set<String> seenCalls = new HashSet<>();
    // De-dupe table ops (schema.name keyed).
    private final Set<String> seenTables = new HashSet<>();
    // Common-table-expression names — excluded from table extraction (they are not real tables).
    private final Set<String> cteNames = new HashSet<>();

    private final SqlServerRoutineInfo result;

    public SqlServerAnalysisVisitor(String objectName, String schema) {
        this.result = new SqlServerRoutineInfo();
        result.setName(objectName);
        result.setSchema(schema);
        result.setType(SqlServerRoutineInfo.RoutineType.PROCEDURE);
    }

    public SqlServerRoutineInfo getResult() {
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Routine identity
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitRoutineDefinition(SqlServerParser.RoutineDefinitionContext ctx) {
        // Routine type
        String kw = ctx.routineKw().getText().toUpperCase();
        result.setType(kw.startsWith("FUNC")
                ? SqlServerRoutineInfo.RoutineType.FUNCTION
                : SqlServerRoutineInfo.RoutineType.PROCEDURE);

        // Routine name: routineName is (namePart (DOT namePart)?)
        SqlServerParser.RoutineNameContext rn = ctx.routineName();
        List<SqlServerParser.NamePartContext> parts = rn.namePart();
        if (parts.size() == 2) {
            // schema.name
            result.setSchema(stripBrackets(parts.get(0).getText()));
            result.setName(stripBrackets(parts.get(1).getText()));
        } else if (parts.size() == 1) {
            result.setName(stripBrackets(parts.get(0).getText()));
        }

        // Line range
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null
                ? ctx.getStop().getLine()
                : ctx.getStart().getLine());

        collectCteNames(ctx.routineBody());
        Void r = visitChildren(ctx);
        extractQualifiedCalls(ctx.routineBody());
        extractSequences(ctx.routineBody());   // proc→function / function→function / →TVF
        extractCaseAndSubqueries(ctx.routineBody());
        return r;
    }

    @Override
    public Void visitTriggerDefinition(SqlServerParser.TriggerDefinitionContext ctx) {
        result.setType(SqlServerRoutineInfo.RoutineType.TRIGGER);
        applyRoutineName(ctx.routineName());
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null ? ctx.getStop().getLine() : ctx.getStart().getLine());
        // Parse the trigger header: ON <table> (AFTER|FOR|INSTEAD OF) <events>
        String header = originalText(ctx.triggerHeader());
        if (header != null) {
            Matcher t = Pattern.compile("(?i)\\bON\\s+\\[?([\\w#$]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?").matcher(header);
            if (t.find()) result.setTriggerTable(t.group(2) != null ? t.group(2) : t.group(1));
            Matcher tm = Pattern.compile("(?i)\\b(INSTEAD\\s+OF|AFTER|BEFORE|FOR)\\b").matcher(header);
            if (tm.find()) result.setTriggerTiming(tm.group(1).replaceAll("\\s+", " ").toUpperCase());
            Matcher ev = Pattern.compile("(?i)\\b(INSERT|UPDATE|DELETE)\\b").matcher(header);
            StringBuilder events = new StringBuilder();
            while (ev.find()) { if (events.length() > 0) events.append(","); events.append(ev.group(1).toUpperCase()); }
            if (events.length() > 0) result.setTriggerEvent(events.toString());
        }
        collectCteNames(ctx.routineBody());
        Void r = visitChildren(ctx);   // walk body → DML table ops, calls, dynamic SQL
        extractQualifiedCalls(ctx.routineBody());
        extractSequences(ctx.routineBody());
        extractCaseAndSubqueries(ctx.routineBody());
        return r;
    }

    @Override
    public Void visitViewDefinition(SqlServerParser.ViewDefinitionContext ctx) {
        result.setType(SqlServerRoutineInfo.RoutineType.VIEW);
        applyRoutineName(ctx.routineName());
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null ? ctx.getStop().getLine() : ctx.getStart().getLine());
        result.setViewQuery(originalText(ctx.routineBody()));   // the defining SELECT
        collectCteNames(ctx.routineBody());
        Void r = visitChildren(ctx);   // walk SELECT body → source tables
        extractQualifiedCalls(ctx.routineBody());
        extractSequences(ctx.routineBody());
        extractCaseAndSubqueries(ctx.routineBody());
        return r;
    }

    /**
     * Recover CASE expressions and nested SELECT subqueries from the routine body text.
     * The grammar consumes both inside stmtTail as raw tokens (no dedicated context),
     * so they are scanned once over the whole body — same approach used for sequences
     * and qualified calls. Each match is added to the shared statement inventory using
     * the common vocabulary tokens "CASE" / "SUBQUERY" so all dialects report uniformly.
     */
    private void extractCaseAndSubqueries(ParserRuleContext bodyCtx) {
        if (bodyCtx == null) return;
        String text = originalText(bodyCtx);
        if (text == null || text.isEmpty()) return;
        int baseLine = bodyCtx.getStart().getLine();

        Matcher c = CASE_PATTERN.matcher(text);
        while (c.find()) {
            result.getStatements().add(
                    new SqlServerStatementInfo("CASE", lineAt(text, c.start(), baseLine)));
        }
        Matcher s = SUBQUERY_PATTERN.matcher(text);
        while (s.find()) {
            result.getStatements().add(
                    new SqlServerStatementInfo("SUBQUERY", lineAt(text, s.start(), baseLine)));
        }
    }

    private void applyRoutineName(SqlServerParser.RoutineNameContext rn) {
        if (rn == null) return;
        List<SqlServerParser.NamePartContext> parts = rn.namePart();
        if (parts.size() == 2) {
            result.setSchema(stripBrackets(parts.get(0).getText()));
            result.setName(stripBrackets(parts.get(1).getText()));
        } else if (parts.size() == 1) {
            result.setName(stripBrackets(parts.get(0).getText()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Parameters
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitParam(SqlServerParser.ParamContext ctx) {
        SqlServerParamInfo p = new SqlServerParamInfo();
        p.setName(ctx.AT_VAR().getText());
        p.setDataType(ctx.dataType().getText());
        boolean isOutput = false;
        for (SqlServerParser.ParamModifierContext mod : ctx.paramModifier()) {
            if (mod.OUTPUT() != null || mod.OUT() != null) { isOutput = true; break; }
        }
        p.setDirection(isOutput
                ? SqlServerParamInfo.Direction.OUT
                : SqlServerParamInfo.Direction.IN);
        p.setLine(ctx.getStart().getLine());
        result.getParams().add(p);
        return null; // don't recurse — no nested params
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE @variable
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareStatement(SqlServerParser.DeclareStatementContext ctx) {
        // DECLARE @a INT, @b DECIMAL(18,2) ... — one variable per declareItem.
        for (SqlServerParser.DeclareItemContext item : ctx.declareItem()) {
            SqlServerVariableInfo v = new SqlServerVariableInfo();
            v.setName(item.AT_VAR().getText());
            v.setDataType(item.dataType() != null ? item.dataType().getText() : null);
            v.setLine(item.getStart().getLine());
            result.getVariables().add(v);

            // DECLARE @sql ... = N'...SELECT...FROM...' — dynamic SQL built in an initializer.
            if (item.expr() != null) {
                String et = item.expr().getText();
                if (et.startsWith("'") || et.startsWith("N'") || et.startsWith("n'")) {
                    int line = item.getStart().getLine();
                    String orig = originalText(item.expr());
                    SqlServerDynamicSqlInfo d = new SqlServerDynamicSqlInfo();
                    d.setKind(SqlServerDynamicSqlInfo.Kind.SET_SQL);
                    d.setSqlSource(orig);
                    d.setLine(line);
                    result.getDynamicSql().add(d);
                    addTableOpsFromText(orig, line);
                    attachJoins(orig, line);
                }
            }
        }
        // Cursor form: DECLARE <name> CURSOR ... FOR <select>
        if (ctx.declareItem().isEmpty() && ctx.ID() != null) {
            String tail = originalText(ctx.stmtTail());
            if (tail != null && tail.toUpperCase().contains("CURSOR")) {
                SqlServerCursorInfo cur = new SqlServerCursorInfo();
                cur.setName(ctx.ID().getText());
                cur.setQuery(tail.trim());
                cur.setLine(ctx.getStart().getLine());
                // DECLARE itself is not added to stmtOperations: the downstream reader
                // (NodeScanFacetReader) already synthesizes a base "DECLARE" operation for every
                // cursor from its declaration; stmtOperations carries only the post-DECLARE
                // lifecycle (OPEN/FETCH/CLOSE/DEALLOCATE), matching the Postgres dialect's convention.
                result.getCursors().add(cur);
            }
        }
        return null; // no nested declares
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Statement inventory (drives the statement summary) + TRY/CATCH handlers
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitStatement(SqlServerParser.StatementContext ctx) {
        if (ctx.getChildCount() > 0) {
            org.antlr.v4.runtime.tree.ParseTree c0 = ctx.getChild(0);
            if (c0 instanceof SqlServerParser.TransactionStatementContext) {
                addTransactionStatement((SqlServerParser.TransactionStatementContext) c0);
            } else {
                String type = statementType(c0);
                if (type != null) {
                    result.getStatements().add(
                            new SqlServerStatementInfo(type, ctx.getStart().getLine()));
                }
            }
        }
        return visitChildren(ctx);
    }

    /**
     * Transaction-control capture (T-SQL):
     *   COMMIT [TRAN|TRANSACTION]                → COMMIT
     *   ROLLBACK [TRAN|TRANSACTION] [savepoint]  → ROLLBACK (+ savepointName if present)
     *   SAVE TRAN|TRANSACTION savepoint          → SAVEPOINT (+ savepointName)
     *   BEGIN TRAN|TRANSACTION                    → BEGIN_TRAN
     */
    private void addTransactionStatement(SqlServerParser.TransactionStatementContext ctx) {
        int line = ctx.getStart().getLine();
        SqlServerStatementInfo si = new SqlServerStatementInfo();
        si.setLine(line);
        String name = ctx.ID() != null ? ctx.ID().getText() : null;
        if (ctx.COMMIT() != null) {
            si.setType("COMMIT");
        } else if (ctx.ROLLBACK() != null) {
            si.setType("ROLLBACK");
            if (name != null) si.setSavepointName(name);
        } else if (ctx.SAVE() != null) {
            si.setType("SAVEPOINT");
            if (name != null) si.setSavepointName(name);
        } else {
            si.setType("BEGIN_TRAN");
        }
        result.getStatements().add(si);
    }

    @Override
    public Void visitTryBlock(SqlServerParser.TryBlockContext ctx) {
        SqlServerExceptionHandlerInfo eh = new SqlServerExceptionHandlerInfo();
        eh.setLine(ctx.getStart().getLine());
        eh.setLineEnd(ctx.getStop() != null ? ctx.getStop().getLine() : ctx.getStart().getLine());
        eh.setStatementsCount(ctx.statement() != null ? ctx.statement().size() : 0);
        result.getExceptionHandlers().add(eh);
        return visitChildren(ctx);
    }

    private String statementType(org.antlr.v4.runtime.tree.ParseTree child) {
        if (child instanceof SqlServerParser.ExecStatementContext)        return "EXEC";
        if (child instanceof SqlServerParser.DeclareStatementContext)     return "DECLARE";
        if (child instanceof SqlServerParser.SetStatementContext)         return "SET";
        if (child instanceof SqlServerParser.InsertStatementContext)      return "INSERT";
        if (child instanceof SqlServerParser.UpdateStatementContext)      return "UPDATE";
        if (child instanceof SqlServerParser.DeleteStatementContext)      return "DELETE";
        if (child instanceof SqlServerParser.SelectStatementContext)      return "SELECT";
        if (child instanceof SqlServerParser.IfStatementContext)          return "IF";
        if (child instanceof SqlServerParser.WhileStatementContext)       return "WHILE_LOOP";
        if (child instanceof SqlServerParser.TryBlockContext)             return "TRY_CATCH";
        if (child instanceof SqlServerParser.TransactionStatementContext) return "TRANSACTION";
        if (child instanceof SqlServerParser.CreateStatementContext)      return "CREATE";
        if (child instanceof SqlServerParser.ReturnStatementContext)      return "RETURN";
        if (child instanceof SqlServerParser.BeginEndBlockContext)        return "BLOCK";
        if (child instanceof SqlServerParser.OtherStatementContext) {
            // derive from the leading keyword only (MERGE/OPEN/FETCH/CLOSE/PRINT/THROW/WITH…)
            org.antlr.v4.runtime.ParserRuleContext prc = (org.antlr.v4.runtime.ParserRuleContext) child;
            if (prc.getStart() != null) {
                String first = prc.getStart().getText();
                if (first != null && first.matches("[A-Za-z]+")) {
                    String kw = first.toUpperCase();
                    // Normalize WITH-led statements to the common vocabulary token "CTE"
                    // so all dialects report common-table-expressions uniformly.
                    if ("WITH".equals(kw)) return "CTE";
                    return kw;
                }
            }
            return "OTHER";
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SET @var = expr  — detect dynamic SQL pattern (SET @sql = '...')
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitSetStatement(SqlServerParser.SetStatementContext ctx) {
        // Session-option form (SET NOCOUNT ON) has no expr — nothing to inspect.
        if (ctx.expr() == null) return null;
        String exprText = ctx.expr().getText();
        // Detect: the RHS is a string literal → dynamic SQL
        if (exprText.startsWith("'") || exprText.startsWith("N'") || exprText.startsWith("n'")) {
            int line = ctx.getStart().getLine();
            String orig = originalText(ctx.expr());   // preserves whitespace inside the literal
            SqlServerDynamicSqlInfo d = new SqlServerDynamicSqlInfo();
            d.setKind(SqlServerDynamicSqlInfo.Kind.SET_SQL);
            d.setSqlSource(orig);
            d.setLine(line);
            result.getDynamicSql().add(d);
            // Analyze the SQL text embedded in the string literal: recover its tables + joins.
            addTableOpsFromText(orig, line);
            attachJoins(orig, line);
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EXEC / EXECUTE  — proc calls + sp_executesql detection
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExecStatement(SqlServerParser.ExecStatementContext ctx) {
        // EXEC(@sql) / EXEC('literal') form has no routineName — plain string execution, a
        // structurally different mechanism from EXEC sp_executesql (no parameterization).
        if (ctx.routineName() == null) {
            SqlServerDynamicSqlInfo d = new SqlServerDynamicSqlInfo();
            d.setKind(SqlServerDynamicSqlInfo.Kind.EXEC_STRING);
            d.setLine(ctx.getStart().getLine());
            result.getDynamicSql().add(d);
            return null;
        }

        String procName = extractRoutineName(ctx.routineName());

        // sp_executesql → dynamic SQL, not a regular call
        if ("sp_executesql".equalsIgnoreCase(procName)) {
            SqlServerDynamicSqlInfo d = new SqlServerDynamicSqlInfo();
            d.setKind(SqlServerDynamicSqlInfo.Kind.EXEC_SP_EXECUTESQL);
            d.setLine(ctx.getStart().getLine());
            result.getDynamicSql().add(d);
            return null;
        }

        String execSchema = extractRoutineSchema(ctx.routineName());
        String execKey = (execSchema != null ? execSchema.toUpperCase() + "." : "") + (procName != null ? procName.toUpperCase() : "");
        if (procName != null && seenCalls.add(execKey)) {
            SqlServerCallInfo c = new SqlServerCallInfo();
            c.setSchema(execSchema);
            c.setName(procName);
            c.setLine(ctx.getStart().getLine());
            result.getCalls().add(c);
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: INSERT
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitInsertStatement(SqlServerParser.InsertStatementContext ctx) {
        SqlServerTableOpInfo op = new SqlServerTableOpInfo();
        op.setDmlType(SqlServerTableOpInfo.DmlType.INSERT);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(statementText(ctx, true));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: UPDATE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitUpdateStatement(SqlServerParser.UpdateStatementContext ctx) {
        SqlServerTableOpInfo op = new SqlServerTableOpInfo();
        op.setDmlType(SqlServerTableOpInfo.DmlType.UPDATE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(statementText(ctx, false));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: DELETE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeleteStatement(SqlServerParser.DeleteStatementContext ctx) {
        SqlServerTableOpInfo op = new SqlServerTableOpInfo();
        op.setDmlType(SqlServerTableOpInfo.DmlType.DELETE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(statementText(ctx, false));
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: SELECT — scan stmtTail text for FROM clause
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitSelectStatement(SqlServerParser.SelectStatementContext ctx) {
        // Extract every table in the FROM and JOIN clauses (embedded in stmtTail text).
        int line = ctx.getStart().getLine();
        int before = result.getTableOps().size();
        if (ctx.stmtTail() != null) {
            String txt = originalText(ctx.stmtTail());
            addTableOpsFromText(txt, line);
            attachJoins(txt, line);
        }
        // Guarantee at least one SELECT op even when no table was found (e.g. SELECT of vars),
        // preserving the prior behaviour that every SELECT statement records an op.
        if (result.getTableOps().size() == before) {
            SqlServerTableOpInfo op = new SqlServerTableOpInfo();
            op.setDmlType(SqlServerTableOpInfo.DmlType.SELECT);
            op.setLine(line);
            result.getTableOps().add(op);
        } else if (result.getTableOps().size() == before + 1
                && distinctTableRefs(originalText(ctx.stmtTail())) == 1) {
            // Single-table SELECT: every selected column belongs to that one table, so the
            // statement text can be attributed to this op safely.
            //
            // A multi-table SELECT deliberately gets none. Column detail is folded per table by
            // its operation's table name, so handing the same column list to two table ops would
            // print one table's columns on the other's page — stated as fact. Absent detail is
            // the correct answer there until the enricher can resolve qualifiers to tables.
            result.getTableOps().get(result.getTableOps().size() - 1)
                    .setSqlText(statementText(ctx, false));
        }
        return visitChildren(ctx);
    }

    // Inline TVF body: RETURN ( SELECT ... ) — scan the parenthesised body for tables.
    @Override
    public Void visitReturnStatement(SqlServerParser.ReturnStatementContext ctx) {
        if (ctx.parenGroup() != null) {
            String txt = originalText(ctx.parenGroup());
            addTableOpsFromText(txt, ctx.getStart().getLine());
            attachJoins(txt, ctx.getStart().getLine());
        }
        return visitChildren(ctx);
    }

    /** Original source text for a context, with whitespace preserved (getText() strips it). */

    /**
     * The source text of the statement enclosing {@code ctx}.
     *
     * <p>A SELECT's table op is built from a table reference inside the FROM clause, which knows
     * nothing about the statement around it — so it carried no SQL at all, and the column enricher
     * had nothing to work from. Measured before this: DB2 2,732 and PostgreSQL 2,392 statements with
     * no {@code sqlText}, every one a SELECT, which is why those two dialects showed almost no
     * column detail while MySQL (which already had this helper) showed 3,450.
     *
     * <p>Walks up to the nearest context whose name ends in {@code StatementContext} or
     * {@code StmtContext}, which is the naming convention every grammar here follows.
     */
    private String enclosingStatementText(org.antlr.v4.runtime.ParserRuleContext ctx) {
        org.antlr.v4.runtime.ParserRuleContext c = ctx;
        org.antlr.v4.runtime.ParserRuleContext bestSelect = null;
        org.antlr.v4.runtime.ParserRuleContext stmt = null;
        while (c != null) {
            String n = c.getClass().getSimpleName();
            // Prefer the outermost SELECT over the statement wrapping it.
            //
            // PL/pgSQL and SQL PL wrap reads in control flow — `FOR rec IN SELECT ... LOOP`. Walking
            // straight to the enclosing StatementContext captured the loop, so the text handed to
            // the ANSI parser ended in a bare `LOOP` and failed. Measured: 979 PostgreSQL statements
            // captured-but-unparseable, every one of that shape. Taking the outermost Select keeps
            // the joins and WHERE (which is where the column detail lives) and stops before the
            // control-flow keyword.
            if (n.contains("Select") || n.contains("QuerySpec")) bestSelect = c;
            else if (n.endsWith("StatementContext") || n.endsWith("StmtContext")) { stmt = c; break; }
            c = c.getParent();
        }
        org.antlr.v4.runtime.ParserRuleContext pick = bestSelect != null ? bestSelect : stmt;
        return pick != null ? cutAtStatementEnd(trimTrailingBlockKeyword(originalText(pick))) : null;
    }


    /**
     * Cuts the text at the first unquoted semicolon.
     *
     * <p>A grammar context can span more than one statement, and the captured text then reads
     * {@code SELECT COUNT(*) INTO v_n FROM erp.erp_product; CALL erp.erp_usp_write_audit_trail(...)}.
     * ANSI parsing sees two statements and yields nothing for either, so a read with perfectly
     * ordinary columns and predicates came back empty — 1,223 PostgreSQL statements of exactly that
     * shape, all of which had parsed "successfully" while producing no detail.
     *
     * <p>Quote-aware because a semicolon inside a literal is data, not a terminator; cutting there
     * would truncate mid-string and turn a parseable statement into an unparseable one.
     */
    private String cutAtStatementEnd(String sql) {
        if (sql == null) return null;
        char quote = 0;
        for (int i = 0; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0;
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (c == ';') {
                return sql.substring(0, i).stripTrailing();
            }
        }
        return sql;
    }
    /**
     * Strips a trailing block keyword the grammar may have included.
     *
     * <p>Belt and braces for the case above: even with the Select preferred, a grammar rule can end
     * on {@code LOOP}/{@code THEN}/{@code DO}, and one stray keyword makes the whole statement
     * unparseable — losing all of its column detail rather than part of it.
     */
    private String trimTrailingBlockKeyword(String sql) {
        if (sql == null) return null;
        String s = sql.stripTrailing();
        for (String kw : new String[]{"LOOP", "THEN", "DO", "BEGIN"}) {
            if (s.length() > kw.length()) {
                String tail = s.substring(s.length() - kw.length());
                if (tail.equalsIgnoreCase(kw)
                        && Character.isWhitespace(s.charAt(s.length() - kw.length() - 1))) {
                    s = s.substring(0, s.length() - kw.length()).stripTrailing();
                }
            }
        }
        return s;
    }

    private String originalText(ParserRuleContext ctx) {
        if (ctx == null || ctx.getStart() == null || ctx.getStop() == null) return "";
        CharStream cs = ctx.getStart().getInputStream();
        if (cs == null) return ctx.getText();
        return cs.getText(Interval.of(ctx.getStart().getStartIndex(), ctx.getStop().getStopIndex()));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // statementText — the WHOLE statement, for column-level analysis
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Keywords that can only begin a new statement, never continue the current one.
     * Used to bound {@link #statementText} when T-SQL omits the statement terminator.
     */
    private static final Set<String> STATEMENT_START_KEYWORDS = Set.of(
            "BEGIN", "END", "DECLARE", "IF", "ELSE", "WHILE", "EXEC", "EXECUTE",
            "INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE", "CREATE", "ALTER", "DROP",
            "SET", "RETURN", "PRINT", "THROW", "RAISERROR", "GOTO", "BREAK", "CONTINUE",
            "COMMIT", "ROLLBACK", "SAVE", "TRY", "CATCH", "FETCH", "OPEN", "CLOSE",
            "DEALLOCATE", "WAITFOR", "GO");

    /** Never grow a captured statement beyond this; over-capture would be worse than under. */
    private static final int MAX_STATEMENT_CHARS = 8000;

    /**
     * The full source text of a DML statement, for {@code TableOperationEnricher}.
     *
     * <h3>Why {@link #originalText} is not enough</h3>
     * The grammar's {@code stmtTail} rule stops at the first statement-starting keyword, so
     * {@code INSERT INTO t(a,b) SELECT a,b FROM s} yields a context ending at {@code (a,b)} —
     * {@code "INSERT INTO t(a, b)"}, which does not parse and therefore produced <em>no</em>
     * column detail at all. This was measured, not guessed: 57 real T-SQL sources gave
     * 258/3682 operations with column detail, and the unparsed ones were dominated by
     * {@code INSERT ... SELECT} truncated at the column list.
     *
     * <p>So capture continues past the context, tracking string literals, bracket identifiers,
     * comments and parenthesis depth, until the statement genuinely ends: a {@code ;} at depth
     * zero, or — because T-SQL frequently omits it — a keyword that cannot continue this
     * statement. {@code SELECT}/{@code WITH}/{@code VALUES} are legal continuations of an
     * {@code INSERT} and so are not treated as boundaries for one.
     *
     * <p>If the scan would exceed {@link #MAX_STATEMENT_CHARS} the narrow context text is
     * returned instead. Over-capturing would splice unrelated statements together and could
     * attribute one table's columns to another; no column detail is the safer failure.
     */
    private String statementText(ParserRuleContext ctx, boolean insertContinuations) {
        if (ctx == null || ctx.getStart() == null || ctx.getStop() == null) return "";
        CharStream cs = ctx.getStart().getInputStream();
        if (cs == null) return ctx.getText();
        int start = ctx.getStart().getStartIndex();
        int narrowStop = ctx.getStop().getStopIndex();
        String all = wholeSource(cs);
        int size = all.length();
        // The grammar's DML rules end with an optional SEMI. When it is there the statement is
        // already complete and scanning on would only pick up trailing whitespace.
        if (narrowStop >= 0 && narrowStop < size && all.charAt(narrowStop) == ';') {
            return cs.getText(Interval.of(start, narrowStop));
        }
        int i = narrowStop + 1;
        int depth = 0;
        int limit = Math.min(size, start + MAX_STATEMENT_CHARS);
        while (i < limit) {
            char ch = all.charAt(i);
            if (ch == '\'') {                              // string literal, '' escapes
                i++;
                while (i < limit) {
                    if (all.charAt(i) == '\'') {
                        if (i + 1 < limit && all.charAt(i + 1) == '\'') { i += 2; continue; }
                        break;
                    }
                    i++;
                }
                i++;
                continue;
            }
            if (ch == '[') {                               // bracket identifier
                while (i < limit && all.charAt(i) != ']') i++;
                i++;
                continue;
            }
            if (ch == '-' && i + 1 < limit && all.charAt(i + 1) == '-') {
                while (i < limit && all.charAt(i) != '\n') i++;
                continue;
            }
            if (ch == '/' && i + 1 < limit && all.charAt(i + 1) == '*') {
                i += 2;
                while (i + 1 < limit && !(all.charAt(i) == '*' && all.charAt(i + 1) == '/')) i++;
                i += 2;
                continue;
            }
            if (ch == '(') { depth++; i++; continue; }
            if (ch == ')') {
                if (depth == 0) break;                     // closing paren we never opened
                depth--; i++; continue;
            }
            if (ch == ';' && depth == 0) break;
            if (depth == 0 && (Character.isLetter(ch) || ch == '_')) {
                int j = i;
                while (j < limit && (Character.isLetterOrDigit(all.charAt(j)) || all.charAt(j) == '_')) j++;
                String word = all.substring(i, j).toUpperCase();
                if (isBoundaryKeyword(word, insertContinuations)) break;
                i = j;
                continue;
            }
            i++;
        }
        if (i >= limit && limit < size) {
            // Ran into the size cap without finding an end — do not guess.
            return cs.getText(Interval.of(start, narrowStop));
        }
        int end = Math.min(i - 1, size - 1);
        if (end < narrowStop) end = narrowStop;
        return cs.getText(Interval.of(start, end));
    }

    private CharStream cachedStream;
    private String cachedSource;

    /**
     * The whole source, materialised once. {@code CharStream.getText} copies, and
     * {@link #statementText} is called for every DML statement in a routine — thousands on the
     * real sources — so re-extracting per call would be quadratic in source size.
     */
    private String wholeSource(CharStream cs) {
        if (cs != cachedStream) {
            cachedStream = cs;
            cachedSource = cs.getText(Interval.of(0, cs.size() - 1));
        }
        return cachedSource;
    }

    private boolean isBoundaryKeyword(String word, boolean insertContinuations) {
        if (insertContinuations && ("SELECT".equals(word) || "WITH".equals(word)
                || "VALUES".equals(word) || "EXEC".equals(word) || "EXECUTE".equals(word))) {
            return false;
        }
        return STATEMENT_START_KEYWORDS.contains(word) || "SELECT".equals(word);
    }

    /** Emit sequence usages (NEXT VALUE FOR schema.seq) found in the body. */
    private void extractSequences(ParserRuleContext bodyCtx) {
        String text = originalText(bodyCtx);
        if (text == null || text.isEmpty()) return;
        int bodyStartLine = bodyCtx.getStart().getLine();
        Set<String> seen = new HashSet<>();
        Matcher m = SEQ_PATTERN.matcher(text);
        while (m.find()) {
            String schema = m.group(2) != null ? stripBrackets(m.group(1)) : null;
            String name   = m.group(2) != null ? stripBrackets(m.group(2)) : stripBrackets(m.group(1));
            if (!seen.add((schema != null ? schema + "." : "") + name.toUpperCase())) continue;
            SqlServerSequenceInfo s = new SqlServerSequenceInfo();
            s.setSchema(schema);
            s.setName(name);
            // Actual line = body start line + newlines before the match (not just the body start).
            s.setLine(lineAt(text, m.start(), bodyStartLine));
            result.getSequences().add(s);
        }
    }

    /** Emit proc→function / function→function / →TVF edges for schema-qualified calls in the body. */
    private void extractQualifiedCalls(ParserRuleContext bodyCtx) {
        String text = originalText(bodyCtx);
        if (text == null || text.isEmpty()) return;
        Matcher m = QUALIFIED_CALL_PATTERN.matcher(text);
        while (m.find()) {
            String schema = m.group(1);
            String name = m.group(2);
            // Skip INSERT-target tables: "INSERT INTO sales.SalesOrder(col,...)" — the
            // "table(columns)" looks like a call but is a table (already captured as a table-op).
            // Only INTO is excluded; FROM/JOIN may precede legit table-valued-function calls.
            String pre = text.substring(Math.max(0, m.start() - 10), m.start());
            if (pre.matches("(?is).*\\bINTO\\s+$")) continue;
            // Skip self-reference and already-seen targets. Dedup on the SCHEMA-QUALIFIED
            // name so same-named routines in different schemas (e.g. sales.fn_X vs hr.fn_X)
            // are kept as distinct calls and never overwrite each other.
            if (name.equalsIgnoreCase(result.getName())) continue;
            String callKey = (schema != null ? schema.toUpperCase() + "." : "") + name.toUpperCase();
            if (!seenCalls.add(callKey)) continue;
            SqlServerCallInfo c = new SqlServerCallInfo();
            c.setSchema(schema);
            c.setName(name);
            // Actual call-site line, not the body start line.
            c.setLine(lineAt(text, m.start(), bodyCtx.getStart().getLine()));
            result.getCalls().add(c);
        }
    }

    /** Adds a SELECT table op for each FROM/JOIN table found in the given SQL text (accurate lines). */
    private void addTableOpsFromText(String sqlText, int baseLine) {
        if (sqlText == null) return;
        Matcher m = TABLE_REF_PATTERN.matcher(sqlText);
        while (m.find()) {
            String schema = m.group(2) != null ? stripBrackets(m.group(1)) : null;
            String name   = m.group(2) != null ? stripBrackets(m.group(2)) : stripBrackets(m.group(1));
            addTableOp(schema, name, lineAt(sqlText, m.start(), baseLine), SqlServerTableOpInfo.DmlType.SELECT);
        }
    }

    /** How many distinct tables a FROM/JOIN clause set names — 1 means unambiguous attribution. */
    private int distinctTableRefs(String sqlText) {
        if (sqlText == null) return 0;
        Set<String> names = new HashSet<>();
        Matcher m = TABLE_REF_PATTERN.matcher(sqlText);
        while (m.find()) {
            String schema = m.group(2) != null ? stripBrackets(m.group(1)) : null;
            String name   = m.group(2) != null ? stripBrackets(m.group(2)) : stripBrackets(m.group(1));
            names.add(((schema != null ? schema + "." : "") + name).toUpperCase());
        }
        return names.size();
    }

    /** Recovers all DDL/DML operations (MERGE/TRUNCATE/CREATE/ALTER/DROP/INSERT/UPDATE/DELETE/
     *  SELECT reads) from statements consumed generically by otherStatement (WITH-CTE, MERGE, …). */
    @Override
    public Void visitOtherStatement(SqlServerParser.OtherStatementContext ctx) {
        String txt = originalText(ctx);
        scanOps(txt, ctx.getStart().getLine());
        attachJoins(txt, ctx.getStart().getLine());   // MERGE USING / WITH-CTE joins
        recordCursorLifecycleOp(txt, ctx.getStart().getLine());
        return null;
    }

    // OPEN cur; FETCH [NEXT] FROM cur [INTO ...]; CLOSE cur; DEALLOCATE cur;  — these fall through
    // the generic otherStatement catch-all, so recover them here and attach to the matching
    // cursor (by name, within this routine) so its lifecycle is tracked past DECLARE.
    private static final Pattern CURSOR_LIFECYCLE_PATTERN = Pattern.compile(
            "(?i)\\b(OPEN|CLOSE|DEALLOCATE)\\s+([A-Za-z_][\\w]*)\\b"
          + "|\\bFETCH\\b(?:\\s+(?:NEXT|PRIOR|FIRST|LAST|ABSOLUTE|RELATIVE)\\b)?(?:\\s+FROM)?\\s+([A-Za-z_][\\w]*)\\b");

    private void recordCursorLifecycleOp(String text, int baseLine) {
        if (text == null || result.getCursors().isEmpty()) return;
        Matcher m = CURSOR_LIFECYCLE_PATTERN.matcher(text);
        while (m.find()) {
            String op;
            String cursorName;
            if (m.group(1) != null) {
                op = m.group(1).toUpperCase();
                cursorName = m.group(2);
            } else {
                op = "FETCH";
                cursorName = m.group(3);
            }
            if (cursorName == null) continue;
            for (SqlServerCursorInfo cur : result.getCursors()) {
                if (cur.getName() != null && cur.getName().equalsIgnoreCase(cursorName)) {
                    cur.addStmtOperation(op, lineAt(text, m.start(), baseLine));
                    break;
                }
            }
        }
    }

    /** CREATE TABLE #temp( ... ) etc. inside a routine body. */
    @Override
    public Void visitCreateStatement(SqlServerParser.CreateStatementContext ctx) {
        String text = originalText(ctx);
        scanOps(text, ctx.getStart().getLine());
        extractIdentityColumns(text, ctx.getStart().getLine());
        return visitChildren(ctx);
    }

    /**
     * IDENTITY columns (audit #8) — SQL Server's most common auto-increment mechanism, distinct
     * from (and unrelated to) {@code CREATE SEQUENCE} / {@code NEXT VALUE FOR}. Recorded on the
     * shared {@link SqlServerSequenceInfo} model (see its class doc) so the existing
     * sequences-facet pipeline picks these up without a second concept.
     */
    private void extractIdentityColumns(String text, int baseLine) {
        if (text == null || text.isEmpty()) return;
        Matcher tableM = CREATE_TABLE_PATTERN.matcher(text);
        while (tableM.find()) {
            String schema = tableM.group(2) != null ? stripBrackets(tableM.group(1)) : null;
            String table  = tableM.group(2) != null ? stripBrackets(tableM.group(2)) : stripBrackets(tableM.group(1));
            int openParen = tableM.end() - 1;
            int closeParen = matchingCloseParen(text, openParen);
            if (closeParen < 0) continue;
            String body = text.substring(openParen + 1, closeParen);
            int bodyOffset = openParen + 1;

            Matcher idM = IDENTITY_PATTERN.matcher(body);
            while (idM.find()) {
                SqlServerSequenceInfo s = new SqlServerSequenceInfo();
                s.setIdentityColumn(true);
                s.setSchema(schema);
                s.setTableName(table);
                s.setColumnName(stripBrackets(idM.group(1)));
                s.setSeed(idM.group(2) != null ? Long.valueOf(idM.group(2)) : Long.valueOf(1L));
                s.setIncrement(idM.group(3) != null ? Long.valueOf(idM.group(3)) : Long.valueOf(1L));
                s.setLine(lineAt(text, bodyOffset + idM.start(), baseLine));
                result.getSequences().add(s);
            }
        }
    }

    /** Index of the {@code )} that matches the {@code (} at {@code openParenIdx}, or -1. */
    private int matchingCloseParen(String text, int openParenIdx) {
        int depth = 0;
        for (int i = openParenIdx; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') {
                depth--;
                if (depth == 0) return i;
            }
        }
        return -1;
    }

    /** Scan text for every keyword-led table operation and record it with the correct op type. */
    private void scanOps(String text, int baseLine) {
        if (text == null) return;
        Matcher m = KEYWORD_OP_PATTERN.matcher(text);
        while (m.find()) {
            String kw = m.group(1).replaceAll("\\s+", " ").toUpperCase();
            SqlServerTableOpInfo.DmlType op = opForKeyword(kw);
            if (op == null) continue;
            String schema = m.group(3) != null ? stripBrackets(m.group(2)) : null;
            String name   = m.group(3) != null ? stripBrackets(m.group(3)) : stripBrackets(m.group(2));
            SqlServerTableOpInfo added =
                    addTableOp(schema, name, lineAt(text, m.start(), baseLine), op);
            // DDL inside a routine (TRUNCATE/ALTER/DROP/CREATE TABLE) reaches here rather than a
            // DML visitor, because the grammar consumes it through otherStatement. Without the
            // statement text the enricher never sees it, and `ddl` stayed empty for every
            // analysis — including the SQL Server demo schema, which contains 120 occurrences of
            // `TRUNCATE TABLE erp.InventoryTxn`. Measured on disk, not inferred from the absence.
            if (added != null && added.getSqlText() == null) {
                // Sep05-13: every recovered operation gets its statement text, not only DDL.
                //
                // Measured: 235 SQL Server rows reached the screen with no `sqlText` at all — 210
                // recovered from a FROM/JOIN and 25 from a MERGE — so the enricher never saw them
                // and every cell was blank. That was the whole of this dialect's remaining gap.
                //
                // The two cases need different starting points, and using one for both is what
                // makes this subtle. A DDL/DML keyword *begins* its statement, so the match
                // position is the start. `FROM` and `JOIN` sit in the *middle* of one, so starting
                // there yields "FROM erp.Product p INNER JOIN …", which is not a statement in any
                // dialect and would parse to nothing — trading a blank cell for a blank cell plus
                // a misleading "not parsed" label.
                added.setSqlText(kw.startsWith("FROM") || kw.startsWith("JOIN")
                        ? statementAround(text, m.start())
                        : oneStatementFrom(text, m.start()));
            }
        }
    }

    /**
     * Words that can never be an unquoted table name, so a "table" of this name is a mis-parse.
     *
     * <p>These are T-SQL reserved words: the server itself rejects {@code CREATE TABLE SET}, so a
     * recovered name from this set is always a scanning artefact and never a real object being
     * hidden. That is what makes dropping it safe rather than a guess — the alternative, reporting
     * a table the database cannot contain, is a fact the reader has no way to disprove.
     *
     * <p>A bracketed or quoted identifier ({@code [SET]}) is legal in T-SQL, but
     * {@link #stripBrackets} has already removed the brackets by this point, so such a table would
     * be suppressed too. That is accepted deliberately: a table genuinely named {@code [SET]} is
     * vanishingly rare, whereas the mis-parse was measured on the first schema examined.
     */
    private static final Set<String> RESERVED_NON_TABLE = Set.of(
            "SET", "SELECT", "VALUES", "WHERE", "FROM", "JOIN", "INTO", "ON", "AS", "AND", "OR",
            "WHEN", "THEN", "ELSE", "END", "CASE", "BY", "GROUP", "ORDER", "HAVING", "UNION",
            "INNER", "LEFT", "RIGHT", "FULL", "OUTER", "CROSS", "APPLY", "LATERAL", "USING",
            "MATCHED", "TARGET", "SOURCE", "OUTPUT", "TOP", "DISTINCT", "EXISTS", "NOT", "NULL",
            "WITH", "TABLE", "UPDATE", "INSERT", "DELETE", "MERGE", "EXEC", "EXECUTE", "DECLARE",
            "BEGIN", "IF", "WHILE", "RETURN", "PRINT", "THROW");

    /** Keywords whose statement is DDL, as {@link #KEYWORD_OP_PATTERN} normalises them. */
    private static final Set<String> DDL_KEYWORDS = Set.of(
            "CREATE TABLE", "ALTER TABLE", "DROP TABLE", "TRUNCATE TABLE");

    /** One statement out of a text block: from {@code from} to the next {@code ;}, or to the end. */
    /** Keywords that begin a statement whose text we can hand to the column enricher. */
    private static final java.util.regex.Pattern STATEMENT_HEAD = java.util.regex.Pattern.compile(
            "(?i)\\b(SELECT|INSERT|UPDATE|DELETE|MERGE|WITH)\\b");

    /**
     * The statement surrounding a match that sits <em>inside</em> one, such as a {@code FROM} or
     * {@code JOIN}.
     *
     * <p>Walks back to the nearest statement-beginning keyword and forward to the terminator. The
     * nearest one rather than the outermost is deliberate: for a {@code FROM} inside a subquery the
     * inner {@code SELECT} is the statement that actually reads the table, and handing over the
     * outer one would attribute the subquery's columns to the wrong query.
     *
     * <p>Returns null when no head is found, so the caller leaves {@code sqlText} unset rather than
     * passing the enricher a fragment. An honest absence beats a confident mis-parse.
     */
    private static String statementAround(String text, int matchStart) {
        Matcher h = STATEMENT_HEAD.matcher(text);
        int head = -1;
        while (h.find()) {
            if (h.start() > matchStart) break;
            head = h.start();
        }
        if (head < 0) return null;
        String out = oneStatementFrom(text, head);
        return out == null || out.isBlank() ? null : out;
    }

    private static String oneStatementFrom(String text, int from) {
        int end = text.indexOf(';', from);
        return end < 0 ? text.substring(from) : text.substring(from, end);
    }

    private SqlServerTableOpInfo.DmlType opForKeyword(String kw) {
        if (kw.startsWith("FROM") || kw.startsWith("JOIN"))     return SqlServerTableOpInfo.DmlType.SELECT;
        if (kw.startsWith("INSERT"))                            return SqlServerTableOpInfo.DmlType.INSERT;
        if (kw.startsWith("UPDATE"))                            return SqlServerTableOpInfo.DmlType.UPDATE;
        if (kw.startsWith("DELETE"))                            return SqlServerTableOpInfo.DmlType.DELETE;
        if (kw.startsWith("MERGE"))                             return SqlServerTableOpInfo.DmlType.MERGE;
        if (kw.startsWith("TRUNCATE"))                          return SqlServerTableOpInfo.DmlType.TRUNCATE;
        if (kw.startsWith("CREATE"))                            return SqlServerTableOpInfo.DmlType.CREATE;
        if (kw.startsWith("ALTER"))                             return SqlServerTableOpInfo.DmlType.ALTER;
        if (kw.startsWith("DROP"))                              return SqlServerTableOpInfo.DmlType.DROP;
        if (kw.startsWith("INTO"))                              return SqlServerTableOpInfo.DmlType.INSERT;
        return null;
    }

    /** Parse JOIN / APPLY clauses from SQL text and attach each to its ACTUAL base table op
     *  (the nearest preceding FROM), looked up by name — robust to op de-duplication. Handles
     *  SELECTs, MERGE USING subqueries and CTEs. */
    private void attachJoins(String sqlText, int baseLine) {
        if (sqlText == null) return;
        // alias->table map for the whole statement text, so BOTH sides of each join can be
        // resolved from its ON-condition aliases (left side is NOT defaulted to nearest FROM).
        java.util.Map<String, String> aliasMap = buildAliasMap(sqlText);
        Matcher m = JOIN_PATTERN.matcher(sqlText);
        while (m.find()) {
            SqlServerJoinInfo j = new SqlServerJoinInfo();
            String kw = m.group(1).replaceAll("\\s+", " ").toUpperCase();
            String op = m.group(2).toUpperCase();
            j.setJoinType("APPLY".equals(op) ? kw + " APPLY" : kw);   // e.g. "CROSS APPLY", "LEFT OUTER"
            if (m.group(4) != null) {
                j.setJoinedTableSchema(stripBrackets(m.group(3)));
                j.setJoinedTable(stripBrackets(m.group(4)));
            } else {
                j.setJoinedTable(stripBrackets(m.group(3)));
            }
            if (m.group(5) != null) j.setJoinedTableAlias(m.group(5));
            if (m.group(6) != null) j.setCondition(m.group(6).trim());
            j.setLine(lineAt(sqlText, m.start(), baseLine));
            j.setQueryId(baseLine);
            // Skip joins to/from CTE aliases (not real tables).
            if (j.getJoinedTable() == null
                    || cteNames.contains(j.getJoinedTable().toUpperCase())) continue;
            resolveLeftSide(j, aliasMap);
            // Attach to the join's base table (nearest FROM before this JOIN), by name.
            String base = baseTableBefore(sqlText, m.start());
            if (base == null || cteNames.contains(base.toUpperCase())) continue;
            SqlServerTableOpInfo baseOp = findOrCreateSelectOp(base, j.getLine());
            baseOp.getJoins().add(j);   // per-occurrence, like the Oracle path; the UI counts distinct
        }
    }

    // Reserved words that must not be mistaken for a table alias.
    private static final java.util.Set<String> ALIAS_STOPWORDS = java.util.Set.of(
            "ON", "WHERE", "GROUP", "ORDER", "HAVING", "UNION", "INNER", "LEFT", "RIGHT",
            "FULL", "CROSS", "OUTER", "JOIN", "APPLY", "AS", "SET", "WITH", "AND", "OR");

    private static final Pattern ALIAS_TABLE_PATTERN = Pattern.compile(
            "(?i)\\b(?:FROM|JOIN)\\s+\\[?([\\w#$@]+)\\]?(?:\\.\\[?([\\w#$]+)\\]?)?"
          + "(?:\\s+(?:AS\\s+)?([A-Za-z]\\w*))?");

    /** Scan FROM/JOIN clauses in the statement text, mapping each alias (and bare table name) to its table. */
    private java.util.Map<String, String> buildAliasMap(String sqlText) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        Matcher mt = ALIAS_TABLE_PATTERN.matcher(sqlText);
        while (mt.find()) {
            String table = mt.group(2) != null ? stripBrackets(mt.group(2)) : stripBrackets(mt.group(1));
            if (table == null) continue;
            table = table.toUpperCase();
            String alias = mt.group(3);
            if (alias != null && !ALIAS_STOPWORDS.contains(alias.toUpperCase())) {
                m.put(alias.toUpperCase(), table);
            }
            m.put(table, table);
        }
        return m;
    }

    /** Resolve leftTable/leftTableAlias from the ON-condition alias that is NOT the joined table. */
    private void resolveLeftSide(SqlServerJoinInfo j, java.util.Map<String, String> aliasMap) {
        if (j.getCondition() == null) return;
        String joinedAlias = j.getJoinedTableAlias() != null ? j.getJoinedTableAlias().toUpperCase() : null;
        Matcher mt = Pattern.compile("([A-Za-z_][\\w#$]*)\\s*\\.").matcher(j.getCondition());
        java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();
        while (mt.find()) seen.add(mt.group(1).toUpperCase());
        for (String a : seen) {
            if (joinedAlias != null && a.equals(joinedAlias)) continue;
            String t = aliasMap.get(a);
            if (t != null) { j.setLeftTableAlias(a); j.setLeftTable(t); return; }
        }
    }

    /** The table of the nearest FROM clause appearing before the given offset. */
    private String baseTableBefore(String text, int pos) {
        Matcher m = FROM_PATTERN.matcher(text.substring(0, Math.min(pos, text.length())));
        String base = null;
        while (m.find()) {
            base = m.group(2) != null ? stripBrackets(m.group(2)) : stripBrackets(m.group(1));
        }
        return base;
    }

    /** Find an existing table op by name (prefer a SELECT op); create a SELECT op if none. */
    private SqlServerTableOpInfo findOrCreateSelectOp(String name, int line) {
        SqlServerTableOpInfo any = null;
        for (SqlServerTableOpInfo t : result.getTableOps()) {
            if (name.equalsIgnoreCase(t.getTableName())) {
                if (t.getDmlType() == SqlServerTableOpInfo.DmlType.SELECT) return t;
                if (any == null) any = t;
            }
        }
        if (any != null) return any;
        SqlServerTableOpInfo t = new SqlServerTableOpInfo();
        t.setDmlType(SqlServerTableOpInfo.DmlType.SELECT);
        t.setTableName(name);
        t.setLine(line);
        result.getTableOps().add(t);
        return t;
    }

    /** Collect CTE names from a routine body so they aren't mistaken for tables. */
    private void collectCteNames(ParserRuleContext bodyCtx) {
        String text = originalText(bodyCtx);
        if (text == null) return;
        Matcher m = CTE_PATTERN.matcher(text);
        while (m.find()) cteNames.add(m.group(1).toUpperCase());
    }

    /** Add a table op, de-duped by schema.name + operation (so a table can show many op types). */
    /** @return the operation just added, or null when it was skipped or already seen. */
    private SqlServerTableOpInfo addTableOp(String schema, String name, int line,
                                            SqlServerTableOpInfo.DmlType op) {
        if (name == null || name.isEmpty()) return null;
        // Skip CTE aliases and table variables — they are not real tables.
        if (schema == null && (cteNames.contains(name.toUpperCase()) || name.startsWith("@"))) return null;
        // Sep05-11: a recovered name that is a reserved clause keyword is not a table.
        //
        // The recovery patterns above are text-based by necessity — MERGE and WITH-CTEs reach the
        // generic otherStatement rule, so their tables can only be found by scanning. But
        // `MERGE … WHEN MATCHED THEN UPDATE SET tgt.Qty = …` makes KEYWORD_OP_PATTERN read
        // "UPDATE" followed by "SET" and invent a table called SET — 13 phantom rows measured, and
        // a fake entry in the table list that a reader cannot tell from a real one.
        //
        // The guard sits here, at the single funnel, rather than in the regex: all three recovery
        // patterns pass through this method, and fixing one regex would leave the others to be
        // rediscovered one keyword at a time. That is how the previous instance of this defect —
        // the same "SET" phantom in the MySQL MERGE path — came back in a second dialect.
        if (RESERVED_NON_TABLE.contains(name.toUpperCase())) return null;
        String key = ((schema != null ? schema : "") + "." + name + "|" + op).toUpperCase();
        if (!seenTables.add(key)) return null;
        SqlServerTableOpInfo t = new SqlServerTableOpInfo();
        t.setDmlType(op);
        t.setSchemaName(schema);
        t.setTableName(name);
        t.setLine(line);
        result.getTableOps().add(t);
        return t;
    }

    /** Line number of a match at char offset within text that begins at baseLine. */
    private int lineAt(String text, int offset, int baseLine) {
        int n = baseLine;
        int end = Math.min(offset, text.length());
        for (int i = 0; i < end; i++) if (text.charAt(i) == '\n') n++;
        return n;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String extractRoutineName(SqlServerParser.RoutineNameContext ctx) {
        if (ctx == null) return null;
        List<SqlServerParser.NamePartContext> parts = ctx.namePart();
        if (parts.isEmpty()) return null;
        // Last part is the name
        return stripBrackets(parts.get(parts.size() - 1).getText());
    }

    private String extractRoutineSchema(SqlServerParser.RoutineNameContext ctx) {
        if (ctx == null) return null;
        List<SqlServerParser.NamePartContext> parts = ctx.namePart();
        if (parts.size() < 2) return null;
        // First part is the schema
        return stripBrackets(parts.get(0).getText());
    }

    private String extractTableName(SqlServerParser.TableRefContext ctx) {
        if (ctx == null) return null;
        // tableRef: (BRACKET_ID | ID) (DOT (BRACKET_ID | ID))?
        // Children: token, optionally DOT, token
        // The last ID/BRACKET_ID token is the table name
        String text = ctx.getText(); // e.g. "dbo.employees" or "employees"
        int dotIdx = text.lastIndexOf('.');
        if (dotIdx >= 0) {
            return stripBrackets(text.substring(dotIdx + 1));
        }
        return stripBrackets(text);
    }

    private String extractTableSchema(SqlServerParser.TableRefContext ctx) {
        if (ctx == null) return null;
        String text = ctx.getText();
        int dotIdx = text.indexOf('.');
        if (dotIdx >= 0) {
            return stripBrackets(text.substring(0, dotIdx));
        }
        return null;
    }

    private String stripBrackets(String s) {
        if (s == null) return null;
        if (s.startsWith("[") && s.endsWith("]")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }
}
