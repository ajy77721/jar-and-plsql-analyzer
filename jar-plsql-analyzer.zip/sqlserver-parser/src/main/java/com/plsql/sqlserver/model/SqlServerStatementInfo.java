package com.plsql.sqlserver.model;

/** One executable statement, for the statement inventory / summary. */
public class SqlServerStatementInfo {
    private String type;   // INSERT, UPDATE, DELETE, SELECT, EXEC, IF, WHILE, SET, DECLARE, COMMIT, ROLLBACK, SAVEPOINT, ...
    private int line;
    private String sqlText;
    private String savepointName;   // for SAVEPOINT / ROLLBACK TO <name>

    public SqlServerStatementInfo() {}
    public SqlServerStatementInfo(String type, int line) { this.type = type; this.line = line; }

    public String getType() { return type; }
    public void setType(String v) { this.type = v; }
    public int getLine() { return line; }
    public void setLine(int v) { this.line = v; }
    public String getSqlText() { return sqlText; }
    public void setSqlText(String v) { this.sqlText = v; }
    public String getSavepointName() { return savepointName; }
    public void setSavepointName(String v) { this.savepointName = v; }
}
