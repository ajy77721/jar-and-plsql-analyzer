package com.plsql.sqlserver.model;

import java.util.ArrayList;
import java.util.List;

public class SqlServerRoutineInfo {

    public enum RoutineType { PROCEDURE, FUNCTION, TRIGGER, VIEW }

    private String      schema;
    private String      name;
    private RoutineType type = RoutineType.PROCEDURE;
    private int         lineStart;
    private int         lineEnd;
    private List<SqlServerParamInfo>      params     = new ArrayList<>();
    private List<SqlServerVariableInfo>   variables  = new ArrayList<>();
    private List<SqlServerCallInfo>       calls      = new ArrayList<>();
    private List<SqlServerTableOpInfo>    tableOps   = new ArrayList<>();
    private List<SqlServerDynamicSqlInfo> dynamicSql = new ArrayList<>();
    private List<SqlServerCursorInfo>     cursors    = new ArrayList<>();
    private List<SqlServerStatementInfo>  statements = new ArrayList<>();
    private List<SqlServerExceptionHandlerInfo> exceptionHandlers = new ArrayList<>();
    private List<SqlServerSequenceInfo>   sequences  = new ArrayList<>();
    private List<String>                  errors     = new ArrayList<>();

    // Trigger metadata (populated for RoutineType.TRIGGER)
    private String triggerTable;
    private String triggerEvent;
    private String triggerTiming;
    // View defining query (populated for RoutineType.VIEW)
    private String viewQuery;

    public String      getSchema()     { return schema; }
    public void        setSchema(String schema)              { this.schema = schema; }
    public String      getName()       { return name; }
    public void        setName(String name)                  { this.name = name; }
    public RoutineType getType()       { return type; }
    public void        setType(RoutineType type)             { this.type = type; }
    public int         getLineStart()  { return lineStart; }
    public void        setLineStart(int lineStart)           { this.lineStart = lineStart; }
    public int         getLineEnd()    { return lineEnd; }
    public void        setLineEnd(int lineEnd)               { this.lineEnd = lineEnd; }

    public List<SqlServerParamInfo>      getParams()     { return params; }
    public List<SqlServerVariableInfo>   getVariables()  { return variables; }
    public List<SqlServerCallInfo>       getCalls()      { return calls; }
    public List<SqlServerTableOpInfo>    getTableOps()   { return tableOps; }
    public List<SqlServerDynamicSqlInfo> getDynamicSql() { return dynamicSql; }
    public List<SqlServerCursorInfo>     getCursors()    { return cursors; }
    public List<SqlServerStatementInfo>  getStatements() { return statements; }
    public List<SqlServerExceptionHandlerInfo> getExceptionHandlers() { return exceptionHandlers; }
    public List<SqlServerSequenceInfo>   getSequences()  { return sequences; }
    public List<String>                  getErrors()     { return errors; }

    public String getTriggerTable()  { return triggerTable; }
    public void   setTriggerTable(String v)  { this.triggerTable = v; }
    public String getTriggerEvent()  { return triggerEvent; }
    public void   setTriggerEvent(String v)  { this.triggerEvent = v; }
    public String getTriggerTiming() { return triggerTiming; }
    public void   setTriggerTiming(String v) { this.triggerTiming = v; }
    public String getViewQuery()     { return viewQuery; }
    public void   setViewQuery(String v)     { this.viewQuery = v; }
}
