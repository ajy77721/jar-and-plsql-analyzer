package com.plsql.sqlserver.model;

public class SqlServerDynamicSqlInfo {

    /**
     * SET_SQL           — @var built as a string literal (source of a dynamic SQL string).
     * EXEC_STRING        — {@code EXEC (@var)} / {@code EXEC ('literal')}: plain string execution,
     *                       no parameterization, no query-plan reuse.
     * EXEC_SP_EXECUTESQL — {@code EXEC sp_executesql @sql, @params, ...}: parameterized, the
     *                       injection-safer of the two dynamic-SQL mechanisms.
     */
    public enum Kind { SET_SQL, EXEC_STRING, EXEC_SP_EXECUTESQL }

    private Kind   kind;
    private String sqlSource;
    private int    line;

    public Kind   getKind()      { return kind; }
    public void   setKind(Kind kind)         { this.kind = kind; }
    public String getSqlSource() { return sqlSource; }
    public void   setSqlSource(String sqlSource) { this.sqlSource = sqlSource; }
    public int    getLine()      { return line; }
    public void   setLine(int line)          { this.line = line; }
}
