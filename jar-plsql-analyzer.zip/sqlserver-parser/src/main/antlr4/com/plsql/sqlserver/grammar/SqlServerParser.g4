// ============================================================
// SqlServerParser.g4
// Parser grammar for SQL Server T-SQL stored procedures / functions.
// Entry point: compilationUnit
// tokenVocab = SqlServerLexer
//
// Design: permissive + robust. Specific rules exist for the constructs we
// extract (EXEC calls, DML table ops, SET/DECLARE, dynamic SQL); everything
// else is consumed by tolerant catch-all rules so real-world T-SQL parses
// without "no viable alternative" failures.
// ============================================================
parser grammar SqlServerParser;

options { tokenVocab = SqlServerLexer; }

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

compilationUnit
    : (routineDefinition | triggerDefinition | viewDefinition)? EOF
    ;

// CREATE TRIGGER name ON target (AFTER|FOR|INSTEAD OF) events AS body
// (header is consumed permissively; the body statements carry the DML we extract)
triggerDefinition
    : CREATE (OR ALTER)? TRIGGER routineName triggerHeader AS routineBody
    ;

triggerHeader
    : ~AS+
    ;

// CREATE VIEW name [WITH ...] AS <select/union>
viewDefinition
    : CREATE (OR ALTER)? VIEW routineName viewHeader? AS routineBody
    ;

viewHeader
    : ~AS+
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Routine definition
// ─────────────────────────────────────────────────────────────────────────────

routineDefinition
    : CREATE (OR ALTER)? routineKw routineName paramBlock? returnsClause? AS routineBody
    ;

routineKw
    : PROCEDURE
    | PROC
    | FUNCTION
    ;

// RETURNS <type>                       (scalar function)
// RETURNS TABLE                        (inline TVF)
// RETURNS @var TABLE( ... )            (multi-statement TVF)
returnsClause
    : RETURNS AT_VAR? dataType
    ;

routineName
    : namePart (DOT namePart)?
    ;

namePart
    : BRACKET_ID
    | ID
    ;

paramBlock
    : LPAREN (param (COMMA param)*)? RPAREN
    | param (COMMA param)*
    ;

param
    : AT_VAR dataType (EQ defaultVal)? paramModifier*
    ;

// OUTPUT / OUT / READONLY (READONLY tokenises as ID)
paramModifier
    : OUTPUT
    | OUT
    | ID
    ;

// Permissive data type: (schema-qualified) name + optional balanced parenthesised spec.
// Covers INT, DECIMAL(18,2), NVARCHAR(MAX), hr.NewHireList,
// TABLE(Col INT, Col2 DECIMAL(18,2)) ...
dataType
    : (ID | BRACKET_ID) (DOT (ID | BRACKET_ID))? parenGroup?
    ;

// Balanced parenthesised group (handles nested parens).
parenGroup
    : LPAREN (parenGroup | ~(LPAREN | RPAREN))* RPAREN
    ;

defaultVal
    : literal
    | ID
    | MINUS INT_NUM
    | NULL_KW
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Routine body
// ─────────────────────────────────────────────────────────────────────────────

routineBody
    : beginEndBlock
    | statement*
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Statements
// ─────────────────────────────────────────────────────────────────────────────

statement
    : execStatement
    | declareStatement
    | setStatement
    | insertStatement
    | updateStatement
    | deleteStatement
    | selectStatement
    | ifStatement
    | whileStatement
    | tryBlock
    | transactionStatement
    | beginEndBlock
    | createStatement
    | returnStatement
    | otherStatement
    ;

// EXEC (@sql)                 → dynamic SQL
// EXEC schema.proc args...    → outbound call
execStatement
    : (EXEC | EXECUTE) LPAREN expr? RPAREN SEMI?
    | (EXEC | EXECUTE) routineName stmtTail SEMI?
    ;

// DECLARE @a INT, @b DECIMAL(18,2) = 0 ...   (one or more variables / table vars)
// DECLARE cur CURSOR ... FOR ...             (cursor — name is a plain identifier)
declareStatement
    : DECLARE declareItem (COMMA declareItem)* SEMI?
    | DECLARE ID stmtTail SEMI?
    ;

declareItem
    : AT_VAR dataType (EQ expr)?
    ;

// SET @x = expr | SET @x += expr | SET NOCOUNT ON | SET XACT_ABORT ON ...
setStatement
    : SET AT_VAR assignOp expr SEMI?
    | SET stmtTail SEMI?
    ;

assignOp
    : EQ
    | PLUS EQ
    | MINUS EQ
    | STAR EQ
    | SLASH EQ
    | PERCENT EQ
    ;

insertStatement
    : INSERT INTO? tableRef stmtTail SEMI?
    ;

updateStatement
    : UPDATE tableRef stmtTail SEMI?
    ;

deleteStatement
    : DELETE FROM? tableRef stmtTail SEMI?
    ;

selectStatement
    : SELECT stmtTail SEMI?
    ;

ifStatement
    : IF expr (beginEndBlock | statement) (ELSE (beginEndBlock | statement))?
    ;

whileStatement
    : WHILE expr (beginEndBlock | statement)
    ;

beginEndBlock
    : BEGIN statement* END
    ;

tryBlock
    : BEGIN TRY statement* END TRY BEGIN CATCH statement* END CATCH
    ;

// Transaction-control statements — must be matched before beginEndBlock so
// BEGIN TRAN is not mistaken for an (unterminated) BEGIN...END block.
transactionStatement
    : BEGIN (TRAN | TRANSACTION) ID? SEMI?
    | COMMIT (TRAN | TRANSACTION)? ID? SEMI?
    | ROLLBACK (TRAN | TRANSACTION)? ID? SEMI?
    | SAVE (TRAN | TRANSACTION) ID? SEMI?
    ;

// CREATE TABLE #temp( ... ), CREATE INDEX ... (inside a routine body)
createStatement
    : CREATE stmtTail SEMI?
    ;

// RETURN ( SELECT ... )   inline TVF body
// RETURN expr             scalar function / procedure
returnStatement
    : RETURN parenGroup SEMI?
    | RETURN expr? SEMI?
    ;

// Catch-all: any other statement (OPEN/FETCH/CLOSE/DEALLOCATE/PRINT/THROW/
// MERGE/WITH/WAITFOR/...). Consumes up to the next statement boundary.
otherStatement
    : ~(SEMI | BEGIN | END | EXEC | EXECUTE | DECLARE | SET | INSERT | UPDATE | DELETE | SELECT | IF | WHILE | RETURN | CREATE | TRY | CATCH | COMMIT | ROLLBACK)
      (~(SEMI | BEGIN | END))* SEMI?
    | SEMI
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Table reference  (schema.table or just table, brackets or plain ID)
// ─────────────────────────────────────────────────────────────────────────────

tableRef
    : AT_VAR
    | (BRACKET_ID | ID) (DOT (BRACKET_ID | ID))?
    ;

// ─────────────────────────────────────────────────────────────────────────────
// stmtTail — permissive rule that eats everything up to the next
// statement-starting keyword, semicolon, or unmatched END.
// Recursively handles balanced parentheses and CASE...END.
// ─────────────────────────────────────────────────────────────────────────────

stmtTail
    : stmtToken*
    ;

stmtToken
    : LPAREN stmtToken* RPAREN
    | CASE stmtToken* END
    | ~(SEMI | BEGIN | END | CASE | EXEC | EXECUTE | DECLARE | IF | WHILE | INSERT | UPDATE | DELETE | SELECT | RETURN | CREATE | LPAREN | RPAREN)
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Expression (simplified, enough to parse conditions and SET rhs)
// ─────────────────────────────────────────────────────────────────────────────

expr
    : exprAtom+
    ;

exprAtom
    : parenGroup                 // handles (a+b), function args, and (SELECT ...) subqueries
    | CASE stmtToken* END
    | literal
    | AT_VAR
    | AT_AT_VAR
    | BRACKET_ID
    | ID
    | UPDATE                     // T-SQL UPDATE(column) trigger function
    | STAR
    | DOT
    | EQ | NEQ | LT | GT | LEQ | GEQ | PLUS | MINUS | SLASH | PERCENT
    | AND | OR | NOT | IN | LIKE | IS | BETWEEN | EXISTS | NULL_KW | COMMA
    | AMPERSAND | PIPE | CARET | TILDE | EXCL
    ;

literal
    : SQ_STRING
    | N_STRING
    | INT_NUM
    | DEC_NUM
    | NULL_KW
    ;
