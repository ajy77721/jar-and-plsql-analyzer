package com.plsql.postgres.model;

import java.util.ArrayList;
import java.util.List;

public class PostgresRoutineInfo {

    public enum RoutineType { PROCEDURE, FUNCTION }

    private String       schema;
    private String       name;
    private RoutineType  type = RoutineType.PROCEDURE;
    private int          lineStart;
    private int          lineEnd;
    private List<PostgresParamInfo>      params     = new ArrayList<>();
    private List<PostgresVariableInfo>   variables  = new ArrayList<>();
    private List<PostgresCursorInfo>     cursors    = new ArrayList<>();
    private List<PostgresCallInfo>       calls      = new ArrayList<>();
    private List<PostgresTableOpInfo>    tableOps   = new ArrayList<>();
    private List<PostgresDynamicSqlInfo> dynamicSql = new ArrayList<>();
    private List<PostgresStatementInfo>  statements = new ArrayList<>();
    private List<PostgresSequenceInfo>   sequences  = new ArrayList<>();
    private List<PostgresExceptionHandlerInfo> exceptionHandlers = new ArrayList<>();
    private List<String>            errors     = new ArrayList<>();

    public String      getSchema()     { return schema; }
    public void        setSchema(String schema)         { this.schema = schema; }
    public String      getName()       { return name; }
    public void        setName(String name)             { this.name = name; }
    public RoutineType getType()       { return type; }
    public void        setType(RoutineType type)        { this.type = type; }
    public int         getLineStart()  { return lineStart; }
    public void        setLineStart(int lineStart)      { this.lineStart = lineStart; }
    public int         getLineEnd()    { return lineEnd; }
    public void        setLineEnd(int lineEnd)          { this.lineEnd = lineEnd; }

    public List<PostgresParamInfo>      getParams()     { return params; }
    public List<PostgresVariableInfo>   getVariables()  { return variables; }
    public List<PostgresCursorInfo>     getCursors()    { return cursors; }
    public List<PostgresCallInfo>       getCalls()      { return calls; }
    public List<PostgresTableOpInfo>    getTableOps()   { return tableOps; }
    public List<PostgresDynamicSqlInfo> getDynamicSql() { return dynamicSql; }
    public List<PostgresStatementInfo>  getStatements() { return statements; }
    public List<PostgresSequenceInfo>   getSequences()  { return sequences; }
    public List<PostgresExceptionHandlerInfo> getExceptionHandlers() { return exceptionHandlers; }
    public List<String>            getErrors()     { return errors; }
}
