package com.plsql.postgres.visitor;

import com.plsql.postgres.grammar.PostgresParser;
import com.plsql.postgres.grammar.PostgresParserBaseVisitor;
import com.plsql.postgres.model.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ANTLR4 visitor over the PostgresParser parse tree.
 *
 * Extracts:
 *   visitRoutineDefinition  → routine identity (name, schema, type, line range)
 *   visitParam              → parameter list (IN/OUT/INOUT, no @ prefix)
 *   visitDeclareVariableStmt → DECLARE variable
 *   visitDeclareCursorStmt  → DECLARE CURSOR [WITH HOLD] FOR select
 *   visitCallStatement      → CALL [schema.]name(args)
 *   visitInsertStatement    → INSERT table op
 *   visitUpdateStatement    → UPDATE table op
 *   visitDeleteStatement    → DELETE table op
 *   visitSelectStatement    → SELECT table op (scans stmtTail for FROM clause)
 *   visitPrepareStatement   → PREPARE stmt FROM source
 *   visitExecuteImmStmt     → EXECUTE IMMEDIATE source
 *   visitExecuteStatement   → EXECUTE stmt [USING args]
 */
public class PostgresAnalysisVisitor extends PostgresParserBaseVisitor<Void> {

    private final PostgresRoutineInfo result;

    /** CTE names declared via WITH — these are not base tables and must be skipped. */
    private final Set<String> cteNames = new HashSet<>();

    public PostgresAnalysisVisitor(String objectName, String schema) {
        this.result = new PostgresRoutineInfo();
        result.setName(objectName);
        result.setSchema(schema);
        result.setType(PostgresRoutineInfo.RoutineType.PROCEDURE);
    }

    public PostgresRoutineInfo getResult() {
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Routine identity
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitRoutineDefinition(PostgresParser.RoutineDefinitionContext ctx) {
        // Routine type: PROCEDURE or FUNCTION
        if (ctx.FUNCTION() != null) {
            result.setType(PostgresRoutineInfo.RoutineType.FUNCTION);
        } else {
            result.setType(PostgresRoutineInfo.RoutineType.PROCEDURE);
        }

        // routineName: (id DOT)? id
        PostgresParser.RoutineNameContext rnCtx = ctx.routineName();
        if (rnCtx != null) {
            List<PostgresParser.IdContext> ids = rnCtx.id();
            if (ids.size() == 2) {
                // schema.name
                result.setSchema(cleanId(ids.get(0).getText()));
                result.setName(cleanId(ids.get(1).getText()));
            } else if (ids.size() == 1) {
                result.setName(cleanId(ids.get(0).getText()));
            }
        }

        // Line range
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null
                ? ctx.getStop().getLine()
                : ctx.getStart().getLine());

        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Anonymous DO block — no routine identity to extract (DO has no name/params);
    // just record the line range and fall through to visitChildren so the body's
    // table ops/calls/cursors/exception-handlers are captured via the same paths
    // a routine body uses (bodyBlock is shared between the two grammar rules).
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDoStatement(PostgresParser.DoStatementContext ctx) {
        result.setLineStart(ctx.getStart().getLine());
        result.setLineEnd(ctx.getStop() != null ? ctx.getStop().getLine() : ctx.getStart().getLine());
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Parameters
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitParam(PostgresParser.ParamContext ctx) {
        PostgresParamInfo p = new PostgresParamInfo();

        // Direction: IN_KW / OUT_KW / INOUT
        if (ctx.INOUT() != null) {
            p.setDirection(PostgresParamInfo.Direction.INOUT);
        } else if (ctx.OUT_KW() != null) {
            p.setDirection(PostgresParamInfo.Direction.OUT);
        } else {
            p.setDirection(PostgresParamInfo.Direction.IN);
        }

        // Name (no @ prefix in POSTGRES)
        p.setName(cleanId(ctx.id().getText()));

        // Data type
        p.setDataType(ctx.dataType().getText());

        p.setLine(ctx.getStart().getLine());
        result.getParams().add(p);
        return null; // don't recurse — no nested params
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE variable
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareVariableStmt(PostgresParser.DeclareVariableStmtContext ctx) {
        String name = cleanId(ctx.id().getText());
        String dataType = ctx.dataType().getText();

        // Filter out handler keywords (CONTINUE/EXIT/UNDO HANDLER is a different rule,
        // but be defensive)
        if ("CONTINUE".equalsIgnoreCase(name) || "EXIT".equalsIgnoreCase(name)
                || "UNDO".equalsIgnoreCase(name)) {
            return null;
        }

        // Filter out CURSOR type (those are handled by declareCursorStmt)
        if ("CURSOR".equalsIgnoreCase(dataType)) {
            return null;
        }

        PostgresVariableInfo v = new PostgresVariableInfo();
        v.setName(name);
        v.setDataType(dataType);
        if (ctx.expr() != null) {
            v.setDefaultValue(ctx.expr().getText());
        }
        v.setLine(ctx.getStart().getLine());
        result.getVariables().add(v);
        return null; // no nested declares
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DECLARE cursor
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeclareCursorStmt(PostgresParser.DeclareCursorStmtContext ctx) {
        PostgresCursorInfo c = new PostgresCursorInfo();
        c.setName(cleanId(ctx.id(0).getText()));
        c.setWithHold(ctx.HOLD() != null);
        if (ctx.selectStatement() != null) {
            c.setSelectText(ctx.selectStatement().getText());
        }
        c.setLine(ctx.getStart().getLine());
        result.getCursors().add(c);
        // Visit children to catch table ops in the SELECT inside the cursor
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Cursor lifecycle: OPEN / FETCH / CLOSE
    //
    // DECLARE was the only operation ever recorded against a cursor — every c1 in the real corpus
    // showed operations:["DECLARE"] even though the source also does OPEN c1 / FETCH c1 INTO v_rec
    // in a loop / CLOSE c1. PL/pgSQL has no DEALLOCATE; CLOSE is the real terminal operation, so
    // none is synthesized here.
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitOpenStatement(PostgresParser.OpenStatementContext ctx) {
        recordCursorOp(ctx.id().getText(), "OPEN", ctx.getStart().getLine());
        return visitChildren(ctx);
    }

    @Override
    public Void visitFetchStatement(PostgresParser.FetchStatementContext ctx) {
        recordCursorOp(ctx.id().getText(), "FETCH", ctx.getStart().getLine());
        return visitChildren(ctx);
    }

    @Override
    public Void visitCloseStatement(PostgresParser.CloseStatementContext ctx) {
        recordCursorOp(ctx.id().getText(), "CLOSE", ctx.getStart().getLine());
        return visitChildren(ctx);
    }

    /** Attaches an OPEN/FETCH/CLOSE occurrence to the cursor of the same name in this routine. */
    private void recordCursorOp(String rawName, String kind, int line) {
        if (rawName == null) return;
        String name = cleanId(rawName);
        for (PostgresCursorInfo c : result.getCursors()) {
            if (c.getName() != null && c.getName().equalsIgnoreCase(name)) {
                c.getOperations().add(new PostgresCursorInfo.Op(kind, line));
                return;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CALL statement
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitCallStatement(PostgresParser.CallStatementContext ctx) {
        PostgresCallInfo call = new PostgresCallInfo();
        PostgresParser.RoutineNameContext rnCtx = ctx.routineName();
        if (rnCtx != null) {
            List<PostgresParser.IdContext> ids = rnCtx.id();
            if (ids.size() == 2) {
                call.setSchema(cleanId(ids.get(0).getText()));
                call.setName(cleanId(ids.get(1).getText()));
            } else if (ids.size() == 1) {
                call.setName(cleanId(ids.get(0).getText()));
            }
        }
        call.setLine(ctx.getStart().getLine());
        result.getCalls().add(call);
        return null; // don't recurse into args for more calls
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: INSERT
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitInsertStatement(PostgresParser.InsertStatementContext ctx) {
        PostgresTableOpInfo op = new PostgresTableOpInfo();
        op.setDmlType(PostgresTableOpInfo.DmlType.INSERT);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        populateReturningColumns(op, ctx.returningClause());
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: UPDATE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitUpdateStatement(PostgresParser.UpdateStatementContext ctx) {
        PostgresTableOpInfo op = new PostgresTableOpInfo();
        op.setDmlType(PostgresTableOpInfo.DmlType.UPDATE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        populateReturningColumns(op, ctx.returningClause());
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DML: DELETE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitDeleteStatement(PostgresParser.DeleteStatementContext ctx) {
        PostgresTableOpInfo op = new PostgresTableOpInfo();
        op.setDmlType(PostgresTableOpInfo.DmlType.DELETE);
        op.setTableName(extractTableName(ctx.tableRef()));
        op.setSchemaName(extractTableSchema(ctx.tableRef()));
        op.setLine(ctx.getStart().getLine());
        op.setSqlText(originalText(ctx));
        populateReturningColumns(op, ctx.returningClause());
        result.getTableOps().add(op);
        return visitChildren(ctx);
    }

    /** Fills {@code op.getReturningColumns()} from an optional RETURNING clause context. */
    private void populateReturningColumns(PostgresTableOpInfo op, PostgresParser.ReturningClauseContext rc) {
        if (rc == null) return;
        for (PostgresParser.ReturningItemContext item : rc.returningItem()) {
            op.getReturningColumns().add(item.getText());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SELECT — register CTE names up-front so their references are skipped, then
    // descend so FROM/JOIN contexts (incl. inside CTE bodies) are captured.
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitSelectStatement(PostgresParser.SelectStatementContext ctx) {
        if (ctx.withClause() != null) {
            for (PostgresParser.CteDefContext cte : ctx.withClause().cteDef()) {
                if (cte.id() != null) {
                    cteNames.add(cleanId(cte.id().getText()).toUpperCase());
                }
            }
        }
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FROM clause — base tables + joins (grammar contexts only, no text scanning)
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitFromClause(PostgresParser.FromClauseContext ctx) {
        for (PostgresParser.TableReferenceContext tr : ctx.tableReference()) {
            processTableReference(tr);
        }
        return visitChildren(ctx);   // recurse for nested subquery SELECTs / CTEs
    }

    /**
     * Walk one {@code tableReference} (a base tableAtom followed by zero or more
     * joinClauses). The base atom becomes a SELECT table op; each JOINed atom
     * becomes its own SELECT table op AND a PostgresJoinInfo attached to the base op.
     */
    private void processTableReference(PostgresParser.TableReferenceContext tr) {
        PostgresTableOpInfo baseOp = tableOpForAtom(tr.tableAtom());

        java.util.Map<String, String> aliasMap = buildAliasMap(tr);
        int queryId = tr.getStart().getLine();

        for (PostgresParser.JoinClauseContext jc : tr.joinClause()) {
            PostgresTableOpInfo joinedOp = tableOpForAtom(jc.tableAtom());
            if (baseOp == null) continue;

            if (jc.tableAtom() instanceof PostgresParser.AtomTableContext jat) {
                PostgresParser.TableRefContext jref = jat.tableRef();
                // A joined CTE ref yields no standalone table op (handled above) but the
                // JOIN relationship itself is still recorded on the base table.
                PostgresJoinInfo j = new PostgresJoinInfo();
                j.setJoinType(joinTypeText(jc.joinType()));
                j.setJoinedTable(extractTableName(jref));
                j.setJoinedTableSchema(extractTableSchema(jref));
                if (jat.id() != null) {
                    j.setJoinedTableAlias(cleanId(jat.id().getText()));
                }
                if (jc.expr() != null) {
                    j.setCondition(jc.expr().getText());
                }
                j.setLine(jc.getStart().getLine());
                j.setQueryId(queryId);
                resolveLeftSide(j, aliasMap);
                baseOp.getJoins().add(j);
            }
        }
    }

    /** Build alias->table (both upper-cased) for the base atom and each joined atom of a tableReference. */
    private java.util.Map<String, String> buildAliasMap(PostgresParser.TableReferenceContext tr) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        addAtomAlias(m, tr.tableAtom());
        for (PostgresParser.JoinClauseContext jc : tr.joinClause()) {
            addAtomAlias(m, jc.tableAtom());
        }
        return m;
    }

    private void addAtomAlias(java.util.Map<String, String> m, PostgresParser.TableAtomContext atom) {
        if (!(atom instanceof PostgresParser.AtomTableContext at)) return;
        String tbl = extractTableName(at.tableRef());
        if (tbl == null) return;
        tbl = tbl.toUpperCase();
        if (at.id() != null) m.put(cleanId(at.id().getText()).toUpperCase(), tbl);
        m.put(tbl, tbl);
    }

    /** Resolve leftTable/leftTableAlias from the ON-condition alias that is NOT the joined table. */
    private void resolveLeftSide(PostgresJoinInfo j, java.util.Map<String, String> aliasMap) {
        if (j.getCondition() == null) return;
        String joinedAlias = j.getJoinedTableAlias() != null ? j.getJoinedTableAlias().toUpperCase() : null;
        java.util.regex.Matcher mt = java.util.regex.Pattern
                .compile("([A-Za-z_][A-Za-z0-9_$#]*)\\s*\\.").matcher(j.getCondition());
        java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();
        while (mt.find()) seen.add(mt.group(1).toUpperCase());
        for (String a : seen) {
            if (joinedAlias != null && a.equals(joinedAlias)) continue;
            String t = aliasMap.get(a);
            if (t != null) { j.setLeftTableAlias(a); j.setLeftTable(t); return; }
        }
    }

    /**
     * Adds a SELECT table op for the given tableAtom and returns it (null for a CTE
     * reference or a subquery atom, whose inner SELECT is handled by recursion).
     */
    private PostgresTableOpInfo tableOpForAtom(PostgresParser.TableAtomContext atom) {
        // A set-returning function used as a table source (FROM fn(...)) is NOT a table — it is a
        // routine invocation. Return null here; the call edge is captured by visitFunctionCall
        // when visitFromClause descends via visitChildren.
        if (atom instanceof PostgresParser.AtomFuncContext) {
            return null;
        }
        if (atom instanceof PostgresParser.AtomTableContext at) {
            if (isCte(at.tableRef())) return null;
            PostgresTableOpInfo op = new PostgresTableOpInfo();
            op.setDmlType(PostgresTableOpInfo.DmlType.SELECT);
            op.setTableName(extractTableName(at.tableRef()));
            op.setSchemaName(extractTableSchema(at.tableRef()));
            if (at.id() != null) op.setAlias(cleanId(at.id().getText()));
            op.setLine(at.getStart().getLine());
            // Without this a SELECT carried no SQL, so no column detail could be derived from it.
            op.setSqlText(enclosingStatementText(at));
            result.getTableOps().add(op);
            return op;
        }
        if (atom instanceof PostgresParser.AtomParenContext paren) {
            PostgresTableOpInfo first = null;
            for (PostgresParser.TableReferenceContext tr : paren.tableReference()) {
                processTableReference(tr);
                if (first == null && !result.getTableOps().isEmpty()) {
                    first = result.getTableOps().get(result.getTableOps().size() - 1);
                }
            }
            return first;
        }
        return null;   // AtomSubquery — inner SELECT handled by visitChildren recursion
    }

    private boolean isCte(PostgresParser.TableRefContext tr) {
        if (tr == null) return false;
        String schema = extractTableSchema(tr);
        String name = extractTableName(tr);
        return schema == null && name != null && cteNames.contains(name.toUpperCase());
    }

    /** Render a joinType context as spaced upper-case text (e.g. "LEFT OUTER"), or "JOIN" if absent. */
    private String joinTypeText(PostgresParser.JoinTypeContext jt) {
        if (jt == null) return "JOIN";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < jt.getChildCount(); i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(jt.getChild(i).getText().toUpperCase());
        }
        return sb.length() == 0 ? "JOIN" : sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Function calls inside expressions — user-routine invocations (call-tree)
    // ─────────────────────────────────────────────────────────────────────────

    /** Common POSTGRES built-in functions to exclude — only user-routine calls become edges. */
    private static final Set<String> BUILTIN_FUNCTIONS = Set.of(
        "ABS","ACOS","ASCII","ASIN","ATAN","ATAN2","AVG","BIGINT","CARDINALITY",
        "CEIL","CEILING","CHAR","CHARACTER_LENGTH","CHR","COALESCE","CONCAT","CORR",
        "COS","COSH","COT","COUNT","COUNT_BIG","COVARIANCE","CURRENT_DATE","CURRENT_TIME",
        "CURRENT_TIMESTAMP","DATE","DAY","DAYNAME","DAYOFWEEK","DAYOFYEAR","DAYS","DEC",
        "DECIMAL","DECODE","DEGREES","DIGITS","DOUBLE","EXP","FLOAT","FLOOR","GREATEST",
        "HASH","HEX","HOUR","IFNULL","INSERT","INT","INTEGER","JULIAN_DAY","LCASE","LEAST",
        "LEFT","LENGTH","LN","LOCATE","LOG","LOG10","LOWER","LPAD","LTRIM","MAX","MICROSECOND",
        "MIDNIGHT_SECONDS","MIN","MINUTE","MOD","MONTH","MONTHNAME","NULLIF","NVL","POSITION",
        "POSSTR","POWER","QUARTER","RADIANS","RAISE_ERROR","RAND","REAL","REPEAT","REPLACE",
        "RIGHT","ROUND","RPAD","RTRIM","SECOND","SIGN","SIN","SINH","SMALLINT","SOUNDEX",
        "SPACE","SQRT","STDDEV","SUBSTR","SUBSTRING","SUM","TAN","TANH","TIME","TIMESTAMP",
        "TIMESTAMPDIFF","TIMESTAMP_FORMAT","TO_CHAR","TO_DATE","TRANSLATE","TRIM","TRUNC",
        "TRUNCATE","UCASE","UPPER","VALUE","VARCHAR","VARIANCE","WEEK","YEAR",
        // Special/register built-ins (otherwise mis-read as user routine calls).
        // NOTE: window functions (ROW_NUMBER/RANK/DENSE_RANK) and VARCHAR_FORMAT deliberately
        // excluded — they are higher-collision with real user-routine names and were not
        // observed as false-positive call nodes.
        "IDENTITY_VAL_LOCAL","LAST_INSERT_ID","PREVVAL","GENERATE_UNIQUE",
        "CURRENT_SCHEMA","CURRENT_USER","SESSION_USER","SYSTEM_USER","INTNAND","MAX_CARDINALITY",
        // PostgreSQL built-ins (array / JSON / string / config / time / set-returning) — these are
        // engine functions, not user routines, so they must not be crawled as call nodes.
        "ARRAY_LENGTH","ARRAY_AGG","ARRAY_APPEND","ARRAY_CAT","ARRAY_TO_STRING","STRING_TO_ARRAY",
        "ARRAY_POSITION","ARRAY_REMOVE","ARRAY_REPLACE","UNNEST","GENERATE_SERIES",
        "TO_JSONB","TO_JSON","JSONB_BUILD_OBJECT","JSONB_BUILD_ARRAY","JSON_BUILD_OBJECT","JSON_BUILD_ARRAY",
        "JSONB_AGG","JSON_AGG","JSONB_OBJECT_AGG","ROW_TO_JSON","JSONB_SET","JSONB_PRETTY",
        "JSONB_EACH","JSONB_ARRAY_ELEMENTS","JSONB_EXTRACT_PATH","JSONB_EXTRACT_PATH_TEXT","JSONB_TYPEOF",
        "CURRENT_SETTING","SET_CONFIG","PG_TYPEOF","PG_GET_FUNCTIONDEF",
        "NOW","CLOCK_TIMESTAMP","STATEMENT_TIMESTAMP","TRANSACTION_TIMESTAMP","AGE","DATE_TRUNC","DATE_PART","EXTRACT",
        "STRING_AGG","CONCAT_WS","SPLIT_PART","REGEXP_REPLACE","REGEXP_MATCHES","REGEXP_SPLIT_TO_ARRAY",
        "INITCAP","MD5","ENCODE","FORMAT","QUOTE_IDENT","QUOTE_LITERAL","QUOTE_NULLABLE",
        "ROW_NUMBER","RANK","DENSE_RANK","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTILE","PERCENT_RANK","CUME_DIST",
        "BOOL_AND","BOOL_OR","EVERY","MODE","PERCENTILE_CONT","PERCENTILE_DISC",
        // --- Expanded authoritative PostgreSQL built-in coverage (deduped against all above) ---
        // String / text
        "BTRIM","STRPOS","REGEXP_MATCH","REGEXP_SPLIT_TO_TABLE","TO_ASCII","CONVERT",
        "CONVERT_FROM","CONVERT_TO","REVERSE","OVERLAY","PARSE_IDENT","STARTS_WITH",
        "TO_HEX","NORMALIZE","UNISTR","QUOTE","BIT_LENGTH","OCTET_LENGTH","CHAR_LENGTH",
        // Math
        "CBRT","DIV","PI","RANDOM","SETSEED","GCD","LCM","WIDTH_BUCKET","LOG2","FACTORIAL",
        "ACOSD","ASIND","ATAND","ATAN2D","COSD","COTD","SIND","TAND","ACOSH","ASINH","ATANH",
        "SCALE","MIN_SCALE","TRIM_SCALE",
        // Date / time
        "LOCALTIME","LOCALTIMESTAMP","MAKE_DATE","MAKE_TIME","MAKE_TIMESTAMP","MAKE_TIMESTAMPTZ",
        "MAKE_INTERVAL","TO_TIMESTAMP","TO_NUMBER","JUSTIFY_DAYS","JUSTIFY_HOURS","JUSTIFY_INTERVAL",
        "ISFINITE","TIMEOFDAY","DATE_BIN",
        // Aggregate / statistical
        "STDDEV_POP","STDDEV_SAMP","VAR_POP","VAR_SAMP","VARIANCE_POP","COVAR_POP","COVAR_SAMP",
        "BIT_AND","BIT_OR","BIT_XOR","XMLAGG","RANGE_AGG","RANGE_INTERSECT_AGG",
        "REGR_SLOPE","REGR_INTERCEPT","REGR_COUNT","REGR_R2","REGR_AVGX","REGR_AVGY",
        "REGR_SXX","REGR_SYY","REGR_SXY",
        // Array
        "ARRAY_PREPEND","ARRAY_POSITIONS","ARRAY_DIMS","ARRAY_UPPER","ARRAY_LOWER",
        "ARRAY_NDIMS","ARRAY_FILL","TRIM_ARRAY",
        // JSON / JSONB
        "JSONB_INSERT","JSONB_STRIP_NULLS","JSON_TYPEOF","JSONB_ARRAY_ELEMENTS_TEXT",
        "JSON_ARRAY_ELEMENTS","JSON_ARRAY_ELEMENTS_TEXT","JSONB_EACH_TEXT","JSON_EACH","JSON_EACH_TEXT",
        "JSONB_OBJECT_KEYS","JSON_OBJECT_KEYS","JSONB_ARRAY_LENGTH","JSON_ARRAY_LENGTH",
        "JSON_OBJECT","JSONB_OBJECT","JSON_EXTRACT_PATH","JSON_EXTRACT_PATH_TEXT",
        "JSONB_PATH_QUERY","JSONB_PATH_EXISTS","JSONB_PATH_MATCH","JSONB_PATH_QUERY_ARRAY",
        "JSONB_PATH_QUERY_FIRST","JSONB_POPULATE_RECORD","JSON_POPULATE_RECORD",
        "JSON_STRIP_NULLS","JSONB_CONTAINED",
        // Set-returning
        "GENERATE_SUBSCRIPTS",
        // Sequence functions (NEXTVAL/CURRVAL/SETVAL/LASTVAL) are deliberately NOT excluded here —
        // visitFunctionCall intercepts them first and records a PostgresSequenceInfo instead of
        // letting them fall through to (or be discarded by) this generic builtin-exclusion path.
        // Bit / encoding / binary
        "GET_BIT","SET_BIT","GET_BYTE","SET_BYTE",
        // System / catalog / info
        "CURRENT_SCHEMAS","CURRENT_DATABASE","CURRENT_CATALOG","VERSION","PG_BACKEND_PID",
        "TXID_CURRENT","TXID_CURRENT_SNAPSHOT","INET_CLIENT_ADDR","INET_SERVER_ADDR",
        "OBJ_DESCRIPTION","COL_DESCRIPTION","SHOBJ_DESCRIPTION","CURRENT_QUERY","PG_SLEEP",
        "PG_COLUMN_SIZE","PG_SIZE_PRETTY","PG_DATABASE_SIZE","PG_TABLE_SIZE","PG_RELATION_SIZE",
        "PG_TOTAL_RELATION_SIZE","PG_GET_VIEWDEF","PG_GET_INDEXDEF","PG_GET_CONSTRAINTDEF",
        "PG_GET_EXPR","PG_GET_SERIAL_SEQUENCE","PG_GET_USERBYID","HAS_TABLE_PRIVILEGE",
        "HAS_SCHEMA_PRIVILEGE","HAS_COLUMN_PRIVILEGE","PG_NOTIFY","PG_CANCEL_BACKEND",
        "PG_TERMINATE_BACKEND");

    /** Sequence functions Postgres invokes as regular function calls (not Oracle's dot-syntax). */
    private static final Set<String> SEQUENCE_FUNCTIONS = Set.of("NEXTVAL", "CURRVAL", "SETVAL", "LASTVAL");

    @Override
    public Void visitFunctionCall(PostgresParser.FunctionCallContext ctx) {
        List<PostgresParser.IdContext> ids = ctx.id();
        String schema = ids.size() > 1 ? cleanId(ids.get(0).getText()) : null;
        String name   = cleanId(ids.get(ids.size() - 1).getText());

        if (name != null && schema == null && SEQUENCE_FUNCTIONS.contains(name.toUpperCase())) {
            recordSequenceUsage(name.toUpperCase(), ctx);
            return visitChildren(ctx);
        }

        if (name != null && (schema != null || !BUILTIN_FUNCTIONS.contains(name.toUpperCase()))) {
            String qualified = (schema != null && !schema.isBlank()) ? schema + "." + name : name;
            boolean dup = result.getCalls().stream()
                    .anyMatch(c -> qualified.equalsIgnoreCase(c.qualifiedName()));
            if (!dup) {
                PostgresCallInfo call = new PostgresCallInfo();
                call.setName(name);
                call.setSchema(schema);
                call.setLine(ctx.getStart().getLine());
                result.getCalls().add(call);
            }
        }
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: PREPARE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitPrepareStatement(PostgresParser.PrepareStatementContext ctx) {
        PostgresDynamicSqlInfo d = new PostgresDynamicSqlInfo();
        d.setKind(PostgresDynamicSqlInfo.Kind.PREPARE);

        // PREPARE id FROM (id | SQ_STRING)
        List<PostgresParser.IdContext> ids = ctx.id();
        if (!ids.isEmpty()) {
            d.setStmtName(cleanId(ids.get(0).getText()));
        }
        if (ids.size() > 1) {
            // Second id is the source variable
            d.setSqlSource(cleanId(ids.get(1).getText()));
        } else if (ctx.SQ_STRING() != null) {
            d.setSqlSource(ctx.SQ_STRING().getText());
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: EXECUTE IMMEDIATE
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExecuteImmStmt(PostgresParser.ExecuteImmStmtContext ctx) {
        PostgresDynamicSqlInfo d = new PostgresDynamicSqlInfo();
        d.setKind(PostgresDynamicSqlInfo.Kind.EXECUTE_IMMEDIATE);

        if (ctx.id() != null) {
            d.setSqlSource(cleanId(ctx.id().getText()));
        } else if (ctx.SQ_STRING() != null) {
            d.setSqlSource(ctx.SQ_STRING().getText());
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dynamic SQL: EXECUTE stmt [USING ...]
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExecuteStatement(PostgresParser.ExecuteStatementContext ctx) {
        PostgresDynamicSqlInfo d = new PostgresDynamicSqlInfo();
        d.setKind(PostgresDynamicSqlInfo.Kind.EXECUTE);

        // EXECUTE <expr> [INTO ids] [USING …] — the first expr is the (dynamic) SQL text/expression,
        // e.g. a string literal or a format(...) call. Captured via the original source interval
        // (not expr(0).getText(), which ANTLR renders with whitespace stripped between tokens) so
        // the real EXECUTE format('SELECT count(*) FROM erp.%I', v_tab) text survives verbatim —
        // this was previously dropped entirely (stored only under stmtName, which nothing reads).
        List<PostgresParser.ExprContext> exprs = ctx.expr();
        if (exprs != null && !exprs.isEmpty()) {
            String exprText = sourceTextOf(exprs.get(0));
            d.setStmtName(cleanId(exprs.get(0).getText()));
            d.setSqlSource(exprText);
            // Any expr()s after the first are the USING-bound values.
            for (int i = 1; i < exprs.size(); i++) {
                d.getUsingExprs().add(sourceTextOf(exprs.get(i)));
            }
        }

        d.setLine(ctx.getStart().getLine());
        result.getDynamicSql().add(d);
        return null;
    }

    /**
     * Records a {@code nextval('seq')}/{@code currval('seq')}/{@code setval('seq', n)}/
     * {@code lastval()} invocation. The sequence name is the first argument's string-literal
     * text (quotes and schema-dot preserved as written); {@code lastval()} takes no argument.
     */
    private void recordSequenceUsage(String op, PostgresParser.FunctionCallContext ctx) {
        PostgresSequenceInfo seq = new PostgresSequenceInfo();
        seq.setOperation(PostgresSequenceInfo.Operation.valueOf(op));
        seq.setLine(ctx.getStart().getLine());

        String seqName = null;
        PostgresParser.FunctionArgsContext argsCtx = ctx.functionArgs();
        if (argsCtx != null && argsCtx.expr() != null && !argsCtx.expr().isEmpty()) {
            String raw = argsCtx.expr(0).getText();
            if (raw.length() >= 2 && raw.startsWith("'") && raw.endsWith("'")) {
                raw = raw.substring(1, raw.length() - 1);
            }
            seqName = raw;
        }
        seq.setSequenceName(seqName);
        result.getSequences().add(seq);
    }

    /** Verbatim original source text of a parse-tree node's interval, whitespace and all. */
    private String sourceTextOf(org.antlr.v4.runtime.ParserRuleContext ctx) {
        if (ctx == null || ctx.getStart() == null || ctx.getStop() == null) return null;
        org.antlr.v4.runtime.misc.Interval interval = new org.antlr.v4.runtime.misc.Interval(
                ctx.getStart().getStartIndex(), ctx.getStop().getStopIndex());
        return ctx.getStart().getInputStream().getText(interval);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Transaction-control statements → StatementInfo (COMMIT / ROLLBACK / SAVEPOINT)
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitTxnCommit(PostgresParser.TxnCommitContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("COMMIT", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnRollback(PostgresParser.TxnRollbackContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("ROLLBACK", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnRollbackTo(PostgresParser.TxnRollbackToContext ctx) {
        PostgresStatementInfo si = new PostgresStatementInfo("ROLLBACK", ctx.getStart().getLine());
        si.setSavepointName(cleanId(ctx.id().getText()));
        result.getStatements().add(si);
        return visitChildren(ctx);
    }

    @Override
    public Void visitTxnSavepoint(PostgresParser.TxnSavepointContext ctx) {
        PostgresStatementInfo si = new PostgresStatementInfo("SAVEPOINT", ctx.getStart().getLine());
        si.setSavepointName(cleanId(ctx.id().getText()));
        result.getStatements().add(si);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Control-flow / query-shape statements → StatementInfo
    // Each override records ONE statement record per occurrence and still calls
    // visitChildren so nested constructs (and existing capture of calls, table
    // ops, cursors, transactions) are preserved.
    // ─────────────────────────────────────────────────────────────────────────

    /** IF … THEN … [ELSEIF …] [ELSE …] END IF */
    @Override
    public Void visitIfStatement(PostgresParser.IfStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("IF", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /** CASE [expr] WHEN … THEN … [ELSE …] END CASE (statement form). */
    @Override
    public Void visitCaseStatement(PostgresParser.CaseStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("CASE", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /** WHILE expr (DO | LOOP) body END (WHILE | LOOP) */
    @Override
    public Void visitWhileStatement(PostgresParser.WhileStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("WHILE_LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * FOR loop — all forms (DB2 cursor-FOR, PL/pgSQL FOR rec IN <query> LOOP,
     * PL/pgSQL FOR i IN a..b LOOP). Hooked on the forStatement rule itself so the
     * opaque forExprTail handling does not affect detection.
     */
    @Override
    public Void visitForStatement(PostgresParser.ForStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("FOR_LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /** Plain LOOP … END LOOP */
    @Override
    public Void visitLoopStatement(PostgresParser.LoopStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("LOOP", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * Subquery — a parenthesized SELECT used as a table source
     * ( "( SELECT … ) AS alias" in a FROM/JOIN). This is the grammar's dedicated
     * subquery context (tableAtom # atomSubquery); one record per nested SELECT.
     */
    @Override
    public Void visitAtomSubquery(PostgresParser.AtomSubqueryContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("SUBQUERY", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * CTE — each common-table-expression definition inside a WITH clause
     * ( "name AS ( SELECT … )" ). One record per defined CTE.
     */
    @Override
    public Void visitCteDef(PostgresParser.CteDefContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("CTE", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * Subquery — a parenthesized SELECT used in an expression / WHERE / IN / EXISTS
     * ( "( SELECT … )" ) via the dedicated {@code subquery} grammar rule. One record
     * per nested SELECT; descends so inner table ops / calls are still captured.
     */
    @Override
    public Void visitSubquery(PostgresParser.SubqueryContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("SUBQUERY", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * MERGE … (PG15+ upsert-by-match). One record per MERGE statement; descends so
     * any USING (SELECT …) subquery and nested table ops are still captured.
     */
    @Override
    public Void visitMergeStatement(PostgresParser.MergeStatementContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("MERGE", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    /**
     * INSERT … ON CONFLICT … (upsert). Emitted from the onConflictClause so it is
     * recorded once per upsert, in addition to the enclosing INSERT table op.
     */
    @Override
    public Void visitOnConflictClause(PostgresParser.OnConflictClauseContext ctx) {
        result.getStatements().add(new PostgresStatementInfo("UPSERT", ctx.getStart().getLine()));
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Exception handler: EXCEPTION WHEN cond [OR cond]* THEN <stmts>
    // Statements inside are visited normally via visitChildren (still land in the flat
    // statement/call/table-op lists) — this override only adds the handler-level record.
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public Void visitExceptionHandler(PostgresParser.ExceptionHandlerContext ctx) {
        PostgresExceptionHandlerInfo eh = new PostgresExceptionHandlerInfo();
        eh.setLine(ctx.getStart().getLine());
        eh.setLineEnd(ctx.getStop() != null ? ctx.getStop().getLine() : ctx.getStart().getLine());

        List<String> names = new java.util.ArrayList<>();
        for (PostgresParser.HandlerCondContext hc : ctx.handlerCond()) {
            names.add(cleanId(hc.getText()));
        }
        eh.setExceptionName(String.join(" OR ", names));
        eh.setStatementsCount(ctx.statement() != null ? ctx.statement().size() : 0);

        result.getExceptionHandlers().add(eh);
        return visitChildren(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String cleanId(String s) {
        if (s == null) return null;
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    private String extractTableName(PostgresParser.TableRefContext ctx) {
        if (ctx == null) return null;
        List<PostgresParser.IdContext> ids = ctx.id();
        if (ids.isEmpty()) return null;
        // Last id is the table name
        return cleanId(ids.get(ids.size() - 1).getText());
    }

    private String extractTableSchema(PostgresParser.TableRefContext ctx) {
        if (ctx == null) return null;
        List<PostgresParser.IdContext> ids = ctx.id();
        if (ids.size() > 1) {
            return cleanId(ids.get(0).getText());
        }
        return null;
    }

    /**
     * The full SQL of the statement starting at this context.
     *
     * <p>Extends to the statement terminator rather than to {@code ctx.getStop()}. This dialect's
     * grammar rule for a DML statement ends before the {@code SET}/{@code WHERE} clauses, so the
     * context's own interval yielded only {@code "UPDATE orders"} — which parses to nothing useful
     * and produced no column detail at all. Verified against the alternative: SQL Server's rule
     * does span the whole statement and worked, which is what made the truncation visible here.
     *
     * <p>Quotes are tracked so a semicolon inside a string literal does not end the statement
     * early.
     */

    /**
     * The source text of the statement enclosing {@code ctx}.
     *
     * <p>A SELECT's table op is built from a table reference inside the FROM clause, which knows
     * nothing about the statement around it — so it carried no SQL at all, and the column enricher
     * had nothing to work from. Measured before this: DB2 2,732 and PostgreSQL 2,392 statements with
     * no {@code sqlText}, every one a SELECT, which is why those two dialects showed almost no
     * column detail while MySQL (which already had this helper) showed 3,450.
     *
     * <p>Walks up to the nearest context whose name ends in {@code StatementContext} or
     * {@code StmtContext}, which is the naming convention every grammar here follows.
     */
    private String enclosingStatementText(org.antlr.v4.runtime.ParserRuleContext ctx) {
        org.antlr.v4.runtime.ParserRuleContext c = ctx;
        org.antlr.v4.runtime.ParserRuleContext bestSelect = null;
        org.antlr.v4.runtime.ParserRuleContext stmt = null;
        while (c != null) {
            String n = c.getClass().getSimpleName();
            // Prefer the outermost SELECT over the statement wrapping it.
            //
            // PL/pgSQL and SQL PL wrap reads in control flow — `FOR rec IN SELECT ... LOOP`. Walking
            // straight to the enclosing StatementContext captured the loop, so the text handed to
            // the ANSI parser ended in a bare `LOOP` and failed. Measured: 979 PostgreSQL statements
            // captured-but-unparseable, every one of that shape. Taking the outermost Select keeps
            // the joins and WHERE (which is where the column detail lives) and stops before the
            // control-flow keyword.
            if (n.contains("Select") || n.contains("QuerySpec")) bestSelect = c;
            else if (n.endsWith("StatementContext") || n.endsWith("StmtContext")) { stmt = c; break; }
            c = c.getParent();
        }
        org.antlr.v4.runtime.ParserRuleContext pick = bestSelect != null ? bestSelect : stmt;
        return pick != null ? cutAtStatementEnd(trimTrailingBlockKeyword(originalText(pick))) : null;
    }


    /**
     * Cuts the text at the first unquoted semicolon.
     *
     * <p>A grammar context can span more than one statement, and the captured text then reads
     * {@code SELECT COUNT(*) INTO v_n FROM erp.erp_product; CALL erp.erp_usp_write_audit_trail(...)}.
     * ANSI parsing sees two statements and yields nothing for either, so a read with perfectly
     * ordinary columns and predicates came back empty — 1,223 PostgreSQL statements of exactly that
     * shape, all of which had parsed "successfully" while producing no detail.
     *
     * <p>Quote-aware because a semicolon inside a literal is data, not a terminator; cutting there
     * would truncate mid-string and turn a parseable statement into an unparseable one.
     */
    private String cutAtStatementEnd(String sql) {
        if (sql == null) return null;
        char quote = 0;
        for (int i = 0; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0;
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (c == ';') {
                return sql.substring(0, i).stripTrailing();
            }
        }
        return sql;
    }
    /**
     * Strips a trailing block keyword the grammar may have included.
     *
     * <p>Belt and braces for the case above: even with the Select preferred, a grammar rule can end
     * on {@code LOOP}/{@code THEN}/{@code DO}, and one stray keyword makes the whole statement
     * unparseable — losing all of its column detail rather than part of it.
     */
    private String trimTrailingBlockKeyword(String sql) {
        if (sql == null) return null;
        String s = sql.stripTrailing();
        for (String kw : new String[]{"LOOP", "THEN", "DO", "BEGIN"}) {
            if (s.length() > kw.length()) {
                String tail = s.substring(s.length() - kw.length());
                if (tail.equalsIgnoreCase(kw)
                        && Character.isWhitespace(s.charAt(s.length() - kw.length() - 1))) {
                    s = s.substring(0, s.length() - kw.length()).stripTrailing();
                }
            }
        }
        return s;
    }

    /**
     * True when the word at {@code [from, to]} is a keyword that must end a captured statement.
     *
     * <p>Restricted to {@code LOOP} and {@code BEGIN}: neither can appear inside a SQL expression,
     * so cutting at one can never truncate a valid statement. See the caller for why {@code THEN}
     * and {@code END} are excluded despite also ending blocks.
     */
    /**
     * Delegates to {@link com.plsql.dialect.StatementTextCapture}.
     *
     * <p>This method used to be a byte-identical copy of the DB2/PostgreSQL sibling, and
     * both copies carried the same two defects — running into a loop body, and closing a
     * parenthesis never opened — which then had to be found and fixed twice. Sharing it is
     * the point: the next fix lands in one place.
     */
    private String originalText(org.antlr.v4.runtime.ParserRuleContext ctx) {
        return com.plsql.dialect.StatementTextCapture.capture(
                ctx, com.plsql.dialect.StatementTextCapture.DEFAULT_BLOCK_KEYWORDS);
    }
}
