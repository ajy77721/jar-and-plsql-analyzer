package com.plsql.postgres.engine;

import com.plsql.postgres.grammar.PostgresLexer;
import com.plsql.postgres.grammar.PostgresParser;
import com.plsql.postgres.model.*;
import com.plsql.postgres.visitor.PostgresAnalysisVisitor;
import com.plsql.postgres.visitor.PostgresParseErrorListener;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Entry point for IBM POSTGRES SQL PL analysis (ANTLR4-based).
 *
 * Returns a self-contained PostgresRoutineInfo — no dependency on the
 * plsql-parser module. The caller (PostgresProcedureParser in plsql-parser)
 * converts the result to the shared ParseResult model.
 *
 * Flow:
 *   source text
 *     → PostgresLexer  (ANTLR4 lexer from PostgresLexer.g4)
 *     → PostgresParser (ANTLR4 parser from PostgresParser.g4)
 *     → PostgresAnalysisVisitor (extract calls, table ops, variables, dynamic SQL)
 *     → PostgresRoutineInfo
 */
public class PostgresAnalysisEngine {

    private static final Logger log = LoggerFactory.getLogger(PostgresAnalysisEngine.class);

    /**
     * Parse a single POSTGRES PROCEDURE or FUNCTION source.
     *
     * @param source     full CREATE PROCEDURE / FUNCTION DDL text
     * @param objectName fallback name used when grammar cannot resolve it
     * @param schema     owner / database schema
     */
    public PostgresRoutineInfo parse(String source, String objectName, String schema) {
        PostgresRoutineInfo result = new PostgresRoutineInfo();
        result.setName(objectName);
        result.setSchema(schema);
        result.setType(PostgresRoutineInfo.RoutineType.PROCEDURE);

        try {
            PostgresParseErrorListener errors = new PostgresParseErrorListener();

            // PL/pgSQL routines are wrapped as: CREATE ... LANGUAGE plpgsql AS $tag$ <body> $tag$.
            // Strip that wrapper (blank-in-place so line numbers stay correct) to expose the
            // DECLARE/BEGIN…END body the block-structured grammar understands.
            String parseSrc = preprocess(source);

            // Lex
            CharStream chars = CharStreams.fromString(parseSrc);
            PostgresLexer lexer = new PostgresLexer(chars);
            lexer.removeErrorListeners();
            lexer.addErrorListener(errors);

            // Parse
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            PostgresParser parser = new PostgresParser(tokens);
            parser.removeErrorListeners();
            parser.addErrorListener(errors);

            ParseTree tree = parser.compilationUnit();

            // Visit
            PostgresAnalysisVisitor visitor = new PostgresAnalysisVisitor(objectName, schema);
            visitor.visit(tree);

            result = visitor.getResult();
            result.getErrors().addAll(errors.getErrors());

            // Ensure line numbers are set
            result.setLineStart(1);
            if (result.getLineEnd() == 0) {
                result.setLineEnd(countLines(source));
            }

            if (errors.hasErrors()) {
                log.debug("PostgresAnalysisEngine: {} syntax error(s) in {}",
                        errors.getErrors().size(), objectName);
            }

        } catch (Exception e) {
            log.warn("PostgresAnalysisEngine failure on {}: {}", objectName, e.getMessage(), e);
            result.getErrors().add("Parse error: " + e.getMessage());
        }

        return result;
    }

    /**
     * Strip the PL/pgSQL dollar-quote wrapper in place, preserving every newline so line
     * numbers in the analysis still match the original source. Removes
     *   "... LANGUAGE plpgsql AS $tag$"  (prefix)  and  the closing "$tag$ ..."  (suffix),
     * leaving "CREATE [OR REPLACE] PROC/FUNC name(params) [RETURNS t]  <DECLARE…BEGIN…END>".
     * If no dollar-quoted body is found the source is returned unchanged (already block form).
     */
    String preprocess(String source) {
        if (source == null) return null;
        Matcher m = Pattern.compile("\\$[A-Za-z0-9_]*\\$").matcher(source);
        if (!m.find()) return source;                 // not a $-quoted PL/pgSQL body
        String tag = m.group();
        int openStart = m.start(), openEnd = m.end();
        int closeStart = source.indexOf(tag, openEnd);
        if (closeStart < 0) return source;            // unbalanced — leave as-is

        String upper = source.toUpperCase();
        int wrapStart = lastKeywordBefore(upper, "LANGUAGE", openStart);
        if (wrapStart < 0) wrapStart = lastKeywordBefore(upper, "AS", openStart);
        if (wrapStart < 0) wrapStart = openStart;

        char[] c = source.toCharArray();
        blank(c, wrapStart, openEnd);                 // remove "LANGUAGE plpgsql AS $tag$"
        blank(c, closeStart, c.length);               // remove closing "$tag$" + trailing
        return new String(c);
    }

    /** Replace [from,to) with spaces, keeping line breaks so offsets/lines are preserved. */
    private void blank(char[] c, int from, int to) {
        for (int i = Math.max(0, from); i < to && i < c.length; i++) {
            if (c[i] != '\n' && c[i] != '\r') c[i] = ' ';
        }
    }

    /** Last whole-word occurrence of kw at or before `before`, else -1. */
    private int lastKeywordBefore(String upper, String kw, int before) {
        int idx = -1, at = 0;
        while ((at = upper.indexOf(kw, at)) >= 0 && at < before) {
            if (isKeywordAt(upper, at, kw)) idx = at;
            at++;
        }
        return idx;
    }

    /**
     * Extract the body text between the outermost BEGIN...END block.
     * Returns null if no BEGIN keyword is found.
     * Used by tests and external callers expecting the raw body text.
     *
     * Handles compound END keywords (END IF, END WHILE, END FOR, END LOOP,
     * END CASE, END REPEAT) — these do not count as END block closers.
     */
    public String extractBody(String source) {
        if (source == null) return null;
        String upper = source.toUpperCase();
        int beginIdx = indexOfKeyword(upper, "BEGIN", 0);
        if (beginIdx < 0) return null;
        int depth = 0;
        int i = beginIdx;
        while (i < upper.length()) {
            if (isKeywordAt(upper, i, "BEGIN")) {
                depth++;
                i += 5;
            } else if (isKeywordAt(upper, i, "END")) {
                if (!isCompoundEnd(upper, i)) {
                    depth--;
                    if (depth == 0) return source.substring(beginIdx + 5, i).trim();
                }
                i += 3;
            } else {
                i++;
            }
        }
        return source.substring(beginIdx + 5).trim();
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    /**
     * Returns true when "END" at idx is followed by a compound keyword
     * (IF, WHILE, FOR, LOOP, CASE, REPEAT) — meaning it's not a block closer.
     */
    private boolean isCompoundEnd(String upper, int idx) {
        int i = idx + 3;
        while (i < upper.length() && Character.isWhitespace(upper.charAt(i))) i++;
        for (String kw : new String[]{"IF", "WHILE", "FOR", "LOOP", "CASE", "REPEAT"}) {
            if (isKeywordAt(upper, i, kw)) return true;
        }
        return false;
    }

    private int countLines(String src) {
        int c = 1;
        for (char ch : src.toCharArray()) if (ch == '\n') c++;
        return c;
    }

    private int indexOfKeyword(String upper, String kw, int from) {
        int idx = from;
        while ((idx = upper.indexOf(kw, idx)) >= 0) {
            if (isKeywordAt(upper, idx, kw)) return idx;
            idx++;
        }
        return -1;
    }

    private boolean isKeywordAt(String s, int idx, String kw) {
        if (idx + kw.length() > s.length()) return false;
        if (!s.regionMatches(idx, kw, 0, kw.length())) return false;
        boolean before = idx == 0 || !Character.isLetterOrDigit(s.charAt(idx - 1));
        boolean after = (idx + kw.length()) >= s.length()
                || !Character.isLetterOrDigit(s.charAt(idx + kw.length()));
        return before && after;
    }
}
