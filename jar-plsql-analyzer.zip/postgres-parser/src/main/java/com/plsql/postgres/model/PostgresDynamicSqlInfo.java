package com.plsql.postgres.model;

import java.util.ArrayList;
import java.util.List;

public class PostgresDynamicSqlInfo {

    public enum Kind { PREPARE, EXECUTE, EXECUTE_IMMEDIATE }

    private Kind   kind;
    private String stmtName;
    private String sqlSource;
    private int    line;
    /** Source text of each USING-bound expression, in order. */
    private final List<String> usingExprs = new ArrayList<>();

    public Kind   getKind()      { return kind; }
    public void   setKind(Kind kind)         { this.kind = kind; }
    public String getStmtName()  { return stmtName; }
    public void   setStmtName(String stmtName) { this.stmtName = stmtName; }
    public String getSqlSource() { return sqlSource; }
    public void   setSqlSource(String sqlSource) { this.sqlSource = sqlSource; }
    public int    getLine()      { return line; }
    public void   setLine(int line)          { this.line = line; }
    public List<String> getUsingExprs() { return usingExprs; }
}
