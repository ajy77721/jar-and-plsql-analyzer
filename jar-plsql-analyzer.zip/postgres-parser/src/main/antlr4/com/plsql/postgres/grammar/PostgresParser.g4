// ============================================================
// PostgresParser.g4
// Parser grammar for IBM POSTGRES SQL PL stored procedures / functions.
// Entry point: compilationUnit
// tokenVocab = PostgresLexer
// ============================================================
parser grammar PostgresParser;

options { tokenVocab = PostgresLexer; }

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

compilationUnit
    : (routineDefinition | doStatement)? EOF
    ;

// Anonymous PL/pgSQL code block: DO [LANGUAGE lang] $tag$ <body> $tag$ [;]
// The engine's preprocess() step blanks the dollar-quote delimiters (and any trailing
// LANGUAGE clause after the closing tag) in place before this grammar ever sees the text,
// so by the time it reaches this rule it reads as: DO <bodyBlock>. Reuses bodyBlock (the
// same BEGIN…END rule a routine body uses) so DO-block statements go through the exact
// same visitor paths (table ops, calls, cursors, exception handlers, …) as a routine body.
doStatement
    : DO (LANGUAGE id)? bodyBlock SEMI?
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Routine definition
// ─────────────────────────────────────────────────────────────────────────────

routineDefinition
    : CREATE (OR REPLACE)? (PROCEDURE | FUNCTION) routineName
      LPAREN paramList? RPAREN
      (RETURNS dataType)?
      routineCharacteristic*
      bodyBlock?
    ;

// NOTE: REPLACE must be defined in PostgresLexer.g4 as a keyword token.

// Permissive catch-all for routine characteristics that appear between
// the parameter list and BEGIN (e.g. LANGUAGE SQL, NOT DETERMINISTIC, etc.)
// Anything that is not BEGIN, EOF, or the start of another construct is consumed.
routineCharacteristic
    : ~(BEGIN | EOF)+
    ;

bodyBlock
    : BEGIN ATOMIC? body exceptionSection? END SEMI?
    ;

// PL/pgSQL exception handler section: EXCEPTION WHEN cond [OR cond]* THEN <stmts> ...
// Statements inside (e.g. ROLLBACK) are visited normally, so they are captured.
exceptionSection
    : EXCEPTION exceptionHandler+
    ;

exceptionHandler
    : WHEN handlerCond (OR handlerCond)* THEN statement*
    ;

routineName
    : (id DOT)? id
    ;

id
    : ID
    | DQ_ID
    // Allow selected non-structural keywords to be used as identifiers where the
    // parser expects an id. STRUCTURAL clause keywords (FROM, INTO, JOIN, ON,
    // WHERE, GROUP, ORDER, BY, HAVING, UNION, AS, SELECT, the join-type words,
    // ALL, DISTINCT, WHEN, THEN, ELSE, DO, …) are deliberately EXCLUDED so that
    // an expression stops at a clause boundary instead of swallowing it.
    | ATOMIC | CALL | CASE | CAST | CLOSE | CONDITION | CONFLICT | CONTINUE | CREATE | CURRENT
    | CURSOR | DEFAULT | EXISTS | EXIT | FETCH | FUNCTION | HANDLER | HOLD
    | FOREACH | IMMEDIATE | INOUT | IN_KW | IS | LANGUAGE | LIKE | LOOP | MERGE | NEXT | NULL_KW
    | OPEN | OR | OUT_KW | OVER | PARTITION | PREPARE | PROCEDURE | REPEAT
    | REPLACE | RESIGNAL | RETURNS | RETURN | SET | SIGNAL | SQL_KW
    | SQLEXCEPTION | SQLSTATE | SQLWARNING | UNDO | UNTIL | UPDATE
    | VALUE | VALUES | WHILE | WITH
    // USING is deliberately EXCLUDED (unlike the rest of this permissive list): EXECUTE ... USING
    // and MERGE ... USING are both clause boundaries, and letting expr's `exprAtom+` swallow the
    // USING keyword as a bare identifier atom meant the EXECUTE statement's own USING-bound
    // arguments were absorbed into the preceding dynamic-SQL expr instead of being split out —
    // e.g. `EXECUTE '...' USING 0` parsed as one atom-run ending only at the terminating SEMI.
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Parameters
// ─────────────────────────────────────────────────────────────────────────────

paramList
    : param (COMMA param)*
    ;

// PROCEDURE params carry a mode (IN/OUT/INOUT); FUNCTION params carry none.
// The mode is therefore OPTIONAL so both forms parse.
param
    : (IN_KW | OUT_KW | INOUT)? id dataType (DEFAULT defaultVal)?
    ;

dataType
    : id (DOT id)? (LPAREN INT_NUM (COMMA INT_NUM)? RPAREN)? (LBRACK INT_NUM? RBRACK)*
    ;

defaultVal
    : literal
    | id
    | MINUS INT_NUM
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Body
// ─────────────────────────────────────────────────────────────────────────────

body
    : statement*
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Statements
// ─────────────────────────────────────────────────────────────────────────────

statement
    : declareVariableStmt
    | declareCursorStmt
    | declareHandlerStmt
    | callStatement
    | assignStatement
    | setStatement
    | mergeStatement
    | insertStatement
    | updateStatement
    | deleteStatement
    | selectStatement
    | ifStatement
    | caseStatement
    | whileStatement
    | forStatement
    | loopStatement
    | repeatStatement
    | executeImmStmt
    | executeStatement
    | createStatement
    | prepareStatement
    | openStatement
    | closeStatement
    | fetchStatement
    | returnStatement
    | transactionStatement
    | beginBlock
    | otherStatement
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Transaction-control statements (POSTGRES SQL PL)
//   COMMIT [WORK]
//   ROLLBACK [WORK] [TO SAVEPOINT name]
//   SAVEPOINT name [UNIQUE] ON ROLLBACK RETAIN CURSORS ...
//   RELEASE [TO] SAVEPOINT name
// ─────────────────────────────────────────────────────────────────────────────
transactionStatement
    : COMMIT WORK? SEMI?                        # txnCommit
    | ROLLBACK WORK? TO SAVEPOINT? id SEMI?     # txnRollbackTo
    | ROLLBACK WORK? SEMI?                      # txnRollback
    | SAVEPOINT id savepointOpt* SEMI?         # txnSavepoint
    | RELEASE TO? SAVEPOINT id SEMI?           # txnReleaseSavepoint
    ;

// Trailing options after SAVEPOINT name (UNIQUE / ON ROLLBACK RETAIN CURSORS / …)
savepointOpt
    : ~(SEMI | BEGIN | END | DECLARE | CALL | IF | WHILE | FOR | LOOP | REPEAT | PREPARE
        | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE | DELETE | SELECT | RETURN
        | SET | CREATE | MERGE)
    ;

// DECLARE id dataType [DEFAULT expr] ;
// Note: must not match CURSOR declarations — we handle those separately
declareVariableStmt
    : DECLARE id dataType ((DEFAULT | ASSIGN | EQ) expr)? SEMI
    ;

// DECLARE id CURSOR [WITH HOLD] FOR selectStatement
// Also: DECLARE id CURSOR [WITH HOLD] FOR <prepared-statement-name>
//   where the name is an identifier produced by a prior PREPARE statement.
declareCursorStmt
    : DECLARE id CURSOR (WITH HOLD)? FOR selectStatement SEMI?
    | DECLARE id CURSOR (WITH HOLD)? FOR id SEMI
    ;

// DECLARE (CONTINUE|EXIT|UNDO) HANDLER FOR handlerCondList handlerAction
declareHandlerStmt
    : DECLARE (CONTINUE | EXIT | UNDO) HANDLER FOR handlerCondList handlerAction SEMI?
    ;

handlerCondList
    : handlerCond (COMMA handlerCond)*
    ;

handlerCond
    : NOT id       // NOT FOUND
    | SQLEXCEPTION
    | SQLWARNING
    | SQLSTATE VALUE? SQ_STRING
    | id           // condition name
    ;

handlerAction
    : statement
    ;

// CALL [schema.]name(args)
callStatement
    : CALL routineName LPAREN argList? RPAREN SEMI?
    ;

argList
    : expr (COMMA expr)*
    ;

// PL/pgSQL assignment:  target := expr ;   (target may be qualified: rec.field)
// The RHS expr is visited so any function call (e.g. erp.fn_total(x)) is captured as a call.
// PL/pgSQL CASE statement (distinct from the CASE expression):
//   CASE [search] WHEN … THEN <stmts> … [ELSE <stmts>] END CASE;
caseStatement
    : CASE expr? (WHEN expr (COMMA expr)* THEN statement*)+ (ELSE statement*)? END CASE SEMI?
    ;

// PL/pgSQL assignment:  target[:=]expr ;   target may be qualified/subscripted (rec.field, arr[i]).
assignStatement
    : id (DOT id)* (LBRACK expr RBRACK)? ASSIGN expr SEMI?
    ;

setStatement
    : SET id EQ expr SEMI?
    ;

// INSERT [INTO] table ...  optionally followed by an ON CONFLICT (upsert) tail.
// The leading stmtTail stops at CONFLICT (excluded from stmtToken), having consumed
// the "ON" keyword; onConflictClause then recognizes the upsert action.
insertStatement
    : INSERT INTO? tableRef stmtTail onConflictClause? returningClause? SEMI?
    ;

// RETURNING col [, col ...] | RETURNING * — trailing clause on INSERT/UPDATE/DELETE.
returningClause
    : RETURNING returningItem (COMMA returningItem)*
    ;

returningItem
    : STAR
    | expr (AS? id)?
    ;

// ON CONFLICT [ target ] (DO NOTHING | DO UPDATE SET ...) [RETURNING ...].
// The "ON" was already consumed by the preceding stmtTail; this rule starts at
// the CONFLICT token. Its body is consumed permissively up to the statement end.
onConflictClause
    : CONFLICT conflictToken*
    ;

conflictToken
    : LPAREN conflictToken* RPAREN
    | ~(SEMI | BEGIN | END | LPAREN | RPAREN | RETURNING)
    ;

// MERGE INTO target USING source ON cond WHEN [NOT] MATCHED THEN (UPDATE|INSERT|DELETE) ...
// Recognized as a top-level statement (PG15+). Body consumed permissively to the
// terminating ';'. Parenthesized subqueries (USING (SELECT …)) are exposed as real
// selectStatements so nested table ops / subqueries are still captured.
mergeStatement
    : MERGE mergeToken* SEMI?
    ;

mergeToken
    : subquery
    | LPAREN mergeToken* RPAREN
    | CASE mergeToken* END
    | ~(SEMI | BEGIN | END | CASE | LPAREN | RPAREN)
    ;

updateStatement
    : UPDATE tableRef stmtTail returningClause? SEMI?
    ;

deleteStatement
    : DELETE FROM? tableRef stmtTail returningClause? SEMI?
    ;

// Structured SELECT: optional WITH (CTE), one or more UNIONed cores.
// Enough structure to expose FROM / JOIN / CTE via ANTLR contexts (no text scanning).
selectStatement
    : withClause? selectCore (UNION ALL? selectCore)* SEMI?
    ;

withClause
    : WITH cteDef (COMMA cteDef)*
    ;

cteDef
    : id (LPAREN idList RPAREN)? AS LPAREN selectStatement RPAREN
    ;

idList
    : id (COMMA id)*
    ;

selectCore
    : SELECT (ALL | DISTINCT)? selectList
      intoClause?
      fromClause?
      selectRest
    ;

selectList
    : selectItem (COMMA selectItem)*
    ;

selectItem
    : expr (AS? id)?
    ;

intoClause
    : INTO id (COMMA id)*
    ;

fromClause
    : FROM tableReference (COMMA tableReference)*
    ;

// Sep05-11: `LATERAL` may precede an atom both in a comma-separated FROM list
// (`FROM a, LATERAL (SELECT …) x`) and after a JOIN (`CROSS JOIN LATERAL (…)`), so it is optional
// in both places. It is a modifier on the atom, not a table, and carries no name of its own.
//
// To be accurate about what each half of this fix does: the *lexer token* is what removes the
// phantom table, by stopping LATERAL from matching `id`. These two rules were measured and made no
// difference to the tables, joins or error count of a LATERAL query. They are kept because
// without them LATERAL would be a token appearing in no parser rule at all, so every LATERAL
// query would fall out of the structured SELECT path into the permissive catch-all — parsing by
// accident rather than by rule, which is how the next defect gets in.
tableReference
    : LATERAL? tableAtom joinClause*
    ;

tableAtom
    : functionCall (AS? id)?                              # atomFunc
    | tableRef (AS? id)?                                  # atomTable
    | LPAREN selectStatement RPAREN (AS? id)?             # atomSubquery
    | LPAREN tableReference (COMMA tableReference)* RPAREN # atomParen
    ;

joinClause
    : joinType? JOIN LATERAL? tableAtom (ON expr)?
    ;

joinType
    : INNER
    | LEFT OUTER?
    | RIGHT OUTER?
    | FULL OUTER?
    | CROSS
    ;

// Permissive trailing clauses (WHERE / GROUP BY / HAVING / ORDER BY / fetch-first …).
// Stops at UNION, a nested SELECT, or a statement boundary.
selectRest
    : selectRestToken*
    ;

selectRestToken
    : subquery
    | LPAREN selectRestToken* RPAREN
    | CASE selectRestToken* END
    | ~(SEMI | BEGIN | END | CASE | UNION | SELECT | DECLARE | CALL | IF | WHILE
        | FOR | LOOP | REPEAT | PREPARE | EXECUTE | OPEN | CLOSE | FETCH | INSERT
        | UPDATE | DELETE | RETURN | SET | CREATE | LPAREN | RPAREN)
    ;

// IF expr THEN body [ELSEIF expr THEN body]* [ELSE body] END IF [;]
ifStatement
    : IF expr THEN body
      (ELSEIF expr THEN body)*
      (ELSE body)?
      END IF SEMI?
    ;

// WHILE expr DO body END WHILE [;]
whileStatement
    : WHILE expr DO body END WHILE SEMI?          // DB2 form
    | WHILE expr LOOP body END LOOP SEMI?         // PL/pgSQL form
    ;

// FOR var AS cursor DO body END FOR [;]
// Also: FOR label AS cursor-name CURSOR FOR select DO body END FOR
forStatement
    : FOR id (AS id?)? CURSOR? FOR selectStatement DO body END FOR SEMI?           // DB2 cursor-for style
    | FOR id (COMMA id)* IN_KW selectStatement LOOP body END LOOP SEMI?            // PL/pgSQL FOR rec IN <query> LOOP … END LOOP
    | FOR id (COMMA id)* IN_KW forExprTail LOOP body END LOOP SEMI?                // PL/pgSQL FOR i IN [REVERSE] 1..N [BY s] LOOP
    | FOREACH id (COMMA id)* IN_KW forExprTail LOOP body END LOOP SEMI?            // PL/pgSQL FOREACH x IN ARRAY … LOOP … END LOOP
    ;

// The integer-range tail. The lexer tokenizes "1..10" loosely (1. then .10), so consume the
// range expression permissively up to LOOP.
forExprTail
    : ~(LOOP | SEMI | BEGIN | END)+
    ;

loopStatement
    : LOOP body END LOOP SEMI?
    ;

repeatStatement
    : REPEAT body UNTIL expr END REPEAT SEMI?
    ;

// EXECUTE IMMEDIATE must come BEFORE EXECUTE stmt (ANTLR takes first match)
executeImmStmt
    : EXECUTE IMMEDIATE (id | SQ_STRING) SEMI?
    ;

executeStatement
    : EXECUTE expr (INTO id (COMMA id)*)? (USING expr (COMMA expr)*)? SEMI?   // PL/pgSQL EXECUTE format(...) [INTO v] [USING a,b]
    ;

// PL/pgSQL / DDL inside a routine body: CREATE [TEMP|TEMPORARY|UNLOGGED] TABLE …, CREATE INDEX …, etc.
// Consumed permissively up to the terminating ';'.
createStatement
    : CREATE (~SEMI)* SEMI
    ;

prepareStatement
    : PREPARE id FROM (id | SQ_STRING) SEMI?
    ;

openStatement
    : OPEN id SEMI?
    ;

closeStatement
    : CLOSE id SEMI?
    ;

fetchStatement
    : FETCH (NEXT? FROM)? id INTO argList SEMI?
    ;

returnStatement
    : RETURN expr? SEMI?
    ;

beginBlock
    : BEGIN ATOMIC? body exceptionSection? END SEMI?
    ;

// Catch-all for unrecognized statements: consume tokens until semicolon or block boundary
otherStatement
    : ~(SEMI | BEGIN | END | DECLARE | CALL | IF | WHILE | FOR | LOOP | REPEAT | PREPARE
        | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE | DELETE | SELECT | RETURN
        | SET | CREATE | MERGE | EXCEPTION)
      (~(SEMI | BEGIN | END | EXCEPTION))* SEMI?
    | SEMI
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Table reference  (schema.table or just table)
// ─────────────────────────────────────────────────────────────────────────────

tableRef
    : id (DOT id)?
    ;

// ─────────────────────────────────────────────────────────────────────────────
// stmtTail — permissive rule that eats tokens up to next statement boundary.
// Recursively handles balanced parentheses and CASE...END.
// ─────────────────────────────────────────────────────────────────────────────

stmtTail
    : stmtToken*
    ;

stmtToken
    : subquery
    | LPAREN stmtToken* RPAREN
    | CASE stmtToken* END
    | ~(SEMI | BEGIN | END | CASE | DECLARE | CALL | IF | WHILE | FOR | LOOP
        | REPEAT | PREPARE | EXECUTE | OPEN | CLOSE | FETCH | INSERT | UPDATE
        | DELETE | SELECT | RETURN | RETURNING | SET | CREATE | MERGE | CONFLICT | LPAREN | RPAREN)
    ;

// A parenthesized SELECT used as a scalar / IN / EXISTS subquery in an expression
// or a permissive clause tail. Exposes a real selectStatement so the visitor can
// emit a SUBQUERY record and still descend for nested table ops / calls.
subquery
    : LPAREN selectStatement RPAREN
    ;

// ─────────────────────────────────────────────────────────────────────────────
// Expression (simplified — enough to parse conditions and SET rhs)
// ─────────────────────────────────────────────────────────────────────────────

expr
    : exprAtom+
    ;

exprAtom
    : subquery
    | castExpr
    | functionCall
    | LPAREN expr? RPAREN (DOT id)* (LBRACK expr (COMMA expr)* RBRACK)*
    | CASE stmtToken* END
    | literal
    | id (DOT id)* (LBRACK expr (COMMA expr)* RBRACK)*
    | LBRACK (expr (COMMA expr)*)? RBRACK
    | STAR
    | EQ | NEQ | LT | GT | LEQ | GEQ | PLUS | MINUS | SLASH | PERCENT
    | AND | OR | NOT | IN_KW | LIKE | IS | BETWEEN | EXISTS | NULL_KW
    | CURRENT
    | AMPERSAND | PIPE | CARET | TILDE | COLON
    ;

// CAST ( expr AS dataType ) — reuses the shared dataType rule for the target type.
castExpr
    : CAST LPAREN expr AS dataType RPAREN
    ;

// [schema.]name(args) — a function invocation in an expression.
functionCall
    : id (DOT id)? LPAREN functionArgs? RPAREN
    ;

functionArgs
    : STAR
    | expr (COMMA expr)*
    ;

literal
    : SQ_STRING
    | INT_NUM
    | DEC_NUM
    | NULL_KW
    ;
