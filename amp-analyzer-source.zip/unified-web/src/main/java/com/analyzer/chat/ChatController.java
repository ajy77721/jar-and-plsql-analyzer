package com.analyzer.chat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;
import com.analyzer.storage.RequestScopedArtifactStore;
import com.analyzer.storage.sso.CapturedSsoContext;
import com.analyzer.storage.sso.SsoCredentialsResolver;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    private final ChatService chatService;

    /**
     * Every artifact these endpoints touch is addressed by an {@link ArtifactKey}, which is
     * relative to the data root and cannot express a location outside it.
     *
     * <p>The original guard was a {@code path.contains("..")} substring check, which stops
     * nothing: an ABSOLUTE path such as {@code /etc/passwd} contains no "..", so it passed. The
     * read endpoint would return the file and the write endpoint would overwrite it — arbitrary
     * read and write anywhere the process user can reach, unauthenticated. Keys close that hole
     * structurally: {@link #keyInsideDataRoot} rejects "." / ".." segments outright and drops the
     * leading separator of an absolute path, so the request can only ever name something under
     * the store root.
     */
    private final ArtifactStore store;

    @org.springframework.beans.factory.annotation.Value("${chat.classic.enabled:true}")
    private boolean classicEnabled;

    @org.springframework.beans.factory.annotation.Value("${chat.chatbox.enabled:true}")
    private boolean chatboxEnabled;

    private final com.plsqlanalyzer.web.config.ConfigDirService configDirService;

    /**
     * Snapshots the caller's SSO context for chat writes (task #32), so a script/output write is
     * carried out under the user's identity rather than the shared default one.
     */
    private final SsoCredentialsResolver ssoCredentialsResolver;

    public ChatController(ChatService chatService,
                           @Qualifier("jarArtifactStore") ArtifactStore store,
                           com.plsqlanalyzer.web.config.ConfigDirService configDirService,
                           SsoCredentialsResolver ssoCredentialsResolver) {
        this.chatService = chatService;
        this.store = store;
        this.configDirService = configDirService;
        this.ssoCredentialsResolver = ssoCredentialsResolver;
    }

    /**
     * Runs a chat write under the caller's captured routing scope and SSO context — the same
     * CAPTURE → INSTALL idiom every other store-touching controller uses (see
     * {@code ConversionController}/{@code ClaudeController}). Chat writes are synchronous on the
     * request thread today, so this is explicit rather than load-bearing for the common case; it
     * makes the routing auditable and guarantees the write can never degrade to the shared default
     * store if a future change moves a write off the request thread.
     *
     * <p>{@code captureScope()} answers {@link RequestScopedArtifactStore.Scope#NONE} when there is
     * no request-bound session (local/CLI/pre-SSO), and {@link CapturedSsoContext#capture} answers
     * {@code null} likewise — so those documented legacy paths are unchanged.
     */
    private RequestScopedArtifactStore.Scope captureRoutingScope() {
        return store instanceof RequestScopedArtifactStore routed
                ? routed.captureScope()
                : RequestScopedArtifactStore.Scope.NONE;
    }

    private <T> T withUserContext(java.util.function.Supplier<T> action) {
        RequestScopedArtifactStore.Scope routingScope = captureRoutingScope();
        CapturedSsoContext ssoContext = CapturedSsoContext.capture(ssoCredentialsResolver);
        try (AutoCloseable routed = routingScope.install();
             AutoCloseable ctx = ssoContext == null ? null : ssoContext.install()) {
            return action.get();
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** An action that may throw {@link IOException} (the file-write path). */
    @FunctionalInterface
    private interface IoAction<T> {
        T run() throws IOException;
    }

    private <T> T withUserContextIO(IoAction<T> action) throws IOException {
        RequestScopedArtifactStore.Scope routingScope = captureRoutingScope();
        CapturedSsoContext ssoContext = CapturedSsoContext.capture(ssoCredentialsResolver);
        try (AutoCloseable routed = routingScope.install();
             AutoCloseable ctx = ssoContext == null ? null : ssoContext.install()) {
            return action.run();
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * List files the chatbot has produced for download, THIS SESSION. Reads from ChatService's
     * ArtifactStore-backed capture (see ChatService.captureGeneratedArtifacts), not raw local
     * disk — this is deliberately session-scoped and store-backed rather than one global local
     * directory listing (the earlier version of this endpoint), because a global local-disk
     * listing is wrong once the app runs in mongodb or S3 storage mode: it would still work by
     * accident locally but silently show nothing (or the wrong thing) once storage.mode is
     * anything else, exactly the inconsistency the user flagged.
     */
    @GetMapping("/sessions/{id}/outputs")
    public ResponseEntity<List<Map<String, Object>>> listOutputs(@PathVariable String id) {
        return ResponseEntity.ok(chatService.listOutputs(id));
    }

    /** Download one output file — content comes back through {@link ChatService#getOutputBytes},
     *  which reads via the same storage-mode-aware ArtifactStore as everything else in this app. */
    @GetMapping("/sessions/{id}/outputs/{filename}")
    public ResponseEntity<byte[]> downloadOutput(@PathVariable String id, @PathVariable String filename) {
        byte[] data = chatService.getOutputBytes(id, filename);
        if (data == null) return ResponseEntity.notFound().build();
        String lower = filename.toLowerCase();
        MediaType type = lower.endsWith(".json") ? MediaType.APPLICATION_JSON
                : lower.endsWith(".xlsx") ? MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                : lower.endsWith(".csv") ? MediaType.parseMediaType("text/csv")
                : MediaType.APPLICATION_OCTET_STREAM;
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(data);
    }

    /**
     * Deletes one output/result file — explicit user direction: "how i can remove old json...
     * user should have delete option once it download." Removes the durable store copy, the
     * in-memory listing, and the live sandbox file (see ChatService.deleteOutput) so it stops
     * appearing in the Downloads strip and stops taking up space, in one action.
     */
    @DeleteMapping("/sessions/{id}/outputs/{filename}")
    public ResponseEntity<Void> deleteOutput(@PathVariable String id, @PathVariable String filename) {
        boolean removed = withUserContext(() -> chatService.deleteOutput(id, filename));
        return removed ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    private InputStream openRead(ArtifactKey key) throws IOException {
        return store.read(key);
    }

    private OutputStream openWrite(ArtifactKey key, long contentLength) throws IOException {
        return store.write(key, contentLength);
    }

    @GetMapping("/config")
    public Map<String, Object> getChatConfig() {
        return Map.of(
                "classicEnabled", classicEnabled,
                "chatboxEnabled", chatboxEnabled
        );
    }

    @PostMapping("/sessions")
    public ResponseEntity<?> createSession(@RequestBody Map<String, Object> body) {
        String name = (String) body.get("name");
        String scope = (String) body.getOrDefault("scope", "GLOBAL");
        String chatType = (String) body.getOrDefault("chatType", "classic");
        @SuppressWarnings("unchecked")
        Map<String, String> scopeContext = (Map<String, String>) body.get("scopeContext");

        if (name == null || name.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Session name is required"));
        }

        ChatSession session = withUserContext(
                () -> chatService.createSession(name, scope.toUpperCase(), chatType, scopeContext));
        return ResponseEntity.ok(Map.of(
                "id", session.getId(),
                "name", session.getName(),
                "scope", session.getScope(),
                "chatType", session.getChatType(),
                "createdAt", session.getCreatedAt().toString()
        ));
    }

    @GetMapping("/sessions")
    public ResponseEntity<List<Map<String, Object>>> listSessions(
            @RequestParam(required = false) String scope,
            @RequestParam(required = false) String chatType) {
        return ResponseEntity.ok(chatService.listSessions(scope, chatType));
    }

    @GetMapping("/sessions/{id}")
    public ResponseEntity<?> getSession(@PathVariable String id) {
        ChatSession session = chatService.getSession(id);
        if (session == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(session);
    }

    /**
     * A page of one session's transcript — Q67 / L30.
     *
     * <p>A new endpoint, so there is no legacy shape to preserve: it always answers the envelope.
     * That is what lets {@code openSession} stop fetching {@code /sessions/{id}}, whose response
     * carries every message ever exchanged in order to render the last screenful.
     *
     * @param before the {@code seq} to page backwards from — {@code after} under
     *               {@code sort=SEQ_DESC} (PLAN-08 §3.2), spelled the way the UI reads it
     * @param sort   accepted only as {@code SEQ_DESC}; anything else is a 400 rather than a
     *               silently different ordering
     */
    @GetMapping("/sessions/{id}/messages")
    public ResponseEntity<?> getMessages(@PathVariable String id,
                                         @RequestParam(required = false) Long before,
                                         @RequestParam(required = false) Integer limit,
                                         @RequestParam(required = false) String q,
                                         @RequestParam(required = false) String sort) {
        if (sort != null && !sort.isBlank()
                && !ChatTranscriptReader.SORT_SEQ_DESC.equalsIgnoreCase(sort)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "BAD_PAGE_REQUEST",
                    "message", "Unknown sort '" + sort + "'. Allowed: ["
                            + ChatTranscriptReader.SORT_SEQ_DESC + "]"));
        }
        if (limit != null && (limit < 1 || limit > com.analyzer.storage.page.PageRequest.MAX_LIMIT)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "BAD_PAGE_REQUEST",
                    "message", "limit must be between 1 and "
                            + com.analyzer.storage.page.PageRequest.MAX_LIMIT));
        }
        try {
            var page = chatService.messages(id, before, limit, q);
            if (page == null) return ResponseEntity.notFound().build();
            var info = page.page();
            return ResponseEntity.ok(Map.of(
                    "items", page.items(),
                    "page", pageBlock(info)));
        } catch (IOException e) {
            log.error("Failed to page messages for session {}: {}", id, e.getMessage());
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to read transcript"));
        }
    }

    /** The wire shape of the paging block, written out field by field so it is stated once. */
    private static Map<String, Object> pageBlock(com.analyzer.storage.page.PageInfo info) {
        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("nextCursor", info.nextCursor());   // null iff hasMore is false
        out.put("hasMore", info.hasMore());
        out.put("total", info.total());
        out.put("totalIsExact", info.totalIsExact());
        out.put("limit", info.limit());
        out.put("sort", info.sort());
        return out;
    }

    @DeleteMapping("/sessions/{id}")
    public ResponseEntity<?> deleteSession(@PathVariable String id) {
        boolean deleted = withUserContext(() -> chatService.deleteSession(id));
        if (!deleted) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of("deleted", id));
    }

    @PostMapping("/sessions/{id}/messages")
    public ResponseEntity<?> sendMessage(@PathVariable String id, @RequestBody Map<String, String> body) {
        String message = body.get("message");
        if (message == null || message.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Message is required"));
        }

        String pageContext = body.get("pageContext");
        log.info("Chat message to session {}: {} chars, context: {}", id, message.length(),
                pageContext != null ? pageContext.length() + " chars" : "none");
        ChatMessage response = withUserContext(() -> chatService.sendMessage(id, message, pageContext));
        if (response == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(Map.of(
                "role", response.getRole(),
                "content", response.getContent(),
                "timestamp", response.getTimestamp().toString()
        ));
    }

    @GetMapping("/sessions/{id}/report")
    public ResponseEntity<?> downloadReport(@PathVariable String id) {
        String markdown = chatService.generateMarkdownReport(id);
        if (markdown == null) return ResponseEntity.notFound().build();

        ChatSession session = chatService.getSession(id);
        String fileName = (session != null ? session.getName() : id)
                .replaceAll("[^a-zA-Z0-9_-]", "_") + "_report.md";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .contentType(MediaType.TEXT_MARKDOWN)
                .body(markdown);
    }

    // ── Script history — the "store into DB, keep in-memory, allow deletion" half of the
    // extract/export feature (ChatService.captureGeneratedScripts persists these). The assistant
    // itself has no path to these endpoints; they exist only for the app's own UI. ──────────────

    @GetMapping("/sessions/{id}/scripts")
    public ResponseEntity<List<Map<String, Object>>> listScripts(@PathVariable String id) {
        return ResponseEntity.ok(chatService.listScripts(id));
    }

    @GetMapping("/sessions/{id}/scripts/{filename}")
    public ResponseEntity<String> downloadScript(@PathVariable String id, @PathVariable String filename) {
        String content = chatService.getScriptContent(id, filename);
        if (content == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(content);
    }

    @DeleteMapping("/sessions/{id}/scripts/{filename}")
    public ResponseEntity<Void> deleteScript(@PathVariable String id, @PathVariable String filename) {
        boolean removed = withUserContext(() -> chatService.deleteScript(id, filename));
        return removed ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    private static final long MAX_READ_SIZE = 512 * 1024;

    /**
     * Turns a client-supplied path into a key inside the data root, or throws.
     *
     * <p>There is no base directory to compare against any more, so the {@code startsWith(root)}
     * containment check is replaced by refusing the inputs that could escape in the first place:
     * any "." or ".." segment is rejected rather than normalized away, and a leading separator is
     * simply dropped so an absolute path is read as relative to the root. Every remaining segment
     * is then re-validated by {@link ArtifactKey}, which cannot hold a separator at all.
     */
    private ArtifactKey keyInsideDataRoot(String clientPath) throws IOException {
        if (clientPath.indexOf('\0') >= 0) throw new IOException("Illegal path");
        List<String> segments = new ArrayList<>();
        for (String raw : clientPath.replace("\\", "/").split("/")) {
            if (raw.isBlank()) continue;            // leading "/", or a doubled separator
            if (raw.equals(".") || raw.equals("..")) {
                throw new IOException("Path escapes the data directory");
            }
            segments.add(raw);
        }
        if (segments.isEmpty()) throw new IOException("Path is empty");
        try {
            return ArtifactKey.of(segments.toArray(new String[0]));
        } catch (IllegalArgumentException e) {
            throw new IOException("Illegal path: " + e.getMessage());
        }
    }

    /**
     * Explicit user direction: "classic should also flow same rules" as the new chatbox. Before
     * this, {@code keyInsideDataRoot} alone let classic chat's own "attach file"/"[FILE_CREATE:...]
     * approve & create" workflow (shared/chat.js) read or write ANYTHING under the whole data
     * root — including data/config/plsql-config.yaml, the same real plaintext DB credentials file
     * the sandboxed chatbot's guard hook (chat-guard.py) exists specifically to block. That gap
     * existed because these two REST endpoints are a raw HTTP path, never mediated by the Claude
     * CLI at all — chat-guard.py only ever sees Claude's OWN tool calls, so it had zero effect
     * here regardless of how tight it got.
     *
     * <p>Confines both endpoints to the same logical "chat's own space" the new chatbox is
     * confined to: the {@code claude-chatbot/} ArtifactStore prefix (ChatService.CHAT_ROOT) —
     * the durable, storage-mode-aware home for chat sessions/scripts/outputs. A request for
     * anything outside that prefix (e.g. {@code data/config/...}, {@code plsql/...}) is rejected
     * the same way an out-of-sandbox path is rejected for the CLI-driven chatbot.
     */
    private static final String CHAT_SANDBOX_PREFIX = "claude-chatbot";

    private ArtifactKey keyInsideChatSandbox(String clientPath) throws IOException {
        ArtifactKey key = keyInsideDataRoot(clientPath);
        if (!key.segments().isEmpty() && CHAT_SANDBOX_PREFIX.equals(key.segments().get(0))) {
            return key;
        }
        throw new IOException("Path is outside the chatbot's own sandbox (must be under " + CHAT_SANDBOX_PREFIX + "/)");
    }

    /**
     * Same deny-list categories as scripts/claude-hooks/chat-guard.py's DENY_PATTERNS — reimplemented
     * here in Java because this write path is a raw REST call, never routed through the Claude CLI
     * that hook actually intercepts. Kept intentionally close to that file's own list (same
     * rationale, same categories) rather than introducing a third, divergent deny-list; see that
     * file's own comments for why each category is there.
     */
    private static final List<java.util.regex.Pattern> DESTRUCTIVE_CONTENT_PATTERNS = List.of(
            "\\brm\\s+-[a-zA-Z]*r[a-zA-Z]*f\\b", "\\brm\\s+-r\\b", "\\brm\\s+-f\\b",
            "\\bshutil\\.rmtree\\b", "\\bos\\.remove\\b", "\\bos\\.unlink\\b", "\\.unlink\\s*\\(",
            "\\bkill\\s+-?\\d", "\\bkillall\\b", "\\bpkill\\b", "\\bshutdown\\b", "\\breboot\\b",
            "\\bsudo\\b", "\\bchmod\\s+777\\b",
            "\\bgit\\s+push\\s+.*--force\\b", "\\bgit\\s+reset\\s+--hard\\b",
            "\\bDROP\\s+(TABLE|DATABASE|COLLECTION|INDEX|SCHEMA)\\b", "\\bDELETE\\s+FROM\\b",
            "\\bTRUNCATE\\s+(TABLE)?\\b", "\\bUPDATE\\s+\\S+\\s+SET\\b",
            "\\.drop\\s*\\(", "\\.dropDatabase\\s*\\(", "\\.dropCollection\\s*\\(",
            "\\.delete_one\\s*\\(", "\\.delete_many\\s*\\(", "\\.deleteOne\\s*\\(", "\\.deleteMany\\s*\\(",
            "\\.update_one\\s*\\(", "\\.update_many\\s*\\(", "\\.updateOne\\s*\\(", "\\.updateMany\\s*\\("
    ).stream().map(p -> java.util.regex.Pattern.compile(p, java.util.regex.Pattern.CASE_INSENSITIVE)).toList();

    private static String firstDestructiveMatch(String content) {
        for (java.util.regex.Pattern p : DESTRUCTIVE_CONTENT_PATTERNS) {
            if (p.matcher(content).find()) return p.pattern();
        }
        return null;
    }

    @PostMapping("/files/read")
    public ResponseEntity<?> readFile(@RequestBody Map<String, String> body) {
        String filePath = body.get("path");
        if (filePath == null || filePath.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path is required"));
        }

        ArtifactKey key;
        try {
            key = keyInsideChatSandbox(filePath);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        if (!store.exists(key)) {
            return ResponseEntity.ok(Map.of("error", "File not found: " + filePath));
        }

        try {
            // size() is -1 for anything that is not a readable artifact — a directory key
            // included, which is how the old isDirectory() check is preserved without a
            // filesystem-only predicate.
            long size = store.size(key);
            if (size < 0) {
                return ResponseEntity.ok(Map.of("error", "Path is not a readable file"));
            }
            if (size > MAX_READ_SIZE) {
                return ResponseEntity.ok(Map.of("error", "File too large (" + (size / 1024) + "KB). Max: " + (MAX_READ_SIZE / 1024) + "KB"));
            }
            String content;
            try (InputStream in = openRead(key)) {
                content = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            log.info("Chat file read: {} ({} bytes)", filePath, size);
            return ResponseEntity.ok(Map.of("content", content, "path", filePath, "size", size));
        } catch (IOException e) {
            log.error("Failed to read file {}: {}", filePath, e.getMessage());
            return ResponseEntity.ok(Map.of("error", "Failed to read: " + e.getMessage()));
        }
    }

    @PostMapping("/files/write")
    public ResponseEntity<?> writeFile(@RequestBody Map<String, String> body) {
        String filePath = body.get("path");
        String content = body.get("content");

        if (filePath == null || filePath.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path is required"));
        }
        if (content == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Content is required"));
        }

        ArtifactKey key;
        try {
            key = keyInsideChatSandbox(filePath);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        String hit = firstDestructiveMatch(content);
        if (hit != null) {
            log.warn("Blocked chat file write ({}): content matched destructive pattern {}", filePath, hit);
            return ResponseEntity.badRequest().body(Map.of("error",
                    "Blocked: this content matched a destructive-operation pattern and is not permitted "
                            + "(same rule the sandboxed chatbot enforces) — rephrase without delete/kill/drop/update commands."));
        }
        try {
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            withUserContextIO(() -> {
                try (OutputStream out = openWrite(key, bytes.length)) {
                    out.write(bytes);
                }
                return null;
            });
            log.info("Chat file written: {} ({} bytes)", filePath, content.length());
            return ResponseEntity.ok(Map.of("success", true, "path", filePath, "size", content.length()));
        } catch (IOException e) {
            log.error("Failed to write file {}: {}", filePath, e.getMessage());
            return ResponseEntity.ok(Map.of("error", "Failed to write: " + e.getMessage()));
        }
    }
}
