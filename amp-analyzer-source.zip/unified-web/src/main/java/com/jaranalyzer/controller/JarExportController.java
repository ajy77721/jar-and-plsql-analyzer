package com.jaranalyzer.controller;

import com.analyzer.queue.AnalysisQueueService;
import com.analyzer.queue.QueueJob;
import com.analyzer.storage.ArtifactEntry;
import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.service.JarDataPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * UI-041/UI-043 (§249's JAR-side bulk export plan) — the JAR-screen equivalent of
 * {@code ParserAnalysisController#exportBundle} (§251, {@code UI-042}'s PL/SQL half).
 *
 * <p><b>Fast path ({@code POST /{id}/export/bundle})</b>: unlike the PL/SQL side, the JAR
 * screen's "5 reports" ({@code summary-export.js#exportAllReports}) are derived entirely
 * client-side from data the browser already holds in memory ({@code JA.summary._epReports} and
 * friends) — there is no server-side equivalent of {@code AnalysisService.getTables} etc. to call
 * for them. Duplicating that derivation logic in Java here would create a second copy that could
 * silently drift from the real one. Instead, the client sends the exact JSON it already builds
 * (the same objects {@code exportAllReports()} already downloads today) and this endpoint's job
 * is pure orchestration: zip those, plus — genuinely new, and genuinely server-side — every
 * ALREADY-CACHED decompiled class source for this jar, read straight from the same
 * {@link ArtifactStore} key {@link DecompileController} caches into
 * ({@code jar/<id>/decompiled/<class>.java}). No new decompilation happens on this path.
 *
 * <p><b>Background path ({@code POST /{id}/export/bundle/full-source-job})</b>: submits a
 * {@link AnalysisQueueService} job (reusing the exact same queue/executor/SSE mechanism every
 * other long-running job in this app already uses — {@code /api/queue} polling, no new progress
 * mechanism invented) that decompiles every NOT-yet-cached class for the jar, then writes one zip
 * of everything now cached to a fixed per-jar {@link ArtifactStore} key. No pre-existing
 * "background job produces a downloadable artifact" convention was found anywhere in this
 * codebase (confirmed by reading {@code QueueJob}/{@code QueueController} in full — {@code
 * resultName} is a plain display string on every other job type, never a fetchable key) — this
 * is the smallest reasonable equivalent: the completed job's {@code metadata.bundleReady} flag
 * plus a fixed download key the UI hits once {@code GET /api/queue/{id}} reports {@code COMPLETE}.
 *
 * <p><b>WAR screen</b>: the same four routes are also mapped under {@code /api/war/wars}. The WAR
 * page is a fork of the JAR page and reuses these very scripts, so it was calling the
 * {@code /api/jar/jars} URLs with a WAR id. That silently produced wrong-but-plausible results
 * rather than an error: WAR artifacts live under the {@code jar/war/<id>/} key root
 * ({@link com.jaranalyzer.service.WarDataPaths#keyRoot()}), so a WAR id looked up against the
 * JAR-rooted {@code jar/<id>/} prefix found no decompiled cache — cache-status reported 0, the
 * fast-path zip came back with reports but no source, and the background job 404'd on its
 * analysis-exists guard. Which prefix to use is decided per request from the URI rather than by
 * duplicating the handlers, so the two screens cannot drift apart.
 */
@RestController("jarExportController")
@RequestMapping({"/api/jar/jars", "/api/war/wars"})
public class JarExportController {

    private static final Logger log = LoggerFactory.getLogger(JarExportController.class);

    private final JarDataPaths jarDataPaths;
    private final JarDataPaths warDataPaths;
    private final ArtifactStore store;
    private final ObjectMapper objectMapper;
    private final AnalysisQueueService queueService;

    public JarExportController(JarDataPaths jarDataPaths,
                                @org.springframework.beans.factory.annotation.Qualifier("warPersistenceService")
                                com.jaranalyzer.service.PersistenceService warPersistenceService,
                                @org.springframework.beans.factory.annotation.Qualifier("jarArtifactStore") ArtifactStore store,
                                ObjectMapper objectMapper,
                                AnalysisQueueService queueService) {
        this.jarDataPaths = jarDataPaths;
        this.warDataPaths = warPersistenceService.getPaths();
        this.store = store;
        this.objectMapper = objectMapper;
        this.queueService = queueService;
    }

    /**
     * Which key root this request addresses. Derived from the URI because the two mappings above
     * are the only thing that distinguishes a WAR call from a JAR one — the id itself carries no
     * marker, and a WAR and a JAR may legitimately share a name.
     */
    private boolean isWarRequest(jakarta.servlet.http.HttpServletRequest request) {
        return request.getRequestURI().startsWith("/api/war/");
    }

    private JarDataPaths pathsFor(jakarta.servlet.http.HttpServletRequest request) {
        return isWarRequest(request) ? warDataPaths : jarDataPaths;
    }

    /** UI-041 fast path request body — see class doc. */
    public record ExportBundleRequest(Map<String, JsonNode> reports, Boolean includeCachedSource) {}

    @PostMapping("/{id}/export/bundle")
    public void exportBundle(@PathVariable String id,
                              @RequestBody(required = false) ExportBundleRequest body,
                              jakarta.servlet.http.HttpServletRequest request,
                              jakarta.servlet.http.HttpServletResponse response) throws IOException {
        ExportBundleRequest req = body != null ? body : new ExportBundleRequest(Map.of(), null);
        Map<String, JsonNode> reports = req.reports() != null ? req.reports() : Map.of();
        boolean includeCachedSource = Boolean.TRUE.equals(req.includeCachedSource());

        String safeId = id.replaceAll("[^a-zA-Z0-9._-]", "_");
        response.setContentType("application/zip");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + safeId + "-export.zip\"");

        try (java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(response.getOutputStream())) {
            for (Map.Entry<String, JsonNode> e : reports.entrySet()) {
                String fileName = e.getKey() == null || e.getKey().isBlank() ? "report.json" : e.getKey();
                try {
                    byte[] bytes = objectMapper.writeValueAsBytes(e.getValue());
                    zos.putNextEntry(new java.util.zip.ZipEntry("reports/" + fileName));
                    zos.write(bytes);
                    zos.closeEntry();
                } catch (Exception ignored) {
                    // One bad report entry must not fail the rest of the bundle.
                }
            }
            if (includeCachedSource) {
                writeCachedSourceEntries(zos, id, pathsFor(request));
            }
            zos.finish();
        }
    }

    /** Writes one {@code source/<FQCN>.java} zip entry per already-decompiled-and-cached class. */
    private void writeCachedSourceEntries(java.util.zip.ZipOutputStream zos, String id, JarDataPaths paths) {
        ArtifactKey decompiledDir = paths.jarRootKey(id).resolve("decompiled");
        try (Stream<ArtifactEntry> entries = store.list(decompiledDir, true)) {
            entries.filter(e -> !e.directory()).forEach(e -> {
                try (InputStream in = store.read(e.key())) {
                    zos.putNextEntry(new java.util.zip.ZipEntry("source/" + e.key().leaf()));
                    in.transferTo(zos);
                    zos.closeEntry();
                } catch (IOException ignored) {
                    // One unreadable cached source file must not fail the whole bundle.
                }
            });
        } catch (IOException e) {
            log.debug("No decompiled cache dir for {} (or unreadable): {}", id, e.getMessage());
        }
    }

    /** How many of this jar's classes are already decompiled-and-cached, for the UI's "N of M
     *  cached" label before the user opts into the background job. */
    @GetMapping("/{id}/export/bundle/cache-status")
    public Map<String, Object> cacheStatus(@PathVariable String id,
            jakarta.servlet.http.HttpServletRequest request) {
        ArtifactKey decompiledDir = pathsFor(request).jarRootKey(id).resolve("decompiled");
        long cached;
        try (Stream<ArtifactEntry> entries = store.list(decompiledDir, true)) {
            cached = entries.filter(e -> !e.directory()).count();
        } catch (IOException e) {
            cached = 0;
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("cachedClasses", cached);
        return result;
    }

    /** UI-043 — submits the background "decompile everything not yet cached" job, reusing the
     *  exact {@code /api/queue} mechanism. {@code maxClasses} is test/debug-only (caps how many
     *  classes the job processes, so this can be verified at a small scale without waiting on a
     *  full 10,704-class decompile). */
    @PostMapping("/{id}/export/bundle/full-source-job")
    public Map<String, Object> submitFullSourceJob(@PathVariable String id,
            @RequestBody(required = false) Map<String, Object> body,
            jakarta.servlet.http.HttpServletRequest request) {
        boolean war = isWarRequest(request);
        JarDataPaths paths = war ? warDataPaths : jarDataPaths;
        if (!store.exists(paths.analysisKey(id)) && !store.exists(paths.correctedKey(id))) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    (war ? "War" : "Jar") + " analysis not found: " + id);
        }
        Map<String, Object> metadata = new LinkedHashMap<>();
        metadata.put("jarId", id);
        // The executor runs long after this request is gone, so the key root it must use has to
        // travel with the job rather than be re-derived from a URI it will never see again.
        metadata.put("war", war);
        if (body != null && body.get("maxClasses") instanceof Number n) {
            metadata.put("maxClasses", n.intValue());
        }
        QueueJob job = queueService.submit(QueueJob.Type.JAR_EXPORT_BUNDLE,
                "Decompile all classes for export: " + id, metadata);
        return Map.of("jobId", job.id);
    }

    /** Streams the zip a completed {@code JAR_EXPORT_BUNDLE} job produced. 404s until the job's
     *  {@code metadata.bundleReady} flag is set by {@link com.analyzer.queue.JarExportBundleExecutor}. */
    @GetMapping("/{id}/export/bundle/download")
    public void downloadFullBundle(@PathVariable String id,
                                    jakarta.servlet.http.HttpServletRequest request,
                                    jakarta.servlet.http.HttpServletResponse response) throws IOException {
        ArtifactKey resultKey = pathsFor(request).jarRootKey(id).resolve("export-full-bundle.zip");
        if (!store.exists(resultKey)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "No completed full-source export bundle for " + id
                            + " — submit a job via POST .../export/bundle/full-source-job first");
        }
        String safeId = id.replaceAll("[^a-zA-Z0-9._-]", "_");
        response.setContentType("application/zip");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + safeId + "-full-export.zip\"");
        try (InputStream in = store.read(resultKey); OutputStream out = response.getOutputStream()) {
            in.transferTo(out);
        }
    }
}
