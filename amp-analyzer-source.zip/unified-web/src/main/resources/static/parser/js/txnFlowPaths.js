window.PA = window.PA || {};

/**
 * Flow sub-view — EXECUTION PATHS.
 *
 * One path on screen at a time (the resolver enumerates alternative runs when a guarded
 * conditional commit/rollback branches the flow): a path-selector chip row, the resolver's own
 * plain-English outcome sentence, then one row per PROCEDURE on that path — with a plain summary
 * of what happens (writes + their survival verdict + the transaction points) and an expandable
 * per-line detail (each op ONCE — no cross-proc repeats).
 *
 * Registered as PA.txnFlowPaths. PA.txnTrace's Flow dispatch calls render(container, data) with
 * the txn-runs doc it fetched ONCE per entry (data.runs) — the same doc the other two flow
 * sub-views receive.
 */
PA.txnFlowPaths = {
    _selRun: 0,
    _selRunKey: null,
    _openProcs: {},

    render: function (c, data) {
        var runs = (data && data.runs) || [];
        var SURV = {
            survived: { label: 'survived', cls: 'commit', tip: 'committed — permanent' },
            discarded: { label: 'discarded', cls: 'rollback', tip: 'undone by a rollback on this path' },
            open: { label: 'open', cls: 'open', tip: 'transaction still open — survives only if a caller commits later' }
        };
        var key = ((PA.api && PA.api._analysisName) || '') + '|' + ((PA.context && PA.context.procId) || '');
        if (PA.txnFlowPaths._selRunKey !== key || PA.txnFlowPaths._selRun >= runs.length) PA.txnFlowPaths._selRun = 0;
        var run = runs[PA.txnFlowPaths._selRun];

        // ── Path selector: ONE path on screen at a time (the user's comprehension ask) ──
        var html = '<div class="txn-pathsel">';
        // Not a one-way door (task 55 feedback): back to the brief when the brief exists.
        if (data.brief && data.brief.length) {
            html += '<button class="btn btn-sm" style="margin-right:8px" onclick="PA.txnTrace.backToBrief()"'
                + ' title="Back to the transactions table">‹ Back</button>';
        }
        html += '<span class="txn-pathsel-label">Execution path:</span>';
        runs.forEach(function (r, i) {
            var active = i === PA.txnFlowPaths._selRun;
            var cond = (r.assumptions && r.assumptions.length)
                ? r.assumptions.map(function (a) { return (a.taken ? '' : 'NOT ') + (a.condition || '?'); }).join(' AND ')
                : 'unconditional';
            html += '<button class="txn-path-chip' + (active ? ' active' : '') + '"'
                + ' onclick="PA.txnFlowPaths.selectRun(' + i + ')" title="' + PA.escAttr(cond) + '">'
                + 'Path ' + (i + 1) + (r.kind === 'autonomous' ? ' (autonomous)' : '')
                + '<span class="txn-path-cond">' + PA.esc(cond.length > 34 ? cond.slice(0, 34) + '…' : cond) + '</span></button>';
        });
        if (data.pathCountExceeded) html += '<span class="txn-implicit" style="margin-left:6px">(path limit reached — see guards on the Table view)</span>';
        html += '</div>';

        // ── The outcome sentence leads (the resolver's own, derived from the replay) ──
        var oc = { COMMITTED: 'ok', ROLLED_BACK: 'err', PARTIAL: '', OPEN: '', AUTONOMOUS: 'ok' }[run.outcome] || '';
        html += '<div class="txn-outcome-card">'
            + '<span class="txn-exit-tag ' + oc + '" style="font-size:11px">' + PA.esc(run.outcome || '') + '</span>'
            + '<span class="txn-resolve-line" style="display:inline">' + (run.summary || '') + '</span>'
            + '<button class="btn btn-sm txn-detail-btn" style="float:right" onclick="PA.txnTrace.openDetail(' + PA.txnFlowPaths._selRun + ')" title="Full per-write call tree">Details</button>'
            + '</div>';

        // ── Group the run's events by procedure, in execution order — the grid's row source.
        //    A CALL event is the call SITE, not work of its own, so it does not start a row.
        var procs = [];
        var byId = {};
        (run.events || []).forEach(function (e) {
            var u = e.nodeId || '';
            if (e.kind === 'CALL') return;
            if (!byId[u]) { byId[u] = { nodeId: u, proc: e.proc || u, depth: e.depth || 0, events: [] }; procs.push(byId[u]); }
            byId[u].events.push(e);
        });

        // ── Task 64-review: the per-proc rows are a REAL PA.tf GRID now (sort/columns/paging —
        // the user's ask: the same table format everywhere); the ROW CLICK expands that proc's
        // op TABLE below (its own grid: filter + pager; the ops DEDUPED with a xN-calls chip).
        var gridRows = procs.map(function (p) {
            var writes = p.events.filter(function (e) { return e.kind === 'WRITE'; });
            var counts = {};
            writes.forEach(function (e) { var sv = e.survival || 'open'; counts[sv] = (counts[sv] || 0) + 1; });
            var txnBits = [];
            p.events.forEach(function (e) {
                if (e.kind === 'COMMIT') txnBits.push('COMMIT :' + e.line);
                if (e.kind === 'ROLLBACK') txnBits.push('ROLLBACK :' + e.line);
                if (e.kind === 'ROLLBACK_TO') txnBits.push('RB-TO ' + (e.name || '') + ' :' + e.line);
            });
            return { proc: p.proc, nodeId: p.nodeId, depth: p.depth, writes: writes,
                     survived: counts.survived || 0, discarded: counts.discarded || 0,
                     openW: counts.open || 0, txnBits: txnBits.join(', ') };
        });

        html += '<div style="margin:4px 0"><input id="tfpSearch" type="search" placeholder="Filter procedures…"'
            + ' style="width:260px" oninput="PA.tf.setSearch(\'tfp\', this.value); PA.tf.filter(\'tfp\')"></div>';
        html += '<div class="pagination-bar" id="tfp-pager" style="display:none"></div>';
        html += '<table class="to-table txn-flow-table" style="width:100%"><thead><tr>'
            + '<th data-sort-col="0" onclick="PA.tf.sort(\'tfp\',0)">Procedure</th>'
            + '<th data-sort-col="1" onclick="PA.tf.sort(\'tfp\',1)">Depth</th>'
            + '<th data-sort-col="2" onclick="PA.tf.sort(\'tfp\',2)">Writes</th>'
            + '<th data-sort-col="3" onclick="PA.tf.sort(\'tfp\',3)">Txn boundaries</th>'
            + '</tr></thead><tbody id="tfp-tbody"></tbody></table>';
        c.innerHTML = html;

        PA.txnFlowPaths._pathRows = gridRows;
        if (window.PA && PA.tf) {
            PA.tf.init('tfp', gridRows, PA.pageSize.get(), PA.txnFlowPaths._renderPathRow, {
                renderDetail: PA.txnFlowPaths._renderPathDetail,
                sortKeys: {
                    0: { fn: function (r) { return r.proc || ''; } },
                    1: { fn: function (r) { return r.depth || 0; } },
                    2: { fn: function (r) { return r.writes.length || 0; } }
                },
                searchFn: function (r, q) {
                    return ((r.proc || '') + ' ' + (r.txnBits || '')).toUpperCase().indexOf(q) >= 0;
                }
            });
            PA.tf.render('tfp');
        }
    },

    // The path's proc row.
    _renderPathRow: function (p, idx, esc) {
        var writes = (p.writes.length || 0)
            ? p.writes.length + ' — '
                + '<span class="txn-survival commit">' + (p.survived || 0) + ' survive' + (p.survived === 1 ? 's' : '') + '</span>'
                + (p.discarded ? ' / <span class="txn-survival rollback">' + p.discarded + ' discarded</span>' : '')
                + (p.openW ? ' / <span class="txn-survival open">' + p.openW + ' open</span>' : '')
            : '<span style="color:var(--text-muted)">—</span>';
        var html = '<tr class="to-row" onclick="PA.tf.toggleDetail(\'tfp\',' + idx + ')" style="cursor:pointer" title="Show this procedure\'s operations">';
        html += '<td class="txn-flow-proc" style="font-family:var(--font-mono)">' + esc((p.proc || '').replace(/\$/g, '.')) + '</td>';
        html += '<td>' + (p.depth || 0) + '</td>';
        html += '<td style="white-space:nowrap">' + writes + '</td>';
        html += '<td style="font-family:var(--font-mono);font-size:11px">' + esc(p.txnBits || '—') + '</td>';
        html += '</tr>';
        return html;
    },

    // The expand: the proc's ops ON THIS PATH — DEDUPED (a proc called 32x repeated its same
    // 2 ops 32x — now the unique ops + a xN-calls chip), each line clickable.
    _renderPathDetail: function (p, idx, esc) {
        var seen = {}, deduped = [], callN = {};
        (p.writes || []).forEach(function (e) {
            var k = (e.op || '') + '|' + (e.table || '') + '|' + e.line;
            if (!seen[k]) { seen[k] = true; deduped.push(e); }
            callN[k] = (callN[k] || 0) + 1;
        });
        var html = '<div class="to-detail" style="padding:6px 12px;background:var(--bg-secondary)">';
        html += '<table class="to-table" style="font-size:11.5px"><thead><tr>'
            + '<th>Operation</th><th>Table</th><th>Line (click = source)</th><th>Survival</th><th>Calls</th>'
            + '</tr></thead><tbody>';
        deduped.forEach(function (e) {
            var sv = e.survival || 'open';
            var SURV = { survived: { label: 'survived', cls: 'commit' }, discarded: { label: 'discarded', cls: 'rollback' }, open: { label: 'open', cls: 'open' } };
            var s = SURV[sv] || SURV.open;
            var k = (e.op || '') + '|' + (e.table || '') + '|' + e.line;
            html += '<tr>'
                + '<td>' + esc(e.op || 'WRITE') + '</td>'
                + '<td>' + esc(e.table || '') + '</td>'
                + '<td><span class="est-usedby-proc" onclick="event.stopPropagation();PA.sourceView.openNodeAtLine(\''
                    + PA.escJs(p.nodeId || '') + '\',' + (e.line || 0) + ')">' + (e.line || '?') + '</span></td>'
                + '<td><span class="txn-survival ' + s.cls + '">' + s.label + '</span></td>'
                + '<td>' + (callN[k] > 1 ? 'x ' + callN[k] : '1') + '</td>'
                + '</tr>';
        });
        html += '</tbody></table></div>';
        return html;
    },

    selectRun: function (i) { PA.txnFlowPaths._selRun = i; PA.txnTrace.render(); },
    toggleProc: function (k) { PA.txnFlowPaths._openProcs[k] = !PA.txnFlowPaths._openProcs[k]; PA.txnTrace.render(); }
};
