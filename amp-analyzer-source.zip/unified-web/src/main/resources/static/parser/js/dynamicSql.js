window.PA = window.PA || {};

/**
 * Dynamic SQL report — lists every dynamic execution across the analysis:
 * Oracle EXECUTE IMMEDIATE / OPEN FOR, SQL Server EXEC(@sql) / sp_executesql /
 * SET @sql = '...'. Dialect-agnostic (data comes from node-detail "dynamicSql").
 *
 * Server-paged (PLAN-08 §4.3 step 12), through the shared table framework's page-source path
 * (`PA.tf.init` over `PA.api.facetPageSource('dynamic-sql', …)`). Every dynamic statement in the
 * analysis carries its full SQL text, so the whole report was one of the larger responses on this
 * screen; only a page of it is fetched now. The search box (`q`) and the Direct/Subtree/SubFlow
 * selector (`scope`) travel with the request — searching or scoping the page in the browser would
 * silently apply to twenty-five rows.
 */
PA.dynamicSql = {
    // Retained for callers that test "is this loaded"; the rows are no longer held client-side.
    data: [],
    _q: '',
    _src: null,
    _summary: null,

    async load() {
        var container = document.getElementById('dynContainer');
        if (container) container.innerHTML = '<div class="empty-msg">Loading...</div>';
        this._src = PA.api.facetPageSource('dynamic-sql', this._scopeParams());
        await this._loadSummary();
        this._initTable();
    },

    /** The scope selector as request parameters. */
    _scopeParams() {
        var ctx = PA.context || {};
        if (!ctx.procId || PA._isPackageRoot()) return { scope: 'full' };
        return { scope: PA._scope, procId: PA._currentScopeId() };
    },

    /** The unscoped and in-scope totals for the header chips, which used to be array lengths. */
    async _loadSummary() {
        this._summary = await PA.api.facetSummary('dynamic-sql', this._scopeParams());
    },

    /** The static grid skeleton + PA.tf.init over the existing server page source. */
    _initTable() {
        var container = document.getElementById('dynContainer');
        if (!container) return;

        var html = '<div class="pagination-bar" id="dyn-pager" style="display:none"></div>'
            + '<table class="to-table" style="width:100%"><thead><tr>'
            + '<th data-sort-col="0" onclick="PA.tf.sort(\'dyn\',0)">Procedure</th>'
            + '<th data-sort-col="1" onclick="PA.tf.sort(\'dyn\',1)">Type</th>'
            + '<th data-sort-col="2" onclick="PA.tf.sort(\'dyn\',2)">Line</th>'
            + '<th>SQL / Expression</th>'
            + '</tr></thead><tbody id="dyn-tbody"></tbody></table>';
        container.innerHTML = html;

        PA.tf.init('dyn', this._src, 25, this._renderRow, {
            // The endpoint's closed sort enum, keyed by the column index the <th> carries. The SQL
            // column is not sortable — the honest answer, since sorting the browser's one page
            // would reorder twenty-five rows and nothing else.
            serverSorts: {
                0: { asc: 'PROCEDURE_ASC', desc: 'PROCEDURE_DESC' },
                1: { asc: 'TYPE_ASC', desc: 'TYPE_DESC' },
                2: { asc: 'LINE_ASC', desc: 'LINE_DESC' }
            },
            onFilter: function () {
                PA.dynamicSql._updateChips();
                PA.dynamicSql._maybeEmpty();
            }
        });
        var st = PA.tf.state('dyn');
        if (st) { st.sortCol = 0; st.sortDir = 'asc'; }
        PA.tf._updateSortIndicators('dyn');
    },

    onSearch() {
        this._q = ((document.getElementById('dynSearch') || {}).value || '');
        // Server-paged: the framework forwards `q` to the endpoint and restarts, debounced. A
        // client-side filter over one page would look like it worked while missing every other page.
        PA.tf.setSearch('dyn', this._q);
        PA.tf.filter('dyn');
    },

    clearFilters() {
        var s = document.getElementById('dynSearch');
        if (s) s.value = '';
        this._q = '';
        PA.tf.setSearch('dyn', '');
        PA.tf.filter('dyn');
    },

    applyScope() {
        if (this._src) {
            var params = this._scopeParams();
            this._src.setParam('scope', params.scope);
            this._src.setParam('procId', params.procId || '');
            this._loadSummary().then(function () {
                if (PA.tf.state('dyn')) PA.tf._restart('dyn');
                PA.dynamicSql._updateChips();
            });
        }
    },

    /** Header chips from the summary (unscoped/in-scope totals) and the server's matched count. */
    _updateChips() {
        var sum = this._summary;
        var st = PA.tf.state('dyn');
        var allTotal = sum ? sum.total : (this.data || []).length;
        var scopedTotal = sum ? sum.scopedTotal : allTotal;
        // `matched` is the count matching the current filters, or -1 when the server could not
        // count cheaply — in which case no "n shown" chip is rendered rather than a guess.
        var matched = (st && st.totalIsExact) ? st.serverTotal : -1;

        var total = document.getElementById('dynTotalCount');
        if (total) total.textContent = allTotal + ' dynamic';
        var filtered = document.getElementById('dynFilteredCount');
        if (filtered) {
            if (matched >= 0 && matched !== scopedTotal) {
                filtered.style.display = ''; filtered.textContent = matched + ' shown';
            } else { filtered.style.display = 'none'; }
        }
    },

    /** The framework's generic empty row says "No data found"; this screen says what it means. */
    _maybeEmpty() {
        var st = PA.tf.state('dyn');
        var tb = document.getElementById('dyn-tbody');
        if (!st || !tb) return;
        if (st.loading || st.loadError) return;
        if (st.totalIsExact && st.serverTotal === 0) {
            tb.innerHTML = '<tr><td colspan="4" class="empty-msg" style="padding:20px;text-align:center">'
                + 'No dynamic SQL found in this analysis</td></tr>';
        }
    },

    /** Strip the N'...' / '...' string wrapper and de-indent so multi-line dynamic SQL
     *  renders compact and left-aligned instead of shifted far right with big gaps. */
    _normalize(s) {
        if (!s) return '';
        s = s.trim().replace(/^N?'/, '').replace(/'\s*$/, '').replace(/''/g, "'");
        var lines = s.split('\n');
        while (lines.length && !lines[0].trim()) lines.shift();
        while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
        var min = Infinity;
        lines.forEach(function (l) {
            if (l.trim()) { var m = (l.match(/^\s*/) || [''])[0].length; if (m < min) min = m; }
        });
        if (min !== Infinity && min > 0) lines = lines.map(function (l) { return l.slice(min); });
        return lines.join('\n').trim();
    },

    /** One row of the grid. `idx` is the global row index, which the copy button keys off. */
    _renderRow(d, idx, esc) {
        var proc = '<span class="to-detail-proc" onclick="PA.showProcedure(\''
            + PA.escJs(d.procedureId || d.procedureName || '') + '\')">'
            + esc(d.procedureName || '') + '</span>';
        var line = d.lineNumber
            ? '<span class="to-detail-line" data-tip="Open source at line" onclick="event.stopPropagation(); PA.sourceView.openAtLine(\''
                + PA.escJs(d.sourceFile || '') + '\', ' + d.lineNumber + ')">L' + d.lineNumber + '</span>'
            : '';
        var rawExpr = PA.dynamicSql._normalize(d.sqlExpression || '');
        var expr;
        if (rawExpr) {
            // Full (un-truncated) SQL text for this row, so the copy button copies the complete
            // statement even when the cell shows a scrollable/clamped view.
            PA.dynamicSql._pageTexts = PA.dynamicSql._pageTexts || [];
            PA.dynamicSql._pageTexts[idx] = rawExpr;
            // Scrollable code block (preserves whitespace) + a copy button for the full SQL.
            expr = '<div class="dyn-sql-wrap">'
                + '<button class="btn btn-sm dyn-sql-copy" title="Copy SQL" '
                + 'onclick="event.stopPropagation();PA.dynamicSql.copyExpr(' + idx + ',this)">Copy</button>'
                + '<pre class="dyn-sql-code">' + esc(rawExpr) + '</pre></div>';
        } else {
            // Executor rows (sp_executesql / EXEC(@sql)) run a string built in a SET row
            // above — they carry no inline SQL. Show an explanation instead of a blank cell.
            var t = (d.type || '').toUpperCase();
            var note = t.indexOf('SP_EXECUTESQL') >= 0
                ? 'Executes a dynamic string via sp_executesql (built in a SET @sql above)'
                : (t.indexOf('EXEC') >= 0
                    ? 'Executes a dynamic string (@sql built above)'
                    : '(no inline SQL captured for this execution)');
            expr = '<span style="color:var(--text-muted);font-style:italic">' + esc(note) + '</span>';
        }
        var uv = (d.usingVariables && d.usingVariables.length)
            ? '<div style="color:var(--text-muted);font-size:10px;margin-top:2px">USING: ' + esc(d.usingVariables.join(', ')) + '</div>'
            : '';
        return '<tr class="to-row"><td class="nowrap">' + proc + '</td>'
            + '<td class="nowrap"><span class="ct-call-badge DYNAMIC" title="Dynamic SQL execution">' + esc(d.type || 'DYNAMIC') + '</span></td>'
            + '<td class="nowrap">' + line + '</td>'
            + '<td><span class="sql-cell">' + expr + '</span>' + uv + '</td></tr>';
    },

    /** Copy the full (un-truncated) dynamic SQL for a row on the current page. */
    copyExpr(idx, btn) {
        var txt = (PA.dynamicSql._pageTexts || [])[idx] || '';
        var done = function () {
            if (!btn) return;
            var old = btn.textContent;
            btn.textContent = 'Copied';
            setTimeout(function () { btn.textContent = old; }, 1200);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(txt).then(done, done);
        } else {
            var ta = document.createElement('textarea');
            ta.value = txt; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta); done();
        }
    }
};
