window.PA = window.PA || {};

/**
 * Flow sub-view — BY PROCEDURE (the default landing of the Flow view).
 *
 * One row per procedure in the resolved flow: its transactions (T-ids), its write-survival
 * counts (survived / discarded / open), its transaction-op tally (C·R·S·RT) and its line
 * span. Click a row → the procedure's own per-op GRID expands BELOW it (its own filter, sort
 * and pager — a proc can carry hundreds of ops); every LINE cell is clickable and opens the
 * source at that exact line for verification.
 *
 * Registered as PA.txnFlowProcs. PA.txnTrace's Flow dispatch calls render(container, data)
 * with the txn-runs doc it fetched ONCE per entry (data.procRollup) — the same doc the other
 * two flow sub-views (By-transaction, Execution paths) receive.
 */
PA.txnFlowProcs = {
    render: function (c, data) {
        var rollup = data.procRollup || [];
        var s = data.briefSummary || {};
        var counts = [];
        if (s.committed) counts.push(s.committed + ' committed');
        if (s.rolledBack) counts.push(s.rolledBack + ' rolled back');
        if (s.partial) counts.push(s.partial + ' partial');
        if (s.open) counts.push(s.open + ' open');
        var html = '<div class="txn-pathsel">'
            + '<span class="txn-pathsel-label">Procedures in this flow:</span>'
            + '<span class="txn-resolve-line" style="display:inline">' + rollup.length + ' procedure' + (rollup.length === 1 ? '' : 's')
            + (counts.length ? ' — ' + counts.join(', ') : '') + '</span>'
            + '</div>'
            + '<div style="margin:4px 0"><input id="tbpSearch" type="search" placeholder="Filter procedures…"'
            + ' style="width:280px" oninput="PA.tf.setSearch(\'tbp\', this.value); PA.tf.filter(\'tbp\')"></div>'
            + '<div class="pagination-bar" id="tbp-pager" style="display:none"></div>'
            + '<table class="to-table"><thead><tr>'
            + '<th data-sort-col="0" onclick="PA.tf.sort(\'tbp\',0)">Procedure</th>'
            + '<th data-sort-col="1" onclick="PA.tf.sort(\'tbp\',1)">Transactions</th>'
            + '<th data-sort-col="2" onclick="PA.tf.sort(\'tbp\',2)">Writes</th>'
            + '<th data-sort-col="3" onclick="PA.tf.sort(\'tbp\',3)">Txn ops</th>'
            + '<th data-sort-col="4" onclick="PA.tf.sort(\'tbp\',4)">Lines</th>'
            + '</tr></thead><tbody id="tbp-tbody"></tbody></table>';
        c.innerHTML = html;

        if (window.PA && PA.tf) {
            PA.tf.init('tbp', rollup, PA.pageSize.get(), PA.txnFlowProcs._renderProcRow, {
                renderDetail: PA.txnFlowProcs._renderProcDetail,
                sortKeys: {
                    0: { fn: function (p) { return p.proc || ''; } },
                    1: { fn: function (p) { return (p.transactions || []).join(','); } },
                    2: { fn: function (p) { return p.writesTotal || 0; } },
                    3: { fn: function (p) { return (p.commits || 0) + (p.rollbacks || 0) + (p.savepoints || 0) + (p.rollbackTos || 0); } },
                    4: { fn: function (p) { return p.firstLine || 0; } }
                },
                searchFn: function (p, q) {
                    return ((p.proc || '') + ' ' + (p.transactions || []).join(' ')).toUpperCase().indexOf(q) >= 0;
                }
            });
            PA.tf.initColFilters('tbp', {
                1: { label: 'Transactions', valueFn: function (p) { return (p.transactions || []).slice(); } }
            });
            PA.tf.render('tbp');
        }
    },

    _renderProcRow: function (p, idx, esc) {
        var writes = (p.writesTotal || 0)
            ? '<span class="txn-survival survived" title="survived">' + (p.survived || 0) + '</span>'
              + ' / <span class="txn-survival discarded" title="discarded">' + (p.discarded || 0) + '</span>'
              + (p.open ? ' / <span class="txn-survival open" title="open">' + p.open + '</span>' : '')
            : '<span style="color:var(--text-muted)">—</span>';
        var ops = (p.commits || 0) + 'C · ' + (p.rollbacks || 0) + 'R · ' + (p.savepoints || 0) + 'S · ' + (p.rollbackTos || 0) + 'RT';
        var html = '<tr class="to-row" onclick="PA.tf.toggleDetail(\'tbp\',' + idx + ')" style="cursor:pointer" title="Show this procedure\'s operations">';
        html += '<td style="font-weight:600;color:var(--badge-purple);font-family:var(--font-mono)">' + esc(p.proc || '') + '</td>';
        html += '<td style="white-space:nowrap">'
            + (p.transactions || []).map(function (t) {
                return '<span class="est-usedby-proc" onclick="event.stopPropagation();PA.txnTrace.setRunsMode(\'brief\')">' + esc(t) + '</span>';
              }).join(', ') || '—';
        html += '</td>';
        html += '<td style="white-space:nowrap">' + writes + '</td>';
        html += '<td style="white-space:nowrap;font-family:var(--font-mono);font-size:11px" title="C=commit R=rollback S=savepoint RT=rollback-to">' + ops + '</td>';
        html += '<td style="white-space:nowrap">' + (p.firstLine || 0) + '–' + (p.lastLine || 0) + '</td>';
        html += '</tr>';
        return html;
    },

    // The op-row renderer for ONE proc's detail grid — bound to the proc's nodeId (every op's
    // line opens THE PROC's source at the op's line). Exposed for the tests.
    _makeOpRowRenderer: function (nodeId) {
        return function (o, idx, esc) {
            var surv = o.survival
                ? '<span class="txn-survival ' + esc(o.survival) + '">' + esc(o.survival) + '</span>'
                : '<span style="color:var(--text-muted)">—</span>';
            var h = '<tr class="to-row">';
            h += '<td>' + esc(o.kind || '') + (o.name ? ' <span style="color:var(--text-muted)">(' + esc(o.name) + ')</span>' : '') + '</td>';
            h += '<td>' + esc(o.table || '—') + '</td>';
            h += '<td><span class="est-usedby-proc" onclick="event.stopPropagation();PA.sourceView.openNodeAtLine(\''
                + PA.escJs(nodeId) + '\',' + (o.line || 0) + ')">' + (o.line || '?') + '</span></td>';
            h += '<td>' + surv + '</td>';
            h += '</tr>';
            return h;
        };
    },

    // The expand: the proc's per-op table — Op / Table / Line / Survival, LINE CLICKABLE.
    // The framework WRAPS this return in its own <td colspan="20"> — return the CONTENT
    // (a <div>), never a <tr> (a tr inside a td is dropped by the browser = 'nothing shows').
    _renderProcDetail: function (p, idx, esc) {
        var ops = (p.ops || []);
        var key = 'tbpd-' + idx;
        var html = '<div class="to-detail" style="padding:8px 14px;background:var(--bg-secondary)">';
        html += '<div style="margin:2px 0"><input id="' + key + 'Search" type="search" placeholder="Filter operations…"'
            + ' style="width:240px" oninput="PA.tf.setSearch(\'' + key + '\', this.value); PA.tf.filter(\'' + key + '\')"></div>';
        html += '<div class="pagination-bar" id="' + key + '-pager" style="display:none"></div>';
        html += '<table class="to-table" style="font-size:11.5px"><thead><tr>'
            + '<th data-sort-col="0" onclick="PA.tf.sort(\'' + key + '\',0)">Operation</th>'
            + '<th data-sort-col="1" onclick="PA.tf.sort(\'' + key + '\',1)">Table</th>'
            + '<th data-sort-col="2" onclick="PA.tf.sort(\'' + key + '\',2)">Line (click = source)</th>'
            + '<th data-sort-col="3" onclick="PA.tf.sort(\'' + key + '\',3)">Survival</th>'
            + '</tr></thead><tbody id="' + key + '-tbody"></tbody></table></div>';
        var nodeId = p.nodeId || '';
        var procOps = ops;
        var renderRow = PA.txnFlowProcs._makeOpRowRenderer(nodeId);
        setTimeout(function () {
            if (!window.PA || !PA.tf) return;
            PA.tf.init(key, procOps, 10, renderRow, {});
            PA.tf.render(key);
        }, 0);
        return html;
    }
};
