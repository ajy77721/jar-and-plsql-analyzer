window.PA = window.PA || {};

PA.claudeSessions = {
    _pollTimer: null,

    open: function() {
        PA.claudeSessions.close();
        var overlay = document.createElement('div');
        overlay.className = 'tds-overlay';
        overlay.id = 'claudeSessionsOverlay';
        overlay.onclick = function(e) { if (e.target === overlay) PA.claudeSessions.close(); };

        var modal = document.createElement('div');
        modal.className = 'tds-modal';
        modal.style.maxWidth = '900px';
        modal.onclick = function(e) { e.stopPropagation(); };
        modal.innerHTML =
            '<div class="tds-header">' +
                '<span style="font-weight:700">Claude Sessions</span>' +
                '<div style="display:flex;gap:6px;align-items:center">' +
                    '<button class="btn btn-sm" onclick="PA.claudeSessions.killAll()" style="color:var(--red)">Kill All</button>' +
                    '<button class="btn btn-sm" onclick="PA.claudeSessions.refresh()">Refresh</button>' +
                    '<button class="btn btn-sm" onclick="PA.claudeSessions.close()">&times;</button>' +
                '</div>' +
            '</div>' +
            '<div class="tds-body" id="claudeSessionsBody" style="padding:0;overflow:auto;max-height:65vh">' +
                '<div class="empty-msg">Loading...</div>' +
            '</div>';

        overlay.appendChild(modal);
        document.body.appendChild(overlay);
        requestAnimationFrame(function() { overlay.classList.add('open'); });

        PA.claudeSessions._pollTimer = PollConfig.every('claudeProgressMs',
            function() { PA.claudeSessions.refresh(); });
    },

    close: function() {
        PA.claudeSessions._pollTimer = PollConfig.clear(PA.claudeSessions._pollTimer);
        var el = document.getElementById('claudeSessionsOverlay');
        if (el) { el.classList.remove('open'); setTimeout(function() { if (el.parentNode) el.remove(); }, 200); }
    },

    /**
     * One tick: the live session list, plus the usage totals only if they changed.
     *
     * The totals come from an append-only call log that used to be re-read and re-aggregated on
     * the server for every one of these ticks, at 5 s, to render seven numbers that had not moved.
     * Now the response carries an ETag over the log's length, so an unchanged tick is a 304 and
     * the cached totals are re-rendered without re-fetching or re-aggregating anything. The tick
     * itself is at the configured claudeProgressMs (30 s) rather than a hard-coded 5 s.
     */
    _statsEtag: null,
    _statsCache: null,

    refresh: function() {
        var body = document.getElementById('claudeSessionsBody');
        if (!body) return;

        var headers = PA.claudeSessions._statsEtag
            ? { 'If-None-Match': PA.claudeSessions._statsEtag } : {};

        Promise.all([
            fetch('/api/parser/claude/sessions').then(function(r) { return r.json(); }).catch(function() { return {}; }),
            fetch('/api/parser/claude/stats', { headers: headers }).then(function(r) {
                if (r.status === 304) return PA.claudeSessions._statsCache || {};
                PA.claudeSessions._statsEtag = r.headers.get('ETag');
                return r.json().then(function(j) {
                    PA.claudeSessions._statsCache = j;
                    return j;
                });
            }).catch(function() { return PA.claudeSessions._statsCache || {}; })
        ]).then(function(res) {
            var data = res[0] || {};
            var sessions = data.sessions || (Array.isArray(data) ? data : []) || [];
            var summary = data.summary || {};
            PA.claudeSessions._render(body, sessions, summary, res[1] || {});
        }).catch(function(e) {
            body.innerHTML = '<div class="empty-msg" style="color:var(--red)">Failed to load: ' + PA.esc(e.message || '') + '</div>';
        });
    },

    _fmtBytes: function(n) {
        n = n || 0;
        if (n < 1024) return n + ' B';
        if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
        return (n / 1048576).toFixed(2) + ' MB';
    },

    _fmtDur: function(ms) {
        ms = ms || 0;
        if (ms < 1000) return ms + ' ms';
        var s = ms / 1000;
        if (s < 60) return s.toFixed(1) + 's';
        return Math.floor(s / 60) + 'm ' + Math.round(s % 60) + 's';
    },

    _card: function(label, value) {
        return '<div style="flex:1;min-width:110px;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius-md);padding:8px 12px">'
            + '<div style="font-size:16px;font-weight:700;color:var(--text)">' + value + '</div>'
            + '<div style="font-size:10px;text-transform:uppercase;color:var(--text-muted)">' + label + '</div></div>';
    },

    _renderUsage: function(stats) {
        var log = (stats && stats.log) || {};
        var calls = log.totalCalls || stats.totalCalls || 0;
        var html = '<div style="padding:12px 16px;border-bottom:1px solid var(--border)">';
        html += '<div style="font-size:11px;text-transform:uppercase;color:var(--text-muted);margin-bottom:8px">Claude API Usage (persisted)</div>';
        html += '<div style="display:flex;gap:8px;flex-wrap:wrap">';
        html += this._card('API Calls', calls);
        html += this._card('Sessions', log.sessionCount || 0);
        html += this._card('Prompt', this._fmtBytes(log.totalPromptBytes || stats.totalPromptBytes || 0));
        html += this._card('Response', this._fmtBytes(log.totalResponseBytes || stats.totalResponseBytes || 0));
        html += this._card('Avg Duration', this._fmtDur(log.avgDurationMs || stats.avgDurationMs || 0));
        html += this._card('Total Duration', this._fmtDur(log.totalDurationMs || stats.totalDurationMs || 0));
        html += this._card('Errors', log.errors || stats.errors || 0);
        html += '</div>';

        var sess = log.sessions || [];
        if (sess.length) {
            // The per-session usage rows are a shared PA.tf grid, not a hand-rolled table.
            html += '<div style="margin-top:12px">'
                + '<table class="to-table" style="width:100%"><thead><tr>'
                + '<th data-sort-col="0" onclick="PA.tf.sort(\'csUsage\',0)">Session</th>'
                + '<th data-sort-col="1" onclick="PA.tf.sort(\'csUsage\',1)">Type</th>'
                + '<th data-sort-col="2" onclick="PA.tf.sort(\'csUsage\',2)" style="text-align:right">Calls</th>'
                + '<th data-sort-col="3" onclick="PA.tf.sort(\'csUsage\',3)" style="text-align:right">Prompt</th>'
                + '<th data-sort-col="4" onclick="PA.tf.sort(\'csUsage\',4)" style="text-align:right">Response</th>'
                + '<th data-sort-col="5" onclick="PA.tf.sort(\'csUsage\',5)" style="text-align:right">Duration</th>'
                + '<th data-sort-col="6" onclick="PA.tf.sort(\'csUsage\',6)" style="text-align:right">Errors</th>'
                + '</tr></thead><tbody id="csUsage-tbody"></tbody></table>'
                + '<div class="pagination-bar" id="csUsage-pager" style="display:none"></div>'
                + '</div>';
        }
        html += '</div>';
        return html;
    },

    /** One per-session usage row (a PA.tf renderRow). */
    _renderUsageRow: function(s, idx, esc) {
        var html = '<tr class="to-row">';
        html += '<td style="font-family:var(--font-mono);font-size:9px">' + esc(String(s.sessionId || '').slice(0, 8)) + '</td>';
        html += '<td>' + esc(s.sessionType || '') + '</td>';
        html += '<td style="text-align:right">' + (s.callCount || 0) + '</td>';
        html += '<td style="text-align:right">' + PA.claudeSessions._fmtBytes(s.promptBytes) + '</td>';
        html += '<td style="text-align:right">' + PA.claudeSessions._fmtBytes(s.responseBytes) + '</td>';
        html += '<td style="text-align:right">' + PA.claudeSessions._fmtDur(s.durationMs) + '</td>';
        html += '<td style="text-align:right;color:' + ((s.errorCount || 0) > 0 ? 'var(--red)' : 'inherit') + '">' + (s.errorCount || 0) + '</td>';
        html += '</tr>';
        return html;
    },

    _render: function(body, sessions, summary, stats) {
        stats = stats || {};
        var log = (stats && stats.log) || {};
        var usageSess = log.sessions || [];
        var usageHtml = PA.claudeSessions._renderUsage(stats);

        var html;
        if (!sessions.length) {
            html = usageHtml
                + '<div class="empty-msg">No live Claude sessions this server session.</div>';
        } else {
            var running = summary.running || 0;
            html = usageHtml;
            html += '<div style="padding:10px 16px;font-size:11px;color:var(--text-muted);border-bottom:1px solid var(--border);display:flex;gap:12px">';
            html += '<span>' + sessions.length + ' total</span>';
            if (running > 0) html += '<span style="color:var(--blue);font-weight:600">' + running + ' running</span>';
            if (summary.complete) html += '<span style="color:var(--green)">' + summary.complete + ' complete</span>';
            if (summary.failed) html += '<span style="color:var(--red)">' + summary.failed + ' failed</span>';
            if (summary.killed) html += '<span style="color:var(--orange)">' + summary.killed + ' killed</span>';
            html += '</div>';

            // The live session list is a shared PA.tf grid (pagination, sorting, search).
            html += '<table class="to-table" style="width:100%"><thead><tr>'
                + '<th data-sort-col="0" onclick="PA.tf.sort(\'cs\',0)">ID</th>'
                + '<th data-sort-col="1" onclick="PA.tf.sort(\'cs\',1)">Analysis</th>'
                + '<th data-sort-col="2" onclick="PA.tf.sort(\'cs\',2)">Type</th>'
                + '<th data-sort-col="3" onclick="PA.tf.sort(\'cs\',3)">Status</th>'
                + '<th>Detail</th>'
                + '<th>Duration</th>'
                + '<th>Action</th>'
                + '</tr></thead><tbody id="cs-tbody"></tbody></table>'
                + '<div class="pagination-bar" id="cs-pager" style="display:none"></div>';
        }
        body.innerHTML = html;

        // The usage sub-table is present whenever the log has per-session rows.
        if (usageSess.length) {
            PA.tf.init('csUsage', usageSess, 10, PA.claudeSessions._renderUsageRow, {
                sortKeys: {
                    0: { fn: function(s) { return s.sessionId || ''; } },
                    1: { fn: function(s) { return s.sessionType || ''; } },
                    2: { fn: function(s) { return s.callCount || 0; } },
                    3: { fn: function(s) { return s.promptBytes || 0; } },
                    4: { fn: function(s) { return s.responseBytes || 0; } },
                    5: { fn: function(s) { return s.durationMs || 0; } },
                    6: { fn: function(s) { return s.errorCount || 0; } }
                }
            });
            PA.tf.render('csUsage');
        }
        if (sessions.length) {
            PA.tf.init('cs', sessions, 10, PA.claudeSessions._renderSessionRow, {
                sortKeys: {
                    0: { fn: function(s) { return s.id || ''; } },
                    1: { fn: function(s) { return s.analysisName || ''; } },
                    2: { fn: function(s) { return s.type || ''; } },
                    3: { fn: function(s) { return s.status || ''; } }
                }
            });
            PA.tf.render('cs');
        }
    },

    /** One live session row (a PA.tf renderRow). */
    _renderSessionRow: function(s, idx, esc) {
        var statusColors = { RUNNING: 'var(--blue)', COMPLETE: 'var(--green)', FAILED: 'var(--red)', KILLED: 'var(--orange)' };
        var sc = statusColors[s.status] || 'var(--text-muted)';
        var html = '<tr class="to-row">';
        html += '<td style="font-family:var(--font-mono);font-size:10px">' + esc(s.id || '') + '</td>';
        html += '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(s.analysisName || '') + '</td>';
        html += '<td>' + esc(s.type || '') + '</td>';
        html += '<td style="color:' + sc + ';font-weight:700">' + esc(s.status || '') + '</td>';
        html += '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + PA.escAttr(s.detail || '') + '">' + esc(s.detail || '') + '</td>';
        html += '<td>' + esc(s.durationFormatted || '-') + '</td>';
        html += '<td>';
        if (s.status === 'RUNNING') {
            html += '<button class="btn btn-sm" style="color:var(--red);font-size:10px;padding:2px 8px" onclick="PA.claudeSessions.kill(\'' + PA.esc(s.analysisName || '') + '\',\'' + PA.esc(s.id || '') + '\')">Kill</button>';
        }
        html += '</td></tr>';
        return html;
    },

    kill: function(analysisName, sessionId) {
        if (!analysisName || !sessionId) return;
        fetch('/api/parser/analyses/' + encodeURIComponent(analysisName) + '/claude/sessions/' + encodeURIComponent(sessionId) + '/kill', { method: 'POST' })
            .then(function() {
                PA.toast('Session killed', 'warn');
                PA.claudeSessions.refresh();
            })
            .catch(function(e) {
                PA.toast('Failed to kill session: ' + (e.message || e), 'error');
            });
    },

    killAll: function() {
        fetch('/api/parser/claude/sessions/kill-all', { method: 'POST' })
            .then(function() {
                PA.toast('All sessions killed', 'warn');
                PA.claudeSessions.refresh();
            })
            .catch(function(e) {
                PA.toast('Failed to kill sessions: ' + (e.message || e), 'error');
            });
    }
};
