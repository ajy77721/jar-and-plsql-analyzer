window.PA = window.PA || {};

/**
 * Task 63 — the Coverage panel: how much of the analysis the grammar captured (vs regex fallback),
 * how much of it is verified, and — for every cell that is not 100% — the rows behind the gap.
 *
 * <h2>Where the numbers come from</h2>
 *
 * One endpoint, `GET /api/parser/analyses/{name}/coverage`, serving the save-time grammar-vs-regex
 * document (task 67) merged with the verification funnel (task 63's backend addition). A 404 means
 * the analysis predates the artifact — this panel's empty state, not an error.
 *
 * <h2>Why these are styled divs, not a chart library</h2>
 *
 * The app has no charting dependency and the ask is to stay inside its own idiom. A grammar-vs-regex
 * share is a stacked horizontal bar — a flex row of two segments with a 2px surface gap, the same
 * shape `.sum-bd-bar` already uses in the Summary tab. The funnel is the same bar, one row per
 * stage, sized as a percentage of the node total. Both render as plain HTML, theme with the app's
 * own CSS variables, and cost nothing to load.
 *
 * <h2>Colour is never the only signal</h2>
 *
 * Green (grammar) vs red (fallback) is a status encoding, and green/red is exactly the pair
 * colour-blind readers confuse (the palette validator scores it ΔE≈3 under protanopia). So every
 * segment is direct-labelled with its own name, percentage and count, and the fallback segment
 * additionally carries a diagonal texture — identity survives greyscale, forced-colours and print.
 */
PA.coverage = {
    /** The last fetched document, kept for re-renders; null until loaded. */
    data: null,

    /** Panel entry point — fetch, then render into `#covContainer`. */
    async load() {
        var container = document.getElementById('covContainer');
        if (!container) return;
        container.innerHTML = '<div class="empty-msg">Loading coverage…</div>';
        var doc = null;
        try { doc = await PA.api.getCoverage(); } catch (e) { doc = null; }
        if (!doc) {
            container.innerHTML = PA.coverage.emptyHtml(
                'This analysis predates the coverage artifact.',
                'Coverage is recorded at save time — grammar-vs-regex share, the verification funnel, '
                + 'and the gaps. Re-run the analysis to populate this panel.');
            return;
        }
        PA.coverage.data = doc;
        container.innerHTML = PA.coverage.renderPanel(doc);
        PA.coverage._initGapTable(doc);
    },

    emptyHtml(title, hint) {
        return '<div class="cov-empty">'
            + '<div class="cov-empty-title">' + PA.esc(title) + '</div>'
            + '<div class="cov-empty-hint">' + PA.esc(hint) + '</div>'
            + '</div>';
    },

    /* ------------------------------- panel shell ------------------------------- */

    renderPanel(doc) {
        return '<div class="cov-grid">'
            + PA.coverage.renderGrammarCard(doc)
            + PA.coverage.renderFunnelCard(doc && doc.verification)
            + '</div>'
            + PA.coverage.renderGapsCard(doc);
    },

    /* --------------------------- 1. grammar vs regex --------------------------- */

    renderGrammarCard(doc) {
        var constructs = (doc && doc.constructs) || [];
        var fallbackTotal = PA.coverage.fallbackTotal(doc);
        var headline = (doc && typeof doc.grammarSharePct === 'number')
            ? '<div class="cov-headline">'
                + '<span class="cov-headline-num">' + PA.coverage.pct(doc.grammarSharePct) + '</span>'
                + '<span class="cov-headline-label">grammar-parsed</span>'
                + '<span class="cov-headline-sub">' + fallbackTotal + ' regex fallback'
                + (doc.grammarAttempts != null ? ' · ' + doc.grammarAttempts + ' attempts' : '') + '</span>'
              + '</div>'
            : '';
        var bars = constructs.length
            ? constructs.map(PA.coverage.barRow).join('')
            : '<div class="cov-none">No constructs recorded for this analysis.</div>';
        return '<div class="cov-card">'
            + '<div class="cov-card-title">Grammar vs regex fallback</div>'
            + headline
            + '<div class="cov-bars">' + bars + '</div>'
            + '<div class="cov-legend-row">'
            +   '<span class="cov-legend"><span class="cov-swatch cov-swatch-grammar"></span>Grammar</span>'
            +   '<span class="cov-legend"><span class="cov-swatch cov-swatch-fallback"></span>Regex fallback</span>'
            + '</div>'
            + '</div>';
    },

    /** One construct's stacked bar — grammar (green) over fallback (red), each direct-labelled. */
    barRow(c) {
        var dialect = String(c.dialect || '').toUpperCase();
        var construct = c.construct || '';
        var grammar = Number(c.grammar || 0);
        var fallback = Number(c.fallback || 0);
        var total = grammar + fallback;
        var gPct = total > 0 ? (grammar / total) * 100 : 100;
        var fPct = 100 - gPct;
        var label = dialect + (construct ? ' · ' + construct : '');
        return '<div class="cov-bar-row">'
            + '<div class="cov-bar-label" title="' + PA.escAttr(label) + '">' + PA.esc(label) + '</div>'
            + '<div class="cov-bar-track" title="' + PA.escAttr(grammar + ' grammar / ' + fallback + ' regex fallback') + '">'
            +   '<div class="cov-bar-seg cov-bar-grammar" style="width:' + gPct.toFixed(2) + '%"></div>'
            +   '<div class="cov-bar-seg cov-bar-fallback" style="width:' + fPct.toFixed(2) + '%"></div>'
            + '</div>'
            + '<div class="cov-bar-value">'
            +   '<span class="cov-v-grammar">' + gPct.toFixed(1) + '% grammar</span>'
            +   '<span class="cov-v-sep">·</span>'
            +   '<span class="cov-v-fallback">' + fPct.toFixed(1) + '% fallback (' + fallback + ')</span>'
            + '</div>'
            + '</div>';
    },

    /** The regex-fallback total: the served field when present, else summed from the constructs. */
    fallbackTotal(doc) {
        if (doc && typeof doc.regexFallbackTotal === 'number') return doc.regexFallbackTotal;
        var constructs = (doc && doc.constructs) || [];
        return constructs.reduce(function (a, c) { return a + Number(c.fallback || 0); }, 0);
    },

    /* --------------------------- 2. verification funnel --------------------------- */

    /** The four funnel stages, in order, as {key,label,count}. Pure — the panel and the tests share it. */
    funnelStages(verification) {
        var f = (verification && verification.funnel) || {};
        var total = Number(f.nodes || 0);
        return [
            { key: 'nodes', label: 'Nodes', count: total },
            { key: 'sourceCaptured', label: 'Source captured', count: Number(f.sourceCaptured || 0) },
            { key: 'catalogVerified', label: 'Catalog verified', count: Number(f.catalogVerified || 0) },
            { key: 'lineChecked', label: 'Line checked', count: Number(f.lineChecked || 0) }
        ];
    },

    renderFunnelCard(verification) {
        var title = '<div class="cov-card-title">Verification funnel</div>';
        if (!verification || !verification.funnel) {
            return '<div class="cov-card">' + title
                + '<div class="cov-none">No verification data in this analysis.</div></div>';
        }
        var stages = PA.coverage.funnelStages(verification);
        var total = stages[0].count;
        var rows = stages.map(function (s) {
            var pct = total > 0 ? (s.count / total) * 100 : 0;
            return '<div class="cov-funnel-row">'
                + '<div class="cov-funnel-stage">' + PA.esc(s.label) + '</div>'
                + '<div class="cov-funnel-track"><div class="cov-funnel-fill" style="width:' + pct.toFixed(2) + '%"></div></div>'
                + '<div class="cov-funnel-value">' + s.count + (total > 0 ? ' (' + pct.toFixed(0) + '%)' : '') + '</div>'
                + '</div>';
        }).join('');
        var gap = total - stages[stages.length - 1].count;
        var note = gap > 0
            ? '<div class="cov-funnel-note">' + gap + ' node(s) not fully verified — see the missing &amp; why table below.</div>'
            : '<div class="cov-funnel-note cov-funnel-note-ok">Every node is fully verified.</div>';
        return '<div class="cov-card">' + title
            + '<div class="cov-funnel">' + rows + '</div>' + note
            + '</div>';
    },

    /* --------------------------- 3. missing & why table --------------------------- */

    renderGapsCard(doc) {
        var title = '<div class="cov-card-title">Missing &amp; why</div>';
        if (!PA.coverage.gapRows(doc).length) {
            return '<div class="cov-card cov-card-wide">' + title
                + '<div class="cov-none cov-none-ok">Nothing missing — every cell is 100%.</div>'
                + '</div>';
        }
        return '<div class="cov-card cov-card-wide">' + title
            + '<div class="cov-gaps-hint">Every cell that is not 100%. Click a row to see the rows behind the gap.</div>'
            + '<div class="to-container cov-gaps-container" id="covGapContainer">'
            +   '<table class="to-table"><thead><tr>'
            +     '<th data-sort-col="0" onclick="PA.tf.sort(\'cov-gap\',0)">Kind</th>'
            +     '<th data-sort-col="1" onclick="PA.tf.sort(\'cov-gap\',1)">Dialect</th>'
            +     '<th data-sort-col="2" onclick="PA.tf.sort(\'cov-gap\',2)">Construct</th>'
            +     '<th data-sort-col="3" onclick="PA.tf.sort(\'cov-gap\',3)">Missing</th>'
            +     '<th data-sort-col="4" onclick="PA.tf.sort(\'cov-gap\',4)">Share</th>'
            +     '<th>Why</th>'
            +   '</tr></thead><tbody id="cov-gap-tbody"></tbody></table>'
            + '</div>'
            + '<div class="pagination-bar" id="cov-gap-pager" style="display:none"></div>'
            + '</div>';
    },

    /**
     * Every non-100% cell as a flat row list, in two kinds:
     *  - `grammar` rows — one per dialect×construct with a regex fallback (the fallback rows are
     *    aggregated at save time; the drill explains that honestly and points at the Dynamic SQL tab);
     *  - `verification` rows — one per funnel stage that is short of the node total; the drill lists
     *    the exact nodes behind that stage, each clickable to its source.
     */
    gapRows(doc) {
        var rows = [];
        var constructs = (doc && doc.constructs) || [];
        constructs.forEach(function (c) {
            var fallback = Number(c.fallback || 0);
            if (fallback <= 0) return;
            var total = Number(c.grammar || 0) + fallback;
            rows.push({
                kind: 'Grammar',
                dialect: String(c.dialect || '').toUpperCase(),
                construct: c.construct || '',
                missing: fallback,
                sharePct: total > 0 ? (fallback / total) * 100 : 0,
                why: 'regex fallback — the grammar did not match this construct',
                nodes: null
            });
        });
        var ver = doc && doc.verification;
        if (ver && ver.funnel) {
            var total = Number(ver.funnel.nodes || 0);
            var gaps = ver.gaps || {};
            var dialect = PA.coverage.analysisDialect(doc);
            [['sourceCaptured', 'Source captured', 'source not captured'],
             ['catalogVerified', 'Catalog verified', 'not found in catalog'],
             ['lineChecked', 'Line checked', 'declaring-line mismatch']].forEach(function (s) {
                var have = Number(ver.funnel[s[0]] || 0);
                var missing = total - have;
                if (missing <= 0) return;
                rows.push({
                    kind: 'Verification',
                    dialect: dialect,
                    construct: s[1],
                    missing: missing,
                    sharePct: total > 0 ? (missing / total) * 100 : 0,
                    why: s[2],
                    nodes: gaps[s[0]] || []
                });
            });
        }
        return rows;
    },

    /** The analysis's own dialect, from whatever the document carries; '' when unknown. */
    analysisDialect(doc) {
        if (!doc) return '';
        if (doc.dialect) return String(doc.dialect).toUpperCase();
        var constructs = doc.constructs || [];
        return constructs.length ? String(constructs[0].dialect || '').toUpperCase() : '';
    },

    /** PA.tf row renderer — the grid's own esc is passed in as the third argument. */
    gapRowHtml(row, i, esc) {
        var kindClass = row.kind === 'Verification' ? 'cov-kind-verify' : 'cov-kind-grammar';
        return '<tr class="to-row">'
            + '<td><span class="cov-kind ' + kindClass + '">' + esc(row.kind) + '</span></td>'
            + '<td>' + esc(row.dialect) + '</td>'
            + '<td class="cov-mono">' + esc(row.construct) + '</td>'
            + '<td class="cov-num">' + esc(String(row.missing)) + '</td>'
            + '<td class="cov-num">' + esc(row.sharePct.toFixed(1) + '%') + '</td>'
            + '<td class="cov-why">' + esc(row.why) + '</td>'
            + '</tr>';
    },

    /** PA.tf detail renderer — the rows behind the gap. Returned bare (the framework wraps the cell). */
    gapDetailHtml(row, i, esc) {
        if (row.kind === 'Grammar') {
            return '<div class="cov-detail">'
                + '<div class="cov-detail-note">Regex-fallback statements are counted per construct at save '
                + 'time; their individual locations are not indexed, so there are no rows to open here. '
                + 'The captured dynamic-SQL statements are listed in the <b>Dynamic SQL</b> sub-tab.</div>'
                + '</div>';
        }
        var nodes = row.nodes || [];
        if (!nodes.length) {
            return '<div class="cov-detail"><div class="cov-detail-note">No node rows recorded for this stage.</div></div>';
        }
        var items = nodes.map(function (n) {
            var where = n.schema ? n.schema + '.' : '';
            var line = n.lineStart ? ' · line ' + n.lineStart : '';
            return '<li class="cov-detail-item" onclick="PA.coverage.openNode(\'' + PA.escJs(n.nodeId) + '\',' + Number(n.lineStart || 0) + ')" '
                + 'title="Open ' + PA.escAttr(n.sourceFile || n.nodeId) + '">'
                + '<span class="cov-detail-name">' + esc(where + (n.name || n.nodeId)) + '</span>'
                + '<span class="cov-detail-type">' + esc(n.objectType || '') + '</span>'
                + '<span class="cov-detail-why">' + esc(n.why || '') + line + '</span>'
                + '</li>';
        }).join('');
        return '<div class="cov-detail"><ul class="cov-detail-list">' + items + '</ul></div>';
    },

    /** Open a node's source at its declaring line — the same jump the rest of the app uses. */
    openNode(nodeId, line) {
        if (PA.sourceView && PA.sourceView.openNodeAtLine) {
            PA.sourceView.openNodeAtLine(nodeId, line || 0);
        } else {
            PA.toast('Source view is unavailable', 'error');
        }
    },

    _initGapTable(doc) {
        var tbody = document.getElementById('cov-gap-tbody');
        if (!tbody) return;                     // no gaps (or the shell was not mounted)
        var rows = PA.coverage.gapRows(doc);
        if (!rows.length) return;
        PA.tf.init('cov-gap', rows, 25, PA.coverage.gapRowHtml, {
            renderDetail: PA.coverage.gapDetailHtml,
            sortKeys: {
                0: function (r) { return r.kind; },
                1: function (r) { return r.dialect; },
                2: function (r) { return r.construct; },
                3: function (r) { return r.missing; },
                4: function (r) { return r.sharePct; }
            }
        });
        PA.tf.render('cov-gap');
    },

    /* --------------------------------- helpers --------------------------------- */

    pct(v) {
        var n = Number(v);
        return (isFinite(n) ? n : 0).toFixed(1) + '%';
    }
};
