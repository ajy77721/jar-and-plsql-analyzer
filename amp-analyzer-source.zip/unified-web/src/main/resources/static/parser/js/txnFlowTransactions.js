window.PA = window.PA || {};

/**
 * Flow sub-view — BY TRANSACTION (the T-brief table).
 *
 * One row per transaction (T1, T2, …): its outcome chip, the plain-English note, its start/end
 * as clickable proc@line links (opens the source at that line), and the procedures it spans
 * (each with its own op chips). An outcome quick-filter (chips) narrows the table. The rows
 * render through the shared table framework (sortable columns, search, remembered page size,
 * pagination) — NOT a hand-rolled table. Clicking a row expands its per-proc detail.
 *
 * Registered as PA.txnFlowTransactions. PA.txnTrace's Flow dispatch calls render(container, data)
 * with the txn-runs doc it fetched ONCE per entry (data.brief / data.briefSummary) — the same doc
 * the other two flow sub-views receive.
 */
PA.txnFlowTransactions = {
    _filter: 'ALL',   // ALL | COMMITTED | ROLLED_BACK | OPEN | PARTIAL

    _outcomeChip: function (oc) {
        var map = { COMMITTED: 'ok', ROLLED_BACK: 'err', OPEN: 'open', PARTIAL: '',
                    SAVED_WITH_PARENT: 'ok', ROLLED_BACK_TO_SAVEPOINT: 'rollback' };
        return map[oc] || '';
    },

    render: function (c, data) {
        var brief = data.brief || [];
        var s = data.briefSummary || {};
        var counts = [];
        if (s.committed) counts.push(s.committed + ' committed');
        if (s.rolledBack) counts.push(s.rolledBack + ' rolled back');
        if (s.partial) counts.push(s.partial + ' partial');
        if (s.open) counts.push(s.open + ' open');
        if (s.savedWithParent) counts.push(s.savedWithParent + ' saved with parent');

        // ── Back control + header (the user's navigation ask: a way back to the prior state) ──
        var backTo = PA.txnTrace._briefBackTo;
        var html = '<div class="txn-pathsel">'
            + (backTo ? '<button class="btn btn-sm" style="margin-right:8px" onclick="PA.txnTrace.goBack()"'
                + ' title="Back to ' + PA.escAttr(backTo.label || 'the previous view') + '">‹ Back</button>' : '')
            + '<span class="txn-pathsel-label">Transactions:</span>'
            + '<span class="txn-resolve-line" style="display:inline">' + (s.transactions || brief.length)
            + ' transaction' + (brief.length === 1 ? '' : 's') + ' in this flow'
            + (counts.length ? ' — ' + counts.join(', ') : '') + '</span>'
            + '</div>';

        // The outcome quick-filter chips (click to narrow; click again to clear).
        var filters = ['ALL', 'COMMITTED', 'ROLLED_BACK', 'PARTIAL', 'OPEN'];
        html += '<div class="txn-pathsel" style="margin-top:4px">';
        filters.forEach(function (f) {
            var active = PA.txnFlowTransactions._filter === f;
            var n = f === 'ALL' ? brief.length : brief.filter(function (t) { return t.outcome === f; }).length;
            if (f !== 'ALL' && !n && !active) return;
            html += '<span class="txn-op-chip" style="cursor:pointer;' + (active ? '' : 'opacity:.55')
                + '" onclick="PA.txnFlowTransactions.setFilter(\'' + f + '\')">' + f + ' (' + n + ')</span> ';
        });
        html += '</div>';

        html += '<div id="txnBriefContainer">'
            + '<div style="margin:4px 0"><input id="tbrSearch" type="search" placeholder="Filter transactions…"'
            + ' style="width:280px" oninput="PA.tf.setSearch(\'tbr\', this.value); PA.tf.filter(\'tbr\')"></div>'
            + '<div class="pagination-bar" id="tbr-pager" style="display:none"></div>'
            + '<table class="to-table"><thead><tr>'
            + '<th data-sort-col="0" onclick="PA.tf.sort(\'tbr\',0)">T</th>'
            + '<th data-sort-col="1" onclick="PA.tf.sort(\'tbr\',1)">Outcome</th>'
            + '<th>What happens</th>'
            + '<th data-sort-col="3" onclick="PA.tf.sort(\'tbr\',3)">Starts</th>'
            + '<th data-sort-col="4" onclick="PA.tf.sort(\'tbr\',4)">Ends</th>'
            + '<th data-sort-col="5" onclick="PA.tf.sort(\'tbr\',5)">Procs</th>'
            + '</tr></thead><tbody id="tbr-tbody"></tbody></table></div>';
        c.innerHTML = html;

        var f = PA.txnFlowTransactions._filter;
        var rows = f === 'ALL' ? brief : brief.filter(function (t) { return t.outcome === f; });
        if (window.PA && PA.tf) {
            PA.tf.init('tbr', rows, PA.pageSize.get(), PA.txnFlowTransactions._renderBriefRow, {
                // Task-64-review — the row CLICK's expand: the T's procs + their ops as a TABLE
                // (the same shape as By-procedure's expand) — the grid was created WITHOUT it, so
                // the click opened an EMPTY row (nothing to show).
                renderDetail: PA.txnFlowTransactions._renderTDetail,
                sortKeys: {
                    0: { fn: function (t) { return t.id || ''; } },
                    1: { fn: function (t) { return t.outcome || ''; } },
                    3: { fn: function (t) { return (t.start ? (t.start.proc || '') + '@' + (t.start.line || 0) : ''); } },
                    4: { fn: function (t) { return (t.end ? (t.end.proc || '') + '@' + (t.end.line || 0) : '~no boundary'); } },
                    5: { fn: function (t) { return t.procCount || 0; } }
                },
                searchFn: function (t, q) {
                    var hay = [t.id, t.outcome, t.note, t.rollbackVia,
                        (t.start ? t.start.proc : ''), (t.end ? t.end.proc : '')].join(' ').toUpperCase();
                    return hay.indexOf(q) >= 0;
                }
            });
            // The user's ask: column filters like every other grid in the app (array-backed, so
            // the popover value lists come from the whole in-memory set — no serverValues needed).
            PA.tf.initColFilters('tbr', {
                0: { label: 'T', valueFn: function (t) { return t.id || ''; } },
                1: { label: 'Outcome', valueFn: function (t) { return t.outcome || ''; } },
                5: { label: 'Procs', valueFn: function (t) { return String(t.procCount || 0); } }
            });
            PA.tf.render('tbr');
        }
    },

    // The T-row's expand: ITS procs' ops — one row per op (proc/op/line clickable/survival).
    _renderTDetail: function (t, idx, esc) {
        var html = '<div class="to-detail" style="padding:8px 14px;background:var(--bg-secondary)">';
        html += '<table class="to-table" style="font-size:11.5px"><thead><tr>'
            + '<th>Procedure</th><th>Operation</th><th>Table</th><th>Line (click = source)</th><th>Survival</th>'
            + '</tr></thead><tbody>';
        (t.procs || []).forEach(function (p) {
            (p.ops || []).forEach(function (o) {
                var surv = o.survival
                    ? '<span class="txn-survival ' + esc(o.survival) + '">' + esc(o.survival) + '</span>'
                    : '<span style="color:var(--text-muted)">—</span>';
                html += '<tr>'
                    + '<td style="font-family:var(--font-mono)">' + esc(p.proc || '') + '</td>'
                    + '<td>' + esc(o.op || o.kind || '') + '</td>'
                    + '<td>' + esc(o.table || '—') + '</td>'
                    + '<td><span class="est-usedby-proc" onclick="event.stopPropagation();PA.sourceView.openNodeAtLine(\''
                        + PA.escJs(p.nodeId || '') + '\',' + (o.line || 0) + ')">' + (o.line || '?') + '</span></td>'
                    + '<td>' + surv + '</td>'
                    + '</tr>';
            });
        });
        html += '</tbody></table></div>';
        return html;
    },

    _renderBriefRow: function (t, idx, esc) {
        var oc = PA.txnFlowTransactions._outcomeChip(t.outcome);
        var link = function (p) {
            if (!p || !p.proc) return '<span style="color:var(--text-muted)">—</span>';
            return '<span class="est-usedby-proc" onclick="event.stopPropagation();PA.sourceView.openNodeAtLine(\''
                + PA.escJs(p.nodeId || '') + '\',' + (p.line || 0) + ')">' + esc(p.proc)
                + ' <span style="color:var(--text-muted)">@' + (p.line || '?') + '</span></span>';
        };
        var parentTag = t.parent ? ' <span style="color:var(--text-muted)">in ' + esc(t.parent) + '</span>' : '';
        var html = '<tr class="to-row" onclick="PA.tf.toggleDetail(\'tbr\',' + idx + ')" style="cursor:pointer" title="Show this transaction\'s procs">';
        html += '<td style="white-space:nowrap"><b>' + esc(t.id || '?') + '</b>' + parentTag
            + (t.kind === 'autonomous' ? ' <span class="est-badge">AUTONOMOUS</span>' : '') + '</td>';
        html += '<td style="white-space:nowrap"><span class="txn-exit-tag ' + oc + '" style="font-size:10px">' + esc(t.outcome || '?') + '</span></td>';
        html += '<td>' + esc(t.note || '')
            + (t.rollback === 'DELEGATED' && t.rollbackVia ? '<br><span style="color:var(--text-muted)">rollback lives in: ' + esc(t.rollbackVia) + '</span>' : '')
            + '</td>';
        html += '<td style="white-space:nowrap">' + link(t.start) + '</td>';
        html += '<td style="white-space:nowrap">' + (t.end ? link(t.end) : '<span style="color:var(--text-muted)">no boundary</span>') + '</td>';
        // Task-64-review fix — the Procs cell showed EVERY op as a chip (a 60-write T rendered
        // a "WRITE WRITE WRITE…" wall — unreadable). The CELL shows the proc NAMES only; the
        // OPS live in the row-click's expand table (the same rule as By-procedure).
        var names = (t.procs || []).map(function (p) { return p.proc || ''; }).join(', ');
        var pc = '<div style="max-width:300px;white-space:normal;font-size:11px">'
            + '<b>' + (t.procCount || 0) + '</b> · ' + esc(names) + '</div>';
        html += '<td>' + pc + '</td>';
        html += '</tr>';
        return html;
    },

    setFilter: function (f) {
        PA.txnFlowTransactions._filter = (PA.txnFlowTransactions._filter === f) ? 'ALL' : f;
        PA.txnTrace.render();
    }
};
