/**
 * The login flow's UX contract, asserted against the shipped index.html.
 *
 * Three regressions this locks down:
 *   1. The device flow auto-starts once per browser session (a refresh must not register a second
 *      device code) and resumes an in-flight flow instead of restarting it.
 *   2. Step 2 is a full-takeover panel: the code is big and copyable, and ONE "Open AWS
 *      verification →" button is the only way the AWS tab opens (the click is the gesture that
 *      makes window.open reliable; the auto-open attempt is gone — it always popup-blocks). The
 *      handle is kept so the AWS tab can be auto-closed on success, and a live status line flips
 *      to green once AWS confirms.
 *   3. The approval→usable-app path polls every 2 s and shows a live status while the server
 *      finishes.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { ok, equal, includes, excludes } from './lib/assert.mjs';
import { installDom } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel) => readFile(path.join(STATIC, rel), 'utf8');

export async function test_login_auto_starts_the_device_flow() {
  const html = await read('index.html');
  // The auto-start entry point exists and is what the page-lock landing calls.
  includes(html, 'function awsSsoAutoStartLogin()',
    'the login page must define the auto-start helper');
  includes(html, 'awsSsoAutoStartLogin();',
    'loadAwsSsoStatus / the 401 handler must call awsSsoAutoStartLogin');
  // It registers the device flow (POST /api/auth/aws/start) and lands on Step 2 — but it must NOT
  // try to open the AWS tab itself: without a gesture that is always popup-blocked.
  includes(html, 'awsSsoContinue({ startUrl: startUrl })',
    'auto-start must register the device flow without auto-opening a tab');
  excludes(html, 'autoRedirect',
    'the popup-blocked auto-open attempt must be gone — the button is the gesture');
}

export async function test_auto_start_is_guarded_once_per_session() {
  const html = await read('index.html');
  includes(html, "AWS_SSO_AUTOSTART_KEY = 'awsSsoAutoStarted'",
    'a sessionStorage guard key must gate auto-start');
  includes(html, 'sessionStorage.getItem(AWS_SSO_AUTOSTART_KEY)',
    'auto-start must read the session guard before registering');
  includes(html, 'sessionStorage.setItem(AWS_SSO_AUTOSTART_KEY',
    'auto-start must set the session guard when it registers');
  // Unauthenticated-only: bail out when a live session is already known.
  includes(html, 'if (_awsSsoSession) return;',
    'auto-start must be a no-op when already authenticated');
}

export async function test_step2_is_a_takeover_panel_with_one_open_button() {
  const html = await read('index.html');
  // ONE big primary action, wired to the click-gesture opener.
  includes(html, 'id="awsSsoOpenAwsBtn"',
    'Step 2 must have the big Open AWS verification button');
  includes(html, 'onclick="awsSsoOpenVerifyTab()"',
    'the big button must open the AWS tab');
  includes(html, 'Open AWS verification',
    'the button label must be "Open AWS verification →"');
  // The code is shown big and copyable (69f): a small copy affordance sits under it.
  includes(html, 'id="awsSsoCopyCodeBtn"', 'the panel must offer a copy-code button');
  includes(html, 'onclick="awsSsoCopyCode()"', 'the copy button must run the copy handler');
  includes(html, 'id="awsSsoUserCode"', 'the big device code must be rendered');
  // Still no fallback link: the URL carries the code, so the button is the only way out.
  excludes(html, 'id="awsSsoVerifyLink"',
    'the fallback link below must be gone — one button only');
}

export async function test_aws_tab_opens_by_gesture_and_closes_on_success() {
  const html = await read('index.html');
  // The click gesture is what makes the new tab reliable.
  includes(html, "window.open(href, '_blank')",
    'the button must open the AWS portal in a new tab');
  includes(html, 'function awsSsoCloseVerifyTab(',
    'the app must try to close the AWS tab once the login completes');
  includes(html, 'w.close()',
    'closing the AWS tab must use the window handle');
  includes(html, 'you can close the AWS tab',
    'when the tab cannot be closed, the app must say so as a hint');
  // Last-resort fallback only: same-tab redirect, flow still persisted.
  includes(html, 'window.location.href = href',
    'a blocked popup must fall back to the same-tab redirect');
  includes(html, "AWS_SSO_FLOW_KEY = 'awsSsoFlow'",
    'the in-flight flow must be persisted across the AWS redirect');
  includes(html, 'function awsSsoReadFlow()',
    'returning to the app must be able to resume the persisted flow');
  includes(html, 'awsSsoShowStep(2)',
    'the resumed flow must restore the device-verification step');
}

export async function test_poll_interval_is_two_seconds() {
  const html = await read('index.html');
  includes(html, 'const AWS_SSO_POLL_MS = 2000;',
    'the device-flow poll must run every 2 s for a fast post-approval hand-off');
  includes(html, 'setInterval(awsSsoPoll, AWS_SSO_POLL_MS)',
    'the poll timer must use the 2 s interval');
  excludes(html, 'AWS_SSO_POLL_FALLBACK_MS',
    'the retired 5 s poll fallback must be gone');
}

export async function test_post_approval_shows_live_status() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoStatusLine"',
    'the modal must render a shared live-status line');
  includes(html, 'Approved — entering…',
    'the post-approval step must show the entering status');
  includes(html, 'function awsSsoAwaitReconnect(',
    'the UI must wait briefly for the server-side auto-reconnect');
  includes(html, 'awsSsoEnterWorkspace()',
    'the UI must admit the user once the session is connected');
}

/* ─────────── Change 69b/69c/69d — back, own-bucket hint, create-bucket retry ─────────── */

// Pulls a top-level `function name(...) { ... }` out of the shipped page so the pure helpers can
// be exercised directly, not only asserted as substrings. Brace-counted rather than regexed: the
// bodies contain nested blocks (and the odd `function (k) { ... }` callback).
function extractFn(src, name) {
  let at = src.indexOf('function ' + name + '(');
  ok(at >= 0, name + ' was not found in index.html');
  // Keep a leading `async` — without it an extracted awaited body is a syntax error to evaluate.
  if (src.slice(at - 6, at) === 'async ') at -= 6;
  let depth = 0, i = src.indexOf('{', at);
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { i++; break; } }
  }
  return src.slice(at, i);
}

// Evaluates the named functions in isolation and hands them back. Only for the ones with no
// page-global dependencies (document aside) — the rest are asserted as source text.
async function loadFns(names) {
  const html = await read('index.html');
  const body = names.map((n) => extractFn(html, n)).join('\n');
  return new Function(body + '\nreturn { ' + names.join(', ') + ' };')();
}

/* 69b — Back on the code step, and switch-account on the chooser. */

export async function test_step2_back_abandons_the_flow_without_disconnecting() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoBackBtn"', 'step 2 must offer a Back control');
  includes(html, 'onclick="awsSsoRestartLogin()"', 'Back must run the shared restart helper');
  // The helper stops the poll and clears the saved flow, exactly as the expiry path does …
  const restart = extractFn(html, 'awsSsoRestartLogin');
  includes(restart, 'awsSsoStopPoll()', 'Back must cancel the in-flight poll');
  includes(restart, 'awsSsoClearFlow()', 'Back must clear the saved device flow');
  includes(restart, 'awsSsoShowStep(1)', 'Back must return to step 1');
  // … but a pre-connect Back must never drop a connected session or its saved target.
  excludes(restart, 'awsSsoDisconnect', 'Back must not call the disconnect path');
  excludes(restart, '_awsSsoSession = null', 'Back must not null out a live session');
  excludes(restart, 'AWS_SSO_BUCKET_KEY', 'Back must not touch the remembered bucket');
}

export async function test_chooser_offers_switching_account() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoSwitchAccountBtn"',
    'the chooser must offer a different-account button');
  includes(html, 'Sign in with a different account', 'the button label must be explicit');
  includes(html, 'onclick="awsSsoRestartLogin()"', 'it must reuse the shared restart helper');
  includes(html, 'If this list looks wrong, close this and sign in again.',
    'the existing chooser hint text must be kept');
}

/* 69c/69d — classifying the failure from the trailing AWS code. */

export async function test_connect_error_code_is_the_trailing_aws_code() {
  const { awsSsoErrorCode } = await loadFns(['awsSsoErrorCode']);
  equal(awsSsoErrorCode('Bucket "amp-x" not found — ... (NoSuchBucket)'), 'NoSuchBucket',
    'the trailing (NoSuchBucket) must be recognised');
  equal(awsSsoErrorCode('Bucket "amp-x" denied access — ... (AccessDenied)'), 'AccessDenied',
    'the trailing (AccessDenied) must be recognised');
  equal(awsSsoErrorCode('Failed to connect to S3: network down'), '',
    'an unclassified error must yield no code');
  equal(awsSsoErrorCode('(AccessDenied) then more text'), '',
    'only the LAST token counts — a leading code is not the contract');
  equal(awsSsoErrorCode(''), '', 'an empty message must be safe');
  equal(awsSsoErrorCode(undefined), '', 'a missing message must be safe');
}

export async function test_access_denied_renders_the_own_bucket_hint() {
  const { awsSsoRenderConnectHint } = await loadFns(['awsSsoErrorCode', 'awsSsoRenderConnectHint']);
  const dom = installDom();
  const hint = dom.add('awsSsoError3Hint');
  awsSsoRenderConnectHint('Bucket "shared" denied access — ask the owner (AccessDenied)');
  equal(hint.style.display, 'block', 'the AccessDenied hint must be shown');
  includes(hint.innerHTML, "This bucket's owner hasn't granted your account.",
    'the own-bucket explanation must be rendered');
  includes(hint.innerHTML, 'Use my own bucket', 'the own-bucket button must be rendered');
  includes(hint.innerHTML, 'awsSsoUseOwnBucket()', 'the button must run the own-bucket action');
}

export async function test_no_such_bucket_renders_the_create_hint() {
  const { awsSsoRenderConnectHint } = await loadFns(['awsSsoErrorCode', 'awsSsoRenderConnectHint']);
  const dom = installDom();
  const hint = dom.add('awsSsoError3Hint');
  awsSsoRenderConnectHint('Bucket "amp-x" not found — it may be misspelled (NoSuchBucket)');
  equal(hint.style.display, 'block', 'the NoSuchBucket hint must be shown');
  includes(hint.innerHTML, 'No bucket with this name was found.',
    'the not-found explanation must be rendered');
  includes(hint.innerHTML, 'Create this bucket in my account', 'the create button must be rendered');
  includes(hint.innerHTML, 'id="awsSsoCreateBucketBtn"', 'the create button must be addressable');
  includes(hint.innerHTML, 'awsSsoCreateBucket()', 'the button must run the create retry');
}

export async function test_unclassified_failure_shows_no_hint() {
  const { awsSsoRenderConnectHint } = await loadFns(['awsSsoErrorCode', 'awsSsoRenderConnectHint']);
  const dom = installDom();
  const hint = dom.add('awsSsoError3Hint');
  hint.style.display = 'block';
  hint.innerHTML = '<button>stale</button>';
  awsSsoRenderConnectHint('Failed to connect to S3: connection reset');
  equal(hint.style.display, 'none', 'an unclassified failure must not show a recovery hint');
  equal(hint.innerHTML, '', 'a stale recovery button must be dropped');
}

export async function test_use_my_own_bucket_clears_and_focuses_the_field() {
  const { awsSsoUseOwnBucket } = await loadFns(['awsSsoUseOwnBucket']);
  const dom = installDom();
  const input = dom.add('awsSsoBucket');
  input.value = 'someone-elses-bucket';
  let focused = false;
  input.focus = function () { focused = true; };
  awsSsoUseOwnBucket();
  equal(input.value, '', 'the bucket field must be cleared for the user to retype');
  equal(input.placeholder, 'e.g. my-own-bucket (in YOUR account)',
    'the placeholder must say whose account the field now expects');
  ok(focused, 'the field must be focused so the user can type immediately');
}

export async function test_clearing_errors_also_drops_the_recovery_hint() {
  const html = await read('index.html');
  const clear = extractFn(html, 'awsSsoClearErrors');
  includes(clear, "getElementById('awsSsoError3Hint')",
    'clearing the error UI must also drop the step-3 recovery hint');
}

/* 69d — the create retry reuses the connect body builder and adds only the opt-in flag. */

export async function test_connect_body_builder_carries_the_confirmed_account() {
  const { awsSsoConnectBody } = await loadFns(['awsSsoConnectBody']);
  globalThis._awsSsoChosen = { accountId: '111', roleName: 'Admin' };
  const withChoice = awsSsoConnectBody('b', 'r', 'Me', null);
  equal(withChoice.bucket, 'b', 'the bucket must be carried');
  equal(withChoice.region, 'r', 'the region must be carried');
  equal(withChoice.accountId, '111', 'the confirmed account must ride along');
  equal(withChoice.roleName, 'Admin', 'the confirmed role must ride along');
  excludes(JSON.stringify(withChoice), 'createIfMissing',
    'a plain connect must not send the create flag');
  const created = awsSsoConnectBody('b', 'r', 'Me', { createIfMissing: 'true' });
  equal(created.createIfMissing, 'true', 'the create retry must add the opt-in flag');
  equal(created.accountId, '111', 'the create retry must still carry the confirmed account');
  globalThis._awsSsoChosen = null;
  const plain = awsSsoConnectBody('b', 'r', 'Me', null);
  excludes(JSON.stringify(plain), 'accountId',
    'with no chooser pick the body must carry no accountId');
}

export async function test_create_bucket_prefers_new_endpoint_with_connect_fallback() {
  const html = await read('index.html');
  const create = extractFn(html, 'awsSsoCreateBucket');
  // The dedicated endpoint is preferred …
  includes(create, '/api/auth/aws/create-bucket',
    'the create action must POST the dedicated create endpoint');
  // … with a 404 fallback to the connect createIfMissing retry already built.
  includes(create, 'res.status === 404', 'a missing endpoint must be detected by its 404');
  includes(create, 'awsSsoCreateBucketViaConnect(', 'a 404 must fall back to the connect retry');
  includes(create, "btn.disabled = true", 'the create button must be disabled while the request runs');
  // The fallback is the original connect createIfMissing retry, body builder reused.
  const fallback = extractFn(html, 'awsSsoCreateBucketViaConnect');
  includes(fallback, '/api/auth/aws/connect', 'the fallback must hit the connect endpoint');
  includes(fallback, 'awsSsoConnectBody(',
    'the fallback must reuse the connect body builder, not duplicate it');
  includes(fallback, "createIfMissing: 'true'", 'the fallback must send the opt-in string flag');
}

/* 69e — the full stepped connect flow: chooser -> bucket screen -> connected state. */

export async function test_chooser_next_is_explicit_and_never_auto_connects() {
  const html = await read('index.html');
  // The chooser's button is now "Next" and runs the explicit handler.
  includes(html, 'onclick="awsSsoChooseNext()"', 'the chooser button must run the Next handler');
  includes(html, '>\n                        Next\n                    </button>',
    'the chooser button label must be "Next"');
  const next = extractFn(html, 'awsSsoChooseNext');
  includes(next, 'awsSsoShowStep(3)', 'Next must advance to the bucket screen');
  // The old zero-click shortcut is gone: no connect, no saved-bucket lookup, no auto-close.
  excludes(next, 'awsSsoConnect(', 'Next must NOT auto-connect');
  excludes(next, 'AWS_SSO_BUCKET_KEY', 'Next must NOT read the remembered bucket');
  excludes(next, 'loading your workspace', 'the auto-connect status text must be gone');
  // And no auto-connect survives anywhere in the modal flow.
  excludes(html, 'closeOnSuccess', 'the post-login auto-connect path must be fully retired');
}

export async function test_chooser_is_always_shown_after_login() {
  const html = await read('index.html');
  const after = extractFn(html, 'awsSsoAfterLogin');
  // The chooser is shown whenever the account list is non-empty (single account included) …
  includes(after, 'awsSsoChooseNeeded = accounts.length > 0',
    'any non-empty account list must put the chooser in play');
  includes(after, "awsSsoShowStep('choose')", 'the chooser must be shown after login');
  // … and the old saved-bucket auto-connect inside the login path is gone.
  excludes(after, 'awsSsoConnect(', 'the login path must not auto-connect a saved bucket');
  // The server-side background auto-reconnect on login is kept.
  includes(after, 'awsSsoAwaitReconnect(4000)', 'the background auto-reconnect on login stays');
}

export async function test_bucket_screen_has_the_four_actions() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoVerifyBtn"', 'the bucket screen must offer Verify bucket');
  includes(html, 'onclick="awsSsoVerifyBucket()"', 'Verify bucket must run the dry-run');
  includes(html, '>\n                            Verify bucket\n',
    'the verify button label must be "Verify bucket"');
  includes(html, 'onclick="awsSsoConnect()"', 'the primary action must be the real connect');
  includes(html, '>\n                            Start work\n',
    'the primary action label must be "Start work"');
  includes(html, 'id="awsSsoBucketBackBtn"', 'the bucket screen must offer Back');
  includes(html, 'onclick="awsSsoBucketBack()"', 'Back must run the bucket-back handler');
}

export async function test_bucket_back_returns_to_the_chooser_without_disconnecting() {
  const { awsSsoBucketBack } = await loadFns(['awsSsoBucketBack']);
  let shown = null;
  globalThis.awsSsoShowStep = (s) => { shown = s; };
  globalThis._awsSsoAccounts = [{ accountId: '111' }];
  awsSsoBucketBack();
  equal(shown, 'choose', 'with an account list, Back returns to the chooser');
  globalThis._awsSsoAccounts = [];
  awsSsoBucketBack();
  equal(shown, 1, 'with no list to return to, Back falls back to step 1');
  delete globalThis.awsSsoShowStep;
  // It must never log out or drop an existing connection.
  const src = extractFn(await read('index.html'), 'awsSsoBucketBack');
  excludes(src, 'awsSsoDisconnect', 'Back must not disconnect');
  excludes(src, '_awsSsoSession = null', 'Back must not drop the live session');
}

export async function test_verify_bucket_renders_friendly_result_and_classifies() {
  const html = await read('index.html');
  const verify = extractFn(html, 'awsSsoVerifyBucket');
  includes(verify, '/api/auth/aws/test-bucket', 'Verify bucket must use the dry-run endpoint');
  includes(verify, 'awsSsoRenderConnectHint(', 'a failure must reuse the shared hint classifier');
  includes(verify, 'awsSsoSetBucketResult(',
    'a success must render the friendly result line');
  includes(verify, "textContent = 'Verify bucket'", 'the button label must be restored after a run');
  // The friendly-result renderer shows/hides its own element.
  const { awsSsoSetBucketResult } = await loadFns(['awsSsoSetBucketResult']);
  const dom = installDom();
  const el = dom.add('awsSsoBucketResult');
  awsSsoSetBucketResult('Bucket "b" exists and you have full access.');
  equal(el.style.display, 'block', 'a result message must be shown');
  includes(el.textContent, 'exists and you have full access', 'the message must be rendered');
  awsSsoSetBucketResult('');
  equal(el.style.display, 'none', 'an empty message must hide the line');
}

export async function test_start_work_connects_and_lands_in_the_connected_state() {
  const html = await read('index.html');
  // Start work is the real connect, and the modal stays open (no auto-close).
  includes(html, "btn.textContent = 'Start work'", 'the connect button must be labelled Start work');
  const adopt = extractFn(html, 'awsSsoAdoptSession');
  excludes(adopt, 'closeAwsSsoModal', 'a successful connect must NOT close the modal');
  includes(adopt, 'awsSsoFillTargets(_awsSsoSession)',
    'a successful connect must render the connected state in place');
}

export async function test_connected_state_offers_change_bucket_and_change_account() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoConnectedActions"', 'the connected state must render an actions row');
  includes(html, 'id="awsSsoChangeBucketBtn"', 'it must offer Change bucket');
  includes(html, 'onclick="awsSsoChangeBucket()"', 'Change bucket must run its handler');
  includes(html, 'id="awsSsoChangeAccountBtn"', 'it must offer Change account');
  includes(html, 'onclick="awsSsoRestartLogin()"', 'Change account must reuse the restart path');
  // The actions row is toggled by the same fill that renders the connected pill.
  includes(extractFn(html, 'awsSsoFillTargets'), "actions.style.display = 'flex'",
    'the connected actions must be shown with the connected state');
  // Change bucket reopens the bucket screen prefilled from the current target, without disconnecting.
  const change = extractFn(html, 'awsSsoChangeBucket');
  includes(change, 'awsSsoShowStep(3)', 'Change bucket must reopen the bucket screen');
  includes(change, 'awsSsoFillTargets(_awsSsoSession)',
    'Change bucket must prefill from the current target');
  excludes(change, 'awsSsoDisconnect', 'Change bucket must not disconnect');
}

/* 69f — the AWS verify step is a panel, not a popup: no auto-open, click to open, live status. */

export async function test_step_two_never_auto_opens_the_portal() {
  const html = await read('index.html');
  // The ONLY window.open is inside the click handler. The flow-starting helpers must not open one:
  // an auto-open after an async fetch has no gesture and is always popup-blocked.
  includes(extractFn(html, 'awsSsoOpenVerifyTab'), "window.open(href, '_blank')",
    'the click handler must be the opener');
  excludes(extractFn(html, 'awsSsoContinue'), 'window.open',
    'starting the flow must not open a window');
  excludes(extractFn(html, 'awsSsoAutoStartLogin'), 'window.open',
    'auto-start must not open a window');
  excludes(extractFn(html, 'awsSsoRenderFlow'), 'window.open',
    'rendering the code must not open a window');
  excludes(html, 'autoRedirect', 'the retired auto-redirect attempt must stay gone');
}

export async function test_open_aws_verification_opens_the_portal_tab() {
  const { awsSsoOpenVerifyTab } = await loadFns(['awsSsoOpenVerifyTab']);
  installDom();
  let opened = null;
  const handle = { closed: false, focus() {} };
  globalThis.window.open = (href, target) => { opened = { href, target }; return handle; };
  globalThis.awsSsoClearErrors = () => {};
  globalThis.awsSsoSetStep2Status = () => {};
  globalThis._awsSsoVerifyUrl = 'https://d-x.awsapps.com/start#/device?user_code=ABCD-EFGH';
  globalThis._awsSsoVerifyWindow = null;

  awsSsoOpenVerifyTab();
  ok(opened, 'the click must open the portal in a tab');
  equal(opened.href, globalThis._awsSsoVerifyUrl, 'the portal URL must be opened');
  equal(opened.target, '_blank', 'it must open a new tab');
  equal(globalThis._awsSsoVerifyWindow, handle,
    'the tab handle must be tracked so success can close it');

  // A second click re-focuses the same tab rather than opening another.
  opened = null;
  awsSsoOpenVerifyTab();
  equal(opened, null, 'a second click must not open a second tab');

  delete globalThis.window.open;
  delete globalThis.awsSsoClearErrors;
  delete globalThis.awsSsoSetStep2Status;
}

export async function test_step_two_status_line_flips_to_verified() {
  const html = await read('index.html');
  // The panel ships with the waiting line, and the poll's complete branch flips it to the green
  // verified text before advancing (the tab is still cleaned up, the chooser still follows).
  includes(html, 'Waiting for you to verify&hellip;', 'the panel must start on the waiting line');
  const poll = extractFn(html, 'awsSsoPoll');
  includes(poll, "awsSsoSetStep2Status('Verified — confirmed by AWS', 'done')",
    'a completed poll must flip the panel status to the verified text');
  includes(poll, 'awsSsoCloseVerifyTab()', 'the AWS tab must still be cleaned up on success');
  includes(poll, 'awsSsoAfterLogin(', 'the flow must still advance to the chooser');

  // The renderer: 'wait' is orange + pulsing, 'done' is green + static.
  const { awsSsoSetStep2Status } = await loadFns(['awsSsoSetStep2Status']);
  const dom = installDom();
  const wrap = dom.add('awsSsoPollHint');
  const dot = dom.add('awsSsoPollDot');
  const label = dom.add('awsSsoPollText');
  awsSsoSetStep2Status('Waiting for you to verify…', 'wait');
  equal(label.textContent, 'Waiting for you to verify…', 'the waiting text must be shown');
  equal(dot.style.background, 'var(--orange)', 'waiting uses the orange dot');
  awsSsoSetStep2Status('Verified — confirmed by AWS', 'done');
  equal(label.textContent, 'Verified — confirmed by AWS', 'the verified text must replace it');
  equal(dot.style.background, 'var(--green)', 'verified uses the green dot');
  equal(dot.style.animation, 'none', 'the pulse must stop once verified');
  equal(wrap.style.color, 'var(--green)', 'the whole line must turn green');
}

export async function test_copy_code_button_copies_the_visible_code() {
  const { awsSsoCopyCode } = await loadFns(['awsSsoCopyCode']);
  const dom = installDom();
  const code = dom.add('awsSsoUserCode');
  const btn = dom.add('awsSsoCopyCodeBtn');
  code.textContent = 'ABCD-EFGH';
  let written = null;
  // navigator is a getter-only global in Node, so it must be redefined rather than assigned.
  const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    value: { clipboard: { writeText: (t) => { written = t; return Promise.resolve(); } } }
  });
  awsSsoCopyCode();
  await new Promise((r) => setTimeout(r, 0));
  equal(written, 'ABCD-EFGH', 'the visible code must be written to the clipboard');
  equal(btn.textContent, 'Copied', 'the button must confirm the copy');
  if (originalNavigator) Object.defineProperty(globalThis, 'navigator', originalNavigator);
  else delete globalThis.navigator;
}

/* 69f follow-up — a stale "Your session expired" note must not survive a successful verify/connect. */

export async function test_verify_success_clears_the_stale_expiry_note() {
  const fns = await loadFns(['awsSsoClearExpiredNote', 'awsSsoVerifyBucket']);
  const dom = installDom();
  const note = dom.add('awsSsoExpiredNote');
  note.style.display = 'block';   // the orange note is showing (e.g. a 401 fired during a pod restart)

  // Stub the page-globals the success path touches — none of them is what this test is about.
  globalThis.awsSsoClearExpiredNote = fns.awsSsoClearExpiredNote;   // the real hider, under test
  globalThis.awsSsoConnectFields = () => ({ bucket: 'b', region: 'r', displayName: '' });
  globalThis.awsSsoClearErrors = () => {};
  globalThis.awsSsoSetBucketResult = () => {};
  globalThis.awsSsoRenderCapabilities = () => {};
  globalThis.awsSsoShowError = () => {};
  globalThis.awsSsoRenderConnectHint = () => {};
  globalThis._awsSsoChosen = null;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => ({
    ok: true, status: 200,
    json: async () => ({ ok: true, capabilities: { read: true, upload: true, write: true } })
  });

  await fns.awsSsoVerifyBucket();
  equal(note.style.display, 'none',
    'a passing verify proves the session is live — the stale expiry note must be hidden');

  globalThis.fetch = realFetch;
  for (const k of ['awsSsoClearExpiredNote', 'awsSsoConnectFields', 'awsSsoClearErrors',
    'awsSsoSetBucketResult', 'awsSsoRenderCapabilities', 'awsSsoShowError',
    'awsSsoRenderConnectHint', '_awsSsoChosen']) delete globalThis[k];
}

export async function test_connect_success_clears_the_stale_expiry_note() {
  const fns = await loadFns(['awsSsoClearExpiredNote', 'awsSsoAdoptSession']);
  const dom = installDom();
  const note = dom.add('awsSsoExpiredNote');
  note.style.display = 'block';

  // Stub the page-globals the success path touches — none of them is what this test is about.
  globalThis.awsSsoClearExpiredNote = fns.awsSsoClearExpiredNote;   // the real hider, under test
  globalThis.awsSsoClearErrors = () => {};
  globalThis.awsSsoSetBucketResult = () => {};
  globalThis.setAwsSsoPill = () => {};
  globalThis.awsSsoFillTargets = () => {};
  globalThis.invalidateCache = () => {};
  globalThis.loadStats = () => {};
  globalThis.loadProgress = () => {};
  globalThis.loadClaudeStats = () => {};
  globalThis.awsSsoSetStatus = () => {};
  globalThis.localStorage = { setItem() {} };
  globalThis._awsSsoChosen = null;

  fns.awsSsoAdoptSession({ bucket: 'b', region: 'r', capabilities: {} }, 'b', 'r');
  equal(note.style.display, 'none',
    'a successful connect re-establishes the session — the stale expiry note must be hidden');

  for (const k of ['awsSsoClearExpiredNote', 'awsSsoClearErrors', 'awsSsoSetBucketResult',
    'setAwsSsoPill', 'awsSsoFillTargets', 'invalidateCache', 'loadStats', 'loadProgress',
    'loadClaudeStats', 'awsSsoSetStatus', 'localStorage', '_awsSsoChosen', '_awsSsoSession']) {
    delete globalThis[k];
  }
}

/* 69g — stale verify output must not outlive its context. */

// Shows a previous verify's output (a result line + green badges) so a test can prove it is wiped.
function seedStaleVerifyOutput(dom, resultText) {
  const result = dom.add('awsSsoBucketResult');
  const caps = dom.add('awsSsoCapabilities');
  result.textContent = resultText;
  result.style.display = 'block';
  caps.innerHTML = '<span>Read ✓ Upload ✓ Write ✓</span>';
  caps.style.display = 'block';
  return { result, caps };
}

async function loadVerifyFns() {
  const fns = await loadFns([
    'awsSsoSetBucketResult', 'awsSsoRenderCapabilities', 'awsSsoResetVerifyResult'
  ]);
  globalThis.awsSsoSetBucketResult = fns.awsSsoSetBucketResult;
  globalThis.awsSsoRenderCapabilities = fns.awsSsoRenderCapabilities;
  globalThis.awsSsoResetVerifyResult = fns.awsSsoResetVerifyResult;
  return fns;
}

function unloadVerifyFns() {
  for (const k of ['awsSsoSetBucketResult', 'awsSsoRenderCapabilities', 'awsSsoResetVerifyResult',
    'awsSsoShowStep', 'awsSsoFillTargets', 'awsSsoRenderIdentity', '_awsSsoSession',
    '_awsSsoChosen', '_awsSsoVerified', 'localStorage', 'AWS_SSO_BUCKET_KEY',
    'AWS_SSO_REGION_KEY', 'AWS_SSO_DEFAULT_BUCKET', 'AWS_SSO_DEFAULT_REGION']) delete globalThis[k];
}

export async function test_change_bucket_clears_the_previous_verify_output() {
  const fns = await loadVerifyFns();
  const dom = installDom();
  const { result, caps } = seedStaleVerifyOutput(dom, 'old-bucket @ ap-south-1 — exists, full access.');
  globalThis._awsSsoVerified = 'old-bucket @ ap-south-1';
  globalThis._awsSsoSession = null;
  globalThis.awsSsoShowStep = () => {};
  globalThis.awsSsoFillTargets = () => {};

  const { awsSsoChangeBucket } = await loadFns(['awsSsoChangeBucket']);
  awsSsoChangeBucket();

  equal(result.style.display, 'none',
    'entering the bucket screen via Change bucket must clear the stale result line');
  equal(caps.style.display, 'none',
    'the previous bucket\'s green badges must not bleed into the fields about to be edited');
  equal(globalThis._awsSsoVerified, '', 'the remembered verified pair must be forgotten');
  unloadVerifyFns();
}

export async function test_entering_step_three_for_a_fresh_flow_clears_verify_output() {
  const html = await read('index.html');
  // Both fresh-flow entry points (chooser Next, and the no-account-list fallback) reset it.
  includes(extractFn(html, 'awsSsoChooseNext'), 'awsSsoResetVerifyResult()',
    'Next must clear any previous verify output on the way into the bucket screen');
  includes(extractFn(html, 'awsSsoAfterLogin'), 'awsSsoResetVerifyResult()',
    'the no-chooser path must clear any previous verify output too');
}

export async function test_clearing_errors_also_clears_the_verify_output() {
  const fns = await loadVerifyFns();
  const dom = installDom();
  const { result, caps } = seedStaleVerifyOutput(dom, 'old-bucket @ ap-south-1 — exists, full access.');
  // awsSsoClearErrors walks the step keys and looks each error element up by id; stub the two
  // page-globals it needs so it reaches the reset without touching the error banners.
  globalThis.AWS_SSO_STEP_KEYS = [1, 2, 'choose', 3];
  globalThis.awsSsoErrorId = () => null;

  const { awsSsoClearErrors } = await loadFns(['awsSsoClearErrors']);
  awsSsoClearErrors();

  equal(result.style.display, 'none', 'any error (incl. the session-expired path) must wipe the result line');
  equal(caps.style.display, 'none', 'any error must wipe the older verify badges');
  delete globalThis.AWS_SSO_STEP_KEYS;
  delete globalThis.awsSsoErrorId;
  unloadVerifyFns();
}

export async function test_editing_the_target_resets_the_result_line() {
  const html = await read('index.html');
  // Both fields are wired to the edit handler.
  includes(html, 'id="awsSsoBucket" type="text" value="amp-analyzer-parse-jar" oninput="awsSsoOnTargetEdit()"',
    'the bucket field must reset verify output when edited');
  includes(html, 'id="awsSsoRegion" type="text" value="ap-south-1" oninput="awsSsoOnTargetEdit()"',
    'the region field must reset verify output when edited');

  const fns = await loadVerifyFns();
  const dom = installDom();
  const { result, caps } = seedStaleVerifyOutput(dom, 'old-bucket @ ap-south-1 — exists, full access.');
  const { awsSsoOnTargetEdit } = await loadFns(['awsSsoOnTargetEdit']);
  awsSsoOnTargetEdit();
  equal(result.style.display, 'none',
    'editing a field must reset the old result line — a verified state belongs to the current fields');
  equal(caps.style.display, 'none', 'editing a field must reset the old badges');
  unloadVerifyFns();
}

export async function test_verify_success_line_names_the_pair_it_verified() {
  const html = await read('index.html');
  const verify = extractFn(html, 'awsSsoVerifyBucket');
  // The remembered pair and the line both name bucket @ region.
  includes(verify, "_awsSsoVerified = fields.bucket + ' @ ' + fields.region",
    'the verified pair must be remembered');
  includes(verify, 'awsSsoSetBucketResult(_awsSsoVerified +', 'the success line must name that pair');
}

/* 69g — tooltips + helper text. */

export async function test_action_tooltips_and_helper_text_are_present() {
  const html = await read('index.html');
  // Native title tooltips, verbatim.
  includes(html, 'title="Checks this bucket exists and your identity has access — connects nothing"',
    'Verify bucket must carry its tooltip');
  includes(html, 'title="Connects the app to this bucket with your verified identity"',
    'Start work must carry its tooltip');
  includes(html, 'title="Choose a different AWS account"', 'Back must carry its tooltip');
  includes(html, 'title="Continue with the selected account/role"', 'Next must carry its tooltip');
  includes(html, 'title="Opens AWS&rsquo;s own sign-in page in a new tab; we never see your password"',
    'Open AWS verification must carry its tooltip');
  // Visible muted helper lines under the button rows.
  includes(html, 'Verify bucket: checks this bucket exists and your identity has access',
    'the bucket row must explain Verify bucket in text');
  includes(html, 'Start work: connects the app to this bucket with your verified identity',
    'the bucket row must explain Start work in text');
  includes(html, 'Back: choose a different AWS account',
    'the bucket row must explain Back in text');
  includes(html, 'Continue with the selected account/role',
    'the chooser must explain Next in text');
  includes(html, 'we never see your password',
    'step 2 must explain the AWS tab in text');
  // The modal's existing muted small-text idiom.
  ok(/font-size:11px;color:var\(--sidebar-muted\)/.test(html),
    'helper lines must use the modal\'s muted small-text style');
}

/* 69g — connected means in use and closable. */

export async function test_connected_state_offers_close_and_continue() {
  const html = await read('index.html');
  includes(html, 'id="awsSsoCloseContinueBtn"',
    'the connected state must offer a primary close action');
  includes(html, 'onclick="closeAwsSsoModal()"', 'it must close the modal, same as the × button');
  includes(html, 'Close &amp; continue working', 'the primary label must say what it does');
  // Change bucket / Change account stay secondary; Disconnect stays in the header.
  includes(html, 'id="awsSsoChangeBucketBtn"', 'Change bucket must stay available');
  includes(html, 'id="awsSsoChangeAccountBtn"', 'Change account must stay available');
  includes(html, 'id="awsSsoDisconnectWrap"', 'Disconnect must stay in the header');
  includes(html, 'id="awsSsoConnectedBreadcrumb"', 'the connected state must carry a breadcrumb');
}

export async function test_connected_breadcrumb_names_the_target_and_the_exits() {
  const fns = await loadFns(['awsSsoRenderIdentity', 'awsSsoRenderCapabilities', 'awsSsoFillTargets']);
  const dom = installDom();
  ['awsSsoIdentity', 'awsSsoBucket', 'awsSsoRegion', 'awsSsoDisplayName', 'awsSsoCapabilities',
    'awsSsoConnectedMsg', 'awsSsoConnectedBreadcrumb', 'awsSsoDisconnectWrap', 'awsSsoConnectedActions']
    .forEach((id) => dom.add(id));
  globalThis.awsSsoRenderIdentity = fns.awsSsoRenderIdentity;
  globalThis.awsSsoRenderCapabilities = fns.awsSsoRenderCapabilities;
  globalThis.localStorage = { getItem: () => null };
  // The page's own storage-key/default consts, needed by the not-connected branch.
  globalThis.AWS_SSO_BUCKET_KEY = 'awsSsoBucket';
  globalThis.AWS_SSO_REGION_KEY = 'awsSsoRegion';
  globalThis.AWS_SSO_DEFAULT_BUCKET = 'amp-analyzer-parse-jar';
  globalThis.AWS_SSO_DEFAULT_REGION = 'ap-south-1';
  globalThis._awsSsoChosen = null;

  fns.awsSsoFillTargets({ connected: true, bucket: 'my-bucket', region: 'ap-south-1', role: 'Admin', name: 'Ajay' });
  const bc = dom.get('awsSsoConnectedBreadcrumb');
  equal(bc.style.display, 'block', 'the breadcrumb must be shown while connected');
  includes(bc.textContent, 's3://my-bucket', 'the breadcrumb must name the bucket in use');
  includes(bc.textContent, 'as Admin', 'the breadcrumb must name the role');
  includes(bc.textContent, 'until you Disconnect or Change.',
    'the breadcrumb must name how the connection ends');

  fns.awsSsoFillTargets(null);
  equal(bc.style.display, 'none', 'the breadcrumb must hide when there is no connection');
  unloadVerifyFns();
}
