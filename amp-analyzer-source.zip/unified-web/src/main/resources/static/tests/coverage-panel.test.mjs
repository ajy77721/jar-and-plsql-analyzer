/**
 * Task 63 — the Coverage panel (`parser/js/coverage.js`).
 *
 * <h2>What is claimed</h2>
 *
 * The panel renders three things from the coverage document the endpoint serves: the
 * grammar-vs-regex share per construct (green/red, direct-labelled), the verification funnel
 * (nodes → sourceCaptured → catalogVerified → lineChecked), and a "missing & why" grid whose
 * every non-100% row drills into the rows behind the gap — the unverified nodes, each clickable
 * to its source.
 *
 * <h2>Why this runs the code rather than reading it</h2>
 *
 * "A bar is 50% green" and "the table has one row per gap" are behavioural claims. A source check
 * for `cov-bar-grammar` would pass on a bar whose width was never computed and a grid whose drill
 * never rendered. So this loads the real `shared/tableFramework.js` and the real
 * `parser/js/coverage.js` over the DOM stub and asserts on the markup that lands in
 * `#cov-gap-tbody` and in the panel HTML.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { installDom, esc } from './lib/dom.mjs';
import { ok, equal, includes, excludes, atLeast } from './lib/assert.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel) => readFile(path.join(STATIC, rel), 'utf8');

/** The real shape the endpoint serves, with a deliberate gap at every stage. */
function fixtureDoc() {
  return {
    grammarAttempts: 80,
    grammarSharePct: 50.15,
    regexFallbackTotal: 170,
    constructs: [
      { dialect: 'oracle', construct: 'dynSql', grammar: 169, fallback: 168, sharePct: 50.15 },
      { dialect: 'db2', construct: 'dynSql', grammar: 105, fallback: 2, sharePct: 98.13 }
    ],
    verification: {
      funnel: { nodes: 63, withVerification: 63, sourceCaptured: 61, catalogVerified: 58, lineChecked: 59 },
      unverified: [
        { nodeId: 'ANALYZER$A', name: 'A', objectType: 'PROCEDURE', schema: 'ANALYZER', sourceFile: 'ANALYZER.A.prc', lineStart: 1, why: 'declaring-line mismatch' }
      ],
      gaps: {
        sourceCaptured: [
          { nodeId: 'ANALYZER$A', name: 'A', objectType: 'PROCEDURE', schema: 'ANALYZER', sourceFile: 'ANALYZER.A.prc', lineStart: 1, why: 'source not captured' }
        ],
        catalogVerified: [
          { nodeId: 'ANALYZER$B', name: 'B', objectType: 'FUNCTION', schema: 'ANALYZER', sourceFile: 'ANALYZER.B.prc', lineStart: 10, why: 'not found in catalog' }
        ],
        lineChecked: [
          { nodeId: 'ANALYZER$A', name: 'A', objectType: 'PROCEDURE', schema: 'ANALYZER', sourceFile: 'ANALYZER.A.prc', lineStart: 1, why: 'declaring-line mismatch' }
        ]
      }
    }
  };
}

/** A perfectly-covered document — no fallback, every funnel stage at the node total. */
function perfectDoc() {
  return {
    grammarAttempts: 5,
    grammarSharePct: 100,
    constructs: [{ dialect: 'postgres', construct: 'dynSql', grammar: 5, fallback: 0, sharePct: 100 }],
    verification: {
      funnel: { nodes: 10, withVerification: 10, sourceCaptured: 10, catalogVerified: 10, lineChecked: 10 },
      unverified: [], gaps: { sourceCaptured: [], catalogVerified: [], lineChecked: [] }
    }
  };
}

/**
 * Loads the real table framework + coverage module over a fresh DOM, with `getCoverage` answering
 * whatever `doc` the test passes (null models the 404).
 */
async function boot(doc) {
  const dom = installDom();
  globalThis.PA = {};
  globalThis.window = globalThis;
  new Function(await read('shared/escape.js'))();
  PA.esc = function (s) { return Esc.html(s); };
  PA.escAttr = function (s) { return Esc.attr(s); };
  PA.escJs = function (s) { return Esc.js(s); };
  new Function(await read('shared/tableFramework.js'))();
  new Function(await read('parser/js/coverage.js'))();
  PA.api = { getCoverage: async () => doc };
  dom.add('covContainer');
  // The panel markup is assigned to innerHTML, which the stub does not parse — register the grid's
  // own elements so PA.tf can find them (the same technique parser-statements-detail-table uses).
  dom.add('cov-gap-tbody');
  dom.add('cov-gap-pager');
  return dom;
}

/* ---------------------------- grammar-vs-regex bars ---------------------------- */

export async function test_bar_row_splits_grammar_and_fallback_with_direct_labels() {
  await boot(null);
  const html = PA.coverage.barRow({ dialect: 'oracle', construct: 'dynSql', grammar: 169, fallback: 168 });
  // 169 / 337 ≈ 50.15% grammar, 49.85% fallback — the bar widths follow the counts.
  includes(html, 'ORACLE · dynSql', 'the bar names its dialect and construct');
  includes(html, 'cov-bar-grammar" style="width:50.15%', 'the grammar segment is sized to its share');
  includes(html, 'cov-bar-fallback" style="width:49.85%', 'the fallback segment takes the remainder');
  includes(html, '50.1% grammar', 'the grammar share is direct-labelled');
  includes(html, '49.9% fallback (168)', 'the fallback share is direct-labelled with its count');
}

export async function test_grammar_card_headlines_the_overall_share() {
  await boot(null);
  const html = PA.coverage.renderGrammarCard(fixtureDoc());
  includes(html, 'Grammar vs regex fallback', 'the card is titled');
  includes(html, '50.1%', 'the overall grammar share headlines the card');
  includes(html, '170 regex fallback', 'the fallback total is shown');
  includes(html, 'cov-swatch-fallback', 'the legend carries a fallback swatch (never colour alone)');
}

/* ----------------------------- verification funnel ----------------------------- */

export async function test_funnel_has_the_four_stages_in_order() {
  await boot(null);
  const stages = PA.coverage.funnelStages(fixtureDoc().verification);
  equal(stages.length, 4, 'the funnel is four stages');
  equal(stages[0].key, 'nodes', 'stage 1 is the node total');
  equal(stages[1].key, 'sourceCaptured', 'stage 2 is sourceCaptured');
  equal(stages[2].key, 'catalogVerified', 'stage 3 is catalogVerified');
  equal(stages[3].key, 'lineChecked', 'stage 4 is lineChecked');
  equal(stages[0].count, 63, 'the total is read from the funnel');
  equal(stages[3].count, 59, 'the last stage count is read from the funnel');
}

export async function test_funnel_card_renders_counts_and_percentages() {
  await boot(null);
  const html = PA.coverage.renderFunnelCard(fixtureDoc().verification);
  includes(html, 'Source captured', 'the stage is named');
  includes(html, '61 (97%)', 'the count and share are rendered');
  includes(html, '58 (92%)', 'the catalog stage count is rendered');
  includes(html, '4 node(s) not fully verified', 'the shortfall is surfaced');
}

export async function test_funnel_card_handles_a_missing_verification_block() {
  await boot(null);
  const html = PA.coverage.renderFunnelCard(undefined);
  includes(html, 'No verification data', 'an analysis without the block shows an honest empty state');
}

/* --------------------------- missing & why table rows --------------------------- */

export async function test_gap_rows_cover_grammar_and_each_short_stage() {
  await boot(null);
  const rows = PA.coverage.gapRows(fixtureDoc());
  // 2 constructs both carry a fallback → 2 grammar rows; 3 funnel stages are short → 3 verification rows.
  equal(rows.filter(r => r.kind === 'Grammar').length, 2, 'one grammar row per construct with a fallback');
  equal(rows.filter(r => r.kind === 'Verification').length, 3, 'one verification row per short stage');
  const oracle = rows.find(r => r.kind === 'Grammar' && r.dialect === 'ORACLE');
  equal(oracle.missing, 168, 'the grammar row carries the fallback count');
  atLeast(oracle.sharePct, 49, 'the grammar row carries the fallback share');
  const line = rows.find(r => r.construct === 'Line checked');
  equal(line.missing, 63 - 59, 'the line-checked row counts the shortfall');
  equal(line.nodes.length, 1, 'the row carries the nodes behind the gap');
}

export async function test_gap_rows_are_empty_when_everything_is_100_percent() {
  await boot(null);
  equal(PA.coverage.gapRows(perfectDoc()).length, 0, 'a fully-covered analysis has no gap rows');
}

export async function test_gap_row_html_is_a_table_row_with_the_cell_values() {
  await boot(null);
  const row = PA.coverage.gapRows(fixtureDoc()).find(r => r.kind === 'Grammar' && r.dialect === 'DB2');
  const html = PA.coverage.gapRowHtml(row, 0, esc);
  includes(html, '<tr class="to-row">', 'the row is a grid row');
  includes(html, 'DB2', 'the dialect cell');
  includes(html, 'dynSql', 'the construct cell');
  includes(html, '1.9%', 'the share cell carries the fallback (missing) share, not the grammar share');
}

/* ------------------------------ the drill-down ------------------------------ */

export async function test_verification_drill_lists_nodes_clickable_to_source() {
  await boot(null);
  const row = PA.coverage.gapRows(fixtureDoc()).find(r => r.construct === 'Catalog verified');
  const html = PA.coverage.gapDetailHtml(row, 0, esc);
  includes(html, 'ANALYZER.B', 'the node is listed by its qualified name');
  includes(html, "PA.coverage.openNode('ANALYZER$B',10)", 'the node opens its source at its declaring line');
  includes(html, 'not found in catalog', 'the row says why the node is missing');
}

export async function test_grammar_drill_is_honest_about_missing_per_row_locations() {
  await boot(null);
  const row = PA.coverage.gapRows(fixtureDoc()).find(r => r.kind === 'Grammar');
  const html = PA.coverage.gapDetailHtml(row, 0, esc);
  includes(html, 'not indexed', 'the grammar drill states the fallback rows are not individually indexed');
  includes(html, 'Dynamic SQL', 'and points at where the captured statements live');
}

/* ------------------------------ load + empty state ------------------------------ */

export async function test_load_renders_the_panel_and_mounts_the_grid() {
  const dom = await boot(fixtureDoc());
  await PA.coverage.load();
  const container = dom.get('covContainer');
  includes(container.innerHTML, 'Grammar vs regex fallback', 'the bars card is mounted');
  includes(container.innerHTML, 'Verification funnel', 'the funnel card is mounted');
  includes(container.innerHTML, 'Missing &amp; why', 'the gaps card is mounted');
  const tbody = dom.get('cov-gap-tbody');
  includes(tbody.innerHTML, 'ORACLE', 'the grid rendered its grammar rows');
  includes(tbody.innerHTML, 'Line checked', 'the grid rendered its verification rows');
}

export async function test_load_shows_the_empty_state_when_the_analysis_predates_coverage() {
  const dom = await boot(null);
  await PA.coverage.load();
  const container = dom.get('covContainer');
  includes(container.innerHTML, 'predates the coverage artifact', 'the 404 state is explained');
  excludes(container.innerHTML, 'cov-bar-row', 'no charts are rendered for a predating analysis');
}

export async function test_perfect_analysis_reports_nothing_missing() {
  const dom = await boot(perfectDoc());
  await PA.coverage.load();
  const container = dom.get('covContainer');
  includes(container.innerHTML, 'Nothing missing', 'a fully-covered analysis says so');
  excludes(container.innerHTML, 'cov-kind-grammar', 'and has no grammar gap rows');
}
