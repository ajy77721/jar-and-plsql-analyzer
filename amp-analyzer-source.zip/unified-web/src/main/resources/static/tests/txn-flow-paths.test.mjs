/**
 * Task 65 — the Flow view's EXECUTION-PATHS sub-view (PA.txnFlowPaths): one path on screen at a
 * time (the path-selector chips), the resolver's own plain-English outcome sentence, and one row
 * per PROCEDURE on that path with a per-write survival verdict (survived / discarded / open) and
 * an expandable per-line detail (each op ONCE — no cross-proc repeats).
 *
 * The sub-view is its own file, registered as PA.txnFlowPaths and rendered by PA.txnTrace's Flow
 * dispatch with the SAME doc the other two tabs receive.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { ok, includes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(STATIC, p), 'utf8');

const RUNS_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false,
  runs: [
    {
      runId: 1, kind: 'main', outcome: 'PARTIAL',
      assumptions: [{ nodeId: 'CHILD', line: 30, condition: "v_mode = 'FULL'", taken: true }],
      events: [
        { seq: 1, kind: 'WRITE', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 12, table: 'ORDERS', op: 'UPDATE', survival: 'survived' },
        { seq: 2, kind: 'CALL', nodeId: 'CHILD', proc: 'ERP_CHILD', depth: 1, line: 20 },
        { seq: 3, kind: 'WRITE', nodeId: 'CHILD', proc: 'ERP_CHILD', depth: 1, line: 22, table: 'ORDER_LINES', op: 'UPDATE', survival: 'survived' },
        { seq: 4, kind: 'COMMIT', nodeId: 'CHILD', proc: 'ERP_CHILD', depth: 1, line: 30,
          guard: { kind: 'IF', line: 29, condition: "v_mode = 'FULL'" } },
        { seq: 5, kind: 'WRITE', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 40, table: 'ORDERS', op: 'DELETE', survival: 'discarded' },
        { seq: 6, kind: 'ROLLBACK', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 50 },
        { seq: 7, kind: 'COMMIT', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 60 }
      ],
      writes: [],
      summary: "On this path the work is PARTIALLY saved: the ROLLBACK at line 50 (in ERP_T1) undoes the uncommitted work up to that point; the COMMIT at line 30 (in ERP_CHILD) makes the work before it permanent. Writes: 2 survive, 1 discarded."
    }
  ]
};

const BRIEF_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false, briefVersion: 'brief-4',
  briefSummary: { transactions: 1, committed: 1 },
  brief: [ { id: 'T1', kind: 'transaction', outcome: 'COMMITTED',
      start: { proc: 'ERP_T1', nodeId: 'T1', line: 12 }, end: { proc: 'ERP_T1', nodeId: 'T1', line: 60 },
      procCount: 1, procs: [], outcomes: [{ path: 0, outcome: 'COMMITTED' }], rollback: 'NONE', note: 'saved' } ],
  runs: [ { runId: 1, kind: 'main', outcome: 'COMMITTED', assumptions: [], events: [], writes: [], summary: 'ok' } ]
};

async function loadTxnFlowPaths(doc) {
  const dom = installDom();
  dom.add('txnContainerTrace');
  globalThis.window = globalThis;
  globalThis.PA = {
    esc, escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    escAttr: esc,
    api: { _analysisName: 'ORACLE~DEMO~LOCAL~T1' },
    context: { procId: 'T1', callTreeRootId: 'T1' },
    analysisData: { transactionStatements: [] },
    isInScope: () => true,
    sourceView: { openNodeAtLine: () => {}, openModal: () => {} },
    callTrace: null,
  };
  globalThis.fetch = async () => ({ ok: true, json: async () => doc });
  // The REAL table framework: the per-proc rows are a PA.tf grid now (the row renderer is handed
  // to PA.tf.init, so the tests reach the markup through PA.tf._state['tfp'], as the brief/procs
  // tests do).
  new Function(await read('shared/tableFramework.js'))();
  new Function(await read('parser/js/txnTrace.js'))();
  // The three flow sub-views ship together (index.html loads all three); the dispatch needs the
  // siblings present so the fallback chain behaves as in the browser.
  new Function(await read('parser/js/txnFlowProcs.js'))();
  new Function(await read('parser/js/txnFlowTransactions.js'))();
  new Function(await read('parser/js/txnFlowPaths.js'))();
  return dom;
}

export async function test_paths_view_is_registered_and_renders_the_timelines() {
  await loadTxnFlowPaths(RUNS_DOC);
  ok(PA.txnFlowPaths && typeof PA.txnFlowPaths.render === 'function',
    'the Execution-paths view registers as PA.txnFlowPaths with a render(container, data) entry point');
}

export async function test_paths_view_renders_the_runtime_timeline_with_survival() {
  const dom = await loadTxnFlowPaths(RUNS_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.setRunsMode('paths');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));   // the fetch resolves

  const html = c.innerHTML;
  includes(html, 'Execution path:', 'the path selector did not render');
  includes(html, 'PARTIALLY saved', 'the resolver’s own outcome sentence must be shown, not a fixed template');
  includes(html, 'v_mode = ', 'the guard assumption must be stated (escaped — DB-sourced text)');
  includes(html, '&#39;FULL&#39;', 'the guard condition is escaped like any DB-sourced text');
  includes(html, '2 survive', 'the writes the callee’s commit persisted read as survived');
  includes(html, '1 discarded', 'the write undone by the rollback is marked discarded');

  // The per-proc rows are a REAL PA.tf GRID now: the skeleton renders, and the rows live in the
  // framework state (the browser renders them through PA.tf into tbody tfp-tbody — the string-shim
  // harness no-ops that DOM write, so the row markup is reached via the captured renderers).
  includes(html, '<tbody id="tfp-tbody">', 'the per-proc grid tbody is present');
  includes(html, 'tfpSearch', 'the grid search box is wired');
  includes(html, "PA.tf.sort('tfp',0)", 'the columns sort through the framework');
  const st = PA.tf._state['tfp'];
  ok(st && st.data.length === 2, 'both procedures on the path are grid rows, got: ' + (st && st.data.length));
  ok(st.renderRow === PA.txnFlowPaths._renderPathRow, 'the rows render through the paths row renderer');
  ok(st.renderDetail === PA.txnFlowPaths._renderPathDetail, 'the expand renders through the paths detail renderer');

  // The row renderer itself (the browser calls it per row): proc, depth, survival counts, txn bits.
  const escFn = (v) => String(v == null ? '' : v);
  const entryRow = st.renderRow(st.data[0], 0, escFn);
  includes(entryRow, 'ERP_T1', 'the entry procedure is its own row');
  includes(entryRow, 'txn-survival', 'the per-proc row carries the survival counts');
  includes(entryRow, '1 survive', 'the surviving write is counted on the row');
  includes(entryRow, '1 discarded', 'the write undone by the rollback is marked discarded');
  includes(entryRow, 'COMMIT', 'commit points appear on the row');
  const childRow = st.renderRow(st.data[1], 1, escFn);
  includes(childRow, 'ERP_CHILD', 'the callee is its own per-procedure row');
  includes(childRow, '1 survive', 'the callee’s commit-persisted write reads as survived');

  // The expand: the proc's ops ON THIS PATH, deduped, each line clickable into the source.
  const detail = st.renderDetail(st.data[0], 0, escFn);
  includes(detail, 'openNodeAtLine', 'every op line is clickable into the source');
  includes(detail, 'survived', 'the survival chip is on the op row');
  includes(detail, 'discarded', 'the discarded write’s chip is on the op row');
  includes(detail, 'ORDERS', 'the table the op touches is shown');
}

export async function test_paths_view_is_the_fallback_when_a_doc_has_no_brief_or_proc_rollup() {
  // A sidecar with only runs (no brief, no procRollup) — the default tab falls through to the
  // paths view rather than an empty screen.
  const dom = await loadTxnFlowPaths(RUNS_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, 'Execution path:', 'a runs-only doc falls through to the paths view');
}

export async function test_paths_view_renders_after_switching_to_the_tab() {
  const dom = await loadTxnFlowPaths(BRIEF_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, 'tbr-tbody', 'the brief is shown first when it exists');

  PA.txnTrace.setRunsMode('paths');   // = the "Execution paths" tab click
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  const html = c.innerHTML;
  includes(html, 'Execution path:', 'the per-path detail renders after switching to the tab');
  includes(html, 'unconditional', 'this fixture’s single path reads unconditional — the detail view is live');
}
