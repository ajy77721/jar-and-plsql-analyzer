/**
 * Task 65 — the Flow view's THREE tab views. The user's ask: "create a different JS for all three
 * and link them based on the click on the tab button." So: a REAL tab bar in index.html
 * ([By procedure] [By transaction] [Execution paths]), and each tab's click switches the rendered
 * sub-view — from the SAME doc, fetched ONCE per entry (one fetch, three renderings).
 *
 * PA.txnTrace keeps the top-level dispatch + the single fetch/cache; the three sub-views register
 * as PA.txnFlowProcs / PA.txnFlowTransactions / PA.txnFlowPaths and each exposes render(c, data).
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { equal, ok, includes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(STATIC, p), 'utf8');

// One doc carrying ALL THREE shapes: procRollup (By procedure), brief (By transaction) and runs
// with events (Execution paths) — exactly what the resolver emits for a real entry.
const FULL_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false, briefVersion: 'brief-4',
  briefSummary: { transactions: 2, committed: 1, rolledBack: 1 },
  procRollup: [
    { proc: 'ERP_T1', nodeId: 'T1', transactions: ['T1'], writesTotal: 5, survived: 3, discarded: 2, open: 0,
      commits: 1, rollbacks: 1, savepoints: 1, rollbackTos: 0, firstLine: 12, lastLine: 60,
      ops: [ { kind: 'WRITE', op: 'UPDATE', line: 12, table: 'ORDERS', survival: 'survived' } ] },
    { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', transactions: ['T1'], writesTotal: 0,
      commits: 0, rollbacks: 1, savepoints: 0, rollbackTos: 0, firstLine: 5, lastLine: 5,
      ops: [ { kind: 'ROLLBACK', line: 5 } ] }
  ],
  brief: [
    { id: 'T1', kind: 'transaction', outcome: 'ROLLED_BACK',
      start: { proc: 'ERP_T1', nodeId: 'T1', line: 12 }, end: { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', line: 5 },
      procCount: 2, procs: [], outcomes: [{ path: 0, outcome: 'ROLLED_BACK' }], rollback: 'DELEGATED', rollbackVia: 'ERP_USP_TXN_ERROR_HANDLER',
      note: 'discarded' }
  ],
  runs: [ { runId: 1, kind: 'main', outcome: 'ROLLED_BACK', assumptions: [], writes: [], summary: 'ok',
    events: [
      { seq: 1, kind: 'WRITE', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 12, table: 'ORDERS', op: 'UPDATE', survival: 'survived' },
      { seq: 2, kind: 'ROLLBACK', nodeId: 'T1', proc: 'ERP_T1', depth: 0, line: 50 }
    ] } ]
};

async function loadTxnFlowAll(doc) {
  const dom = installDom();
  dom.add('txnContainerTrace');
  // The real tab bar + its three buttons (as index.html ships them) so the switch can toggle the
  // active class the same way the browser does.
  dom.add('txnFlowTabs');
  dom.add('txnFlowProcsTab');
  dom.add('txnFlowTransactionsTab');
  dom.add('txnFlowPathsTab');
  globalThis.window = globalThis;
  globalThis.PA = {
    esc, escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    escAttr: esc,
    api: { _analysisName: 'ORACLE~DEMO~LOCAL~T1' },
    context: { procId: 'T1', callTreeRootId: 'T1' },
    analysisData: { transactionStatements: [] },
    isInScope: () => true,
    sourceView: { openNodeAtLine: () => {}, openModal: () => {} },
    callTrace: null,
  };
  let fetches = 0;
  globalThis.fetch = async () => { fetches++; return { ok: true, json: async () => doc }; };
  new Function(await read('shared/tableFramework.js'))();
  new Function(await read('parser/js/txnTrace.js'))();
  new Function(await read('parser/js/txnFlowProcs.js'))();
  new Function(await read('parser/js/txnFlowTransactions.js'))();
  new Function(await read('parser/js/txnFlowPaths.js'))();
  return { dom, fetchCount: () => fetches };
}

export async function test_tab_switch_renders_each_view_from_the_same_fetched_doc() {
  const { dom, fetchCount } = await loadTxnFlowAll(FULL_DOC);
  const c = dom.get('txnContainerTrace');

  // ── Enter the Flow view: the By-procedure tab is the default ──
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, '<tbody id="tbp-tbody">', 'the default tab renders the By-procedure grid');
  ok(dom.get('txnFlowProcsTab').classList.contains('active'), 'the By-procedure tab is highlighted');
  equal(fetchCount(), 1, 'the doc is fetched ONCE on entry');

  // ── Click "By transaction" ──
  PA.txnTrace.setRunsMode('brief');   // = the tab button's onclick
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, '<tbody id="tbr-tbody">', 'the By-transaction tab renders the T-brief grid');
  ok(dom.get('txnFlowTransactionsTab').classList.contains('active'), 'the clicked tab is highlighted');
  ok(!dom.get('txnFlowProcsTab').classList.contains('active'), 'the previous tab is un-highlighted');

  // ── Click "Execution paths" ──
  PA.txnTrace.setRunsMode('paths');   // = the tab button's onclick
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, 'Execution path:', 'the Execution-paths tab renders the path timelines');
  ok(dom.get('txnFlowPathsTab').classList.contains('active'), 'the paths tab is highlighted');

  // ── Back to "By procedure" — still no refetch ──
  PA.txnTrace.setRunsMode('procs');
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, '<tbody id="tbp-tbody">', 'switching back re-renders the By-procedure grid');

  equal(fetchCount(), 1, 'all four renderings came from the SAME fetched doc — one fetch, three views');
}

export async function test_flow_tab_bar_is_wired_in_index_html() {
  const src = await read('parser/index.html');
  includes(src, 'id="txnFlowTabs"', 'the flow tab bar exists in the page');
  // The three tab BUTTONS (the app's own .dt-subtab styling), each switching via setRunsMode.
  includes(src, '>By procedure</button>', 'the By-procedure tab button is labelled');
  includes(src, '>By transaction</button>', 'the By-transaction tab button is labelled');
  includes(src, '>Execution paths</button>', 'the Execution-paths tab button is labelled');
  includes(src, "setRunsMode('procs')", 'the By-procedure tab switches via setRunsMode');
  includes(src, "setRunsMode('brief')", 'the By-transaction tab switches via setRunsMode');
  includes(src, "setRunsMode('paths')", 'the Execution-paths tab switches via setRunsMode');
  includes(src, 'class="dt-subtab', 'the tab buttons use the app’s sub-tab styling');
  // Each of the three views is a SEPARATE file, loaded by the page.
  includes(src, 'txnFlowProcs.js', 'the By-procedure view file is loaded');
  includes(src, 'txnFlowTransactions.js', 'the By-transaction view file is loaded');
  includes(src, 'txnFlowPaths.js', 'the Execution-paths view file is loaded');
}

export async function test_flow_tabs_are_three_registered_view_objects() {
  await loadTxnFlowAll(FULL_DOC);
  ['txnFlowProcs', 'txnFlowTransactions', 'txnFlowPaths'].forEach((k) => {
    ok(PA[k] && typeof PA[k].render === 'function', k + ' registers a render(container, data) entry point');
  });
  // txnTrace keeps the dispatch + the single fetch, not the three renderers.
  ok(typeof PA.txnTrace._renderRuns === 'function', 'txnTrace keeps the one-fetch entry point');
  ok(typeof PA.txnTrace._renderRunsNow === 'function', 'txnTrace keeps the dispatch');
  ok(PA.txnTrace._renderProcs === undefined, 'the By-procedure renderer no longer lives in txnTrace');
  ok(PA.txnTrace._renderBrief === undefined, 'the By-transaction renderer no longer lives in txnTrace');
}
