/**
 * The remaining hand-rolled parser tables, converted to the shared PA.tf grid.
 *
 * <p>The user's rule: every data list renders through the shared grid, never a hand-rolled table,
 * and the legacy `PA.pager` is retired. These tests pin the two halves of that:
 *
 *   - each converted screen now emits the framework's skeleton (`<tbody id="X-tbody">`, a
 *     `#X-pager`, `PA.tf.sort(...)` headers) and hands its rows to `PA.tf.init`;
 *   - no production file still calls `PA.pager` (it is now dead, kept on disk but unused).
 */
import { readFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { ok, equal, includes, excludes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel) => readFile(path.join(STATIC, rel), 'utf8');
/** Source with comments removed — the fix's own explanation names the pattern it removed. */
const code = (src) => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

/** Minimal globals + the REAL table framework (the grids are PA.tf grids, not stubs). */
async function boot() {
  const dom = installDom();
  globalThis.window = globalThis;
  globalThis.PA = {
    esc,
    escAttr: (v) => String(v == null ? '' : v),
    escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    pageSize: null,
  };
  new Function(await read('shared/tableFramework.js'))();
  return dom;
}

// ─────────────────────────────── dynamic SQL (server-paged) ───────────────────────────────

function dynSource(items) {
  return {
    __pageSource: true,
    _q: '',
    setParam() {},
    param() { return ''; },
    reset() {},
    fetchPage() {
      return Promise.resolve({
        items: items,
        page: { nextCursor: null, hasMore: false, total: items.length, totalIsExact: true },
      });
    },
  };
}

export async function test_dynamic_sql_renders_a_tf_grid_over_its_page_source() {
  const dom = await boot();
  dom.add('dynContainer');
  globalThis.PA.isPageSource = (x) => !!(x && x.__pageSource);
  new Function(await read('parser/js/dynamicSql.js'))();
  PA.dynamicSql._src = dynSource([{ procedureName: 'P1', type: 'EXECUTE_IMMEDIATE', lineNumber: 5, sqlExpression: "EXECUTE IMMEDIATE 'SELECT 1'" }]);

  PA.dynamicSql._initTable();

  const c = dom.get('dynContainer');
  includes(c.innerHTML, '<tbody id="dyn-tbody">', 'the dynamic-SQL grid must use the framework tbody');
  includes(c.innerHTML, 'id="dyn-pager"', 'the pager element must exist');
  includes(c.innerHTML, "PA.tf.sort('dyn',0)", 'the columns sort through the framework');
  const st = PA.tf._state['dyn'];
  ok(st && st.src === PA.dynamicSql._src, 'the grid must be initialised from the server page source');
  ok(st.serverSorts && st.serverSorts[0] && st.serverSorts[0].asc === 'PROCEDURE_ASC',
    'the endpoint sort enum must be declared for the server-paged grid');
  // The row renderer is a real function the framework calls.
  const row = PA.dynamicSql._renderRow({ procedureName: 'P1', type: 'EXECUTE_IMMEDIATE', lineNumber: 5, sqlExpression: "EXECUTE IMMEDIATE 'SELECT 1'" }, 0, esc);
  includes(row, 'EXECUTE IMMEDIATE', 'the row shows the normalized SQL');
  includes(row, 'copyExpr(0', 'the copy button is keyed to the global row index');
  equal(PA.dynamicSql._pageTexts[0], PA.dynamicSql._normalize("EXECUTE IMMEDIATE 'SELECT 1'"),
    'the full (un-truncated) SQL is stored for the copy button');
}

// ─────────────────────────────── tableDetail Claude comparison ───────────────────────────────

export async function test_table_detail_claude_comparison_is_two_tf_grids() {
  const dom = await boot();
  dom.add('tdModalBody');
  dom.add('tdCount');
  globalThis.PA.nodeIndex = { byId: () => null };
  globalThis.PA.sourceView = { openAtLine() {} };
  new Function(await read('parser/js/tableDetail.js'))();

  PA.tableDetail._tableName = 'T';
  PA.tableDetail._data = {
    claudeVerification: {
      claudeVerifications: [
        { operation: 'UPDATE', procedureName: 'P1', status: 'CONFIRMED', reason: 'ok' },
        { operation: 'DELETE', procedureName: 'NEWPROC', status: 'NEW', reason: 'claude found it' },
      ],
    },
  };
  PA.tableDetail._allAccess = [
    { operation: 'UPDATE', procedureName: 'P1', procedureId: 'P1', sourceFile: 'a.sql', lineNumber: 5 },
  ];

  PA.tableDetail._renderClaudeComparison();

  const body = dom.get('tdModalBody');
  includes(body.innerHTML, '<tbody id="tdcm-tbody">', 'the matched grid is a framework table');
  includes(body.innerHTML, 'id="tdcm-pager"', 'the matched grid has a pager');
  includes(body.innerHTML, '<tbody id="tdcn-tbody">', 'the NEW grid is a framework table');
  includes(body.innerHTML, 'id="tdcn-pager"', 'the NEW grid has a pager');
  ok(PA.tf._state['tdcm'] && PA.tf._state['tdcm'].data.length === 1, 'the matched grid holds the matched row');
  ok(PA.tf._state['tdcn'] && PA.tf._state['tdcn'].data.length === 1, 'the NEW grid holds the new op');
  const row = PA.tableDetail._renderClaudeMatchedRow(PA.tf._state['tdcm'].data[0], 0, esc);
  includes(row, 'P1', 'the matched row names the procedure');
  includes(row, 'showProcedureOnTop', 'the procedure link opens on top');
}

export async function test_table_detail_no_longer_uses_the_legacy_pager() {
  const src = code(await read('parser/js/tableDetail.js'));
  excludes(src, 'PA.pager', 'tableDetail still drives the legacy pager');
  excludes(src, 'closeAndShowProcedure', 'the close-the-table helper survived');
  includes(src, 'showProcedureOnTop', 'the procedure link must open on top of the table modal');
  includes(src, 'PA.sourceView.openModal', 'the procedure must open through the stacked source modal');
}

// ─────────────────────────────── claudeSessions ───────────────────────────────

export async function test_claude_sessions_are_tf_grids() {
  const dom = await boot();
  dom.add('claudeSessionsBody');
  new Function(await read('parser/js/claudeSessions.js'))();

  const sessions = [
    { id: 'abc123', analysisName: 'A', type: 'verify', status: 'RUNNING', detail: 'd', durationFormatted: '1s' },
    { id: 'def456', analysisName: 'B', type: 'verify', status: 'COMPLETE', detail: 'd2', durationFormatted: '2s' },
  ];
  const stats = { log: { sessions: [{ sessionId: 'abcdefgh', sessionType: 'verify', callCount: 3, promptBytes: 2048, responseBytes: 4096, durationMs: 1500, errorCount: 0 }] } };
  PA.claudeSessions._render(dom.get('claudeSessionsBody'), sessions, { running: 1 }, stats);

  const body = dom.get('claudeSessionsBody');
  includes(body.innerHTML, '<tbody id="cs-tbody">', 'the session list is a framework table');
  includes(body.innerHTML, 'id="cs-pager"', 'the session list has a pager');
  includes(body.innerHTML, '<tbody id="csUsage-tbody">', 'the per-session usage sub-table is a framework table');
  ok(PA.tf._state['cs'] && PA.tf._state['cs'].data.length === 2, 'the session grid holds both sessions');
  ok(PA.tf._state['csUsage'] && PA.tf._state['csUsage'].data.length === 1, 'the usage grid holds the usage row');
  const row = PA.claudeSessions._renderSessionRow(sessions[0], 0, esc);
  includes(row, 'RUNNING', 'the session row shows the status');
  includes(row, 'Kill', 'a running session offers Kill');
  const usage = PA.claudeSessions._renderUsageRow(stats.log.sessions[0], 0, esc);
  includes(usage, '2.0 KB', 'the usage row formats the prompt size');
}

// ─────────────────────────────── cacheManager ───────────────────────────────

export async function test_cache_manager_is_a_tf_grid() {
  const dom = await boot();
  dom.add('cacheMgrBody');
  globalThis.PA._DS_LABEL = { ORACLE: 'Oracle' };
  new Function(await read('parser/js/cacheManager.js'))();
  PA.cacheManager._data = [
    { dbType: 'ORACLE', project: 'P', environment: 'DEV', connectionName: 'conn', analysisCount: 2, sizeBytes: 1024 },
  ];

  PA.cacheManager._render();

  const body = dom.get('cacheMgrBody');
  includes(body.innerHTML, '<tbody id="cm-tbody">', 'the cached-connection list is a framework table');
  includes(body.innerHTML, 'id="cm-pager"', 'the cached-connection list has a pager');
  ok(PA.tf._state['cm'] && PA.tf._state['cm'].data.length === 1, 'the grid holds the connection row');
  const row = PA.cacheManager._renderRow(PA.cacheManager._data[0], 0, esc);
  includes(row, 'Oracle', 'the row shows the datasource label');
  includes(row, '_clearConn', 'the row offers Clear');
}

// ─────────────────────────────── queryRunner (dynamic columns) ───────────────────────────────

export async function test_query_runner_result_grid_uses_the_results_own_columns() {
  const dom = await boot();
  const area = dom.add('qrResults');
  new Function(await read('parser/js/queryRunner.js'))();
  PA.queryRunner._resultsArea = area;

  PA.queryRunner._showResults({
    columns: ['ID', 'NAME'],
    rows: [[1, 'a'], [2, null]],
    rowCount: 2,
    executionMs: 3,
  });

  includes(area.innerHTML, '<tbody id="qr-tbody">', 'the result grid is a framework table');
  includes(area.innerHTML, '<th>ID</th>', 'the header is built from the result columns');
  includes(area.innerHTML, '<th>NAME</th>', '…every column');
  ok(PA.tf._state['qr'] && PA.tf._state['qr'].data.length === 2, 'the grid holds both result rows');
  const r0 = PA.queryRunner._renderResultRow([1, 'a'], 0, esc);
  includes(r0, '>1<', 'the row number cell is 1-based');
  includes(r0, '>a<', 'the value renders');
  const r1 = PA.queryRunner._renderResultRow([2, null], 1, esc);
  includes(r1, 'NULL', 'a null value renders as NULL');
}

// ─────────────────────────────── the retired pager ───────────────────────────────

export async function test_no_production_file_still_calls_the_legacy_pager() {
  const roots = ['parser/js', 'plsql/js', 'jar/js', 'shared'];
  const users = [];
  for (const root of roots) {
    let entries;
    try { entries = await readdir(path.join(STATIC, root)); }
    catch { continue; }
    for (const f of entries) {
      if (!f.endsWith('.js') || f === 'pagination.js') continue;
      const src = code(await read(`${root}/${f}`));
      if (/PA\.pager\b/.test(src)) users.push(`${root}/${f}`);
    }
  }
  equal(users.length, 0, `files still calling PA.pager: ${users.join(', ')} — the legacy pager must have no users`);
}

export async function test_the_overview_row_opens_the_table_without_closing_the_overview() {
  const src = code(await read('parser/js/claudeEnrichment.js'));
  excludes(src, '_closeOverview();PA.tableDetail.open', 'the overview must not be closed before opening the table');
  includes(src, 'PA.tableDetail.open', 'the coverage row still opens the table detail');
}
