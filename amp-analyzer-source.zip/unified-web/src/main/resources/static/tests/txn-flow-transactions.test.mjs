/**
 * Task 65 — the Flow view's BY-TRANSACTION sub-view (PA.txnFlowTransactions): the T-brief table,
 * one row per transaction (T1, T2, …) — outcome chip, the plain-English note, start/end as
 * clickable proc@line links, the procs it spans — plus the outcome quick-filter chips. The rows
 * render through the shared table framework (sortable columns, search, pager, column filters).
 *
 * The sub-view is its own file, registered as PA.txnFlowTransactions and rendered by PA.txnTrace's
 * Flow dispatch with the SAME doc the other two tabs receive.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { equal, ok, includes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(STATIC, p), 'utf8');

const BRIEF_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false, briefVersion: 'brief-4',
  briefSummary: { transactions: 4, committed: 1, rolledBack: 1, open: 1, partial: 0, savedWithParent: 0 },
  brief: [
    {
      id: 'T1', kind: 'transaction', parent: null, outcome: 'COMMITTED',
      start: { proc: 'ERP_T1', nodeId: 'T1', line: 12, op: 'UPDATE' },
      end: { proc: 'ERP_CHILD', nodeId: 'CHILD', line: 30, op: 'COMMIT' },
      procCount: 2,
      procs: [
        { proc: 'ERP_T1', nodeId: 'T1', ops: [{ op: 'UPDATE', line: 12, table: 'ORDERS' }] },
        { proc: 'ERP_CHILD', nodeId: 'CHILD', ops: [{ op: 'COMMIT', line: 30 }] }
      ],
      outcomes: [{ path: 0, outcome: 'COMMITTED' }],
      rollback: 'NONE',
      note: 'saved by the COMMIT at ERP_CHILD@30'
    },
    {
      id: 'T2', kind: 'transaction', parent: null, outcome: 'ROLLED_BACK',
      start: { proc: 'ERP_T2', nodeId: 'T2', line: 40, op: 'UPDATE' },
      end: { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', line: 5, op: 'ROLLBACK' },
      procCount: 2,
      procs: [
        { proc: 'ERP_T2', nodeId: 'T2', ops: [{ op: 'UPDATE', line: 40, table: 'ORDERS' }] },
        { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', ops: [{ op: 'ROLLBACK', line: 5 }] }
      ],
      outcomes: [{ path: 0, outcome: 'ROLLED_BACK' }],
      rollback: 'DELEGATED', rollbackVia: 'ERP_USP_TXN_ERROR_HANDLER',
      note: 'discarded by a ROLLBACK inside ERP_USP_TXN_ERROR_HANDLER — the error handler one call down the line, not in ERP_T2'
    },
    {
      id: 'T3', kind: 'transaction', parent: null, outcome: 'OPEN',
      start: { proc: 'ERP_T3', nodeId: 'T3', line: 50, op: 'UPDATE' },
      procCount: 1,
      procs: [{ proc: 'ERP_T3', nodeId: 'T3', ops: [{ op: 'UPDATE', line: 50, table: 'ORDERS' }] }],
      outcomes: [{ path: 0, outcome: 'OPEN' }],
      rollback: 'NONE',
      note: 'no explicit COMMIT or ROLLBACK anywhere in the reachable flow — the writes stay uncommitted; the session teardown decides (implicit rollback).'
    },
    {
      id: 'T4', kind: 'savepoint-region', parent: 'T1', outcome: 'ROLLED_BACK_TO_SAVEPOINT',
      start: { proc: 'ERP_T1', nodeId: 'T1', line: 20, op: 'SAVEPOINT' },
      end: { proc: 'ERP_T1', nodeId: 'T1', line: 40, op: 'ROLLBACK_TO' },
      procCount: 1,
      procs: [{ proc: 'ERP_T1', nodeId: 'T1', ops: [{ op: 'SAVEPOINT', line: 20 }, { op: 'ROLLBACK_TO', line: 40 }] }],
      outcomes: [{ path: 0, outcome: 'ROLLED_BACK_TO_SAVEPOINT' }],
      rollback: 'NONE',
      note: 'the ROLLBACK TO SAVEPOINT at ERP_T1@40 undid this savepoint’s writes — everything before the savepoint stays.'
    }
  ],
  runs: [ { runId: 1, kind: 'main', outcome: 'COMMITTED', assumptions: [], events: [], writes: [], summary: 'ok' } ]
};

async function loadTxnFlowTransactions(doc) {
  const dom = installDom();
  dom.add('txnContainerTrace');
  dom.add('txnBriefContainer');
  globalThis.window = globalThis;
  globalThis.PA = {
    esc, escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    escAttr: esc,
    api: { _analysisName: 'ORACLE~DEMO~LOCAL~T1' },
    context: { procId: 'T1', callTreeRootId: 'T1' },
    analysisData: { transactionStatements: [] },
    isInScope: () => true,
    sourceView: { openNodeAtLine: () => {}, openModal: () => {} },
    callTrace: null,
  };
  globalThis.fetch = async () => ({ ok: true, json: async () => doc });
  new Function(await read('shared/tableFramework.js'))();
  new Function(await read('parser/js/txnTrace.js'))();
  new Function(await read('parser/js/txnFlowTransactions.js'))();
  return dom;
}

export async function test_transactions_view_is_registered_and_renders_the_brief() {
  await loadTxnFlowTransactions(BRIEF_DOC);
  ok(PA.txnFlowTransactions && typeof PA.txnFlowTransactions.render === 'function',
    'the By-transaction view registers as PA.txnFlowTransactions with a render(container, data) entry point');
}

export async function test_transactions_view_renders_one_row_per_transaction() {
  const dom = await loadTxnFlowTransactions(BRIEF_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.setRunsMode('brief');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));

  const html = c.innerHTML;
  includes(html, '4 transactions in this flow', 'the count leads');
  includes(html, '1 committed', 'the summary counts lead');
  includes(html, '1 rolled back', '…including the rollback count');
  // The standard GRID (the user's ask): the shared to-table with sortable headers, a search
  // box, the pager element and column filters — NOT a hand-rolled table.
  includes(html, '<table class="to-table">', 'the brief renders the shared table framework’s markup');
  includes(html, '<tbody id="tbr-tbody">', 'the framework’s tbody is present');
  includes(html, 'id="tbr-pager"', 'the pager element exists — without it 82 of 92 rows are unreachable');
  includes(html, 'PA.tf.sort(\'tbr\',0)', 'the columns sort through the framework');
  includes(html, 'tbrSearch', 'the search box is wired');
  // The framework STATE carries every brief row — the browser renders them through PA.tf.
  const st = PA.tf._state['tbr'];
  ok(st && st.data.length === 4, 'the grid holds all 4 transaction rows, got: ' + (st && st.data.length));
  ok(st.renderRow === PA.txnFlowTransactions._renderBriefRow, 'the rows render through the brief row renderer');
  ok(st.colFilterDefs && st.colFilterDefs[1] && st.colFilterDefs[1].label === 'Outcome',
    'the outcome column has a column filter (the user’s ask)');
  // The row renderer itself (the browser calls it per row): ids, notes, links, parents, chips.
  const row = st.renderRow(BRIEF_DOC.brief[0], 0, (v) => String(v == null ? '' : v));
  includes(row, '<b>T1</b>', 'the row shows the transaction id');
  includes(row, 'saved by the COMMIT at ERP_CHILD@30', 'T1’s plain-English note');
  ok(row.includes('openNodeAtLine'), 'the start/end cells link into the source at the line');
  const delegated = st.renderRow(BRIEF_DOC.brief[1], 1, (v) => String(v == null ? '' : v));
  includes(delegated, 'error handler one call down the line', 'the delegated rollback’s note names the pattern');
  includes(delegated, 'rollback lives in: ERP_USP_TXN_ERROR_HANDLER', 'the delegate proc is named');
  const openRow = st.renderRow(BRIEF_DOC.brief[2], 2, (v) => String(v == null ? '' : v));
  includes(openRow, 'no boundary', 'the open transaction’s end cell says there is none');
  const sub = st.renderRow(BRIEF_DOC.brief[3], 3, (v) => String(v == null ? '' : v));
  includes(sub, 'in T1', 'the savepoint region shows its parent');
  // The outcome quick-filter chips narrow through the view's own filter path.
  includes(html, 'COMMITTED (1)', 'the outcome quick-filter chips are shown');
  PA.txnFlowTransactions.setFilter('COMMITTED');
  await new Promise((r) => setTimeout(r, 5));
  equal(PA.tf._state['tbr'].data.length, 1, 'the outcome chip narrows the grid to that outcome');
  PA.txnFlowTransactions.setFilter('COMMITTED');   // click again to clear
  await new Promise((r) => setTimeout(r, 5));
  equal(PA.tf._state['tbr'].data.length, 4, 'clicking the active chip clears the filter');
  // The search narrows through the framework's own filter path.
  PA.tf.setSearch('tbr', 'no_recovery');
  PA.tf.filter('tbr');
  equal(PA.tf._state['tbr'].filtered.length, 0, 'a non-matching search narrows to nothing');
  PA.tf.setSearch('tbr', 'T5');
  PA.tf.filter('tbr');
  // T5 in the LIVE doc is the no-recovery proc; in this fixture no row matches T5 — the point
  // is that the search path runs, not the count.
  ok(Array.isArray(PA.tf._state['tbr'].filtered));
  // the per-path timelines are NOT this view — they are a sibling tab
  ok(!html.includes('Execution path:'), 'the per-path selector must not render on the brief');
}

export async function test_transactions_view_is_the_fallback_when_a_doc_has_no_proc_rollup() {
  // A doc whose resolver emitted a brief but no procRollup: the default By-procedure tab falls
  // through to the By-transaction view rather than rendering nothing.
  const dom = await loadTxnFlowTransactions(BRIEF_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, 'tbr-tbody', 'no procRollup → the brief is shown by default');
}
