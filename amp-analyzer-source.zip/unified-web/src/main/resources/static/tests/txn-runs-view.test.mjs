/**
 * The transaction FLOW (runs) entry point — the UI over the backend's interprocedural transaction
 * resolver (`/txn-runs/{nodeId}`). Task 65 split the flow's three sub-views into their own files
 * (PA.txnFlowProcs / PA.txnFlowTransactions / PA.txnFlowPaths — see the txn-flow-*.test.mjs files);
 * what stays in PA.txnTrace is the top-level view dispatch, the ONE fetch per entry, and the
 * "needs a rooted procedure" guard tested here.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { includes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(STATIC, p), 'utf8');

const RUNS_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false,
  runs: [ { runId: 1, kind: 'main', outcome: 'COMMITTED', assumptions: [], events: [], writes: [], summary: 'ok' } ]
};

async function loadTxnTrace(runsDoc) {
  const dom = installDom();
  dom.add('txnContainerTrace');
  globalThis.window = globalThis;
  globalThis.PA = {
    esc, escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    escAttr: esc,
    api: { _analysisName: 'ORACLE~DEMO~LOCAL~T1' },
    context: { procId: 'T1', callTreeRootId: 'T1' },
    analysisData: { transactionStatements: [] },
    isInScope: () => true,
    sourceView: {},
    callTrace: null,
  };
  globalThis.fetch = async () => ({ ok: true, json: async () => runsDoc });
  new Function(await read('parser/js/txnTrace.js'))();
  return dom;
}

export async function test_runs_view_needs_a_rooted_procedure() {
  const dom = await loadTxnTrace(RUNS_DOC);
  const c = dom.get('txnContainerTrace');
  PA.context.procId = '';
  PA.context.callTreeRootId = '';
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));
  includes(c.innerHTML, 'rooted procedure',
    'the runs view silently rendering the whole analysis would misstate the semantics — it needs an entry');
}

export async function test_statements_facet_gives_transaction_types_their_own_family() {
  const src = (await read('parser/js/statements.js')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  includes(src, "COMMIT: 'txn'", 'COMMIT must join the txn pill family');
  includes(src, 'BEGIN_TRAN', 'the SQL Server begin-transaction type must be classified');
  includes(src, "COMMIT: 'var(--badge-green)'", 'COMMIT must render green (persists)');
  includes(src, "ROLLBACK: 'var(--badge-red)'", 'ROLLBACK must render red (discards)');
}

export async function test_source_view_marks_transaction_lines() {
  const src = (await read('parser/js/sourceView.js')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  includes(src, '_txnLineMap', 'the source view has no transaction-line map');
  includes(src, 'src-txn-mark', 'the gutter badge is not emitted');
  includes(src, 'detail.transactionScope', 'the txn lines must come from the loaded node’s transactionScope');
}
