/**
 * Task 65 — the Flow view's BY-PROCEDURE sub-view (PA.txnFlowProcs): one row per procedure in the
 * resolved flow (its transactions, its write-survival counts, its transaction-op tally and its
 * line span), with a row click expanding the procedure's OWN per-op grid (filter + sort + pager;
 * every LINE cell opens the source at that exact line).
 *
 * The sub-view is its own file, registered as PA.txnFlowProcs and rendered by PA.txnTrace's Flow
 * dispatch with the SAME doc the other two tabs receive.
 */
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { ok, includes } from './lib/assert.mjs';
import { installDom, esc } from './lib/dom.mjs';

const STATIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(STATIC, p), 'utf8');

const ROLLUP_DOC = {
  entry: 'T1', dialect: 'ORACLE', pathCountExceeded: false, briefVersion: 'brief-4',
  briefSummary: { transactions: 2, committed: 1, rolledBack: 1 },
  procRollup: [
    { proc: 'ERP_T1', nodeId: 'T1', transactions: ['T1'], writesTotal: 5, survived: 3, discarded: 2, open: 0,
      commits: 1, rollbacks: 1, savepoints: 1, rollbackTos: 0, firstLine: 12, lastLine: 60,
      ops: [
        { kind: 'WRITE', op: 'UPDATE', line: 12, table: 'ORDERS', survival: 'survived' },
        { kind: 'SAVEPOINT', line: 20, name: 'sp' },
        { kind: 'COMMIT', line: 60, survival: 'survived' }
      ] },
    { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', transactions: ['T1'], writesTotal: 0,
      commits: 0, rollbacks: 1, savepoints: 0, rollbackTos: 0, firstLine: 5, lastLine: 5,
      ops: [ { kind: 'ROLLBACK', line: 5 } ] }
  ],
  brief: [ { id: 'T1', kind: 'transaction', outcome: 'ROLLED_BACK',
      start: { proc: 'ERP_T1', nodeId: 'T1', line: 12 }, end: { proc: 'ERP_USP_TXN_ERROR_HANDLER', nodeId: 'HANDLER', line: 5 },
      procCount: 2, procs: [], outcomes: [{ path: 0, outcome: 'ROLLED_BACK' }], rollback: 'DELEGATED', rollbackVia: 'ERP_USP_TXN_ERROR_HANDLER',
      note: 'discarded' } ],
  runs: [ { runId: 1, kind: 'main', outcome: 'ROLLED_BACK', assumptions: [], events: [], writes: [], summary: 'ok' } ]
};

async function loadTxnFlowProcs(doc) {
  const dom = installDom();
  dom.add('txnContainerTrace');
  globalThis.window = globalThis;
  globalThis.PA = {
    esc, escJs: (s) => String(s == null ? '' : s).replace(/'/g, "\\'"),
    escAttr: esc,
    api: { _analysisName: 'ORACLE~DEMO~LOCAL~T1' },
    context: { procId: 'T1', callTreeRootId: 'T1' },
    analysisData: { transactionStatements: [] },
    isInScope: () => true,
    sourceView: { openNodeAtLine: () => {}, openModal: () => {} },
    callTrace: null,
  };
  globalThis.fetch = async () => ({ ok: true, json: async () => doc });
  // The REAL table framework: the proc list is a PA.tf grid (sortable columns, search, the
  // remembered page size, pagination — not a hand-rolled table).
  new Function(await read('shared/tableFramework.js'))();
  new Function(await read('parser/js/txnTrace.js'))();
  new Function(await read('parser/js/txnFlowProcs.js'))();
  return dom;
}

export async function test_procs_view_is_registered_and_renders_the_proc_grid() {
  await loadTxnFlowProcs(ROLLUP_DOC);
  ok(PA.txnFlowProcs && typeof PA.txnFlowProcs.render === 'function',
    'the By-procedure view registers as PA.txnFlowProcs with a render(container, data) entry point');
}

export async function test_procs_list_is_the_first_view_and_expands_to_the_op_table() {
  const dom = await loadTxnFlowProcs(ROLLUP_DOC);
  const c = dom.get('txnContainerTrace');
  PA.txnTrace.setView('runs');
  PA.txnTrace.render();
  await new Promise((r) => setTimeout(r, 5));

  const html = c.innerHTML;
  includes(html, '2 procedures', 'the PROC LIST leads — procs as rows, not counts');
  includes(html, '<tbody id="tbp-tbody">', 'the proc list is the shared grid');
  includes(html, 'PA.tf.sort(\'tbp\',0)', 'the columns sort through the framework');
  includes(html, 'tbpSearch', 'the search box is wired');
  // the grid state carries the rows; the row renderer shows proc/transactions/writes/ops/lines
  const st = PA.tf._state['tbp'];
  ok(st && st.data.length === 2, 'both procs are rows');
  ok(st.renderRow === PA.txnFlowProcs._renderProcRow, 'the rows render through the proc row renderer');
  ok(st.renderDetail === PA.txnFlowProcs._renderProcDetail, 'the expand renders through the proc detail renderer');
  const row = st.renderRow(ROLLUP_DOC.procRollup[0], 0, (v) => String(v == null ? '' : v));
  includes(row, 'ERP_T1', 'the proc name is the row');
  includes(row, 'T1', 'the transactions column names the T');
  // The detail is ITS OWN GRID (filter + sort + pager — a proc can have 240 ops); the op
  // rows render through the grid's row renderer, bound to the proc's nodeId.
  const detail = st.renderDetail(ROLLUP_DOC.procRollup[0], 0, (v) => String(v == null ? '' : v));
  includes(detail, 'tbpd-0Search', 'the expand carries its own filter box');
  includes(detail, 'tbpd-0-pager', 'the expand carries its own pager');
  const opRow = PA.txnFlowProcs._makeOpRowRenderer('T1')(ROLLUP_DOC.procRollup[0].ops[0], 0, (v) => String(v == null ? '' : v));
  includes(opRow, 'openNodeAtLine', 'EVERY op line is clickable into the source (verify in place)');
  includes(opRow, 'survived', 'the survival chip is on the op row');
  const handlerOpRow = PA.txnFlowProcs._makeOpRowRenderer('HANDLER')(ROLLUP_DOC.procRollup[1].ops[0], 0, (v) => String(v == null ? '' : v));
  includes(handlerOpRow, 'ROLLBACK', 'the handler proc’s own rollback is its op row — clickable to its line 5');
}
