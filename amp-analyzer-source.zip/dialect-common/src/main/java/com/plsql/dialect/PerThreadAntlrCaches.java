package com.plsql.dialect;

import org.antlr.v4.runtime.atn.ATN;
import org.antlr.v4.runtime.atn.PredictionContextCache;
import org.antlr.v4.runtime.dfa.DFA;

/**
 * Per-thread ANTLR prediction caches for a grammar engine — the pattern PlSqlParserEngine
 * (plsql-parser) uses to make CONCURRENT parses of one grammar safe: the generated lexer/parser
 * otherwise share `static final DFA[] _decisionToDFA` + a static prediction-context cache, and
 * ANTLR MUTATES those during prediction. Two threads parsing the same grammar without this race
 * on the shared structures (torn DFA states, wrong parses).
 *
 * <p>The caches live on the thread (a ThreadLocal), so the DFA stays warm across that thread's
 * parses and the memory is bounded by the number of live parse threads — the crawl's bounded
 * pool. Each engine installs its thread's instances via {@code lexer.setInterpreter(...)} /
 * {@code parser.setInterpreter(...)} before any prediction happens.
 *
 * <p>Task 61-W2: this replaces the crawl's dialectParseLock serialization for the four dialect
 * engines (MySQL/SQL Server/DB2/Postgres) — the lock was a per-instance monitor guarding
 * process-global state, which both serialized every non-Oracle parse AND still raced across
 * crawler instances.
 */
public final class PerThreadAntlrCaches {

    /** One thread's caches: its own DFA arrays + its own prediction-context cache. */
    public static final class Caches {
        public final DFA[] lexerDfa;
        public final DFA[] parserDfa;
        public final PredictionContextCache contextCache = new PredictionContextCache();

        public Caches(ATN lexerAtn, ATN parserAtn) {
            lexerDfa = newDfaArray(lexerAtn);
            parserDfa = newDfaArray(parserAtn);
        }

        private static DFA[] newDfaArray(ATN atn) {
            DFA[] dfas = new DFA[atn.getNumberOfDecisions()];
            for (int i = 0; i < dfas.length; i++) {
                dfas[i] = new DFA(atn.getDecisionState(i), i);
            }
            return dfas;
        }
    }

    /** A ThreadLocal of caches for one grammar pair (pass {@code Lexer._ATN}, {@code Parser._ATN}). */
    public static ThreadLocal<Caches> of(ATN lexerAtn, ATN parserAtn) {
        return ThreadLocal.withInitial(() -> new Caches(lexerAtn, parserAtn));
    }

    private PerThreadAntlrCaches() {}
}
