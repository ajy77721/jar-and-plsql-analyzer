# EC2 SQL Server Express — the minimal, almost-free demo box

One `t3.small` Ubuntu 24.04 instance running **SQL Server 2022 Express** — the
**free edition** (no license cost, ever; limits: 10 GB/db, 1.4 GB RAM buffer
pool/db, 4 cores — ample for the demo corpus).

**Costs**: instance ~$15/mo full-time, **~$7–8/mo** stopped nights + weekends,
disk (30 GB gp3) ~$2.5/mo. The SQL Server license itself is **$0**.

## Launch (console, ~5 minutes)

1. EC2 → Launch instance (account `331472312345`):
   - **Name**: `amp-sqlserver-demo`
   - **AMI**: Ubuntu Server 24.04 LTS (**x86_64** — no ARM build exists)
   - **Type**: `t3.small` (2 GB — SQL Server on Linux's hard minimum; `t3.medium`
     for comfort at ~$30/mo)
   - **Key pair**: create/select one
   - **Storage**: 30 GB gp3
   - **Security group**: SSH (22) from **My IP only**; **1433 from the needed
     IPs only** (your IP + the Kanopy cluster NAT egress) — never 0.0.0.0/0
   - **Advanced details → User data**: paste the whole
     [`sqlserver-express-userdata.sh`](./sqlserver-express-userdata.sh)
2. Launch. First boot installs + configures Express and creates `analyzer-db`
   (~5 min). Watch progress: `ssh ubuntu@<IP> 'tail -f /var/log/cloud-init-output.log'`

## Seed the demo corpus (once)

User-data cannot reach this private repo, so the seed is one manual step:

```bash
scp db-setup/seed/sqlserver.sql ubuntu@<EC2_IP>:~/
ssh ubuntu@<EC2_IP> \
  'sqlcmd -S localhost,1433 -U sa -P "Password123!" -C -i ~/sqlserver.sql'
```

Idempotent — safe to re-run. Entry procedure for analysis: `erp.USP_RUNMRPCYCLE`.

## Wire into amp-analyzer

UI → new connection: host `<EC2_PUBLIC_IP>`, port `1433`, **SQL auth**
(`sa` / `Password123!` — or create a dedicated `analyzer_demo` login instead of
`sa`), database `analyzer-db`. TlsKeystore/encryption: sqlcmd needs `-C`
(trust server cert) locally; the app's connection config has the equivalent
trust/encryption toggle.

## Make it cheap

Stop it nights + weekends: EC2 → Instance scheduler (or an EventBridge rule
`stop` at 19:00 Mon–Fri, `start` at 08:00 Mon). A stopped instance costs only
the disk (~$2.5/mo).

## Housekeeping

- The `sa` password lives in the seed/user-data because the corpus is a demo;
  do not point this box at anything real.
- MongoDB policy: EC2 in the shared services account may need an
  aws-services@mongodb.com nod — same as the `iam:CreateUser` wall.
