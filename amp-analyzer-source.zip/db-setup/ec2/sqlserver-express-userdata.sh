#!/bin/bash
# ============================================================================
# EC2 user-data: SQL Server 2022 EXPRESS on Ubuntu 24.04 — the free edition.
#
# Paste this into EC2 → Launch instance → Advanced details → User data
# (or pass as --user-data file://... on the CLI). It runs once on first boot.
#
# Installs the license-free Express edition, sets the SA password the demo seed
# expects, creates 'analyzer-db', and leaves mssql listening on 1433.
#
#   IMPORTANT — after first boot, seed the demo schema (user-data cannot reach
#   the private repo):
#     scp db-setup/seed/sqlserver.sql ubuntu@<EC2_IP>:~/
#     ssh ubuntu@<EC2_IP> 'sqlcmd -S localhost,1433 -U sa -P "Password123!" -C -i ~/sqlserver.sql'
#
# Express limits (fine for the demo corpus): 10 GB per database, 1.4 GB RAM
# buffer pool per db, 4 cores. This box wants ≥2 GB RAM — launch t3.small.
# Idempotent: re-running setup/mssql-conf steps is safe.
# ============================================================================
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive

log() { echo "[mssql-userdata] $*"; }

# 1. The Microsoft repo for mssql-server 2022 on Ubuntu 24.04.
log "adding the Microsoft package repo"
curl -fsSL https://packages.microsoft.com/keys/microsoft.asc \
  | sudo tee /etc/apt/trusted.gpg.d/microsoft.asc >/dev/null
sudo add-apt-repository -y \
  "$(wget -qO- https://packages.microsoft.com/config/ubuntu/24.04/mssql-server-2022.list)"
sudo apt-get update -y

# 2. Install + configure. mssql-conf setup is normally interactive; the env
#    vars pre-answer it (MSSQL_PID=Express = the FREE edition, MSSQL_SA_PASSWORD
#    = the demo seed's expected password, MSSQL_COLLATION default).
log "installing mssql-server (Express)"
sudo apt-get install -y mssql-server

if ! /opt/mssql/bin/sqlservr --version >/dev/null 2>&1 && [ ! -f /var/opt/mssql/.configured ]; then
  log "configuring Express edition + SA password"
  sudo MSSQL_PID=Express \
       MSSQL_SA_PASSWORD='Password123!' \
       MSSQL_COLLATION='SQL_Latin1_General_CP1_CI_AS' \
       /opt/mssql/bin/mssql-conf -n setup accept-eula
  sudo touch /var/opt/mssql/.configured
fi
sudo systemctl enable --now mssql-server

# 3. sqlcmd for the seeding step (mssql-tools18, yes to the EULA quietly).
log "installing mssql-tools18 (sqlcmd)"
sudo add-apt-repository -y \
  "$(wget -qO- https://packages.microsoft.com/config/ubuntu/24.04/prod.list)" || true
sudo apt-get update -y && sudo apt-get install -y mssql-tools18 unixodbc-dev || \
  log "mssql-tools18 failed to install — seed with a containerized sqlcmd instead"
sudo ln -sf /opt/mssql-tools18/bin/sqlcmd /usr/local/bin/sqlcmd || true

# 4. Wait until the server accepts logins, then create the demo database.
log "waiting for SQL Server to accept connections"
for i in $(seq 1 24); do
  if sqlcmd -S localhost,1433 -U sa -P 'Password123!' -C -Q "SELECT 1" >/dev/null 2>&1; then
    break
  fi
  sleep 5
done
sqlcmd -S localhost,1433 -U sa -P 'Password123!' -C \
  -Q "IF DB_ID('analyzer-db') IS NULL CREATE DATABASE [analyzer-db];" \
  || log "WARN: could not create analyzer-db — create it before seeding"

log "DONE — SQL Server Express is up on 1433 (analyzer-db created)."
log "NEXT: seed the demo schema — see the IMPORTANT note in the header."
