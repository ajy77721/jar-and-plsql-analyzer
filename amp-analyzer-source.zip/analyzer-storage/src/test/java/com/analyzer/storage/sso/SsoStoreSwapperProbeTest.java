package com.analyzer.storage.sso;

import com.analyzer.storage.s3.FakeS3Server;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationEventPublisher;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Connect-time behaviour of {@link SsoStoreSwapper} against a real {@link FakeS3Server} over HTTP:
 * the two human error classifications a failed probe now produces (missing bucket, cross-account
 * denial) and the opt-in auto-create of a missing bucket in the user's own account.
 *
 * <p>Real HTTP (not a mocked {@code S3Client}) so the SDK's own error-code mapping — {@code
 * NoSuchBucket}/{@code AccessDenied}/{@code BucketAlreadyOwnedByYou}/{@code BucketAlreadyExists} —
 * is exercised, which is exactly what the classification keys on. The fake never checks a signature,
 * so IAM/credential behaviour is out of reach here; the credential provider is a fixed stub.
 */
class SsoStoreSwapperProbeTest {

    private static final String REGION = "us-east-1";
    private static final String SESSION = "sess-1";

    private FakeS3Server server;

    @AfterEach
    void tearDown() {
        if (server != null) server.close();
    }

    /** A swapper whose probe client is pointed at {@code server} via the configured S3 endpoint. */
    private SsoStoreSwapper swapper(String defaultBucket) {
        SsoCredentialsResolver credentials = mock(SsoCredentialsResolver.class);
        when(credentials.resolveFor(anyString())).thenReturn(
                StaticCredentialsProvider.create(AwsBasicCredentials.create("AK", "SK")));
        return new SsoStoreSwapper(defaultBucket, REGION, server.endpoint(),
                credentials, mock(CurrentHttpSession.class),
                mock(SsoSessionRegistry.class), mock(ApplicationEventPublisher.class));
    }

    @Test
    void missingBucketProbeReportsTheFriendlyNotFoundError() throws IOException {
        server = new FakeS3Server("seed-bucket");

        SsoStoreSwapper.ConnectResult result = swapper("seed-bucket")
                .connect(SESSION, "missing-bucket", REGION);

        assertFalse(result.ok(), "a missing bucket must not connect");
        assertEquals(
                "Bucket \"missing-bucket\" not found — check the name, or create it in your own "
                        + "account and connect to that. (NoSuchBucket)",
                result.capabilities().error());
        assertFalse(server.hasBucket("missing-bucket"), "a plain connect never creates anything");
    }

    @Test
    void accessDeniedProbeReportsTheFriendlyDeniedError() throws IOException {
        server = new FakeS3Server("denied-bucket");
        server.denyAllAccess();

        SsoStoreSwapper.ConnectResult result = swapper("denied-bucket")
                .connect(SESSION, "denied-bucket", REGION);

        assertFalse(result.ok(), "a denied bucket must not connect");
        assertEquals(
                "Bucket \"denied-bucket\" denied access — your identity verified, but this bucket's "
                        + "owner policy has not granted your account. Ask the bucket owner for the "
                        + "org-wide grant, or create a bucket in your own account and connect to that "
                        + "instead. (AccessDenied)",
                result.capabilities().error());
    }

    @Test
    void createIfMissingCreatesTheBucketThenConnects() throws IOException {
        server = new FakeS3Server("seed-bucket");

        SsoStoreSwapper.ConnectResult result = swapper("seed-bucket")
                .connect(SESSION, "user-bucket", REGION, true);

        assertTrue(result.ok(), "after creating the missing bucket the connect must succeed");
        assertEquals("user-bucket", result.bucket());
        assertEquals(1, server.createBucketRequests.get(), "exactly one create attempt");
        assertTrue(server.hasBucket("user-bucket"), "the bucket now exists in the user's own account");
    }

    @Test
    void createIfMissingOnAccessDeniedCreatesNothingAndFails() throws IOException {
        server = new FakeS3Server("denied-bucket");
        server.denyAllAccess();

        SsoStoreSwapper.ConnectResult result = swapper("denied-bucket")
                .connect(SESSION, "denied-bucket", REGION, true);

        assertFalse(result.ok(), "an AccessDenied must never be turned into a create-and-connect");
        assertEquals(0, server.createBucketRequests.get(),
                "no create may be attempted on an AccessDenied (cross-account) failure");
        assertTrue(result.capabilities().error().contains("denied access"),
                "the failure must be the friendly denied-access message: "
                        + result.capabilities().error());
    }

    @Test
    void createOnAnAlreadyOwnedBucketIsTreatedAsSuccess() throws IOException {
        server = new FakeS3Server("seed-bucket");
        server.createBucketOutcome(FakeS3Server.CreateBucketOutcome.ALREADY_OWNED);

        SsoStoreSwapper.ConnectResult result = swapper("seed-bucket")
                .connect(SESSION, "user-bucket", REGION, true);

        assertTrue(result.ok(), "BucketAlreadyOwnedByYou means the user owns it: connect proceeds");
        assertEquals(1, server.createBucketRequests.get());
        assertTrue(server.hasBucket("user-bucket"));
    }

    @Test
    void createOnABucketOwnedByAnotherAccountFailsClearly() throws IOException {
        server = new FakeS3Server("seed-bucket");
        server.createBucketOutcome(FakeS3Server.CreateBucketOutcome.ALREADY_EXISTS);

        SsoStoreSwapper.ConnectResult result = swapper("seed-bucket")
                .connect(SESSION, "taken-bucket", REGION, true);

        assertFalse(result.ok(), "a name owned by another account must not connect");
        assertEquals(1, server.createBucketRequests.get(), "the create is attempted exactly once");
        assertTrue(result.capabilities().error().contains("is owned by another AWS account"),
                "the failure must name that the bucket name is taken by another account: "
                        + result.capabilities().error());
        assertFalse(server.hasBucket("taken-bucket"), "no bucket is created under a taken name");
    }

    // ── standalone createBucketIfMissing (backs POST /api/auth/aws/create-bucket) ──────────────

    @Test
    void createBucketIfMissingCreatesAndReturnsTheVerifiedCapabilities() throws IOException {
        server = new FakeS3Server("seed-bucket");

        SsoStoreSwapper.CreateBucketResult result = swapper("seed-bucket")
                .createBucketIfMissing(SESSION, "user-bucket", REGION);

        assertTrue(result.ok(), "creating a missing bucket must succeed");
        assertTrue(result.created(), "a create was attempted and succeeded");
        assertFalse(result.alreadyExisted(), "the bucket was not there before");
        assertTrue(result.capabilities() != null && result.capabilities().ok(),
                "the re-probe's green capabilities must be returned");
        assertEquals(1, server.createBucketRequests.get());
        assertTrue(server.hasBucket("user-bucket"));
    }

    @Test
    void createBucketIfMissingOnAnExistingBucketCreatesNothing() throws IOException {
        server = new FakeS3Server("existing-bucket");

        SsoStoreSwapper.CreateBucketResult result = swapper("existing-bucket")
                .createBucketIfMissing(SESSION, "existing-bucket", REGION);

        assertTrue(result.ok(), "an existing accessible bucket is a success");
        assertTrue(result.alreadyExisted(), "the bucket was already there");
        assertFalse(result.created(), "nothing may be created when the bucket exists");
        assertEquals(0, server.createBucketRequests.get(), "no create request at all");
    }

    @Test
    void createBucketIfMissingOnAnAlreadyOwnedBucketSucceeds() throws IOException {
        server = new FakeS3Server("seed-bucket");
        server.createBucketOutcome(FakeS3Server.CreateBucketOutcome.ALREADY_OWNED);

        SsoStoreSwapper.CreateBucketResult result = swapper("seed-bucket")
                .createBucketIfMissing(SESSION, "user-bucket", REGION);

        assertTrue(result.ok(), "BucketAlreadyOwnedByYou means the user owns it: success");
        assertTrue(result.created(), "a create was attempted");
        assertEquals(1, server.createBucketRequests.get());
        assertTrue(result.capabilities() != null && result.capabilities().ok());
    }

    @Test
    void createBucketIfMissingOnABucketOwnedByAnotherAccountFailsClearly() throws IOException {
        server = new FakeS3Server("seed-bucket");
        server.createBucketOutcome(FakeS3Server.CreateBucketOutcome.ALREADY_EXISTS);

        SsoStoreSwapper.CreateBucketResult result = swapper("seed-bucket")
                .createBucketIfMissing(SESSION, "taken-bucket", REGION);

        assertFalse(result.ok(), "a name owned by another account must fail");
        assertEquals(1, server.createBucketRequests.get());
        assertEquals("taken-bucket is owned by another AWS account — pick a different bucket name. "
                + "(BucketAlreadyExists)", result.error());
        assertFalse(server.hasBucket("taken-bucket"), "no bucket is created under a taken name");
    }

    @Test
    void createBucketIfMissingOnAccessDeniedReportsTheFriendlyDeniedErrorAndCreatesNothing()
            throws IOException {
        server = new FakeS3Server("denied-bucket");
        server.denyAllAccess();

        SsoStoreSwapper.CreateBucketResult result = swapper("denied-bucket")
                .createBucketIfMissing(SESSION, "denied-bucket", REGION);

        assertFalse(result.ok(), "an AccessDenied must never be turned into a create");
        assertEquals(0, server.createBucketRequests.get(), "no create may be attempted on an AccessDenied");
        assertEquals(
                "Bucket \"denied-bucket\" denied access — your identity verified, but this bucket's "
                        + "owner policy has not granted your account. Ask the bucket owner for the "
                        + "org-wide grant, or create a bucket in your own account and connect to that "
                        + "instead. (AccessDenied)",
                result.error());
    }

    @Test
    void createBucketIfMissingWithoutASessionIsRejected() throws IOException {
        server = new FakeS3Server("seed-bucket");
        SsoStoreSwapper swapper = swapper("seed-bucket");

        assertThrows(NotAuthenticatedException.class,
                () -> swapper.createBucketIfMissing(null, "user-bucket", REGION));
        assertThrows(NotAuthenticatedException.class,
                () -> swapper.createBucketIfMissing("  ", "user-bucket", REGION));
        assertEquals(0, server.createBucketRequests.get(), "an unauthenticated call creates nothing");
    }
}
