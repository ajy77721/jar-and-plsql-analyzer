package com.analyzer.storage;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The write-ahead spill: a {@code close()} that returned must survive a process kill, and a
 * surviving spill must upload on the next boot. These tests simulate the crash by letting the
 * upload fail (the flush never reaches S3), leaving the spill behind exactly as a {@code kill -9}
 * between spill and upload would, then boot a fresh store over the same directory.
 */
class WriteBehindStoreSpillTest {

    private static final ArtifactKey KEY = ArtifactKey.of("parser", "db1", "proj", "dev", "obj", "api", "index.json");
    private static final byte[] BODY = "{\"run\":1}".getBytes(StandardCharsets.UTF_8);

    /** A store whose uploads always fail — the crash window's observable stand-in. */
    private static final class FailingStore implements ArtifactStore {
        @Override public OutputStream write(ArtifactKey key) throws IOException {
            throw new IOException("s3 unreachable");
        }
        @Override public OutputStream write(ArtifactKey key, long contentLength) throws IOException {
            throw new IOException("s3 unreachable");
        }
        @Override public InputStream read(ArtifactKey key) { throw new UnsupportedOperationException(); }
        @Override public InputStream read(ArtifactKey key, long o, long l) { throw new UnsupportedOperationException(); }
        @Override public boolean exists(ArtifactKey key) { return false; }
        @Override public long size(ArtifactKey key) { return -1; }
        @Override public long lastModified(ArtifactKey key) { return -1; }
        @Override public boolean delete(ArtifactKey key) { return false; }
        @Override public int deletePrefix(ArtifactKey prefix) { return 0; }
        @Override public Stream<ArtifactEntry> list(ArtifactKey prefix, boolean recursive) { return Stream.empty(); }
        @Override public void copy(ArtifactKey from, ArtifactKey to) { }
        @Override public void move(ArtifactKey from, ArtifactKey to) { }
        @Override public LocalHandle materialize(ArtifactKey key) { throw new UnsupportedOperationException(); }
    }

    /**
     * A store whose {@code write()} blocks until released — the observable stand-in for a stalled
     * S3 upload. {@code entered} lets a test wait until the upload is genuinely in flight (so the
     * read barrier has something pending to time out on).
     */
    private static final class BlockingStore implements ArtifactStore {
        private final CountDownLatch entered = new CountDownLatch(1);
        private final CountDownLatch release = new CountDownLatch(1);

        @Override public OutputStream write(ArtifactKey key) throws IOException {
            return write(key, -1);
        }

        @Override public OutputStream write(ArtifactKey key, long contentLength) throws IOException {
            entered.countDown();
            try {
                release.await();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("interrupted while blocked", e);
            }
            return OutputStream.nullOutputStream();
        }

        @Override public InputStream read(ArtifactKey key) { throw new UnsupportedOperationException(); }
        @Override public InputStream read(ArtifactKey key, long o, long l) { throw new UnsupportedOperationException(); }
        @Override public boolean exists(ArtifactKey key) { return false; }
        @Override public long size(ArtifactKey key) { return -1; }
        @Override public long lastModified(ArtifactKey key) { return -1; }
        @Override public boolean delete(ArtifactKey key) { return false; }
        @Override public int deletePrefix(ArtifactKey prefix) { return 0; }
        @Override public Stream<ArtifactEntry> list(ArtifactKey prefix, boolean recursive) { return Stream.empty(); }
        @Override public void copy(ArtifactKey from, ArtifactKey to) { }
        @Override public void move(ArtifactKey from, ArtifactKey to) { }
        @Override public LocalHandle materialize(ArtifactKey key) { throw new UnsupportedOperationException(); }

        void awaitEntered() throws InterruptedException { entered.await(); }
        void release() { release.countDown(); }
    }

    private static long spillCount(Path dir) throws IOException {
        if (!Files.isDirectory(dir)) return 0;
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(p -> p.getFileName().toString().endsWith(".spill")).count();
        }
    }

    private static void write(WriteBehindStore store, ArtifactKey key, byte[] body) throws IOException {
        try (OutputStream out = store.write(key)) {
            out.write(body);
        }
    }

    @Test
    void aClosedWriteSurvivesAFailedUploadAndReplaysOnBoot(@TempDir Path tmp) throws IOException {
        Path spill = tmp.resolve("spill");
        WriteBehindStore crashing = new WriteBehindStore(new FailingStore(), 2, null, spill);
        try {
            write(crashing, KEY, BODY);
            // The upload fails; the drain surfaces it, exactly as the analysis thread would see.
            assertThrows(IOException.class, crashing::awaitPending);
        } finally {
            crashing.close(1_000);
        }
        // The bytes that reached close() are on disk, not lost with the heap buffer.
        assertEquals(1, spillCount(spill), "the closed write must have spilled before the failed upload");

        // "Restart": a fresh store over the same spill dir with a working backend.
        InMemoryArtifactStore backend = new InMemoryArtifactStore();
        WriteBehindStore booted = new WriteBehindStore(backend, 2, null, spill);
        try {
            int replayed = booted.replaySpills();
            assertEquals(1, replayed, "the surviving spill must replay at boot");
            assertTrue(backend.exists(KEY), "replayed bytes must land in the backend");
            try (InputStream in = backend.read(KEY)) {
                assertArrayEquals(BODY, in.readAllBytes());
            }
            assertEquals(0, spillCount(spill), "a successfully replayed spill is deleted");
        } finally {
            booted.close(1_000);
        }
    }

    @Test
    void aSuccessfulUploadDeletesItsSpill(@TempDir Path tmp) throws IOException {
        Path spill = tmp.resolve("spill");
        InMemoryArtifactStore backend = new InMemoryArtifactStore();
        WriteBehindStore store = new WriteBehindStore(backend, 2, null, spill);
        try {
            write(store, KEY, BODY);
            store.awaitPending();
            assertTrue(backend.exists(KEY));
            assertEquals(0, spillCount(spill), "steady state keeps the spill directory empty");
        } finally {
            store.close(1_000);
        }
    }

    @Test
    void aCorruptSpillIsDiscardedNotReplayed(@TempDir Path tmp) throws IOException {
        Path spill = tmp.resolve("spill");
        Files.createDirectories(spill);
        Files.write(spill.resolve("garbage.spill"), "not a spill record".getBytes(StandardCharsets.UTF_8));

        InMemoryArtifactStore backend = new InMemoryArtifactStore();
        WriteBehindStore store = new WriteBehindStore(backend, 2, null, spill);
        try {
            assertEquals(0, store.replaySpills(), "garbage must never be replayed");
            assertEquals(0, backend.objectCount());
            assertEquals(0, spillCount(spill), "an unparseable spill is reclaimed");
        } finally {
            store.close(1_000);
        }
    }

    @Test
    void withoutASpillDirTheBufferStaysHeapOnly(@TempDir Path tmp) throws IOException {
        // Legacy behaviour preserved: no spill dir means no local writes at all.
        InMemoryArtifactStore backend = new InMemoryArtifactStore();
        WriteBehindStore store = new WriteBehindStore(backend, 2, null, null);
        try {
            write(store, KEY, BODY);
            store.awaitPending();
            assertTrue(backend.exists(KEY));
            try (Stream<Path> s = Files.list(tmp)) {
                assertFalse(s.findAny().isPresent(), "a heap-only store writes nothing locally");
            }
        } finally {
            store.close(1_000);
        }
    }

    @Test
    void theSpillNeverCarriesCredentials(@TempDir Path tmp) throws IOException {
        // Only key + bytes are spilled; the captured SSO context is heap-only. If a future change
        // ever serialises it, this fails.
        Path spill = tmp.resolve("spill");
        WriteBehindStore store = new WriteBehindStore(new FailingStore(), 2, null, spill);
        try {
            write(store, KEY, BODY);
            assertThrows(IOException.class, store::awaitPending);
        } finally {
            store.close(1_000);
        }
        List<Path> files;
        try (Stream<Path> s = Files.list(spill)) {
            files = s.filter(p -> p.getFileName().toString().endsWith(".spill")).toList();
        }
        assertEquals(1, files.size());
        String content = new String(Files.readAllBytes(files.get(0)), StandardCharsets.ISO_8859_1);
        assertFalse(content.contains("alice-secret"), "no credential material may reach the spill");
        assertTrue(content.contains(KEY.leaf()), "the spill records the key it belongs to");
    }

    @Test
    void aStalledUploadDoesNotHangTheReadBarrier() throws Exception {
        // The barrier every read-shaped call crosses must not wait forever on a stalled upload.
        // Bounded patience: it returns, logs a WARN naming the outstanding key, and lets the read
        // proceed best-effort against the delegate's own state (a transient S3 stall must not
        // freeze the UI). The 50 ms bound stands in for MAX_DRAIN_WAIT_MS, which is read once at
        // class init and is 120 s in production.
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        Logger storeLogger = (Logger) LoggerFactory.getLogger(WriteBehindStore.class);
        storeLogger.addAppender(appender);

        BlockingStore delegate = new BlockingStore();
        WriteBehindStore store = new WriteBehindStore(delegate, 1);
        try {
            write(store, KEY, BODY);      // enqueued; the pool thread blocks inside delegate.write
            delegate.awaitEntered();      // the upload is in flight, so `pending` is non-empty

            long start = System.nanoTime();
            boolean drained = store.awaitPending(50);   // the barrier a read crosses, 50 ms bound
            long elapsedMs = (System.nanoTime() - start) / 1_000_000;

            assertFalse(drained, "a stalled upload must exhaust the bounded patience");
            assertTrue(elapsedMs < 5_000,
                    "the barrier must return promptly, not hang (took " + elapsedMs + " ms)");
            assertTrue(appender.list.stream().anyMatch(e ->
                            e.getLevel() == Level.WARN
                                    && e.getFormattedMessage().contains(KEY.toString())),
                    "the stall must be logged loudly, naming the oldest pending key; logs="
                            + appender.list);
        } finally {
            delegate.release();     // unblock the upload so the pool can finish and drain
            store.close(5_000);
            storeLogger.detachAppender(appender);
        }
    }

    @Test
    void theCommonCaseStillDrainsSoAReadSeesTheWrittenBytes(@TempDir Path tmp) throws IOException {
        // The common case is unchanged: uploads complete in milliseconds, the barrier drains fully,
        // and the read sees the bytes — the bounded wait only ever bites on a pathological stall.
        Path spill = tmp.resolve("spill");
        InMemoryArtifactStore backend = new InMemoryArtifactStore();
        WriteBehindStore store = new WriteBehindStore(backend, 2, null, spill);
        try {
            write(store, KEY, BODY);
            try (InputStream in = store.read(KEY)) {
                assertArrayEquals(BODY, in.readAllBytes());
            }
        } finally {
            store.close(1_000);
        }
    }
}
