package com.jaranalyzer.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("PersistenceService — cache invalidation")
class PersistenceServiceCacheTest {

    @TempDir
    Path tmp;

    JarDataPaths paths;
    PersistenceService service;

    @BeforeEach
    void setUp() throws Exception {
        paths = new JarDataPaths(tmp.toString());
        service = new PersistenceService(paths);
        paths.ensureJarRoot("test.jar");
    }

    @Test
    @DisplayName("invalidateSummaryCache deletes the default class-tree cache")
    void invalidateDeletesDefaultClassTree() throws Exception {
        Path cache = paths.classTreeCache("test.jar");
        Files.writeString(cache, "{}", StandardCharsets.UTF_8);
        assertTrue(Files.exists(cache));

        service.invalidateSummaryCache("test.jar");

        assertFalse(Files.exists(cache), "default _class-tree.json must be deleted");
    }

    @Test
    @DisplayName("invalidateSummaryCache deletes version-specific class-tree caches")
    void invalidateDeletesVersionSpecificClassTree() throws Exception {
        Path defaultCache = paths.classTreeCache("test.jar", null);
        Path correctedCache = paths.classTreeCache("test.jar", "corrected");
        Files.writeString(defaultCache, "{}", StandardCharsets.UTF_8);
        Files.writeString(correctedCache, "{\"corrected\":true}", StandardCharsets.UTF_8);

        service.invalidateSummaryCache("test.jar");

        assertFalse(Files.exists(defaultCache), "default cache must be deleted");
        assertFalse(Files.exists(correctedCache), "corrected cache must be deleted");
    }

    @Test
    @DisplayName("invalidateSummaryCache deletes summary caches")
    void invalidateDeletesSummaryCaches() throws Exception {
        Files.writeString(paths.summaryCache("test.jar"), "[]", StandardCharsets.UTF_8);
        Files.writeString(paths.summaryCacheStatic("test.jar"), "[]", StandardCharsets.UTF_8);

        service.invalidateSummaryCache("test.jar");

        assertFalse(Files.exists(paths.summaryCache("test.jar")), "_summary.json must be deleted");
        assertFalse(Files.exists(paths.summaryCacheStatic("test.jar")), "_summary_static.json must be deleted");
    }

    @Test
    @DisplayName("invalidateSummaryCache is a no-op for a non-existent jar root")
    void invalidateNoopWhenJarRootAbsent() {
        // Should not throw even when the jar root doesn't exist
        assertDoesNotThrow(() -> service.invalidateSummaryCache("nonexistent.jar"));
    }

    @Test
    @DisplayName("invalidateSummaryCache also handles .tmp leftover")
    void invalidateDeletesTmpFile() throws Exception {
        Path tmp2 = paths.classTreeCache("test.jar").resolveSibling("_class-tree.json.tmp");
        Files.writeString(tmp2, "partial", StandardCharsets.UTF_8);

        service.invalidateSummaryCache("test.jar");

        assertFalse(Files.exists(tmp2), ".tmp file must be deleted");
    }
}
