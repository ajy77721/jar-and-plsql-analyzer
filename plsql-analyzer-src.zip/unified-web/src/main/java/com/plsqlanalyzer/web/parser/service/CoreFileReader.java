package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Core file reads: merged call graph, source lookup, node-file collection. */
class CoreFileReader {

    private final StaticAnalysisReader r;

    CoreFileReader(StaticAnalysisReader r) {
        this.r = r;
    }

    JsonNode getCallGraph(String name) throws IOException {
        ObjectMapper mapper = r.mapper;
        Path file = r.resolvePath(name, "api/call_graph.json");
        if (Files.isRegularFile(file)) return mapper.readTree(file.toFile());

        // Package analysis: merge call_graphs from all proc subfolders
        JsonNode index;
        try { index = r.getIndex(name); } catch (IOException e) { index = mapper.createObjectNode(); }
        if (!index.has("_packageAnalysis") || !index.get("_packageAnalysis").asBoolean()) throw new IOException("call_graph.json not found: " + file);

        ObjectNode merged = mapper.createObjectNode();
        ArrayNode allNodes = mapper.createArrayNode();
        ArrayNode allEdges = mapper.createArrayNode();
        Path parentDir = Path.of(r.getFlowOutputDir(), name);
        try (Stream<Path> dirs = Files.list(parentDir)) {
            dirs.filter(Files::isDirectory).forEach(sub -> {
                Path cg = sub.resolve("api/call_graph.json");
                if (!Files.isRegularFile(cg)) return;
                try {
                    JsonNode g = mapper.readTree(cg.toFile());
                    JsonNode n = g.get("nodes"); if (n != null && n.isArray()) n.forEach(allNodes::add);
                    JsonNode e = g.get("edges"); if (e != null && e.isArray()) e.forEach(allEdges::add);
                } catch (IOException ignored) {}
            });
        } catch (IOException ignored) {}
        merged.set("nodes", allNodes);
        merged.set("edges", allEdges);
        return merged;
    }

    String getSource(String name, String fileName) throws IOException {
        Path file = Path.of(r.getFlowOutputDir(), name, "sources", fileName);
        if (!Files.exists(file)) {
            Path dir = file.getParent();
            String base = fileName.contains(".") ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName;
            for (String ext : new String[]{".sql", ".prc", ".fnc", ".pkb", ".pks", ".trg"}) {
                Path alt = dir.resolve(base + ext);
                if (Files.exists(alt)) { file = alt; break; }
            }
        }
        if (!Files.exists(file)) {
            // Package analysis: source files live in proc subfolders
            Path parentDir = Path.of(r.getFlowOutputDir(), name);
            try (Stream<Path> dirs = Files.list(parentDir)) {
                for (Path sub : dirs.filter(Files::isDirectory).toList()) {
                    Path candidate = sub.resolve("sources/" + fileName);
                    if (Files.exists(candidate)) return Files.readString(candidate);
                    String base = fileName.contains(".") ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName;
                    for (String ext : new String[]{".sql", ".prc", ".fnc", ".pkb", ".pks", ".trg"}) {
                        Path alt = sub.resolve("sources/" + base + ext);
                        if (Files.exists(alt)) return Files.readString(alt);
                    }
                }
            } catch (IOException ignored) {}
        }
        return Files.readString(file);
    }

    List<Path> collectNodeFiles(String name) throws IOException {
        ObjectMapper mapper = r.mapper;
        List<Path> result = new ArrayList<>();
        Path nodesDir = Path.of(r.getFlowOutputDir(), name, "api/nodes");
        if (Files.isDirectory(nodesDir)) {
            try (Stream<Path> s = Files.list(nodesDir)) {
                s.filter(p -> p.toString().endsWith(".json")).forEach(result::add);
            }
        } else {
            // Package analysis: collect from subfolders
            JsonNode index;
            try { index = r.getIndex(name); } catch (IOException e) { index = mapper.createObjectNode(); }
            if (index.has("_packageAnalysis") && index.get("_packageAnalysis").asBoolean()) {
                Path parentDir = Path.of(r.getFlowOutputDir(), name);
                try (Stream<Path> dirs = Files.list(parentDir)) {
                    for (Path sub : dirs.filter(Files::isDirectory).toList()) {
                        Path subNodes = sub.resolve("api/nodes");
                        if (Files.isDirectory(subNodes)) {
                            try (Stream<Path> sf = Files.list(subNodes)) {
                                sf.filter(p -> p.toString().endsWith(".json")).forEach(result::add);
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
}
