package com.plsqlanalyzer.web.browse;

import com.plsqlanalyzer.web.service.DbSourceFetcher;
import com.plsqlanalyzer.web.util.DbDialectSupport;

/**
 * Resolves the {@link DbBrowseProvider} for a given dialect string
 * (as produced by {@link DbDialectSupport#dialectFromJdbcUrl}).
 *
 * <p>Returns {@code null} for dialects without a browse implementation, so the
 * controller falls back to the Phase-1 "not yet supported" response.</p>
 */
public final class DbBrowseProviderFactory {

    private DbBrowseProviderFactory() {
    }

    /**
     * @param dialect ORACLE / SQLSERVER / MYSQL / DB2 / UNKNOWN
     * @param fetcher existing Oracle fetcher (only used by the Oracle provider)
     * @return a provider, or {@code null} when the dialect is unsupported
     */
    public static DbBrowseProvider get(String dialect, DbSourceFetcher fetcher) {
        if (dialect == null) return null;
        switch (dialect) {
            case DbDialectSupport.ORACLE:
                return new OracleBrowseProvider(fetcher);
            case DbDialectSupport.SQLSERVER:
                return new SqlServerBrowseProvider();
            default:
                return null; // MySQL / DB2 / UNKNOWN -> Phase-1 unsupported fallback
        }
    }
}
