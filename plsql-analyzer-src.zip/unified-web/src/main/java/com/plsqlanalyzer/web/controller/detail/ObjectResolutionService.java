package com.plsqlanalyzer.web.controller.detail;

import com.plsqlanalyzer.analyzer.service.AnalysisService;
import com.plsqlanalyzer.config.DbUserConfig;
import com.plsqlanalyzer.config.EnvironmentConfig;
import com.plsqlanalyzer.config.PlsqlConfig;
import com.plsqlanalyzer.parser.service.OracleDictionaryService.ObjectRecord;
import com.plsqlanalyzer.web.service.DbSourceFetcher;
import com.plsqlanalyzer.web.util.DbDialectSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Object/schema resolution + non-Oracle guard helpers shared by the trigger services. */
@Service
public class ObjectResolutionService {

    private static final Logger log = LoggerFactory.getLogger(ObjectResolutionService.class);

    private final AnalysisService analysisService;
    private final PlsqlConfig config;
    private final DbSourceFetcher dbFetcher;

    public ObjectResolutionService(AnalysisService analysisService, PlsqlConfig config,
                                   DbSourceFetcher dbFetcher) {
        this.analysisService = analysisService;
        this.config = config;
        this.dbFetcher = dbFetcher;
    }

    /** Search for an object across all configured schemas, returning its schema and type. */
    public ResolvedObject findObjectInAllSchemas(String objectName) {
        for (DbUserConfig user : config.getDbUsers()) {
            try (Connection conn = dbFetcher.getConnection(user)) {
                ObjectRecord obj = analysisService.getDictionaryService()
                        .getObjectInfo(conn, user.getUsername(), objectName.toUpperCase());
                if (obj != null) {
                    log.info("Found {} in schema {} as {}", objectName, user.getUsername(), obj.objectType());
                    return new ResolvedObject(user.getUsername().toUpperCase(), obj.objectType());
                }
            } catch (Exception e) {
                log.debug("Error checking {} in {}: {}", objectName, user.getUsername(), e.getMessage());
            }
        }
        return null;
    }

    /**
     * Normalize object type — convert "PACKAGE BODY" to "PACKAGE" for analysis purposes,
     * since we always want to analyze the body for call tracing.
     */
    public String normalizeObjectType(String objectType) {
        if (objectType == null) return "PACKAGE";
        return switch (objectType.toUpperCase()) {
            case "PACKAGE BODY", "PACKAGE" -> "PACKAGE";
            case "PROCEDURE" -> "PROCEDURE";
            case "FUNCTION" -> "FUNCTION";
            case "TRIGGER" -> "TRIGGER";
            default -> "PACKAGE";
        };
    }

    public DbUserConfig findUser(String username) {
        return findUserIn(config.getDbUsers(), username);
    }

    public DbUserConfig findUserIn(List<DbUserConfig> users, String username) {
        return users.stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username))
                .findFirst()
                .orElse(null);
    }

    /**
     * Returns a graceful guard body when the effective connection is not Oracle, else null.
     */
    public Map<String, Object> nonOracleAnalyzeGuard(String projectName, String envName) {
        String url = null;
        if (projectName != null && !projectName.isBlank() && envName != null && !envName.isBlank()) {
            EnvironmentConfig env = config.resolveEnvironment(projectName, envName);
            if (env != null && env.getJdbcUrl() != null) url = env.getJdbcUrl();
        }
        if (url == null) url = dbFetcher.getJdbcUrl();
        if (DbDialectSupport.isOracle(url)) return null;

        String dialect = DbDialectSupport.dialectFromJdbcUrl(url);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", DbDialectSupport.unsupportedMessage("Static PL/SQL analysis", dialect)
                + ". Use crawler analysis instead.");
        body.put("unsupported", true);
        body.put("dialect", dialect);
        return body;
    }

    /** Holds a resolved schema + object type pair. */
    public static class ResolvedObject {
        public final String schema;
        public final String objectType;

        public ResolvedObject(String schema, String objectType) {
            this.schema = schema;
            this.objectType = objectType;
        }
    }
}
