package com.plsqlanalyzer.web.promptconfig;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.service.PromptTemplates;
import com.plsqlanalyzer.web.config.ConfigDirService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Editable prompt configuration — DATA-folder backed (instance store), two-tier.
 *
 * <p>On startup the built-in default prompts are DUMPED into {@code <data-dir>/prompts/}
 * (seeded only if missing) and {@link PromptTemplates} is pointed there, so the running
 * app reads/uses prompts from the data folder.
 *
 * <p>Two save tiers when editing a prompt:
 * <ul>
 *   <li><b>Permanent</b> — {@link #saveTemplate} writes {@code <data-dir>/prompts/<name>.txt};
 *       becomes the prompt for ALL future analyses.</li>
 *   <li><b>Per-analysis</b> — {@link #saveAnalysis} stores a template override + context +
 *       append in {@code <data-dir>/prompt-analysis/<analysisName>.json}. The analysis name
 *       is the scoped folder id which already encodes datasource/project/env/connection, so
 *       the config is bound to that exact analysis identity and used only for it.</li>
 * </ul>
 * Global extras (append/context applied to every prompt) live in
 * {@code <data-dir>/prompt-extras.json}.
 */
@Service
@DependsOn("configDirService") // ensure our data-dir wins over ConfigDirService's config-dir wiring
public class PromptConfigService {

    private static final Logger log = LoggerFactory.getLogger(PromptConfigService.class);

    public static final List<String> KNOWN_TEMPLATES = List.of(
            // Per-dialect DB (PL/SQL family) verification prompts — editable per database
            "plsql-oracle-verification", "plsql-mysql-verification",
            "plsql-sqlserver-verification", "plsql-db2-verification",
            // Java prompts
            "java-mongo-analysis", "java-oracle-analysis", "java-both-analysis",
            "java-mongo-chunk-analysis", "java-oracle-chunk-analysis", "java-both-chunk-analysis",
            "java-mongo-correction", "java-oracle-correction", "java-both-correction",
            // Legacy single PL/SQL template (used by the non-parser path)
            "plsql-verification"
    );

    private final ObjectMapper mapper = new ObjectMapper();
    private final Path dataDir;

    public PromptConfigService(ConfigDirService configDirService) {
        // Authoritative resolved data root (e.g. <cwd>/data). Do NOT use @Value app.data-dir —
        // it can resolve to a module subdir (data/jar) in this app's property setup.
        this.dataDir = configDirService.getDataDir().toAbsolutePath().normalize();
    }

    /** Dump default prompts into the data folder (if missing) and point PromptTemplates there. */
    @PostConstruct
    public void init() {
        try {
            Files.createDirectories(promptsDir());
            for (String name : KNOWN_TEMPLATES) {
                Path f = templateFile(name);
                if (!Files.exists(f)) {
                    String def = classpathDefault(name);
                    if (!def.isEmpty()) Files.writeString(f, def, StandardCharsets.UTF_8);
                }
            }
        } catch (IOException e) {
            log.warn("Prompt seed into {} failed: {}", promptsDir(), e.getMessage());
        }
        pointTemplatesToDataDir();
        log.info("PromptConfigService: prompts store = {} (seeded {} templates)", promptsDir(), KNOWN_TEMPLATES.size());
    }

    private void pointTemplatesToDataDir() {
        // PromptTemplates reads <externalConfigDir>/prompts/<name>.txt — point it at the data dir.
        PromptTemplates.setExternalConfigDir(dataDir);
    }

    // ==================== templates (permanent, shared store) ====================

    public boolean isKnownTemplate(String name) { return name != null && KNOWN_TEMPLATES.contains(name); }

    public List<Map<String, Object>> listTemplates() {
        pointTemplatesToDataDir();
        List<Map<String, Object>> out = new ArrayList<>();
        for (String name : KNOWN_TEMPLATES) {
            Path ext = templateFile(name);
            String defaultText = classpathDefault(name);
            boolean overridden = Files.exists(ext) && !readFileQuiet(ext).equals(defaultText);
            String current = Files.exists(ext) ? readFileQuiet(ext) : defaultText;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("current", current);
            m.put("defaultText", defaultText);
            m.put("overridden", overridden);
            out.add(m);
        }
        return out;
    }

    /** Permanent save — writes into the data-folder store, used by all future analyses. */
    public void saveTemplate(String name, String text) {
        requireKnown(name);
        try {
            Files.createDirectories(promptsDir());
            Files.writeString(templateFile(name), text == null ? "" : text, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to save template " + name, e);
        }
        pointTemplatesToDataDir(); // clears PromptTemplates cache
    }

    /** Reset a template back to the built-in default (re-seeds the data-folder file). */
    public void resetTemplate(String name) {
        requireKnown(name);
        try {
            String def = classpathDefault(name);
            Files.createDirectories(promptsDir());
            Files.writeString(templateFile(name), def, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to reset template " + name, e);
        }
        pointTemplatesToDataDir();
    }

    /** Effective template text: per-analysis override → data-folder store → classpath default. */
    public String effectiveTemplate(String name, String analysisName) {
        if (analysisName != null && !analysisName.isBlank()) {
            Map<String, String> tmpl = analysisTemplates(analysisName);
            String o = tmpl.get(name);
            if (o != null && !o.isEmpty()) return o;
        }
        Path ext = templateFile(name);
        if (Files.exists(ext)) return readFileQuiet(ext);
        return classpathDefault(name);
    }

    private Path promptsDir() { return dataDir.resolve("prompts"); }
    private Path templateFile(String name) { return promptsDir().resolve(name + ".txt"); }

    private String classpathDefault(String name) {
        try (InputStream is = PromptConfigService.class.getClassLoader().getResourceAsStream("prompts/" + name + ".txt")) {
            if (is == null) return "";
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.warn("Failed to read classpath default {}: {}", name, e.getMessage());
            return "";
        }
    }

    // ==================== global extras ====================

    public Map<String, String> getExtras() {
        Map<String, String> r = new LinkedHashMap<>();
        r.put("globalAppend", ""); r.put("globalContext", "");
        Path f = dataDir.resolve("prompt-extras.json");
        if (Files.exists(f)) {
            try {
                Map<?, ?> raw = mapper.readValue(Files.readAllBytes(f), Map.class);
                r.put("globalAppend", str(raw.get("globalAppend")));
                r.put("globalContext", str(raw.get("globalContext")));
            } catch (IOException e) { log.warn("read {}: {}", f, e.getMessage()); }
        }
        return r;
    }

    public Map<String, String> saveExtras(String globalAppend, String globalContext) {
        Map<String, String> d = new LinkedHashMap<>();
        d.put("globalAppend", nz(globalAppend)); d.put("globalContext", nz(globalContext));
        writeJson(dataDir.resolve("prompt-extras.json"), d);
        return d;
    }

    // ==================== per-analysis (scoped, non-permanent) ====================

    /** Per-analysis config: {context, append, templates:{name:text}} bound to the scoped analysis id. */
    public Map<String, Object> getAnalysis(String name) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("context", ""); r.put("append", ""); r.put("templates", new LinkedHashMap<String, String>());
        Path f = analysisFile(name);
        if (Files.exists(f)) {
            try {
                Map<?, ?> raw = mapper.readValue(Files.readAllBytes(f), Map.class);
                r.put("context", str(raw.get("context")));
                r.put("append", str(raw.get("append")));
                Object t = raw.get("templates");
                if (t instanceof Map<?, ?> tm) {
                    Map<String, String> mm = new LinkedHashMap<>();
                    tm.forEach((k, v) -> mm.put(String.valueOf(k), str(v)));
                    r.put("templates", mm);
                }
            } catch (IOException e) { log.warn("read {}: {}", f, e.getMessage()); }
        }
        return r;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> analysisTemplates(String name) {
        Object t = getAnalysis(name).get("templates");
        return t instanceof Map ? (Map<String, String>) t : new LinkedHashMap<>();
    }

    public Map<String, Object> saveAnalysis(String name, String context, String append, Map<String, String> templates) {
        Map<String, Object> d = new LinkedHashMap<>();
        d.put("context", nz(context));
        d.put("append", nz(append));
        Map<String, String> t = new LinkedHashMap<>();
        if (templates != null) templates.forEach((k, v) -> { if (isKnownTemplate(k)) t.put(k, nz(v)); });
        d.put("templates", t);
        writeJson(analysisFile(name), d);
        return d;
    }

    private Path analysisFile(String name) {
        return dataDir.resolve("prompt-analysis").resolve(safeName(name) + ".json");
    }

    static String safeName(String name) {
        if (name == null || name.isBlank()) return "_";
        String c = name.trim().replaceAll("[^A-Za-z0-9._-]", "_").replaceAll("^\\.+", "_");
        if (c.isBlank()) return "_";
        return c.length() > 200 ? c.substring(0, 200) : c;
    }

    // ==================== helpers ====================

    private void requireKnown(String name) {
        if (!isKnownTemplate(name)) throw new IllegalArgumentException("Unknown template name: " + name);
    }

    private void writeJson(Path file, Object data) {
        try {
            Files.createDirectories(file.getParent());
            mapper.writerWithDefaultPrettyPrinter().writeValue(file.toFile(), data);
        } catch (IOException e) { throw new UncheckedIOException("Failed to write " + file, e); }
    }

    private String readFileQuiet(Path file) {
        try { return Files.readString(file, StandardCharsets.UTF_8); }
        catch (IOException e) { log.warn("read {}: {}", file, e.getMessage()); return ""; }
    }

    private static String str(Object o) { return o == null ? "" : o.toString(); }
    private static String nz(String s) { return s == null ? "" : s; }
}
