package com.plsqlanalyzer.web.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Persists chunk fragments, the chunk index, and the resume checkpoint under the claude
 * data dir. Extracted from ClaudeVerificationService to keep files focused; logic unchanged.
 */
class ClaudeFragmentWriter {

    private static final Logger log = LoggerFactory.getLogger(ClaudeFragmentWriter.class);

    private final ObjectMapper mapper;

    ClaudeFragmentWriter(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    void saveFragment(Path dir, String filename, Object data) {
        try {
            if (data instanceof String str) {
                Files.writeString(dir.resolve(filename), str);
            } else {
                mapper.writeValue(dir.resolve(filename).toFile(), data);
            }
        } catch (IOException e) {
            log.error("Failed to save fragment {}: {}", filename, e.getMessage());
        }
    }

    void saveIndex(Path dir, List<VerificationChunk> chunks) {
        Map<String, Object> index = new LinkedHashMap<>();
        List<Map<String, Object>> chunkList = new ArrayList<>();
        for (VerificationChunk chunk : chunks) {
            Map<String, Object> cm = new LinkedHashMap<>();
            cm.put("id", chunk.id);
            cm.put("name", chunk.name);
            cm.put("procedures", chunk.procedureIds);
            cm.put("procedureCount", chunk.procedureIds.size());
            cm.put("tableCount", chunk.tables.size());
            chunkList.add(cm);
        }
        index.put("chunks", chunkList);
        index.put("timestamp", LocalDateTime.now().toString());
        saveFragment(dir, "_index.json", index);
    }

    void saveCheckpoint(Path dir, Set<String> completed) {
        saveFragment(dir, "_checkpoint.json", new ArrayList<>(completed));
    }
}
