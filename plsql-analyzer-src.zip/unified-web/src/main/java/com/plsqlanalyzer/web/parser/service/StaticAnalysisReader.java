package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Reads analysis data from the static flow-output directory.
 * This is the original parser output — immutable, written by ChunkedFlowWriter.
 */
@Component("parserStaticAnalysisReader")
public class StaticAnalysisReader implements AnalysisDataReader {

    private static final int MAX_CACHE_ENTRIES = 30;

    final ObjectMapper mapper = new ObjectMapper();
    final Map<String, JsonNode> synthesizedCache = Collections.synchronizedMap(
            new LinkedHashMap<>(32, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, JsonNode> eldest) {
                    return size() > MAX_CACHE_ENTRIES;
                }
            });

    private final String flowOutputDir;

    private final IndexFacetReader indexFacet;
    private final TableFacetReader tableFacet;
    private final NodeScanFacetReader nodeScanFacet;
    private final SequenceFacetReader sequenceFacet;
    private final CallTreeFacetReader callTreeFacet;
    private final CoreFileReader coreFile;

    public StaticAnalysisReader(@Value("${app.data-dir.base:data}") String dataDir) {
        this.flowOutputDir = Path.of(dataDir, "plsql-parse").toString();
        this.indexFacet = new IndexFacetReader(this);
        this.tableFacet = new TableFacetReader(this);
        this.nodeScanFacet = new NodeScanFacetReader(this);
        this.sequenceFacet = new SequenceFacetReader(this);
        this.callTreeFacet = new CallTreeFacetReader(this);
        this.coreFile = new CoreFileReader(this);
    }

    @Override
    public JsonNode getIndex(String name) throws IOException {
        return indexFacet.getIndex(name);
    }

    @Override
    public JsonNode getNodeDetail(String name, String fileName) throws IOException {
        return indexFacet.getNodeDetail(name, fileName);
    }

    @Override
    public JsonNode getProcedures(String name) throws IOException {
        return indexFacet.getProcedures(name);
    }

    @Override
    public JsonNode getTables(String name) throws IOException {
        return tableFacet.getTables(name);
    }

    @Override
    public JsonNode getCallGraph(String name) throws IOException {
        return coreFile.getCallGraph(name);
    }

    @Override
    public String getSource(String name, String fileName) throws IOException {
        return coreFile.getSource(name, fileName);
    }

    @Override
    public JsonNode getResolver(String name, String type) throws IOException {
        String fileName = switch (type) {
            case "q1" -> "q1_object_resolution.json";
            case "q3" -> "q3_reverse_dependencies.json";
            case "q4" -> "q4_direct_dependencies.json";
            case "ambiguous" -> "q1_ambiguous_objects.json";
            default -> throw new IllegalArgumentException("Unknown resolver type: " + type);
        };
        Path file = resolvePath(name, "resolver/" + fileName);
        return mapper.readTree(file.toFile());
    }

    List<Path> collectNodeFiles(String name) throws IOException {
        return coreFile.collectNodeFiles(name);
    }

    @Override
    public JsonNode getJoins(String name) throws IOException {
        return nodeScanFacet.getJoins(name);
    }

    @Override
    public JsonNode getCursors(String name) throws IOException {
        return nodeScanFacet.getCursors(name);
    }

    @Override
    public JsonNode getSequences(String name) throws IOException {
        return sequenceFacet.getSequences(name);
    }

    public JsonNode getDynamicSql(String name) throws IOException {
        return sequenceFacet.getDynamicSql(name);
    }

    String cacheKey(String name, String type) {
        return name + "::" + type;
    }

    public void evictCache(String analysisName) {
        synthesizedCache.remove(cacheKey(analysisName, "joins"));
        synthesizedCache.remove(cacheKey(analysisName, "cursors"));
        synthesizedCache.remove(cacheKey(analysisName, "sequences"));
        synthesizedCache.remove(cacheKey(analysisName, "tables"));
        synthesizedCache.remove(cacheKey(analysisName, "dynamicSql"));
    }

    /** Clear the entire synthesized cache (all analyses). Returns the number of entries dropped. */
    public int evictAll() {
        int n = synthesizedCache.size();
        synthesizedCache.clear();
        return n;
    }

    @Override
    public JsonNode getCallTree(String name, String nodeId) throws IOException {
        return callTreeFacet.getCallTree(name, nodeId);
    }

    /** Build the call tree using a supplied call graph (lets the Claude reader inject
     *  a corrected/overlaid graph so the tree reflects accepted call changes). */
    public JsonNode getCallTree(String name, String nodeId, JsonNode suppliedCallGraph) throws IOException {
        return callTreeFacet.getCallTree(name, nodeId, suppliedCallGraph);
    }

    @Override
    public JsonNode getCallers(String name, String nodeId) throws IOException {
        return callTreeFacet.getCallers(name, nodeId);
    }

    public JsonNode getCallers(String name, String nodeId, JsonNode suppliedCallGraph) throws IOException {
        return callTreeFacet.getCallers(name, nodeId, suppliedCallGraph);
    }

    // --- helpers (package-visible for reuse by Claude reader) ---

    Map<String, String> loadIdMap(String name) {
        try {
            Path file = resolvePath(name, "api/node_id_map.json");
            if (!Files.isRegularFile(file)) return Collections.emptyMap();
            JsonNode root = mapper.readTree(file.toFile());
            JsonNode stf = root.get("shortToFull");
            if (stf == null || !stf.isObject()) return Collections.emptyMap();
            Map<String, String> map = new HashMap<>();
            stf.fields().forEachRemaining(e -> map.put(e.getKey(), e.getValue().asText()));
            return map;
        } catch (IOException e) {
            return Collections.emptyMap();
        }
    }

    Path resolvePath(String name, String relative) {
        return Path.of(flowOutputDir, name, relative);
    }

    String getFlowOutputDir() {
        return flowOutputDir;
    }

    static String textOrDefault(JsonNode node, String field, String def) {
        JsonNode v = node.get(field);
        return (v != null && !v.isNull()) ? v.asText() : def;
    }

    static int intOrDefault(JsonNode node, String field, int def) {
        JsonNode v = node.get(field);
        return (v != null && v.isNumber()) ? v.asInt() : def;
    }

    static String textOrNull(JsonNode node, String field) {
        JsonNode v = node.get(field);
        return (v != null && !v.isNull()) ? v.asText() : null;
    }
}
