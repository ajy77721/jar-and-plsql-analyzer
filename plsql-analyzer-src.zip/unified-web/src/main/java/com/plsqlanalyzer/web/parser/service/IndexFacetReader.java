package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;

import static com.plsqlanalyzer.web.parser.service.StaticAnalysisReader.*;

/** Index-facet reads: getIndex + getProcedures + getNodeDetail (package-enrichment logic). */
class IndexFacetReader {

    private final StaticAnalysisReader r;

    IndexFacetReader(StaticAnalysisReader r) {
        this.r = r;
    }

    JsonNode getIndex(String name) throws IOException {
        ObjectMapper mapper = r.mapper;
        Path file = r.resolvePath(name, "api/index.json");
        JsonNode raw = mapper.readTree(file.toFile());
        // For package analyses, enrich nodes with detailFile, sourceFile, line info, counts
        if (raw.has("_packageAnalysis") && raw.get("_packageAnalysis").asBoolean()
                && raw.has("nodes") && raw.get("nodes").isArray()) {
            boolean needsEnrich = false;
            for (JsonNode n : raw.get("nodes")) {
                if (!n.has("detailFile") || !n.has("sourceFile") || !n.has("counts")) { needsEnrich = true; break; }
            }
            if (needsEnrich) {
                ObjectNode copy = raw.deepCopy();
                ArrayNode enriched = mapper.createArrayNode();
                for (JsonNode n : raw.get("nodes")) {
                    String subFolder = textOrNull(n, "subfolderName");
                    String detailFile = n.has("detailFile") ? n.get("detailFile").asText() : null;
                    String sourceFile = textOrNull(n, "sourceFile");
                    int lineStart = intOrDefault(n, "lineStart", 0);
                    int lineEnd = intOrDefault(n, "lineEnd", 0);
                    int depth = intOrDefault(n, "depth", 0);
                    JsonNode counts = n.get("counts");

                    if (subFolder != null && (detailFile == null || sourceFile == null || counts == null)) {
                        try {
                            JsonNode subIdx = mapper.readTree(r.resolvePath(name + "/" + subFolder, "api/index.json").toFile());
                            JsonNode subNodes = subIdx.get("nodes");
                            if (subNodes != null && subNodes.isArray()) {
                                for (JsonNode sn : subNodes) {
                                    int d = sn.has("depth") ? sn.get("depth").asInt() : -1;
                                    if (d == 0) {
                                        if (detailFile == null && sn.has("detailFile")) detailFile = sn.get("detailFile").asText();
                                        if (sourceFile == null) sourceFile = textOrNull(sn, "sourceFile");
                                        if (lineStart == 0) lineStart = intOrDefault(sn, "lineStart", 0);
                                        if (lineEnd == 0) lineEnd = intOrDefault(sn, "lineEnd", 0);
                                        if (counts == null) counts = sn.get("counts");
                                        break;
                                    }
                                }
                                if (detailFile == null && subNodes.size() > 0 && subNodes.get(0).has("detailFile")) {
                                    detailFile = subNodes.get(0).get("detailFile").asText();
                                }
                            }
                        } catch (IOException ignored) {}
                    }

                    ObjectNode nc = n.deepCopy();
                    if (detailFile != null) nc.put("detailFile", detailFile);
                    if (sourceFile != null) nc.put("sourceFile", sourceFile);
                    if (lineStart > 0) nc.put("lineStart", lineStart);
                    if (lineEnd > 0) nc.put("lineEnd", lineEnd);
                    nc.put("depth", depth);
                    if (counts != null) nc.set("counts", counts);
                    enriched.add(nc);
                }
                copy.set("nodes", enriched);
                return copy;
            }
        }
        return raw;
    }

    JsonNode getNodeDetail(String name, String fileName) throws IOException {
        ObjectMapper mapper = r.mapper;
        Path file = r.resolvePath(name, "api/nodes/" + fileName);
        if (Files.isRegularFile(file)) return mapper.readTree(file.toFile());

        // Package analysis: the node file lives in a proc subfolder
        JsonNode index;
        try { index = r.getIndex(name); } catch (IOException e) { index = mapper.createObjectNode(); }
        if (!index.has("_packageAnalysis") || !index.get("_packageAnalysis").asBoolean()) {
            throw new IOException("Node file not found: " + file);
        }

        Path parentDir = Path.of(r.getFlowOutputDir(), name);
        try (Stream<Path> dirs = Files.list(parentDir)) {
            for (Path sub : dirs.filter(Files::isDirectory).toList()) {
                Path candidate = sub.resolve("api/nodes/" + fileName);
                if (Files.isRegularFile(candidate)) return mapper.readTree(candidate.toFile());
            }
        } catch (IOException ignored) {}
        throw new IOException("Node file not found in any subfolder: " + fileName);
    }

    JsonNode getProcedures(String name) throws IOException {
        ObjectMapper mapper = r.mapper;
        JsonNode index = r.getIndex(name);
        JsonNode nodes = index.get("nodes");
        if (nodes == null || !nodes.isArray()) return mapper.createArrayNode();

        // For package analyses, inject detailFile into nodes that don't have it
        if (index.has("_packageAnalysis") && index.get("_packageAnalysis").asBoolean()) {
            ArrayNode enriched = mapper.createArrayNode();
            for (JsonNode n : nodes) {
                if (n.has("detailFile")) { enriched.add(n); continue; }
                // Look up the detailFile from the proc's own subfolder index
                String subFolder = textOrNull(n, "subfolderName");
                String detailFile = null;
                if (subFolder != null) {
                    try {
                        JsonNode subIdx = r.getIndex(name + "/" + subFolder);
                        JsonNode subNodes = subIdx.get("nodes");
                        if (subNodes != null && subNodes.isArray()) {
                            for (JsonNode sn : subNodes) {
                                int d = sn.has("depth") ? sn.get("depth").asInt() : -1;
                                if (d == 0 && sn.has("detailFile")) {
                                    detailFile = sn.get("detailFile").asText();
                                    break;
                                }
                            }
                            if (detailFile == null && subNodes.size() > 0 && subNodes.get(0).has("detailFile")) {
                                detailFile = subNodes.get(0).get("detailFile").asText();
                            }
                        }
                    } catch (IOException ignored) {}
                }
                if (detailFile != null) {
                    ObjectNode copy = n.deepCopy();
                    copy.put("detailFile", detailFile);
                    enriched.add(copy);
                } else {
                    enriched.add(n);
                }
            }
            return enriched;
        }

        return nodes;
    }
}
