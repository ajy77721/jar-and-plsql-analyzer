package com.plsqlanalyzer.web.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Read-only access to persisted chunk fragments/index files under the claude data dir.
 * Extracted from ClaudeVerificationService to keep files focused; logic unchanged.
 */
class ClaudeChunkReader {

    private static final Logger log = LoggerFactory.getLogger(ClaudeChunkReader.class);

    private final ObjectMapper mapper;
    private final Path dataBaseDir;

    ClaudeChunkReader(ObjectMapper mapper, Path dataBaseDir) {
        this.mapper = mapper;
        this.dataBaseDir = dataBaseDir;
    }

    private Path claudeDir(String analysisName) {
        return dataBaseDir.resolve(analysisName).resolve("claude");
    }

    Map<String, Object> getChunkFragment(String analysisName, String chunkId) {
        Path dir = claudeDir(analysisName);
        Map<String, Object> fragment = new LinkedHashMap<>();
        fragment.put("chunkId", chunkId);

        // Load input
        Path inputFile = dir.resolve(chunkId + "_input.json");
        if (Files.exists(inputFile)) {
            try {
                fragment.put("input", mapper.readValue(inputFile.toFile(), Object.class));
            } catch (IOException e) {
                fragment.put("input", "Error reading: " + e.getMessage());
            }
        }

        // Load output
        Path outputFile = dir.resolve(chunkId + "_output.json");
        if (Files.exists(outputFile)) {
            try {
                String raw = Files.readString(outputFile);
                // Try to parse as JSON first
                try {
                    fragment.put("output", mapper.readValue(raw, Object.class));
                } catch (Exception e) {
                    fragment.put("output", raw); // raw text
                }
            } catch (IOException e) {
                fragment.put("output", "Error reading: " + e.getMessage());
            }
        }

        // Load error if exists
        Path errorFile = dir.resolve(chunkId + "_error.txt");
        if (Files.exists(errorFile)) {
            try {
                fragment.put("error", Files.readString(errorFile));
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }

        return fragment;
    }

    Map<String, List<String>> getTableChunkMapping(String analysisName) {
        Path dir = claudeDir(analysisName);
        Map<String, List<String>> mapping = new LinkedHashMap<>();

        List<String> chunkIds = listChunks(analysisName);
        for (String chunkId : chunkIds) {
            Path outputFile = dir.resolve(chunkId + "_output.json");
            if (!Files.exists(outputFile)) continue;
            try {
                String raw = Files.readString(outputFile);
                // Try to parse as JSON to extract table names
                try {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> output = mapper.readValue(raw, LinkedHashMap.class);
                    Object tablesObj = output.get("tables");
                    if (tablesObj instanceof List<?> tablesList) {
                        for (Object item : tablesList) {
                            if (item instanceof Map<?, ?> tableMap) {
                                Object nameObj = tableMap.get("tableName");
                                if (nameObj != null) {
                                    String name = nameObj.toString().toUpperCase();
                                    mapping.computeIfAbsent(name, k -> new ArrayList<>()).add(chunkId);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    // Not JSON — scan raw text for table names (best effort)
                    // Look for patterns like "tableName": "XXX" in the raw text
                    java.util.regex.Pattern pat = java.util.regex.Pattern.compile("\"tableName\"\\s*:\\s*\"([^\"]+)\"");
                    java.util.regex.Matcher m = pat.matcher(raw);
                    while (m.find()) {
                        String name = m.group(1).toUpperCase();
                        mapping.computeIfAbsent(name, k -> new ArrayList<>()).add(chunkId);
                    }
                }
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }
        return mapping;
    }

    List<String> listChunks(String analysisName) {
        Path dir = claudeDir(analysisName);
        Path indexFile = dir.resolve("_index.json");
        if (!Files.exists(indexFile)) return Collections.emptyList();
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> index = mapper.readValue(indexFile.toFile(), LinkedHashMap.class);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> chunks = (List<Map<String, Object>>) index.get("chunks");
            if (chunks == null) return Collections.emptyList();
            return chunks.stream().map(c -> (String) c.get("id")).collect(Collectors.toList());
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    List<Map<String, Object>> listChunkSummaries(String analysisName) {
        Path dir = claudeDir(analysisName);
        Path indexFile = dir.resolve("_index.json");
        if (!Files.exists(indexFile)) return Collections.emptyList();
        try {
            Map<String, Object> index = mapper.readValue(indexFile.toFile(), LinkedHashMap.class);
            List<Map<String, Object>> chunks = (List<Map<String, Object>>) index.get("chunks");
            if (chunks == null) return Collections.emptyList();

            List<Map<String, Object>> result = new ArrayList<>();
            for (Map<String, Object> chunk : chunks) {
                String id = (String) chunk.get("id");
                Map<String, Object> summary = new LinkedHashMap<>();
                summary.put("id", id);
                summary.put("name", chunk.get("name"));
                summary.put("procedures", chunk.get("procedures"));
                summary.put("tableCount", chunk.get("tableCount"));

                Path outputFile = dir.resolve(id + "_output.json");
                Path errorFile = dir.resolve(id + "_error.txt");
                if (Files.exists(outputFile)) {
                    summary.put("status", "COMPLETE");
                } else if (Files.exists(errorFile)) {
                    summary.put("status", "ERROR");
                    try { summary.put("error", Files.readString(errorFile).trim()); } catch (IOException ignored) {}
                } else {
                    summary.put("status", "PENDING");
                }
                result.add(summary);
            }
            return result;
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }
}
