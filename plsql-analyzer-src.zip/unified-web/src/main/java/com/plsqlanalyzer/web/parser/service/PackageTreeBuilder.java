package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;

import static com.plsqlanalyzer.web.parser.service.StaticAnalysisReader.*;

/** Builds the package-level virtual call tree and resolves proc subfolder names. */
class PackageTreeBuilder {

    private final StaticAnalysisReader r;

    PackageTreeBuilder(StaticAnalysisReader r) {
        this.r = r;
    }

    /**
     * Build a virtual tree for a package: root = package, children = each proc subtree root.
     */
    JsonNode buildPackageVirtualTree(String name, JsonNode packageIndex) {
        ObjectMapper mapper = r.mapper;
        ObjectNode root = mapper.createObjectNode();
        String pkgName = textOrDefault(packageIndex, "entryPoint", name);
        String schema  = textOrDefault(packageIndex, "entrySchema", "");
        root.put("id",   pkgName.toUpperCase().replace(".", "_").replace("/", "_").replace("\\", "_"));
        root.put("name", pkgName);
        root.put("schemaName", schema);
        root.put("packageName", "");
        root.put("objectType", "PACKAGE");
        root.put("unitType", "PACKAGE");
        root.put("callType", "ROOT");
        root.put("callLineNumber", 0);
        root.put("startLine", 0); root.put("endLine", 0);
        root.put("readable", true);

        ArrayNode children = mapper.createArrayNode();
        JsonNode nodesArr = packageIndex.get("nodes");
        if (nodesArr != null && nodesArr.isArray()) {
            for (JsonNode procNode : nodesArr) {
                String subFolder = textOrNull(procNode, "subfolderName");
                String procId    = textOrNull(procNode, "nodeId");
                String procName  = textOrNull(procNode, "name");
                String procSchema = textOrDefault(procNode, "schema", schema);
                int loc = intOrDefault(procNode, "linesOfCode", 0);

                // Enrich from subfolder depth-0 node for sourceFile, lineStart, lineEnd, counts
                String srcFile = null;
                int lineStart = 0, lineEnd = 0;
                JsonNode childCounts = null;
                if (subFolder != null) {
                    try {
                        JsonNode subIdx = mapper.readTree(r.resolvePath(name + "/" + subFolder, "api/index.json").toFile());
                        JsonNode subNodes = subIdx.get("nodes");
                        if (subNodes != null && subNodes.isArray()) {
                            for (JsonNode sn : subNodes) {
                                int d = sn.has("depth") ? sn.get("depth").asInt() : -1;
                                if (d == 0) {
                                    srcFile = textOrNull(sn, "sourceFile");
                                    lineStart = intOrDefault(sn, "lineStart", 0);
                                    lineEnd = intOrDefault(sn, "lineEnd", 0);
                                    childCounts = sn.get("counts");
                                    if (procNode.has("linesOfCode") == false || intOrDefault(procNode, "linesOfCode", 0) == 0) {
                                        loc = intOrDefault(sn, "linesOfCode", 0);
                                    }
                                    break;
                                }
                            }
                        }
                    } catch (IOException ignored) {}
                }

                ObjectNode child = mapper.createObjectNode();
                child.put("id",   procId   != null ? procId   : (subFolder != null ? subFolder : ""));
                child.put("name", procName != null ? procName : (subFolder != null ? subFolder : ""));
                child.put("schemaName", procSchema);
                child.put("packageName", pkgName);
                child.put("objectType", textOrDefault(procNode, "objectType", "PROCEDURE"));
                child.put("unitType", "PROCEDURE");
                child.put("callType", "INTERNAL");
                child.put("callLineNumber", 0);
                child.put("startLine", lineStart);
                child.put("endLine", lineEnd);
                child.put("sourceFile", srcFile != null ? srcFile : "");
                child.put("linesOfCode", loc);
                child.put("readable", true);
                child.put("_subfolderName", subFolder != null ? subFolder : "");
                if (childCounts != null) child.set("counts", childCounts);
                child.set("children", mapper.createArrayNode());
                children.add(child);
            }
        }
        root.set("children", children);
        return root;
    }

    String resolveSubfolderName(String name, String nodeId) {
        ObjectMapper mapper = r.mapper;
        if (nodeId == null) return null;
        // Fast path: subfolder name matches nodeId directly
        Path direct = Path.of(r.getFlowOutputDir(), name, nodeId);
        if (Files.isDirectory(direct)) return nodeId;
        // Scan subdirs and match by converting their entryPoint to a safe node id
        Path parentDir = Path.of(r.getFlowOutputDir(), name);
        try (Stream<Path> dirs = Files.list(parentDir)) {
            return dirs.filter(Files::isDirectory)
                    .filter(d -> {
                        Path idx = d.resolve("api/index.json");
                        if (!Files.isRegularFile(idx)) return false;
                        try {
                            JsonNode i = mapper.readTree(idx.toFile());
                            String ep = textOrNull(i, "entryPoint");
                            if (ep == null) return false;
                            String computedId = ep.toUpperCase()
                                    .replace(".", "_").replace("/", "_").replace("\\", "_");
                            return computedId.equals(nodeId.toUpperCase());
                        } catch (IOException e) { return false; }
                    })
                    .findFirst()
                    .map(d -> d.getFileName().toString())
                    .orElse(null);
        } catch (IOException e) {
            return null;
        }
    }
}
