package com.plsqlanalyzer.web.controller;

import com.plsqlanalyzer.analyzer.model.CursorOperationSummary;
import com.plsqlanalyzer.analyzer.model.JoinOperationSummary;
import com.plsqlanalyzer.analyzer.model.SequenceOperationSummary;
import com.plsqlanalyzer.analyzer.model.TableOperationSummary;
import com.plsqlanalyzer.web.controller.detail.AnalysisTriggerService;
import com.plsqlanalyzer.web.controller.detail.CallGraphQueryService;
import com.plsqlanalyzer.web.controller.detail.FastAnalysisTriggerService;
import com.plsqlanalyzer.web.controller.detail.HistoryQueryService;
import com.plsqlanalyzer.web.controller.detail.JobQueryService;
import com.plsqlanalyzer.web.controller.detail.MiscQueryService;
import com.plsqlanalyzer.web.controller.detail.ProcedureDetailService;
import com.plsqlanalyzer.web.controller.detail.TableMetadataService;
import com.plsqlanalyzer.web.controller.detail.TableQueryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Thin REST controller for PL/SQL analysis. All endpoint logic lives in the
 * collaborating @Service classes under {@code web.controller.detail}; each method
 * here is a pure delegation to preserve routes, signatures and response shapes.
 */
@RestController("plsqlAnalyzerController")
@RequestMapping("/api/plsql/analysis")
public class AnalyzerController {

    private final AnalysisTriggerService analysisTriggerService;
    private final FastAnalysisTriggerService fastAnalysisTriggerService;
    private final HistoryQueryService historyQueryService;
    private final CallGraphQueryService callGraphQueryService;
    private final ProcedureDetailService procedureDetailService;
    private final TableQueryService tableQueryService;
    private final TableMetadataService tableMetadataService;
    private final MiscQueryService miscQueryService;
    private final JobQueryService jobQueryService;

    public AnalyzerController(AnalysisTriggerService analysisTriggerService,
                             FastAnalysisTriggerService fastAnalysisTriggerService,
                             HistoryQueryService historyQueryService,
                             CallGraphQueryService callGraphQueryService,
                             ProcedureDetailService procedureDetailService,
                             TableQueryService tableQueryService,
                             TableMetadataService tableMetadataService,
                             MiscQueryService miscQueryService,
                             JobQueryService jobQueryService) {
        this.analysisTriggerService = analysisTriggerService;
        this.fastAnalysisTriggerService = fastAnalysisTriggerService;
        this.historyQueryService = historyQueryService;
        this.callGraphQueryService = callGraphQueryService;
        this.procedureDetailService = procedureDetailService;
        this.tableQueryService = tableQueryService;
        this.tableMetadataService = tableMetadataService;
        this.miscQueryService = miscQueryService;
        this.jobQueryService = jobQueryService;
    }

    @PostMapping("/analyze")
    public ResponseEntity<Map<String, Object>> triggerAnalysis(@RequestBody Map<String, String> body) {
        return analysisTriggerService.triggerAnalysis(body);
    }

    @PostMapping("/analyze-fast")
    public ResponseEntity<Map<String, Object>> triggerFastAnalysis(@RequestBody Map<String, String> body) {
        return fastAnalysisTriggerService.triggerFastAnalysis(body);
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> getLatestResult() {
        return historyQueryService.getLatestResult();
    }

    @GetMapping("/history")
    public ResponseEntity<List<Map<String, Object>>> listHistory() {
        return historyQueryService.listHistory();
    }

    @GetMapping("/history/{name}")
    public ResponseEntity<Map<String, Object>> loadAnalysis(@PathVariable String name) {
        return historyQueryService.loadAnalysis(name);
    }

    @DeleteMapping("/history/{name}")
    public ResponseEntity<Map<String, Object>> deleteAnalysis(@PathVariable String name) {
        return historyQueryService.deleteAnalysis(name);
    }

    @GetMapping("/history/{name}/connections")
    public ResponseEntity<Map<String, Object>> getAnalysisConnections(@PathVariable String name) {
        return historyQueryService.getAnalysisConnections(name);
    }

    @GetMapping("/versions")
    public ResponseEntity<List<Map<String, Object>>> listVersions() {
        return historyQueryService.listVersions();
    }

    @GetMapping("/call-graph")
    public ResponseEntity<Object> getFullCallGraph() {
        return callGraphQueryService.getFullCallGraph();
    }

    @GetMapping("/detail/{procName:.+}")
    public ResponseEntity<Map<String, Object>> getProcedureDetail(@PathVariable String procName) {
        return procedureDetailService.getProcedureDetail(procName);
    }

    @GetMapping("/call-tree/{procName:.+}")
    public ResponseEntity<Map<String, Object>> getCallTree(@PathVariable String procName) {
        return callGraphQueryService.getCallTree(procName);
    }

    @GetMapping("/call-tree/{procName:.+}/callers")
    public ResponseEntity<Map<String, Object>> getCallerTree(@PathVariable String procName) {
        return callGraphQueryService.getCallerTree(procName);
    }

    @GetMapping("/tables")
    public ResponseEntity<Collection<TableOperationSummary>> getTableOperations() {
        return tableQueryService.getTableOperations();
    }

    @GetMapping("/tables/{tableName}")
    public ResponseEntity<TableOperationSummary> getTableDetail(@PathVariable String tableName) {
        return tableQueryService.getTableDetail(tableName);
    }

    @GetMapping("/tables/{tableName}/metadata")
    public ResponseEntity<Map<String, Object>> getTableMetadata(@PathVariable String tableName) {
        return tableMetadataService.getTableMetadata(tableName);
    }

    @GetMapping("/tables/{tableName}/triggers")
    public ResponseEntity<List<Map<String, Object>>> getTableTriggers(@PathVariable String tableName) {
        return tableMetadataService.getTableTriggers(tableName);
    }

    @GetMapping("/sequences")
    public ResponseEntity<Collection<SequenceOperationSummary>> getSequenceOperations() {
        return tableQueryService.getSequenceOperations();
    }

    @GetMapping("/joins")
    public ResponseEntity<Collection<JoinOperationSummary>> getJoinOperations() {
        return tableQueryService.getJoinOperations();
    }

    @GetMapping("/cursors")
    public ResponseEntity<Collection<CursorOperationSummary>> getCursorOperations() {
        return tableQueryService.getCursorOperations();
    }

    @GetMapping("/errors")
    public ResponseEntity<List<Map<String, Object>>> getParseErrors() {
        return miscQueryService.getParseErrors();
    }

    @GetMapping("/procedures")
    public ResponseEntity<List<Map<String, Object>>> listProcedures() {
        return callGraphQueryService.listProcedures();
    }

    @GetMapping("/source/{owner}/{objectName:.+}")
    public ResponseEntity<Map<String, Object>> getSource(
            @PathVariable String owner, @PathVariable String objectName) {
        return miscQueryService.getSource(owner, objectName);
    }

    @GetMapping("/references/{objectName:.+}")
    public ResponseEntity<List<Map<String, String>>> getReferences(
            @PathVariable String objectName,
            @RequestParam(required = false) String owner) {
        return miscQueryService.getReferences(objectName, owner);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Map<String, Object>>> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "all") String type) {
        return miscQueryService.search(q, type);
    }

    @GetMapping("/jobs")
    public ResponseEntity<List<Map<String, Object>>> listJobs() {
        return jobQueryService.listJobs();
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<Map<String, Object>> getJob(@PathVariable String jobId) {
        return jobQueryService.getJob(jobId);
    }

    @PostMapping("/jobs/{jobId}/cancel")
    public ResponseEntity<Map<String, Object>> cancelJob(@PathVariable String jobId) {
        return jobQueryService.cancelJob(jobId);
    }
}
