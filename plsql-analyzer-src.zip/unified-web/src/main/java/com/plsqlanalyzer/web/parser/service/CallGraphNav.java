package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.*;

import static com.plsqlanalyzer.web.parser.service.StaticAnalysisReader.*;

/** Call-graph traversal + node-id resolution helpers. */
class CallGraphNav {

    private final ObjectMapper mapper;

    CallGraphNav(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    /** Schema portion of a "SCHEMA$NAME" node id, or "" if none. */
    static String schemaFromNodeId(String nodeId) {
        if (nodeId == null) return "";
        int idx = nodeId.indexOf('$');
        return idx > 0 ? nodeId.substring(0, idx) : "";
    }

    String resolveToFullId(String id, Map<String, String> shortToFull, Set<String> knownFullIds) {
        if (id == null) return null;
        if (knownFullIds.contains(id)) return id;
        String mapped = shortToFull.get(id);
        if (mapped != null && knownFullIds.contains(mapped)) return mapped;
        for (String fullId : knownFullIds) {
            if (fullId.startsWith(id + "_") || fullId.startsWith(id + "$")) return fullId;
        }
        return id;
    }

    ObjectNode buildCallTreeNode(
            String nodeId,
            Map<String, JsonNode> nodeMetadata,
            Map<String, List<JsonNode>> adjacency,
            Map<String, String> shortToFull,
            Set<String> visited,
            JsonNode incomingEdge,
            int depth) {

        ObjectNode treeNode = mapper.createObjectNode();
        String effectiveId = resolveToFullId(nodeId, shortToFull, nodeMetadata.keySet());
        JsonNode meta = nodeMetadata.get(effectiveId);

        treeNode.put("id", effectiveId);
        treeNode.put("name", meta != null ? textOrDefault(meta, "name", nodeId) : nodeId);
        treeNode.put("schemaName", meta != null ? textOrDefault(meta, "schema", "") : "");
        treeNode.put("packageName", meta != null ? textOrDefault(meta, "packageName", "") : "");
        treeNode.put("objectType", meta != null ? textOrDefault(meta, "objectType", "") : "");
        treeNode.put("unitType", meta != null ? textOrDefault(meta, "objectType", "PROCEDURE") : "PROCEDURE");
        treeNode.put("startLine", meta != null ? intOrDefault(meta, "lineStart", 0) : 0);
        treeNode.put("endLine", meta != null ? intOrDefault(meta, "lineEnd", 0) : 0);
        treeNode.put("sourceFile", meta != null ? textOrDefault(meta, "sourceFile", "") : "");
        boolean readable = meta == null || !meta.has("readable") || meta.get("readable").asBoolean(true);
        treeNode.put("readable", readable);

        if (incomingEdge != null) {
            // Prefer schemas on the edge; fall back to node metadata / nodeId prefix
            // (SCHEMA$NAME). Non-Oracle dialects (no packages) often omit edge schemas,
            // which previously made every call default to EXTERNAL.
            String fromSchema = textOrNull(incomingEdge, "fromSchema");
            if (fromSchema == null || fromSchema.isBlank()) {
                fromSchema = schemaFromNodeId(textOrNull(incomingEdge, "fromNodeId"));
            }
            String toSchema = textOrNull(incomingEdge, "toSchema");
            if (toSchema == null || toSchema.isBlank()) {
                toSchema = meta != null ? textOrDefault(meta, "schema", "") : "";
            }
            if (toSchema == null || toSchema.isBlank()) {
                toSchema = schemaFromNodeId(effectiveId);
            }
            boolean sameSchema = fromSchema != null && !fromSchema.isBlank()
                    && fromSchema.equalsIgnoreCase(toSchema);
            String callType = sameSchema ? "INTERNAL" : "EXTERNAL";
            treeNode.put("callType", callType);
            JsonNode lines = incomingEdge.get("lines");
            if (lines != null && lines.isArray() && !lines.isEmpty()) {
                treeNode.put("callLineNumber", lines.get(0).asInt());
            } else {
                treeNode.put("callLineNumber", 0);
            }
        } else {
            treeNode.put("callType", "ROOT");
            treeNode.put("callLineNumber", 0);
        }

        if (visited.contains(effectiveId)) {
            treeNode.put("circular", true);
            treeNode.set("children", mapper.createArrayNode());
            return treeNode;
        }

        visited.add(effectiveId);

        ArrayNode children = mapper.createArrayNode();
        List<JsonNode> outEdges = adjacency.get(effectiveId);
        if (outEdges != null) {
            for (JsonNode edge : outEdges) {
                String toId = textOrNull(edge, "toNodeId");
                if (toId != null) {
                    String fullToId = resolveToFullId(toId, shortToFull, nodeMetadata.keySet());
                    ObjectNode child = buildCallTreeNode(fullToId, nodeMetadata, adjacency, shortToFull, visited, edge, depth + 1);
                    children.add(child);
                }
            }
        }

        treeNode.set("children", children);
        visited.remove(effectiveId);
        return treeNode;
    }
}
