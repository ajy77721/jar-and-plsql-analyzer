package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Persistent per-analysis Claude call log for the PL/SQL parser — the parser
 * analogue of jar-analyzer's ClaudeCallLogger. One JSONL line per Claude CLI
 * call is appended to data/plsql/{analysisName}/claude/_call_log.jsonl.
 * Survives restarts, supports per-analysis and global aggregation. Never throws.
 */
@Component("parserClaudeCallLogger")
public class ClaudeCallLogger {

    private static final Logger log = LoggerFactory.getLogger(ClaudeCallLogger.class);
    private static final String CALL_LOG_FILE = "_call_log.jsonl";

    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${plsql.data-dir:data/plsql}")
    private String dataBaseDir;

    /** Append one Claude call record. Thread-safe, best-effort (errors swallowed). */
    public void logCall(String analysisName, String sessionId, String sessionType,
                        String endpoint, int chunkIndex,
                        long promptBytes, long responseBytes,
                        long durationMs, boolean success, String error) {
        try {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("ts", LocalDateTime.now().toString());
            e.put("sessionId", sessionId);
            e.put("sessionType", sessionType);
            e.put("endpoint", endpoint);
            e.put("chunkIndex", chunkIndex);
            e.put("promptBytes", promptBytes);
            e.put("responseBytes", responseBytes);
            e.put("durationMs", durationMs);
            e.put("success", success);
            e.put("error", error);
            String line = mapper.writeValueAsString(e) + "\n";
            Path logFile = logFilePath(analysisName);
            synchronized (this) {
                Files.createDirectories(logFile.getParent());
                try (FileWriter fw = new FileWriter(logFile.toFile(), StandardCharsets.UTF_8, true)) {
                    fw.write(line);
                }
            }
        } catch (Exception ex) {
            log.debug("Failed to log Claude call for {}: {}", analysisName, ex.getMessage());
        }
    }

    /** Aggregated stats (totals + per-session breakdown) for one analysis. */
    public Map<String, Object> getStats(String analysisName) {
        return aggregate(readAllEntries(analysisName));
    }

    /** All call records for one session within an analysis. */
    public List<Map<String, Object>> getSessionDetail(String analysisName, String sessionId) {
        return readAllEntries(analysisName).stream()
                .filter(e -> sessionId.equals(String.valueOf(e.getOrDefault("sessionId", ""))))
                .collect(Collectors.toList());
    }

    /** Aggregated stats across every analysis (survives restarts). */
    public Map<String, Object> getGlobalStats() {
        List<Map<String, Object>> all = new ArrayList<>();
        Path root = Paths.get(dataBaseDir);
        if (Files.isDirectory(root)) {
            try (Stream<Path> dirs = Files.list(root)) {
                for (Path dir : (Iterable<Path>) dirs::iterator) {
                    if (Files.isDirectory(dir)) all.addAll(readAllEntries(dir.getFileName().toString()));
                }
            } catch (Exception e) {
                log.debug("Failed to scan call logs: {}", e.getMessage());
            }
        }
        return aggregate(all);
    }

    private Map<String, Object> aggregate(List<Map<String, Object>> entries) {
        Map<String, Object> stats = new LinkedHashMap<>();
        long totalDuration = 0, totalPrompt = 0, totalResponse = 0;
        int errors = 0;
        Map<String, List<Map<String, Object>>> bySession = new LinkedHashMap<>();
        for (Map<String, Object> e : entries) {
            totalDuration += toLong(e.get("durationMs"));
            totalPrompt += toLong(e.get("promptBytes"));
            totalResponse += toLong(e.get("responseBytes"));
            if (!Boolean.TRUE.equals(e.get("success"))) errors++;
            bySession.computeIfAbsent(String.valueOf(e.getOrDefault("sessionId", "unknown")),
                    k -> new ArrayList<>()).add(e);
        }
        int n = entries.size();
        stats.put("totalCalls", n);
        stats.put("totalDurationMs", totalDuration);
        stats.put("avgDurationMs", n > 0 ? totalDuration / n : 0L);
        stats.put("totalPromptBytes", totalPrompt);
        stats.put("totalResponseBytes", totalResponse);
        stats.put("totalPromptMb", round2(totalPrompt / 1048576.0));
        stats.put("totalResponseMb", round2(totalResponse / 1048576.0));
        stats.put("sessionCount", bySession.size());
        stats.put("errors", errors);

        List<Map<String, Object>> sessions = new ArrayList<>();
        for (var g : bySession.entrySet()) {
            List<Map<String, Object>> calls = g.getValue();
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("sessionId", g.getKey());
            s.put("sessionType", calls.get(0).getOrDefault("sessionType", ""));
            s.put("callCount", calls.size());
            s.put("durationMs", calls.stream().mapToLong(c -> toLong(c.get("durationMs"))).sum());
            s.put("promptBytes", calls.stream().mapToLong(c -> toLong(c.get("promptBytes"))).sum());
            s.put("responseBytes", calls.stream().mapToLong(c -> toLong(c.get("responseBytes"))).sum());
            s.put("errorCount", calls.stream().filter(c -> !Boolean.TRUE.equals(c.get("success"))).count());
            s.put("startedAt", calls.get(0).getOrDefault("ts", ""));
            s.put("endedAt", calls.get(calls.size() - 1).getOrDefault("ts", ""));
            sessions.add(s);
        }
        stats.put("sessions", sessions);
        return stats;
    }

    private Path logFilePath(String analysisName) {
        return Paths.get(dataBaseDir).resolve(analysisName).resolve("claude").resolve(CALL_LOG_FILE);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> readAllEntries(String analysisName) {
        Path logFile = logFilePath(analysisName);
        if (!Files.isRegularFile(logFile)) return List.of();
        List<Map<String, Object>> entries = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(logFile, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try { entries.add(mapper.readValue(line, Map.class)); }
                catch (Exception ignore) { /* skip malformed line */ }
            }
        } catch (Exception e) {
            log.debug("Failed to read call log for {}: {}", analysisName, e.getMessage());
        }
        return entries;
    }

    private static long toLong(Object v) {
        if (v instanceof Number n) return n.longValue();
        try { return Long.parseLong(String.valueOf(v)); } catch (Exception e) { return 0L; }
    }

    private static double round2(double v) { return Math.round(v * 100.0) / 100.0; }
}
