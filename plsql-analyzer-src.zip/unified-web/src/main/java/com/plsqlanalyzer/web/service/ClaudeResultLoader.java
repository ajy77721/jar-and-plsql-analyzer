package com.plsqlanalyzer.web.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.plsqlanalyzer.analyzer.model.AnalysisResult;
import com.plsqlanalyzer.web.service.ClaudeVerificationService.VerificationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Loads persisted verification results (final + partial) and progress from disk.
 * Extracted from ClaudeVerificationService to keep files focused; logic unchanged.
 */
class ClaudeResultLoader {

    private static final Logger log = LoggerFactory.getLogger(ClaudeResultLoader.class);

    private final ObjectMapper mapper;
    private final Path dataBaseDir;
    private final ClaudeResponseParser parser;
    private final ClaudeResultMerger merger;

    ClaudeResultLoader(ObjectMapper mapper, Path dataBaseDir,
                       ClaudeResponseParser parser, ClaudeResultMerger merger) {
        this.mapper = mapper;
        this.dataBaseDir = dataBaseDir;
        this.parser = parser;
        this.merger = merger;
    }

    private Path claudeDir(String analysisName) {
        return dataBaseDir.resolve(analysisName).resolve("claude");
    }

    VerificationResult loadResult(String analysisName) {
        Path resultFile = claudeDir(analysisName).resolve("_result.json");
        if (!Files.exists(resultFile)) return null;
        try {
            return mapper.readValue(resultFile.toFile(), VerificationResult.class);
        } catch (IOException e) {
            log.error("Failed to load verification result for '{}': {}", analysisName, e.getMessage());
            return null;
        }
    }

    boolean hasVerificationData(String analysisName) {
        Path dir = claudeDir(analysisName);
        if (Files.exists(dir.resolve("_result.json"))) return true;
        // Also check for partial chunk outputs
        if (Files.exists(dir)) {
            try (var stream = Files.list(dir)) {
                return stream.anyMatch(p -> p.getFileName().toString().endsWith("_output.json")
                        && !p.getFileName().toString().startsWith("_"));
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }
        return false;
    }

    VerificationResult loadPartialResult(String analysisName, AnalysisResult staticResult) {
        Path dir = claudeDir(analysisName);
        if (!Files.exists(dir)) return null;

        // First try the final result
        VerificationResult finalResult = loadResult(analysisName);
        if (finalResult != null) return finalResult;

        // No final result — build from completed chunk outputs
        Set<String> completedChunks = loadCheckpoint(dir);
        if (completedChunks.isEmpty()) return null;

        List<ChunkResult> chunkResults = new ArrayList<>();
        for (String chunkId : completedChunks) {
            ChunkResult cr = parser.loadChunkResult(dir, chunkId);
            if (cr != null) chunkResults.add(cr);
        }

        if (chunkResults.isEmpty()) return null;

        // Get total chunk count from index
        int totalChunks = 0;
        Path indexFile = dir.resolve("_index.json");
        if (Files.exists(indexFile)) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> index = mapper.readValue(indexFile.toFile(), LinkedHashMap.class);
                Object chunks = index.get("chunks");
                if (chunks instanceof List<?> list) totalChunks = list.size();
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }

        // Merge partial results
        VerificationResult partial = merger.mergeResults(staticResult, chunkResults);
        partial.totalChunks = totalChunks > 0 ? totalChunks : chunkResults.size();
        partial.error = "Partial result (" + chunkResults.size() + "/" + partial.totalChunks + " chunks completed)";
        log.info("Built partial verification result: {} chunks completed out of {}", chunkResults.size(), partial.totalChunks);
        return partial;
    }

    Map<String, Object> getProgress(String analysisName) {
        Path dir = claudeDir(analysisName);
        Map<String, Object> progress = new LinkedHashMap<>();

        Path checkpointFile = dir.resolve("_checkpoint.json");
        Path indexFile = dir.resolve("_index.json");

        int completed = 0, total = 0, errorChunks = 0;
        if (Files.exists(checkpointFile)) {
            completed = loadCheckpoint(dir).size();
        }
        if (Files.exists(indexFile)) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> index = mapper.readValue(indexFile.toFile(), LinkedHashMap.class);
                Object chunks = index.get("chunks");
                if (chunks instanceof List<?> list) total = list.size();
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }

        // Count error files for error reporting
        if (Files.exists(dir)) {
            try (var stream = Files.list(dir)) {
                errorChunks = (int) stream
                        .filter(p -> p.getFileName().toString().endsWith("_error.txt"))
                        .count();
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }

        // Also count output files directly as a fallback for completed count
        // (checkpoint may not be updated yet if writing is delayed)
        if (completed == 0 && Files.exists(dir)) {
            try (var stream = Files.list(dir)) {
                int outputCount = (int) stream
                        .filter(p -> p.getFileName().toString().endsWith("_output.json"))
                        .count();
                if (outputCount > completed) completed = outputCount;
            } catch (IOException e) { log.debug("IO operation failed: {}", e.getMessage()); }
        }

        progress.put("completedChunks", completed);
        progress.put("totalChunks", total);
        progress.put("errorChunks", errorChunks);
        progress.put("percentComplete", total > 0 ? (int) ((completed * 100.0) / total) : 0);
        progress.put("hasResult", Files.exists(dir.resolve("_result.json")));
        progress.put("hasPartialResult", completed > 0);
        progress.put("isComplete", completed >= total && total > 0);
        return progress;
    }

    Set<String> loadCheckpoint(Path dir) {
        Path cpFile = dir.resolve("_checkpoint.json");
        if (!Files.exists(cpFile)) return new HashSet<>();
        try {
            @SuppressWarnings("unchecked")
            List<String> completed = mapper.readValue(cpFile.toFile(), List.class);
            return new HashSet<>(completed);
        } catch (IOException e) {
            return new HashSet<>();
        }
    }
}
