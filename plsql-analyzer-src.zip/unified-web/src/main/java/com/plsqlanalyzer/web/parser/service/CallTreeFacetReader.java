package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.util.*;

import static com.plsqlanalyzer.web.parser.service.StaticAnalysisReader.*;

/** Call-tree + callers facet reads. */
class CallTreeFacetReader {

    private final StaticAnalysisReader r;
    private final CallGraphNav nav;
    private final PackageTreeBuilder pkgBuilder;

    CallTreeFacetReader(StaticAnalysisReader r) {
        this.r = r;
        this.nav = new CallGraphNav(r.mapper);
        this.pkgBuilder = new PackageTreeBuilder(r);
    }

    JsonNode getCallTree(String name, String nodeId) throws IOException {
        return getCallTree(name, nodeId, r.getCallGraph(name));
    }

    /** Build the call tree using a supplied call graph (lets the Claude reader inject
     *  a corrected/overlaid graph so the tree reflects accepted call changes). */
    JsonNode getCallTree(String name, String nodeId, JsonNode suppliedCallGraph) throws IOException {
        ObjectMapper mapper = r.mapper;
        JsonNode index;
        try { index = r.getIndex(name); } catch (IOException e) { index = mapper.createObjectNode(); }

        boolean isPackage = index.has("_packageAnalysis") && index.get("_packageAnalysis").asBoolean();

        if (isPackage) {
            // Case 1: caller wants the package-level virtual root tree (nodeId == package name)
            String pkgName = textOrDefault(index, "entryPoint", name).toUpperCase();
            String callerUpper = nodeId.toUpperCase().replace(".", "_").replace("/", "_").replace("\\", "_");
            if (callerUpper.equals(pkgName.replace(".", "_"))) {
                return pkgBuilder.buildPackageVirtualTree(name, index);
            }

            // Case 2: caller wants a specific proc subtree — find its subfolder
            String subName = pkgBuilder.resolveSubfolderName(name, nodeId);
            if (subName != null) {
                return getCallTreeFromSubfolder(name + "/" + subName);
            }
            // Fallback: return empty root
            ObjectNode root = mapper.createObjectNode();
            root.put("id", nodeId); root.put("name", nodeId);
            root.put("callType", "ROOT"); root.put("callLineNumber", 0);
            root.set("children", mapper.createArrayNode());
            return root;
        }

        // Normal (non-package) analysis
        JsonNode callGraph = suppliedCallGraph != null ? suppliedCallGraph : r.getCallGraph(name);
        JsonNode edges = callGraph.get("edges");
        Map<String, String> shortToFull = r.loadIdMap(name);

        Map<String, JsonNode> nodeMetadata = new HashMap<>();
        JsonNode nodes = index.get("nodes");
        if (nodes != null && nodes.isArray()) {
            for (JsonNode n : nodes) {
                String fullId = textOrNull(n, "nodeId");
                if (fullId != null) nodeMetadata.put(fullId, n);
            }
        }

        Map<String, List<JsonNode>> adjacency = new HashMap<>();
        if (edges != null && edges.isArray()) {
            for (JsonNode edge : edges) {
                String from = textOrNull(edge, "fromNodeId");
                if (from == null) continue;
                String fullFrom = nav.resolveToFullId(from, shortToFull, nodeMetadata.keySet());
                adjacency.computeIfAbsent(fullFrom, k -> new ArrayList<>()).add(edge);
            }
        }

        String resolvedId = nav.resolveToFullId(nodeId, shortToFull, nodeMetadata.keySet());
        Set<String> visited = new HashSet<>();
        return nav.buildCallTreeNode(resolvedId, nodeMetadata, adjacency, shortToFull, visited, null, 0);
    }

    /**
     * Read the call tree from a subfolder (non-package single-entry analysis).
     * The subfolder's index has the real dollar-format nodeId for the entry proc.
     */
    private JsonNode getCallTreeFromSubfolder(String subPath) throws IOException {
        JsonNode index = r.getIndex(subPath);
        JsonNode callGraph = r.getCallGraph(subPath);
        JsonNode edges = callGraph.get("edges");
        Map<String, String> shortToFull = r.loadIdMap(subPath);

        // Collect real nodeIds from subfolder index
        Map<String, JsonNode> nodeMetadata = new HashMap<>();
        JsonNode nodes = index.get("nodes");
        if (nodes != null && nodes.isArray()) {
            for (JsonNode n : nodes) {
                String fid = textOrNull(n, "nodeId");
                if (fid != null) nodeMetadata.put(fid, n);
            }
        }

        Map<String, List<JsonNode>> adjacency = new HashMap<>();
        if (edges != null && edges.isArray()) {
            for (JsonNode edge : edges) {
                String from = textOrNull(edge, "fromNodeId");
                if (from == null) continue;
                String fullFrom = nav.resolveToFullId(from, shortToFull, nodeMetadata.keySet());
                adjacency.computeIfAbsent(fullFrom, k -> new ArrayList<>()).add(edge);
            }
        }

        // Entry point is depth-0 node
        String entryNodeId = null;
        if (nodes != null && nodes.isArray()) {
            for (JsonNode n : nodes) {
                int depth = n.has("depth") ? n.get("depth").asInt() : -1;
                if (depth == 0) { entryNodeId = textOrNull(n, "nodeId"); break; }
            }
        }
        if (entryNodeId == null && !nodeMetadata.isEmpty()) {
            entryNodeId = nodeMetadata.keySet().iterator().next();
        }

        String resolvedId = nav.resolveToFullId(entryNodeId, shortToFull, nodeMetadata.keySet());
        return nav.buildCallTreeNode(resolvedId, nodeMetadata, adjacency, shortToFull, new HashSet<>(), null, 0);
    }

    JsonNode getCallers(String name, String nodeId) throws IOException {
        return getCallers(name, nodeId, r.getCallGraph(name));
    }

    JsonNode getCallers(String name, String nodeId, JsonNode suppliedCallGraph) throws IOException {
        ObjectMapper mapper = r.mapper;
        JsonNode index = r.getIndex(name);
        JsonNode callGraph = suppliedCallGraph != null ? suppliedCallGraph : r.getCallGraph(name);
        JsonNode edges = callGraph.get("edges");
        Map<String, String> shortToFull = r.loadIdMap(name);

        Map<String, JsonNode> nodeMetadata = new HashMap<>();
        JsonNode nodes = index.get("nodes");
        if (nodes != null && nodes.isArray()) {
            for (JsonNode n : nodes) {
                String fullId = textOrNull(n, "nodeId");
                if (fullId != null) nodeMetadata.put(fullId, n);
            }
        }

        String resolvedId = nav.resolveToFullId(nodeId, shortToFull, nodeMetadata.keySet());

        ArrayNode result = mapper.createArrayNode();
        if (edges != null && edges.isArray()) {
            for (JsonNode edge : edges) {
                String toId = textOrNull(edge, "toNodeId");
                if (toId == null) continue;
                String fullToId = nav.resolveToFullId(toId, shortToFull, nodeMetadata.keySet());
                if (!fullToId.equals(resolvedId)) continue;

                String fromId = textOrNull(edge, "fromNodeId");
                if (fromId == null) continue;
                String fullFromId = nav.resolveToFullId(fromId, shortToFull, nodeMetadata.keySet());
                JsonNode meta = nodeMetadata.get(fullFromId);

                ObjectNode caller = mapper.createObjectNode();
                caller.put("id", fullFromId);
                caller.put("name", meta != null ? textOrDefault(meta, "name", fullFromId) : textOrDefault(edge, "from", fullFromId));
                caller.put("schemaName", meta != null ? textOrDefault(meta, "schema", "") : textOrDefault(edge, "fromSchema", ""));
                caller.put("packageName", meta != null ? textOrDefault(meta, "packageName", "") : "");
                caller.put("objectType", meta != null ? textOrDefault(meta, "objectType", "") : "");
                caller.put("sourceFile", meta != null ? textOrDefault(meta, "sourceFile", "") : "");
                caller.put("startLine", meta != null ? intOrDefault(meta, "lineStart", 0) : 0);
                caller.put("endLine", meta != null ? intOrDefault(meta, "lineEnd", 0) : 0);
                caller.put("unitType", meta != null ? textOrDefault(meta, "objectType", "PROCEDURE") : "PROCEDURE");

                JsonNode lines = edge.get("lines");
                if (lines != null && lines.isArray() && !lines.isEmpty()) {
                    caller.put("callLineNumber", lines.get(0).asInt());
                    ArrayNode allLines = mapper.createArrayNode();
                    for (JsonNode ln : lines) allLines.add(ln.asInt());
                    caller.set("callLines", allLines);
                } else {
                    caller.put("callLineNumber", 0);
                }

                String fromSchema = meta != null ? textOrNull(meta, "schema") : textOrNull(edge, "fromSchema");
                String toSchema = textOrNull(edge, "toSchema");
                String callType = (fromSchema != null && fromSchema.equals(toSchema)) ? "INTERNAL" : "EXTERNAL";
                caller.put("callType", callType);

                result.add(caller);
            }
        }

        return result;
    }
}
