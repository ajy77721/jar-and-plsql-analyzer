package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

import static com.plsqlanalyzer.web.parser.service.StaticAnalysisReader.textOrDefault;

/** Table-facet reads: getTables (package merge). */
class TableFacetReader {

    private final StaticAnalysisReader r;

    TableFacetReader(StaticAnalysisReader r) {
        this.r = r;
    }

    JsonNode getTables(String name) throws IOException {
        ObjectMapper mapper = r.mapper;
        Path file = r.resolvePath(name, "api/tables/index.json");
        if (Files.isRegularFile(file)) return mapper.readTree(file.toFile());

        String key = r.cacheKey(name, "tables");
        JsonNode cached = r.synthesizedCache.get(key);
        if (cached != null) return cached;

        // Package analysis: merge tables from all proc subfolders
        JsonNode index;
        try { index = r.getIndex(name); } catch (IOException e) { index = mapper.createObjectNode(); }
        if (!index.has("_packageAnalysis") || !index.get("_packageAnalysis").asBoolean()) {
            throw new IOException("tables/index.json not found: " + file);
        }

        // Key: schema.name → merged table ObjectNode
        Map<String, ObjectNode> tableMap = new LinkedHashMap<>();
        Map<String, String> opSummary = new LinkedHashMap<>();

        Path parentDir = Path.of(r.getFlowOutputDir(), name);
        List<Path> procDirs = new ArrayList<>();
        try (Stream<Path> dirs = Files.list(parentDir)) {
            dirs.filter(Files::isDirectory).forEach(procDirs::add);
        }
        procDirs.sort(Comparator.comparing(p -> p.getFileName().toString()));

        for (Path procDir : procDirs) {
            Path tablesFile = procDir.resolve("api/tables/index.json");
            if (!Files.isRegularFile(tablesFile)) continue;
            JsonNode tablesIndex = mapper.readTree(tablesFile.toFile());

            // Accumulate operationSummary
            JsonNode opSum = tablesIndex.get("operationSummary");
            if (opSum != null && opSum.isObject()) {
                opSum.fields().forEachRemaining(e -> {
                    int prev = Integer.parseInt(opSummary.getOrDefault(e.getKey(), "0"));
                    opSummary.put(e.getKey(), String.valueOf(prev + e.getValue().asInt()));
                });
            }

            JsonNode tables = tablesIndex.get("tables");
            if (tables == null || !tables.isArray()) continue;
            for (JsonNode tbl : tables) {
                String schema = textOrDefault(tbl, "schema", "");
                String tblName = textOrDefault(tbl, "name", "");
                String tblKey = schema.toUpperCase() + "." + tblName.toUpperCase();

                ObjectNode existing = tableMap.get(tblKey);
                if (existing == null) {
                    existing = tbl.deepCopy();
                    // Ensure usedBy is an array
                    if (!existing.has("usedBy") || !existing.get("usedBy").isArray()) {
                        existing.set("usedBy", mapper.createArrayNode());
                    }
                    tableMap.put(tblKey, existing);
                } else {
                    // Merge allOperations
                    ArrayNode existOps = (ArrayNode) existing.get("allOperations");
                    if (existOps == null) { existOps = mapper.createArrayNode(); existing.set("allOperations", existOps); }
                    JsonNode newOps = tbl.get("allOperations");
                    if (newOps != null && newOps.isArray()) {
                        Set<String> opSet = new LinkedHashSet<>();
                        existOps.forEach(o -> opSet.add(o.asText()));
                        newOps.forEach(o -> opSet.add(o.asText()));
                        existOps.removeAll();
                        opSet.forEach(existOps::add);
                    }
                    // Merge usedBy
                    ArrayNode existUsedBy = (ArrayNode) existing.get("usedBy");
                    if (existUsedBy == null) { existUsedBy = mapper.createArrayNode(); existing.set("usedBy", existUsedBy); }
                    JsonNode newUsedBy = tbl.get("usedBy");
                    if (newUsedBy != null && newUsedBy.isArray()) {
                        for (JsonNode u : newUsedBy) existUsedBy.add(u);
                    }
                }
            }
        }

        ObjectNode result = mapper.createObjectNode();
        result.put("totalTables", tableMap.size());
        ObjectNode opSumNode = mapper.createObjectNode();
        opSummary.forEach((k, v) -> opSumNode.put(k, Integer.parseInt(v)));
        result.set("operationSummary", opSumNode);
        ArrayNode tablesArray = mapper.createArrayNode();
        tableMap.values().forEach(tablesArray::add);
        result.set("tables", tablesArray);
        r.synthesizedCache.put(key, result);
        return result;
    }
}
