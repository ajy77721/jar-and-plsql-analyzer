package com.plsqlanalyzer.web.parser.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.plsql.parser.flow.DbConnectionManager;
import com.plsqlanalyzer.config.ConnectionConfig;
import com.plsqlanalyzer.config.EnvironmentConfig;
import com.plsqlanalyzer.config.PlsqlConfig;
import com.plsqlanalyzer.web.parser.model.AnalysisInfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service("parserAnalysisService")
public class AnalysisService {

    private final String flowOutputDir;
    private final String cacheRoot; // {data}/cache — single tree for schema-resolver cache

    @Value("${app.parser-config-path:config/plsql-config.yaml}")
    private String configPath;

    private final AnalysisReaderFactory readerFactory;
    private final StaticAnalysisReader staticReader;
    private final PlsqlConfig plsqlConfig;
    private final ClaudePersistenceService claudePersistenceService;

    public AnalysisService(@Value("${app.data-dir.base:data}") String dataDir,
                           AnalysisReaderFactory readerFactory,
                           StaticAnalysisReader staticReader,
                           PlsqlConfig plsqlConfig,
                           ClaudePersistenceService claudePersistenceService) {
        this.flowOutputDir = Path.of(dataDir, "plsql-parse").toString();
        this.cacheRoot = Path.of(dataDir, "cache").toString();
        this.readerFactory = readerFactory;
        this.staticReader = staticReader;
        this.plsqlConfig = plsqlConfig;
        this.claudePersistenceService = claudePersistenceService;
    }

    public String getFlowOutputDir() { return flowOutputDir; }

    public List<AnalysisInfo> listAnalyses() throws IOException {
        Path root = Path.of(flowOutputDir);
        if (!Files.isDirectory(root)) return Collections.emptyList();

        List<AnalysisInfo> results = new ArrayList<>();
        try (Stream<Path> dirs = Files.list(root)) {
            dirs.filter(Files::isDirectory)
                .sorted(Comparator.comparingLong((Path p) -> {
                    try { return Files.getLastModifiedTime(p).toMillis(); } catch (IOException e) { return 0L; }
                }).reversed())
                .forEach(dir -> {
                    try {
                        AnalysisInfo info = buildInfo(dir);
                        if (info != null) results.add(info);
                    } catch (IOException ignored) {}
                });
        }
        return results;
    }

    public JsonNode getIndex(String name) throws IOException {
        return readerFactory.getReader(name).getIndex(name);
    }

    public JsonNode getNodeDetail(String name, String fileName) throws IOException {
        return readerFactory.getReader(name).getNodeDetail(name, fileName);
    }

    public JsonNode getTables(String name) throws IOException {
        return readerFactory.getReader(name).getTables(name);
    }

    public JsonNode getCallGraph(String name) throws IOException {
        return readerFactory.getReader(name).getCallGraph(name);
    }

    public String getSource(String name, String fileName) throws IOException {
        return readerFactory.getReader(name).getSource(name, fileName);
    }

    public JsonNode getResolver(String name, String type) throws IOException {
        return readerFactory.getReader(name).getResolver(name, type);
    }

    public JsonNode getProcedures(String name) throws IOException {
        return readerFactory.getReader(name).getProcedures(name);
    }

    public JsonNode getJoins(String name) throws IOException {
        return readerFactory.getReader(name).getJoins(name);
    }

    public JsonNode getCursors(String name) throws IOException {
        return readerFactory.getReader(name).getCursors(name);
    }

    public JsonNode getSequences(String name) throws IOException {
        return readerFactory.getReader(name).getSequences(name);
    }

    public JsonNode getDynamicSql(String name) throws IOException {
        return readerFactory.getReader(name).getDynamicSql(name);
    }

    public JsonNode getCallTree(String name, String nodeId) throws IOException {
        return readerFactory.getReader(name).getCallTree(name, nodeId);
    }

    public JsonNode getCallers(String name, String nodeId) throws IOException {
        return readerFactory.getReader(name).getCallers(name, nodeId);
    }

    /** Clear the in-memory synthesized cache: one analysis if {@code name} given, else all. */
    public int clearCache(String name) {
        if (name != null && !name.isBlank()) {
            staticReader.evictCache(name);
            return 1;
        }
        return staticReader.evictAll();
    }

    /** Derive the datasource dialect from a jdbc URL (no extra DB call). */
    private static String dialectOf(String jdbcUrl) {
        String u = jdbcUrl == null ? "" : jdbcUrl.toLowerCase();
        if (u.contains("sqlserver")) return "SQLSERVER";
        if (u.contains("oracle"))    return "ORACLE";
        if (u.contains("mysql"))     return "MYSQL";
        if (u.contains("db2"))       return "DB2";
        return "UNKNOWN";
    }

    /**
     * Cache footprint grouped per connection (project / environment / connection).
     * Each group: dbType, jdbcUrl, analysis count, total on-disk bytes.
     */
    public List<Map<String, Object>> cacheByConnection() throws IOException {
        Map<String, Map<String, Object>> groups = new LinkedHashMap<>();
        for (AnalysisInfo a : listAnalyses()) {
            String project = a.getProject() == null ? "" : a.getProject();
            String env     = a.getEnvironment() == null ? "" : a.getEnvironment();
            String conn    = a.getConnectionName() == null ? "" : a.getConnectionName();
            String key = project + "|" + env + "|" + conn;
            Map<String, Object> g = groups.computeIfAbsent(key, k -> {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("project", project);
                m.put("environment", env);
                m.put("connectionName", conn);
                m.put("dbType", dialectOf(a.getJdbcUrl()));
                m.put("jdbcUrl", a.getJdbcUrl());
                m.put("analysisCount", 0);
                m.put("sizeBytes", 0L);
                return m;
            });
            g.put("analysisCount", (int) g.get("analysisCount") + 1);
            long size = dirSize(Path.of(flowOutputDir, a.getName()));
            g.put("sizeBytes", (long) g.get("sizeBytes") + size);
        }
        return new ArrayList<>(groups.values());
    }

    /**
     * Clear the in-memory caches for every analysis of a connection, and clear the
     * shared on-disk source-download cache so the next analysis re-fetches fresh
     * source. Analysis results (index/call-graph/sources) are kept.
     * @return number of analyses whose cache was evicted.
     */
    public int clearConnectionCache(String project, String environment, String connName) throws IOException {
        int evicted = 0;
        for (AnalysisInfo a : listAnalyses()) {
            if (matches(a.getProject(), project) && matches(a.getEnvironment(), environment)
                    && matches(a.getConnectionName(), connName)) {
                staticReader.evictCache(a.getName());
                // Clear this connection's scoped schema-resolver disk cache so a re-analysis
                // re-resolves object→schema mappings against the live DB (folder name suffix
                // "__<hash>" is the cache scope; see FlowAnalysisMain --cache-scope).
                String folder = a.getName();
                int sfx = folder.lastIndexOf("__");
                if (sfx >= 0) {
                    String scope = folder.substring(sfx).replaceAll("[^A-Za-z0-9_-]", "_");
                    Path scopedResolver = Path.of(cacheRoot, "schema-resolver", scope);
                    if (Files.isDirectory(scopedResolver)) {
                        try { deleteDirectory(scopedResolver); } catch (Exception ignored) {}
                    }
                }
                evicted++;
            }
        }
        // Clear the legacy shared downloaded-source cache (regenerated on next fetch).
        Path dataRoot = Path.of(flowOutputDir).getParent();
        Path srcCache = dataRoot == null ? Path.of("cache-plsql") : dataRoot.resolve("cache-plsql");
        if (Files.isDirectory(srcCache)) {
            try (Stream<Path> s = Files.list(srcCache)) {
                s.forEach(p -> { try { deleteDirectory(p); } catch (Exception ignored) {} });
            }
        }
        return evicted;
    }

    private static boolean matches(String actual, String wanted) {
        if (wanted == null || wanted.isEmpty()) return true;
        return wanted.equals(actual == null ? "" : actual);
    }

    private static long dirSize(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return 0L;
        try (Stream<Path> s = Files.walk(dir)) {
            return s.filter(Files::isRegularFile).mapToLong(p -> {
                try { return Files.size(p); } catch (IOException e) { return 0L; }
            }).sum();
        } catch (IOException e) { return 0L; }
    }

    public void deleteAnalysis(String name) throws IOException {
        Path dir = Path.of(flowOutputDir, name);
        if (!Files.isDirectory(dir)) throw new NoSuchFileException(name);
        deleteDirectory(dir);
        staticReader.evictCache(name);
        claudePersistenceService.deleteClaudeData(name);
    }

    /**
     * Retention for re-run archives: keep the newest {@code keep} timestamped archive folders
     * for a given base name (e.g. NAME_20260718_145303) and delete older ones (plus their
     * Claude data), so repeated re-analysis doesn't grow the data dir without bound.
     */
    private void pruneOldArchives(String baseFolderName, int keep) {
        try {
            Path parent = Path.of(flowOutputDir);
            if (!Files.isDirectory(parent)) return;
            java.util.regex.Pattern ts = java.util.regex.Pattern.compile(
                    "^" + java.util.regex.Pattern.quote(baseFolderName) + "_\\d{8}_\\d{6}$");
            List<Path> archives;
            try (Stream<Path> s = Files.list(parent)) {
                archives = s.filter(Files::isDirectory)
                        .filter(p -> ts.matcher(p.getFileName().toString()).matches())
                        .sorted(Comparator.comparing(p -> p.getFileName().toString()))
                        .collect(java.util.stream.Collectors.toList());
            }
            for (int i = 0; i < archives.size() - keep; i++) {
                String archName = archives.get(i).getFileName().toString();
                deleteDirectory(archives.get(i));
                try { claudePersistenceService.deleteClaudeData(archName); } catch (Exception ignored) {}
                staticReader.evictCache(archName);
            }
        } catch (IOException e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                    .warn("[AnalysisService] archive prune failed for {}: {}", baseFolderName, e.getMessage());
        }
    }

    private static void deleteDirectory(Path dir) throws IOException {
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.delete(p); } catch (IOException ignored) {}
            });
        }
    }

    public String runAnalysis(String entryPoint) throws Exception {
        return runAnalysis(entryPoint, null, null, null, null);
    }

    public String runAnalysis(String entryPoint, String owner, String objectType) throws Exception {
        return runAnalysis(entryPoint, owner, objectType, null, null);
    }

    public String runAnalysis(String entryPoint, String owner, String objectType,
                               String project, String environment) throws Exception {
        return runAnalysis(entryPoint, owner, objectType, project, environment, null, null);
    }

    /**
     * Compute a short, bounded, URL-safe scope token so analyses of the same object under
     * different project/env/connection/db do NOT collide on disk or in the reader cache.
     * Returns "" when no scope is supplied (keeps back-compat naming for scopeless runs).
     */
    static String scopeSuffix(String project, String environment, String connName, String dbType) {
        String p = project     == null ? "" : project.trim();
        String e = environment == null ? "" : environment.trim();
        String c = connName    == null ? "" : connName.trim();
        String d = dbType      == null ? "" : dbType.trim();
        String raw = (p + "|" + e + "|" + c + "|" + d);
        if (raw.replace("|", "").isEmpty()) return "";           // nothing to scope by
        int h = raw.toUpperCase().hashCode() & 0x7fffffff;        // stable, non-negative
        return "__" + Integer.toString(h, 36).toUpperCase();      // e.g. "__1A2B3C"
    }

    public String runAnalysis(String entryPoint, String owner, String objectType,
                               String project, String environment,
                               String dbType, String connName) throws Exception {
        long analysisStartMs = System.currentTimeMillis(); // full end-to-end timer (crawl + enrichment + write)
        String target = entryPoint;
        // Standalone (schema-level, not a package member): procedures, functions, and also
        // views and triggers — these are never package subprograms in any dialect, so the
        // owner must not be folded into a "package.subprogram" entry key.
        boolean isStandalone = objectType != null &&
                (objectType.equalsIgnoreCase("PROCEDURE") || objectType.equalsIgnoreCase("FUNCTION")
                 || objectType.equalsIgnoreCase("VIEW") || objectType.equalsIgnoreCase("TRIGGER"));
        boolean isPackageOnly = objectType != null && objectType.equalsIgnoreCase("PACKAGE")
                && !entryPoint.contains(".");

        if (!isStandalone && owner != null && !owner.isBlank() && !entryPoint.contains(".")) {
            target = owner.toUpperCase() + "." + entryPoint;
        }

        // Resolve environment config: if project+env provided, generate a temp config file
        // scoped to that environment's connections so the analysis uses the right DB.
        String effectiveConfigPath = configPath;
        String resolvedJdbcUrl = null;
        String resolvedConnName = null;
        EnvironmentConfig envConfig = null;
        if (project != null && !project.isBlank() && environment != null && !environment.isBlank()) {
            envConfig = plsqlConfig.resolveEnvironment(project, environment);
        }
        if (envConfig != null) {
            resolvedJdbcUrl = envConfig.getJdbcUrl();
            // Build env config — written to outputDir so ParserValidationExecutor can find it
            // even after a server restart (temp files are deleted on JVM exit).
            // Actual resultDir may not exist yet; we write the config after createDirectories.
            // Store the envConfig reference; we write the file after resultDir is created below.
            if (!envConfig.getConnections().isEmpty()) {
                resolvedConnName = envConfig.getConnections().stream()
                        .map(ConnectionConfig::getName)
                        .reduce((a, b) -> a + ", " + b)
                        .orElse(null);
            }
        }

        // When a bare package name is submitted, query Oracle ALL_PROCEDURES to discover all procs.
        List<String> entryList = new ArrayList<>();
        if (isPackageOnly) {
            entryList.addAll(discoverPackageEntries(entryPoint, owner, effectiveConfigPath));
        }
        if (entryList.isEmpty()) {
            entryList.add(target);
        }

        // baseFolderName: for a package this is the package name (e.g. CUSTOMER_PG_BPGE_WORKFLOW),
        // for a single proc this is the proc name.
        String baseFolderName;
        if (isPackageOnly) {
            // Name the folder after the package, not owner.package
            baseFolderName = entryPoint.toUpperCase()
                    .replace(".", "_").replace("/", "_").replace("\\", "_");
        } else {
            baseFolderName = target.toUpperCase()
                    .replace(".", "_").replace("/", "_").replace("\\", "_");
        }
        // Scope the identity by project/env/connection/db so different contexts don't collide
        // (on disk or in the reader cache). connName falls back to the env-resolved connection.
        String scopeConn = (connName != null && !connName.isBlank()) ? connName : resolvedConnName;
        // The scope suffix (e.g. "__WL2ZTC") encodes project|env|conn|dbType and is reused as the
        // per-connection cache scope so the schema-resolver disk cache never bleeds between DBs.
        String cacheScope = scopeSuffix(project, environment, scopeConn, dbType);
        baseFolderName = baseFolderName + cacheScope;

        Path resultDir = Path.of(flowOutputDir, baseFolderName);
        if (Files.isDirectory(resultDir)) {
            String oldTs = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String archivedName = baseFolderName + "_" + oldTs;
            Path archived = Path.of(flowOutputDir, archivedName);
            // Archive Claude data to matching timestamped name before moving static folder
            claudePersistenceService.archiveClaudeData(baseFolderName, archivedName);
            try {
                Files.move(resultDir, archived, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException moveEx) {
                // On Windows, directories with open handles can't be atomically moved.
                // Fall through — FlowAnalysisMain will overwrite individual proc subfolders.
                org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                    .warn("[AnalysisService] Could not archive {}: {}", baseFolderName, moveEx.getMessage());
            }
            staticReader.evictCache(baseFolderName);
            // Retention: keep only the newest few timestamped archives so re-runs don't
            // pile up folders in the data dir indefinitely.
            pruneOldArchives(baseFolderName, 3);
        }

        // Write env config into resultDir so it survives server restarts and ParserValidationExecutor
        // can use it. Done before FlowAnalysisMain so the directory exists.
        if (isPackageOnly && entryList.size() > 1) {
            Files.createDirectories(resultDir);
        }
        if (envConfig != null) {
            Path persistedConfig = buildEnvConfigFile(envConfig, project, environment, resultDir);
            if (persistedConfig != null) effectiveConfigPath = persistedConfig.toString();
        }

        if (isPackageOnly && entryList.size() > 1) {
            // For package analysis: run one FlowAnalysisMain per proc in parallel (3-4 threads).
            // All procs share --cache-dir = resultDir so ParseResultCache and NodeParseCache are
            // shared — a package body parsed by proc 1 is never re-parsed by ANTLR for proc 2+.
            final String finalEffectiveConfigPath = effectiveConfigPath;
            int threads = Math.min(4, entryList.size());
            java.util.concurrent.ExecutorService pool =
                    java.util.concurrent.Executors.newFixedThreadPool(threads,
                        r -> { Thread t = new Thread(r, "pkg-proc-exec"); t.setDaemon(false); return t; });
            java.util.List<java.util.concurrent.Future<?>> futures = new java.util.ArrayList<>();
            for (String procEntry : entryList) {
                final String pe = procEntry;
                futures.add(pool.submit(() -> {
                    java.util.List<String> argList = new java.util.ArrayList<>();
                    argList.add("--flow");
                    argList.add("--config"); argList.add(finalEffectiveConfigPath);
                    argList.add("--entry"); argList.add(pe);
                    argList.add("--output-dir"); argList.add(resultDir.toString());
                    argList.add("--cache-dir"); argList.add(resultDir.toString());
                    argList.add("--cache-scope"); argList.add(cacheScope);
                    argList.add("--cache-root"); argList.add(cacheRoot);
                    argList.add("--pretty");
                    com.plsql.parser.flow.FlowAnalysisMain.run(argList.toArray(new String[0]));
                }));
            }
            pool.shutdown();
            // Wait for all procs to finish (B5: bounded wait, cancel on timeout)
            for (java.util.concurrent.Future<?> f : futures) {
                try {
                    f.get(30, java.util.concurrent.TimeUnit.MINUTES);
                } catch (java.util.concurrent.TimeoutException tex) {
                    f.cancel(true);
                    org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                        .warn("[AnalysisService] Proc analysis timed out after 30 min, cancelled");
                } catch (Exception ex) {
                    org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                        .warn("[AnalysisService] Proc analysis thread failed: {}", ex.getMessage());
                }
            }

            // Merge per-proc api/index.json files into one combined index at the package level.
            // Validation runs as a follow-up queue job AFTER this method returns.
            mergePackageIndex(resultDir, entryPoint, owner);
        } else {
            java.util.List<String> argList = new java.util.ArrayList<>();
            argList.add("--flow");
            argList.add("--config"); argList.add(effectiveConfigPath);
            for (String e : entryList) {
                argList.add("--entry"); argList.add(e);
            }
            argList.add("--output-dir"); argList.add(flowOutputDir);
            // Force the scoped folder name so different project/env/conn/db contexts don't collide.
            argList.add("--output-name"); argList.add(baseFolderName);
            // Scope cache to this proc's result folder so it is cleared on re-analysis
            // and never bleeds stale parse results to other procs or future runs.
            argList.add("--cache-dir"); argList.add(resultDir.toString());
            argList.add("--cache-scope"); argList.add(cacheScope);
            argList.add("--cache-root"); argList.add(cacheRoot);
            argList.add("--pretty");

            com.plsql.parser.flow.FlowAnalysisMain.run(argList.toArray(new String[0]));
            // Validation runs as a follow-up queue job — no inline runTableValidation call here.
        }

        // Enrich tables (columns / indexes / constraints / triggers / view defs) INLINE for
        // every dialect so the UI table-detail is populated consistently (SQL Server, MySQL,
        // DB2 via their catalog enrichers; Oracle via TableValidationService).
        try (com.plsql.parser.flow.DbConnectionManager ec =
                     new com.plsql.parser.flow.DbConnectionManager(effectiveConfigPath)) {
            Path base = Path.of(flowOutputDir, baseFolderName);
            List<Path> dirs = new ArrayList<>();
            if (Files.isRegularFile(base.resolve("api/tables/index.json"))) dirs.add(base);
            if (Files.isDirectory(base)) {
                try (Stream<Path> sub = Files.list(base)) {
                    sub.filter(Files::isDirectory)
                       .filter(p -> Files.isRegularFile(p.resolve("api/tables/index.json")))
                       .forEach(dirs::add);
                }
            }
            if (!dirs.isEmpty()) {
                if (ec.isSqlServer())      com.plsql.parser.flow.SqlServerTableEnricher.enrich(ec, dirs);
                else if (ec.isMySQL())     com.plsql.parser.flow.MySqlTableEnricher.enrich(ec, dirs);
                else if (ec.isDB2())       com.plsql.parser.flow.Db2TableEnricher.enrich(ec, dirs);
                else if (ec.isPostgres())  com.plsql.parser.flow.PostgresTableEnricher.enrich(ec, dirs);
                else                       com.plsql.parser.flow.TableValidationService.validateMultiple(ec, dirs);
            }
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] table enrichment failed: {}", e.getMessage());
        }

        staticReader.evictCache(baseFolderName);

        // Patch index.json with project/environment/connection metadata.
        // Fall back to global plsqlConfig connection info when no project/env was selected.
        String patchJdbcUrl = resolvedJdbcUrl;
        String patchConnName = resolvedConnName;
        if ((patchJdbcUrl == null || patchJdbcUrl.isBlank()) && plsqlConfig != null) {
            patchJdbcUrl = plsqlConfig.getJdbcUrl();
        }
        if ((patchConnName == null || patchConnName.isBlank()) && plsqlConfig != null
                && plsqlConfig.getDbUsers() != null && !plsqlConfig.getDbUsers().isEmpty()) {
            patchConnName = plsqlConfig.getDbUsers().stream()
                    .map(u -> (u.getDescription() != null && !u.getDescription().isBlank())
                            ? u.getDescription() : u.getUsername())
                    .filter(Objects::nonNull)
                    .reduce((a, b) -> a + ", " + b)
                    .orElse(null);
        }
        patchConnectionMeta(baseFolderName, project, environment, patchConnName, patchJdbcUrl,
                System.currentTimeMillis() - analysisStartMs);

        return baseFolderName;
    }

    /**
     * After running multi-entry package analysis into resultDir (each proc has its own subfolder),
     * write a merged api/index.json at the resultDir level so listAnalyses() picks it up as one entry.
     */
    private void mergePackageIndex(Path resultDir, String packageName, String owner) {
        ObjectMapper mapper = new ObjectMapper();
        int totalNodes = 0, totalTables = 0, totalEdges = 0, totalLoc = 0, maxDepth = 0;
        long crawlTimeMs = 0;
        int dbCallCount = 0;
        List<String> errors = new ArrayList<>();
        String entrySchema = (owner != null && !owner.isBlank()) ? owner.toUpperCase() : "";
        List<ObjectNode> procNodeList = new ArrayList<>();

        List<Path> procDirs = new ArrayList<>();
        try (Stream<Path> dirs = Files.list(resultDir)) {
            dirs.filter(Files::isDirectory).forEach(procDirs::add);
        } catch (IOException e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] mergePackageIndex scan failed: {}", e.getMessage());
        }
        procDirs.sort(Comparator.comparing(p -> p.getFileName().toString()));

        for (Path procDir : procDirs) {
            Path indexFile = procDir.resolve("api/index.json");
            if (!Files.isRegularFile(indexFile)) continue;
            try {
                JsonNode idx = mapper.readTree(indexFile.toFile());
                int procNodeCount = intOrDefault(idx, "totalNodes", 0);
                totalNodes  += procNodeCount;
                totalTables += intOrDefault(idx, "totalTables", 0);
                totalEdges  += intOrDefault(idx, "totalEdges", 0);
                totalLoc    += intOrDefault(idx, "totalLinesOfCode", 0);
                crawlTimeMs = Math.max(crawlTimeMs, longOrDefault(idx, "crawlTimeMs", 0));
                dbCallCount += intOrDefault(idx, "dbCallCount", 0);
                int d = intOrDefault(idx, "maxDepth", 0);
                if (d > maxDepth) maxDepth = d;
                JsonNode errNode = idx.get("errors");
                if (errNode != null && errNode.isArray()) {
                    errNode.forEach(e -> errors.add(e.asText()));
                }
                String es = textOrDefault(idx, "entrySchema", "");
                if (entrySchema.isEmpty() && !es.isEmpty()) entrySchema = es;

                // Build a node entry for this proc (used by the procedures list in the UI)
                String entryPoint = textOrDefault(idx, "entryPoint", procDir.getFileName().toString());
                String procId = entryPoint.toUpperCase().replace(".", "_")
                        .replace("/", "_").replace("\\", "_");
                String procName = entryPoint.contains(".") ? entryPoint.substring(entryPoint.indexOf('.') + 1) : entryPoint;
                ObjectNode pn = mapper.createObjectNode();
                pn.put("nodeId", procId);
                pn.put("name", procName);
                pn.put("id", procId);
                pn.put("schema", es.isEmpty() ? (owner != null ? owner.toUpperCase() : "") : es);
                pn.put("packageName", packageName.toUpperCase());
                pn.put("objectType", "PROCEDURE");
                pn.put("unitType", "PROCEDURE");
                pn.put("linesOfCode", intOrDefault(idx, "totalLinesOfCode", 0));
                pn.put("callCount", intOrDefault(idx, "totalEdges", 0));
                pn.put("subfolderName", procDir.getFileName().toString());
                // Find detailFile from the proc's own index (depth-0 node)
                String detailFile = null;
                JsonNode procNodes = idx.get("nodes");
                if (procNodes != null && procNodes.isArray()) {
                    for (JsonNode pNode : procNodes) {
                        int pDepth = pNode.has("depth") ? pNode.get("depth").asInt() : -1;
                        if (pDepth == 0 && pNode.has("detailFile")) {
                            detailFile = pNode.get("detailFile").asText();
                            break;
                        }
                    }
                    if (detailFile == null && procNodes.size() > 0 && procNodes.get(0).has("detailFile")) {
                        detailFile = procNodes.get(0).get("detailFile").asText();
                    }
                }
                if (detailFile != null) pn.put("detailFile", detailFile);
                procNodeList.add(pn);
            } catch (IOException ignored) {}
        }

        try {
            Path apiDir = resultDir.resolve("api");
            Files.createDirectories(apiDir);

            ObjectNode root = mapper.createObjectNode();
            root.put("entryPoint", packageName.toUpperCase());
            root.put("entrySchema", entrySchema);
            root.put("totalNodes", totalNodes);
            root.put("totalTables", totalTables);
            root.put("totalEdges", totalEdges);
            root.put("totalLinesOfCode", totalLoc);
            root.put("maxDepth", maxDepth);
            root.put("crawlTimeMs", crawlTimeMs);
            root.put("dbCallCount", dbCallCount);
            root.put("_packageAnalysis", true);
            ArrayNode errArray = root.putArray("errors");
            errors.forEach(errArray::add);
            ArrayNode nodesArray = root.putArray("nodes");
            procNodeList.forEach(nodesArray::add);

            mapper.writerWithDefaultPrettyPrinter().writeValue(apiDir.resolve("index.json").toFile(), root);

            // Gap 7: merge per-proc api/tables/index.json into one at the package level
            mergePackageTablesIndex(resultDir, procDirs, mapper);
            // Merge per-proc node_id_map.json so ParserAnalysisReader.loadIdMap() resolves correctly
            mergePackageNodeIdMap(resultDir, procDirs, mapper);
        } catch (IOException e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] mergePackageIndex write failed: {}", e.getMessage());
        }
    }

    /**
     * Gap 7: Merge per-proc api/tables/index.json files into one at the package level.
     * Deduplicates tables by "schema.name" key — last writer wins for metadata fields.
     */
    @SuppressWarnings("unchecked")
    private void mergePackageTablesIndex(Path resultDir, List<Path> procDirs, ObjectMapper mapper) {
        // tableKey → merged table ObjectNode
        java.util.LinkedHashMap<String, ObjectNode> merged = new java.util.LinkedHashMap<>();

        for (Path procDir : procDirs) {
            Path tablesFile = procDir.resolve("api/tables/index.json");
            if (!Files.isRegularFile(tablesFile)) continue;
            try {
                JsonNode tIdx = mapper.readTree(tablesFile.toFile());
                JsonNode tables = tIdx.get("tables");
                if (tables == null || !tables.isArray()) continue;
                for (JsonNode t : tables) {
                    String schema = t.has("schema") ? t.get("schema").asText().toUpperCase() : "";
                    String name   = t.has("name")   ? t.get("name").asText().toUpperCase()   : "";
                    if (name.isBlank()) continue;
                    String key = schema.isBlank() ? name : schema + "." + name;
                    if (merged.containsKey(key)) {
                        // Merge usedBy lists; keep existing metadata unless missing
                        ObjectNode existing = merged.get(key);
                        JsonNode newUsedBy = t.get("usedBy");
                        if (newUsedBy != null && newUsedBy.isArray()) {
                            ArrayNode existingUsedBy = (ArrayNode) existing.get("usedBy");
                            if (existingUsedBy == null) {
                                existingUsedBy = mapper.createArrayNode();
                                existing.set("usedBy", existingUsedBy);
                            }
                            for (JsonNode u : newUsedBy) existingUsedBy.add(u);
                        }
                        // Copy metadata fields if not already present on the merged entry
                        for (String field : new String[]{"dbColumns","dbConstraints","dbIndexes","viewDefinition","dbFound","dbValidated","dbResolvedType"}) {
                            if (!existing.has(field) && t.has(field)) existing.set(field, t.get(field));
                        }
                    } else {
                        merged.put(key, (ObjectNode) t.deepCopy());
                    }
                }
            } catch (IOException ignored) {}
        }

        if (merged.isEmpty()) return;
        try {
            Path tablesDir = resultDir.resolve("api/tables");
            Files.createDirectories(tablesDir);
            ObjectNode out = mapper.createObjectNode();
            out.put("totalTables", merged.size());
            out.put("_packageMerged", true);
            ArrayNode arr = mapper.createArrayNode();
            merged.values().forEach(arr::add);
            out.set("tables", arr);
            mapper.writerWithDefaultPrettyPrinter().writeValue(tablesDir.resolve("index.json").toFile(), out);
        } catch (IOException e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] mergePackageTablesIndex write failed: {}", e.getMessage());
        }
    }

    /**
     * Merge per-proc api/node_id_map.json files into one package-level file.
     * ParserAnalysisReader.loadIdMap() reads "shortToFull" from api/node_id_map.json at the
     * package root — without this merge it always returns an empty map, breaking all node
     * navigation (call tree, callers, node detail lookups).
     */
    private void mergePackageNodeIdMap(Path resultDir, List<Path> procDirs, ObjectMapper mapper) {
        Map<String, String> shortToFull = new java.util.LinkedHashMap<>();
        Map<String, String> fullToId    = new java.util.LinkedHashMap<>();
        for (Path procDir : procDirs) {
            Path mapFile = procDir.resolve("api/node_id_map.json");
            if (!Files.isRegularFile(mapFile)) continue;
            try {
                JsonNode root = mapper.readTree(mapFile.toFile());
                JsonNode stf = root.get("shortToFull");
                if (stf != null && stf.isObject()) stf.fields().forEachRemaining(e -> shortToFull.putIfAbsent(e.getKey(), e.getValue().asText()));
                JsonNode ftd = root.get("fullToId");
                if (ftd != null && ftd.isObject()) ftd.fields().forEachRemaining(e -> fullToId.putIfAbsent(e.getKey(), e.getValue().asText()));
            } catch (IOException e) {
                org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                    .warn("[AnalysisService] mergePackageNodeIdMap read failed for {}: {}", mapFile, e.getMessage());
            }
        }
        if (shortToFull.isEmpty()) return;
        try {
            Path apiDir = resultDir.resolve("api");
            Files.createDirectories(apiDir);
            ObjectNode out = mapper.createObjectNode();
            out.set("shortToFull", mapper.valueToTree(shortToFull));
            out.set("fullToId",    mapper.valueToTree(fullToId));
            mapper.writeValue(apiDir.resolve("node_id_map.json").toFile(), out);
        } catch (IOException e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] mergePackageNodeIdMap write failed: {}", e.getMessage());
        }
    }

    /**
     * Write an env-scoped YAML config into the analysis output directory so it persists
     * across server restarts and ParserValidationExecutor can use it as a follow-up job.
     * Falls back to a temp file if outputDir is null or not yet created.
     */
    private Path buildEnvConfigFile(EnvironmentConfig envConfig, String project, String environment,
                                     Path outputDir) {
        try {
            String jdbcUrl = envConfig.getJdbcUrl();
            if (jdbcUrl == null || jdbcUrl.isBlank()) {
                org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                    .warn("[AnalysisService] No jdbcUrl for {}/{} — falling back to global config", project, environment);
                return null;
            }

            StringBuilder sb = new StringBuilder();
            sb.append("jdbc_url: \"").append(jdbcUrl.replace("\"", "\\\"")).append("\"\n");
            // Write db_type so DbConnectionManager can load the right driver and use the right queries
            String dbType = envConfig.getConnections().isEmpty() ? "ORACLE"
                    : envConfig.getConnections().get(0).getDbType();
            if (dbType == null || dbType.isBlank()) dbType = "ORACLE";
            sb.append("db_type: \"").append(dbType.toUpperCase()).append("\"\n");
            sb.append("db_users:\n");
            for (ConnectionConfig c : envConfig.getConnections()) {
                String user = c.getUsername() != null ? c.getUsername() : "";
                String pass = c.getPassword() != null ? c.getPassword() : "";
                String desc = c.getDescription() != null ? c.getDescription() : c.getName();
                sb.append("- username: \"").append(user.replace("\"", "\\\"")).append("\"\n");
                sb.append("  password: \"").append(pass.replace("\"", "\\\"")).append("\"\n");
                sb.append("  description: \"").append(desc.replace("\"", "\\\"")).append("\"\n");
            }
            sb.append("source_paths:\n- \"./plsql-sources\"\n");

            Path target;
            if (outputDir != null && Files.isDirectory(outputDir)) {
                // Persist inside analysis folder — survives server restart
                target = outputDir.resolve("plsql-env-config.yaml");
            } else {
                String safeEnv = environment.replaceAll("[^A-Za-z0-9_-]", "_");
                target = Files.createTempFile("plsql-env-" + safeEnv + "-", ".yaml");
                target.toFile().deleteOnExit();
            }
            Files.writeString(target, sb.toString());
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .info("[AnalysisService] Env config for {}/{} written to: {}", project, environment, target);
            return target;
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] Could not build env config for {}/{}: {}", project, environment, e.getMessage());
            return null;
        }
    }

    /** Validate tables for a single-proc output directory. */
    private void runTableValidation(Path outputDir, String cfgPath) {
        if (!Files.isDirectory(outputDir)) return;
        try (com.plsql.parser.flow.DbConnectionManager conn = new com.plsql.parser.flow.DbConnectionManager(cfgPath)) {
            if (conn.isSqlServer())
                com.plsql.parser.flow.SqlServerTableEnricher.enrich(conn, List.of(outputDir));
            else
                com.plsql.parser.flow.TableValidationService.validateMultiple(conn, List.of(outputDir));
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] Table validation failed for {}: {}", outputDir, e.getMessage());
        }
    }

    /**
     * Validate tables for all proc subfolders inside a package output directory.
     * One DB connection + one bulk all_objects query covers every proc's tables.
     */
    private void runTableValidationForPackage(Path packageDir, String cfgPath) {
        if (!Files.isDirectory(packageDir)) return;
        try {
            List<Path> procDirs;
            try (Stream<Path> dirs = Files.list(packageDir)) {
                procDirs = dirs.filter(Files::isDirectory).collect(java.util.stream.Collectors.toList());
            }
            if (procDirs.isEmpty()) return;
            try (com.plsql.parser.flow.DbConnectionManager conn = new com.plsql.parser.flow.DbConnectionManager(cfgPath)) {
                if (conn.isSqlServer())
                    com.plsql.parser.flow.SqlServerTableEnricher.enrich(conn, procDirs);
                else
                    com.plsql.parser.flow.TableValidationService.validateMultiple(conn, procDirs);
            }
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] Table validation failed for package {}: {}", packageDir, e.getMessage());
        }
    }

    /**
     * Patch the top-level api/index.json with project/environment/connection metadata.
     * Called after FlowAnalysisMain writes its output.
     */
    private void patchConnectionMeta(String baseFolderName, String project, String environment,
                                      String connectionName, String jdbcUrl, long totalDurationMs) {
        Path indexFile = Path.of(flowOutputDir, baseFolderName, "api", "index.json");
        if (!Files.isRegularFile(indexFile)) return;
        try {
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode root = (ObjectNode) mapper.readTree(indexFile.toFile());
            if (project != null && !project.isBlank()) root.put("project", project);
            if (environment != null && !environment.isBlank()) root.put("environment", environment);
            if (connectionName != null && !connectionName.isBlank()) root.put("connectionName", connectionName);
            if (jdbcUrl != null && !jdbcUrl.isBlank()) root.put("jdbcUrl", jdbcUrl);
            // Full end-to-end analysis time: crawl + table enrichment + writing (nothing pending).
            if (totalDurationMs > 0) root.put("totalDurationMs", totalDurationMs);
            mapper.writerWithDefaultPrettyPrinter().writeValue(indexFile.toFile(), root);
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] Could not patch connection meta for {}: {}", baseFolderName, e.getMessage());
        }
    }

    /**
     * Query Oracle ALL_PROCEDURES to find all procs/functions in the package.
     * Returns entries like "PKG.PROC_NAME" for each proc found.
     * Falls back to empty list if DB unavailable (caller uses bare package name).
     */
    private List<String> discoverPackageEntries(String pkgName, String owner) {
        return discoverPackageEntries(pkgName, owner, configPath);
    }

    private List<String> discoverPackageEntries(String pkgName, String owner, String cfgPath) {
        String pkgUpper = pkgName.toUpperCase();
        String ownerUpper = (owner != null && !owner.isBlank()) ? owner.toUpperCase() : "CUSTOMER";
        List<String> entries = new ArrayList<>();

        try (DbConnectionManager conn = new DbConnectionManager(cfgPath)) {
            try (Connection c = conn.getConnection(ownerUpper);
                 PreparedStatement ps = c.prepareStatement(
                     "SELECT DISTINCT procedure_name FROM all_procedures " +
                     "WHERE owner = ? AND object_name = ? AND procedure_name IS NOT NULL " +
                     "ORDER BY procedure_name")) {
                ps.setString(1, ownerUpper);
                ps.setString(2, pkgUpper);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String proc = rs.getString(1);
                        if (proc != null && !proc.isBlank()) {
                            entries.add(pkgUpper + "." + proc.trim().toUpperCase());
                        }
                    }
                }
            }
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(AnalysisService.class)
                .warn("[AnalysisService] Could not query procs for {}: {}", pkgName, e.getMessage());
        }

        return entries;
    }

    // --- helpers ---

    private AnalysisInfo buildInfo(Path dir) throws IOException {
        Path indexFile = dir.resolve("api/index.json");
        if (!Files.isRegularFile(indexFile)) return null;

        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        JsonNode root = mapper.readTree(indexFile.toFile());

        AnalysisInfo info = new AnalysisInfo();
        info.setName(dir.getFileName().toString());
        info.setEntryPoint(textOrDefault(root, "entryPoint", dir.getFileName().toString()));
        info.setEntrySchema(textOrDefault(root, "entrySchema", ""));
        info.setTotalNodes(intOrDefault(root, "totalNodes", 0));
        info.setTotalTables(intOrDefault(root, "totalTables", 0));
        info.setTotalEdges(intOrDefault(root, "totalEdges", 0));
        info.setTotalLinesOfCode(intOrDefault(root, "totalLinesOfCode", 0));
        info.setMaxDepth(intOrDefault(root, "maxDepth", 0));
        info.setCrawlTimeMs(longOrDefault(root, "crawlTimeMs", 0));
        // Full end-to-end duration; old analyses without it fall back to crawlTimeMs.
        info.setTotalDurationMs(longOrDefault(root, "totalDurationMs", info.getCrawlTimeMs()));
        info.setDbCallCount(intOrDefault(root, "dbCallCount", 0));
        info.setProject(textOrDefault(root, "project", ""));
        info.setEnvironment(textOrDefault(root, "environment", ""));
        info.setConnectionName(textOrDefault(root, "connectionName", ""));
        info.setJdbcUrl(textOrDefault(root, "jdbcUrl", ""));

        // Use directory last-modified time as the analysis timestamp
        try { info.setTimestamp(Files.getLastModifiedTime(dir).toMillis()); } catch (IOException ignored) {}

        List<String> errors = new ArrayList<>();
        JsonNode errNode = root.get("errors");
        if (errNode != null && errNode.isArray()) {
            errNode.forEach(e -> errors.add(e.asText()));
        }
        info.setErrors(errors);

        return info;
    }

    private static String textOrDefault(JsonNode node, String field, String def) {
        JsonNode v = node.get(field);
        return (v != null && !v.isNull()) ? v.asText() : def;
    }

    private static int intOrDefault(JsonNode node, String field, int def) {
        JsonNode v = node.get(field);
        return (v != null && v.isNumber()) ? v.asInt() : def;
    }

    private static long longOrDefault(JsonNode node, String field, long def) {
        JsonNode v = node.get(field);
        return (v != null && v.isNumber()) ? v.asLong() : def;
    }
}
