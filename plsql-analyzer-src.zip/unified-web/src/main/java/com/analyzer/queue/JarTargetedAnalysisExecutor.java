package com.analyzer.queue;

import com.jaranalyzer.model.EndpointInfo;
import com.jaranalyzer.service.CallGraphService;
import com.jaranalyzer.service.CallGraphService.MethodRef;
import com.jaranalyzer.service.JarParserService;
import com.jaranalyzer.service.PersistenceService;
import com.jaranalyzer.service.SourceEnrichmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Targeted "developer analysis": builds COMPLETE call trees for ONLY the supplied entry
 * methods (not the whole project) and persists them under a "_targeted" id so they list
 * as a separate analysis. Stages 1–3 mirror {@link JarAnalysisExecutor} (parse → index →
 * stream classes); the difference is {@link CallGraphService#buildTreesForRoots} in place
 * of {@code buildEndpointsFromIndex}.
 */
@Component
public class JarTargetedAnalysisExecutor {

    private static final Logger log = LoggerFactory.getLogger(JarTargetedAnalysisExecutor.class);

    private final JarParserService parserService;
    private final CallGraphService callGraphService;
    private final PersistenceService persistenceService;
    private final SourceEnrichmentService sourceEnrichmentService;

    public JarTargetedAnalysisExecutor(JarParserService parserService,
                                       CallGraphService callGraphService,
                                       PersistenceService persistenceService,
                                       SourceEnrichmentService sourceEnrichmentService) {
        this.parserService = parserService;
        this.callGraphService = callGraphService;
        this.persistenceService = persistenceService;
        this.sourceEnrichmentService = sourceEnrichmentService;
    }

    @SuppressWarnings("unchecked")
    public void execute(QueueJob job, BiConsumer<QueueJob, String> broadcast) throws Exception {
        String jarName = (String) job.metadata.get("jarName");
        String tempFilePath = (String) job.metadata.get("tempFilePath");
        long fileSize = ((Number) job.metadata.get("fileSize")).longValue();
        List<Map<String, Object>> rawEntries = (List<Map<String, Object>>) job.metadata.get("entries");

        List<MethodRef> roots = new ArrayList<>();
        for (Map<String, Object> e : rawEntries) {
            String className = (String) e.get("className");
            String methodName = (String) e.get("methodName");
            List<String> paramTypes = (List<String>) e.get("paramTypes");
            roots.add(new MethodRef(className, methodName, paramTypes));
        }

        Path tempJar = Path.of(tempFilePath);
        Path classesFile = null;
        try {
            progress(job, broadcast, "[1/4] Parsing JAR bytecode...");
            JarParserService.ParseResult parseResult = parserService.parseJarToFile(tempJar.toFile(), null, jarName);
            classesFile = parseResult.classesFile();
            checkCancelled(job);

            progress(job, broadcast, "[2/4] Building call-graph index...");
            callGraphService.buildIndex();
            callGraphService.setJarArtifactMap(parseResult.jarArtifactMap());
            parserService.streamClasses(classesFile, cls -> callGraphService.addToIndex(cls));
            progress(job, broadcast, "Index built from " + parseResult.totalClasses() + " classes");
            checkCancelled(job);

            progress(job, broadcast, "[3/4] Building targeted call trees for " + roots.size() + " root(s)...");
            List<EndpointInfo> endpoints = callGraphService.buildTreesForRoots(roots);
            System.gc();
            checkCancelled(job);

            progress(job, broadcast, "[4/4] Writing analysis to disk...");
            persistenceService.storeJar(tempJar, jarName);
            Path storedJar = persistenceService.getJarFilePath(jarName);
            if (storedJar != null) {
                try {
                    sourceEnrichmentService.enrichCallTreesWithSource(endpoints, storedJar);
                } catch (Exception ex) {
                    log.warn("Source enrichment failed (non-fatal): {}", ex.getMessage());
                }
            }
            System.gc();

            String analyzedAt = LocalDateTime.now().toString();
            persistenceService.writeAnalysisStreaming(
                    jarName, null, fileSize, analyzedAt,
                    parseResult.totalClasses(), endpoints.size(),
                    classesFile, endpoints, "TARGETED", null
            );

            job.resultName = jarName;
            progress(job, broadcast, "Targeted analysis complete: " + endpoints.size()
                    + " call trees from " + roots.size() + " requested root(s)");
        } finally {
            Files.deleteIfExists(tempJar);
            if (classesFile != null) Files.deleteIfExists(classesFile);
        }
    }

    private void progress(QueueJob job, BiConsumer<QueueJob, String> broadcast, String message) {
        job.updateProgress(message);
        broadcast.accept(job, "job-progress");
    }

    private void checkCancelled(QueueJob job) {
        if (job.status == QueueJob.Status.CANCELLED) {
            throw new RuntimeException("Job cancelled");
        }
    }
}
