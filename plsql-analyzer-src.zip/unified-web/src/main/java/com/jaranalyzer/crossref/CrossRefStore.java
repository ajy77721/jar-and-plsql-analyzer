package com.jaranalyzer.crossref;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.crossref.model.CrossRefResult;
import com.jaranalyzer.service.JarDataPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Disk I/O for cross-reference run data.
 *
 * Directory layout:
 *   {dataDir}/crossref/{jarId}/{crossRefId}/
 *       meta.json    — request params + timestamp (small, always readable)
 *       result.json  — full CrossRefResult JSON
 *       report.md    — human-readable Markdown comparison report
 *
 * This class is completely independent of FlowRunStore — no shared state, no inheritance.
 */
@Component
public class CrossRefStore {

    private static final Logger log = LoggerFactory.getLogger(CrossRefStore.class);

    private final Path baseCrossRefDir;  // {dataDir}/crossref/
    private final ObjectMapper objectMapper;

    public CrossRefStore(JarDataPaths jarDataPaths, ObjectMapper objectMapper) {
        this.baseCrossRefDir = jarDataPaths.getBaseDir().resolve("crossref");
        this.objectMapper = objectMapper;
    }

    // ── Directory helpers ─────────────────────────────────────────────────────

    public Path createRunDir(String jarId, String crossRefId) throws IOException {
        Path dir = runDir(jarId, crossRefId);
        Files.createDirectories(dir);
        return dir;
    }

    public Path runDir(String jarId, String crossRefId) {
        return baseCrossRefDir.resolve(safe(jarId)).resolve(safe(crossRefId));
    }

    public Path jarCrossRefDir(String jarId) {
        return baseCrossRefDir.resolve(safe(jarId));
    }

    // ── meta.json ─────────────────────────────────────────────────────────────

    public void writeMeta(Path runDir, String crossRefId, String jarId,
                          String endpointPath, String procName, String schema, String mode) {
        try {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("crossRefId", crossRefId);
            m.put("jarId", jarId);
            m.put("endpointPath", endpointPath);
            m.put("procName", procName);
            m.put("schema", schema);
            m.put("mode", mode);
            m.put("timestamp", System.currentTimeMillis());
            Files.write(metaFile(runDir), objectMapper.writeValueAsBytes(m),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            log.warn("CrossRefStore: failed to write meta.json for {}: {}", crossRefId, e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> readMeta(Path runDir) {
        Path f = metaFile(runDir);
        if (!Files.exists(f)) return null;
        try {
            return objectMapper.readValue(f.toFile(), Map.class);
        } catch (Exception e) {
            log.debug("CrossRefStore: cannot read meta.json at {}: {}", f, e.getMessage());
            return null;
        }
    }

    // ── result.json ───────────────────────────────────────────────────────────

    public void writeResult(Path runDir, CrossRefResult result) {
        try {
            byte[] bytes = objectMapper.writeValueAsBytes(result);
            Files.write(resultFile(runDir), bytes,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.warn("CrossRefStore: failed to write result.json: {}", e.getMessage());
        }
    }

    public CrossRefResult readResult(Path runDir) {
        Path f = resultFile(runDir);
        if (!Files.exists(f)) return null;
        try {
            return objectMapper.readValue(f.toFile(), CrossRefResult.class);
        } catch (Exception e) {
            log.warn("CrossRefStore: cannot parse result.json at {}: {}", f, e.getMessage());
            return null;
        }
    }

    public String readResultRaw(Path runDir) {
        Path f = resultFile(runDir);
        if (!Files.exists(f)) return null;
        try {
            return Files.readString(f, StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.warn("CrossRefStore: cannot read result.json: {}", e.getMessage());
            return null;
        }
    }

    // ── report.md ─────────────────────────────────────────────────────────────

    public void writeReport(Path runDir, String markdown) {
        try {
            Files.writeString(reportFile(runDir), markdown, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.warn("CrossRefStore: failed to write report.md: {}", e.getMessage());
        }
    }

    public byte[] readReport(Path runDir) {
        Path f = reportFile(runDir);
        if (!Files.exists(f)) return null;
        try {
            return Files.readAllBytes(f);
        } catch (IOException e) {
            log.warn("CrossRefStore: cannot read report.md: {}", e.getMessage());
            return null;
        }
    }

    // ── History scan ──────────────────────────────────────────────────────────

    /**
     * Lists all cross-ref runs for a given jar, newest first.
     * Each entry is the meta.json content plus a "crossRefId" field.
     */
    public List<Map<String, Object>> listHistory(String jarId) {
        Path dir = jarCrossRefDir(jarId);
        if (!Files.isDirectory(dir)) return List.of();
        List<Map<String, Object>> entries = new ArrayList<>();
        try (var stream = Files.list(dir)) {
            stream.filter(Files::isDirectory)
                  .forEach(runDir -> {
                      Map<String, Object> m = readMeta(runDir);
                      if (m != null) {
                          m.computeIfAbsent("crossRefId", k -> runDir.getFileName().toString());
                          entries.add(m);
                      }
                  });
        } catch (IOException e) {
            log.debug("CrossRefStore: cannot list cross-ref dirs for jar {}: {}", jarId, e.getMessage());
        }
        entries.sort((a, b) -> {
            long ta = toLong(a.get("timestamp"));
            long tb = toLong(b.get("timestamp"));
            return Long.compare(tb, ta);
        });
        return entries;
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    public boolean delete(String jarId, String crossRefId) {
        Path dir = runDir(jarId, crossRefId);
        if (!Files.isDirectory(dir)) return false;
        try {
            deleteRecursively(dir);
            return true;
        } catch (IOException e) {
            log.warn("CrossRefStore: failed to delete run {}/{}: {}", jarId, crossRefId, e.getMessage());
            return false;
        }
    }

    private void deleteRecursively(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            try (var s = Files.list(path)) {
                for (Path child : s.toList()) deleteRecursively(child);
            }
        }
        Files.deleteIfExists(path);
    }

    // ── Internal file path helpers ────────────────────────────────────────────

    public Path metaFile(Path runDir)   { return runDir.resolve("meta.json"); }
    public Path resultFile(Path runDir) { return runDir.resolve("result.json"); }
    public Path reportFile(Path runDir) { return runDir.resolve("report.md"); }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private static String safe(String s) {
        return s == null ? "_" : s.replaceAll("[^a-zA-Z0-9._\\-]", "_");
    }

    private static long toLong(Object v) {
        if (v instanceof Number n) return n.longValue();
        if (v instanceof String s) {
            try { return Long.parseLong(s); } catch (NumberFormatException ignored) {}
        }
        return 0L;
    }
}
