package com.jaranalyzer.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.service.ConversionService;
import com.plsqlanalyzer.web.config.ConfigDirService;
import com.plsqlanalyzer.web.service.ClaudeProcessRunner;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.Stream;

/**
 * Oracle PL/SQL → Java conversion feature.
 *
 * Routes:
 *   POST /api/conversion/convert|validate|fix  — start job
 *   GET  /api/conversion/jobs/{id}             — poll status + live output
 *   GET  /api/conversion/jobs                  — list recent jobs
 *   GET  /api/conversion/claude-status         — check Claude CLI
 *
 * Observability: streams Claude stdout line-by-line into job state in real time.
 * Persistence:   jobs saved to data/conversion/ on every update — survive restart/refresh.
 */
@RestController
@RequestMapping("/api/conversion")
public class ConversionController {

    private static final Logger log = LoggerFactory.getLogger(ConversionController.class);

    private static final int MAX_LIVE_LINES  = 2000;  // rolling buffer cap
    private static final int STREAM_DRAIN_MS = 15_000;
    private static final int TIMEOUT_SEC     = 900;   // 15 min max

    private final ConversionService conversionService;
    private final ClaudeProcessRunner claudeRunner;
    private final ObjectMapper mapper;
    private final ConfigDirService configDirService;

    private final ConcurrentHashMap<String, JobState> jobs = new ConcurrentHashMap<>();
    private final AtomicLong counter = new AtomicLong(1);
    private Path jobsDir;

    public ConversionController(ConversionService conversionService,
                                @Qualifier("plsqlClaudeProcessRunner") ClaudeProcessRunner claudeRunner,
                                ObjectMapper mapper,
                                ConfigDirService configDirService) {
        this.conversionService  = conversionService;
        this.claudeRunner       = claudeRunner;
        this.mapper             = mapper;
        this.configDirService   = configDirService;
    }

    @PostConstruct
    void init() {
        jobsDir = configDirService.getDataDir().resolve("conversion");
        try { Files.createDirectories(jobsDir); } catch (IOException ignored) {}
        loadPersistedJobs();
    }

    // ── Claude availability ───────────────────────────────────────────────────

    @GetMapping("/claude-status")
    public Map<String, Object> claudeStatus() {
        boolean ok = claudeRunner.isAvailable();
        return Map.of("available", ok,
            "message", ok ? "Claude CLI ready" : "Claude CLI not found — run `claude login` first");
    }

    // ── Job list / status ─────────────────────────────────────────────────────

    @GetMapping("/jobs")
    public List<Map<String, Object>> listJobs() {
        List<Map<String, Object>> result = new ArrayList<>();
        jobs.values().stream()
            .sorted(Comparator.comparing(j -> -j.startedAt))
            .limit(50)
            .forEach(j -> result.add(j.toMap(false)));
        return result;
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<Map<String, Object>> jobStatus(@PathVariable String jobId) {
        JobState s = jobs.get(jobId);
        if (s == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(s.toMap(true));
    }

    @GetMapping("/jobs/{jobId}/report")
    public ResponseEntity<Map<String, Object>> jobReport(@PathVariable String jobId) {
        JobState s = jobs.get(jobId);
        if (s == null) return ResponseEntity.notFound().build();
        if (s.reportPath == null || s.reportPath.isBlank())
            return ResponseEntity.ok(Map.of("found", false, "error", "No report path recorded yet"));

        String projectPath = s.req != null ? s.req.projectPath() : null;
        try {
            Path report;
            if (java.nio.file.Paths.get(s.reportPath).isAbsolute()) {
                report = java.nio.file.Paths.get(s.reportPath).normalize();
            } else if (projectPath != null && !projectPath.isBlank()) {
                report = java.nio.file.Paths.get(projectPath).resolve(s.reportPath).normalize();
            } else {
                return ResponseEntity.ok(Map.of("found", false, "error",
                    "Report path is relative but no project path was set: " + s.reportPath));
            }
            if (!Files.exists(report))
                return ResponseEntity.ok(Map.of("found", false, "error",
                    "File not found: " + report, "path", report.toString()));
            String content = Files.readString(report, java.nio.charset.StandardCharsets.UTF_8);
            return ResponseEntity.ok(Map.of("found", true, "content", content, "path", report.toString()));
        } catch (IOException e) {
            return ResponseEntity.ok(Map.of("found", false, "error", e.getMessage()));
        }
    }

    // ── Start jobs ────────────────────────────────────────────────────────────

    @PostMapping("/convert")  public Map<String, Object> convert (@RequestBody ConversionRequest req) { return startJob("convert",  req); }
    @PostMapping("/validate") public Map<String, Object> validate(@RequestBody ConversionRequest req) { return startJob("validate", req); }
    @PostMapping("/fix")      public Map<String, Object> fix     (@RequestBody ConversionRequest req) { return startJob("fix",      req); }

    // ── Internal ──────────────────────────────────────────────────────────────

    private Map<String, Object> startJob(String action, ConversionRequest req) {
        String jobId = String.valueOf(counter.getAndIncrement());
        JobState state = new JobState(jobId, action, req);
        jobs.put(jobId, state);
        persistJob(state);

        Thread t = new Thread(() -> runJob(state, action, req), "conversion-" + jobId);
        t.setDaemon(true);
        t.start();

        return Map.of("jobId", jobId, "status", "running");
    }

    private void runJob(JobState state, String action, ConversionRequest req) {
        try {
            state.setPhase("Preparing instruction");
            state.addLog("⏳ Building Claude instruction file…");

            String instructionMd = conversionService.buildInstruction(action, req);
            state.instructionMd = instructionMd;
            state.addLog("✓ Instruction ready — " + instructionMd.length() + " chars");
            persistJob(state);

            if (!claudeRunner.isAvailable()) {
                state.fail("Claude CLI not available — run `claude login` first.");
                persistJob(state);
                return;
            }

            state.setPhase("Invoking Claude CLI");
            state.addLog("🤖 Claude CLI started (timeout: " + TIMEOUT_SEC + "s)…");
            persistJob(state);

            // Stream Claude stdout live using our own ProcessBuilder
            boolean ok = runClaudeStreaming(instructionMd, state);

            if (!ok) {
                if (!"failed".equals(state.status)) {
                    state.fail("Claude CLI returned no output or timed out.");
                    persistJob(state);
                }
                return;
            }

            // Extract report path from collected output
            state.reportPath = conversionService.extractReportPath(
                String.join("\n", state.liveLines), req);

            state.addLog("✅ Done — " + state.liveLines.size() + " output lines");
            state.complete();
            persistJob(state);

        } catch (Exception e) {
            log.error("Conversion job {} failed", state.jobId, e);
            state.fail("Error: " + e.getMessage());
            persistJob(state);
        }
    }

    /**
     * Run Claude CLI using --verbose --output-format stream-json so events arrive
     * line-by-line in real time (without a TTY Claude buffers all output until exit).
     *
     * Each JSON line is parsed and converted to a human-readable string that is
     * appended to state.liveLines so the UI can display it live.
     *
     * Event types emitted by Claude:
     *   system/init       — session bootstrap (ignored, just logs model)
     *   assistant         — text or tool-use blocks from Claude
     *   tool_result       — output from a tool call
     *   result            — final summary line (contains the full result text)
     *   error             — error event
     */
    private boolean runClaudeStreaming(String prompt, JobState state) {
        List<String> cmd = new ArrayList<>(List.of("claude",
            "--allowedTools", "Read,Grep,Glob,Bash,Write,Edit",
            "-p", "--no-session-persistence",
            "--verbose", "--output-format", "stream-json"));

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(false);

        Process process = null;
        try {
            process = pb.start();
            final Process proc = process;

            // Write prompt to stdin — must close stream so Claude knows input is done
            byte[] promptBytes = prompt.getBytes(StandardCharsets.UTF_8);
            Thread stdinWriter = new Thread(() -> {
                try (OutputStream os = new BufferedOutputStream(proc.getOutputStream(), 65536)) {
                    int off = 0;
                    while (off < promptBytes.length) {
                        int len = Math.min(8192, promptBytes.length - off);
                        os.write(promptBytes, off, len);
                        off += len;
                    }
                    // flush happens automatically on close via try-with-resources
                } catch (IOException e) {
                    if (!e.getMessage().contains("closed") && !e.getMessage().contains("ended"))
                        log.warn("stdin write error: {}", e.getMessage());
                }
            }, "conv-stdin");
            stdinWriter.setDaemon(true);
            stdinWriter.start();

            // Drain stderr silently (Claude writes some diagnostics there)
            Thread stderrReader = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(
                        new InputStreamReader(proc.getErrorStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (!line.isBlank()) log.debug("[claude stderr] {}", line);
                    }
                } catch (IOException ignored) {}
            }, "conv-stderr");
            stderrReader.setDaemon(true);
            stderrReader.start();

            // Read stream-json events LIVE
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String raw;
                int lineCount = 0;
                while ((raw = r.readLine()) != null) {
                    if (raw.isBlank()) continue;
                    String display = parseStreamEvent(raw);
                    if (display != null) {
                        // Split multi-line display strings so each line is its own entry
                        for (String dl : display.split("\n", -1)) {
                            state.appendLiveLine(dl);
                            updatePhaseFromOutput(state, dl);
                        }
                        lineCount++;
                        if (lineCount % 10 == 0) persistJob(state);
                    }
                }
            }

            boolean finished = process.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                state.fail("Timed out after " + TIMEOUT_SEC + "s");
                return false;
            }

            stderrReader.join(STREAM_DRAIN_MS);

            int exitCode = process.exitValue();
            if (exitCode != 0) {
                state.addLog("⚠ Claude exited with code " + exitCode);
                log.warn("Claude exited with code {}", exitCode);
            }

            return true;

        } catch (IOException e) {
            log.error("Failed to spawn Claude process: {}", e.getMessage());
            state.fail("Cannot start Claude CLI: " + e.getMessage());
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroyForcibly();
            state.fail("Interrupted");
            return false;
        } finally {
            if (process != null && process.isAlive()) process.destroyForcibly();
        }
    }

    /**
     * Parse one stream-json line from Claude CLI into a human-readable string,
     * or return null to suppress it from the live feed.
     */
    @SuppressWarnings("unchecked")
    private String parseStreamEvent(String json) {
        try {
            Map<String, Object> ev = mapper.readValue(json, Map.class);
            String type = (String) ev.getOrDefault("type", "");

            return switch (type) {
                case "system" -> {
                    // init event — show model name
                    String sub = (String) ev.getOrDefault("subtype", "");
                    if ("init".equals(sub)) {
                        String model = (String) ev.getOrDefault("model", "");
                        yield "🤖 Session started — model: " + model;
                    }
                    yield null;
                }
                case "assistant" -> {
                    // Extract text and tool-use blocks
                    Object msgObj = ev.get("message");
                    if (!(msgObj instanceof Map)) yield null;
                    Map<String, Object> msg = (Map<String, Object>) msgObj;
                    Object contentObj = msg.get("content");
                    if (!(contentObj instanceof List)) yield null;
                    List<Map<String, Object>> content = (List<Map<String, Object>>) contentObj;
                    StringBuilder sb = new StringBuilder();
                    for (Map<String, Object> block : content) {
                        String btype = (String) block.getOrDefault("type", "");
                        if ("text".equals(btype)) {
                            String text = (String) block.getOrDefault("text", "");
                            if (!text.isBlank()) sb.append(text);
                        } else if ("tool_use".equals(btype)) {
                            String name   = (String) block.getOrDefault("name", "?");
                            Object input  = block.get("input");
                            String detail = "";
                            if (input instanceof Map<?,?> inp) {
                                // Show the most useful field: command, path, pattern, etc.
                                detail = Stream.of("command","path","pattern","query","file_path","glob")
                                    .filter(k -> inp.containsKey(k) && inp.get(k) != null)
                                    .map(k -> inp.get(k).toString())
                                    .findFirst().orElse("");
                            }
                            sb.append("\n🔧 [").append(name).append("] ")
                              .append(detail.length() > 120 ? detail.substring(0, 120) + "…" : detail);
                        }
                    }
                    String out = sb.toString().stripTrailing();
                    yield out.isBlank() ? null : out;
                }
                case "tool_result" -> {
                    // Show a compact summary of what the tool returned
                    Object content = ev.get("content");
                    String text = "";
                    if (content instanceof String s) {
                        text = s;
                    } else if (content instanceof List<?> list && !list.isEmpty()) {
                        Object first = list.get(0);
                        if (first instanceof Map<?,?>) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> m = (Map<String, Object>) first;
                            text = String.valueOf(m.getOrDefault("text", ""));
                        }
                    }
                    if (text.isBlank()) yield null;
                    // Trim long output — first 3 lines
                    String[] lines = text.split("\n", 4);
                    String preview = String.join("\n", java.util.Arrays.copyOf(lines, Math.min(3, lines.length)));
                    if (lines.length > 3) preview += "\n  … +" + (text.split("\n").length - 3) + " more lines";
                    yield "  ↳ " + preview.trim();
                }
                case "result" -> {
                    boolean isErr = Boolean.TRUE.equals(ev.get("is_error"));
                    String res = (String) ev.getOrDefault("result", "");
                    Object dur = ev.getOrDefault("duration_ms", 0);
                    String time = dur instanceof Number n ? (n.longValue() / 1000) + "s" : "";
                    if (isErr) yield "❌ Claude error: " + res;
                    yield "✅ Completed in " + time + (res != null && !res.isBlank() ? "\n" + res : "");
                }
                default -> null;
            };
        } catch (Exception e) {
            log.debug("Could not parse stream event: {}", json.length() > 80 ? json.substring(0,80) : json);
            return null;
        }
    }

    private void updatePhaseFromOutput(JobState state, String line) {
        String lo = line.toLowerCase();
        if (lo.contains("phase 0") || lo.contains("loading claude.md"))
            state.setPhase("Phase 0 — Loading project context");
        else if (lo.contains("phase 0b") || lo.contains("dependency tree"))
            state.setPhase("Phase 0B — Building dependency tree");
        else if (lo.contains("phase 1") && lo.contains("fetch"))
            state.setPhase("Phase 1 — Fetching Oracle source");
        else if (lo.contains("phase 1b") || lo.contains("chunk"))
            state.setPhase("Phase 1B — Chunked analysis");
        else if (lo.contains("phase 2") || lo.contains("decompos"))
            state.setPhase("Phase 2 — Decomposing Oracle logic");
        else if (lo.contains("phase 3") || lo.contains("locating java"))
            state.setPhase("Phase 3 — Locating Java files");
        else if (lo.contains("phase 4") || lo.contains("coverage mapping"))
            state.setPhase("Phase 4 — Logic coverage mapping");
        else if (lo.contains("phase 5") || lo.contains("validate.sh"))
            state.setPhase("Phase 5 — Running validate.sh");
        else if (lo.contains("sonar"))
            state.setPhase("Phase 5B — SonarQube analysis");
        else if (lo.contains("phase 6") || lo.contains("test coverage"))
            state.setPhase("Phase 6 — Test coverage analysis");
        else if (lo.contains("phase 7") || lo.contains("writing report") || lo.contains("validation_report"))
            state.setPhase("Phase 7 — Writing report");
        else if (lo.contains("phase 8") || lo.contains("completion summary"))
            state.setPhase("Phase 8 — Summary");
        else if (lo.contains("applying fix") || lo.contains("fix applied"))
            state.setPhase("Applying fixes");
        else if (lo.contains("mvn") && lo.contains("compile"))
            state.setPhase("Compiling");
        else if (lo.contains("implementing") || lo.contains("generating"))
            state.setPhase("Generating Java code");
    }

    // ── Persistence ───────────────────────────────────────────────────────────

    private void persistJob(JobState state) {
        if (jobsDir == null) return;
        try {
            Path file = jobsDir.resolve(state.jobId + ".json");
            mapper.writeValue(file.toFile(), state.toMap(true));
        } catch (IOException e) {
            log.warn("Failed to persist job {}: {}", state.jobId, e.getMessage());
        }
    }

    private void loadPersistedJobs() {
        if (jobsDir == null || !Files.isDirectory(jobsDir)) return;
        try (var stream = Files.list(jobsDir)) {
            stream.filter(p -> p.toString().endsWith(".json"))
                  .forEach(p -> {
                      try {
                          @SuppressWarnings("unchecked")
                          Map<String, Object> m = mapper.readValue(p.toFile(), Map.class);
                          JobState s = JobState.fromMap(m);
                          jobs.put(s.jobId, s);
                          long id = Long.parseLong(s.jobId);
                          counter.updateAndGet(c -> Math.max(c, id + 1));
                          // Mark in-flight jobs as interrupted
                          if ("running".equals(s.status)) {
                              s.status = "interrupted";
                              s.phase  = "Interrupted — server restarted";
                              s.addLog("⚠ Job interrupted by server restart");
                          }
                      } catch (Exception e) {
                          log.debug("Could not load persisted job {}: {}", p.getFileName(), e.getMessage());
                      }
                  });
        } catch (IOException e) {
            log.warn("Could not list conversion jobs dir: {}", e.getMessage());
        }
        log.info("Loaded {} persisted conversion jobs", jobs.size());
    }

    // ── Models ────────────────────────────────────────────────────────────────

    public record ConversionRequest(
        String procedure, String module, String service, String controller,
        String owner, String projectPath, String jarId, boolean batch
    ) {}

    static class JobState {
        String jobId;
        String action;
        ConversionRequest req;
        long startedAt = System.currentTimeMillis();

        volatile String phase  = "Initializing";
        volatile String status = "running";
        volatile String reportPath;
        volatile String instructionMd;
        volatile String error;

        final CopyOnWriteArrayList<String> log      = new CopyOnWriteArrayList<>();
        final CopyOnWriteArrayList<String> liveLines = new CopyOnWriteArrayList<>();

        JobState(String jobId, String action, ConversionRequest req) {
            this.jobId  = jobId;
            this.action = action;
            this.req    = req;
        }

        void addLog(String msg)         { log.add(msg); }
        void setPhase(String p)         { this.phase = p; }
        void appendLiveLine(String line) {
            liveLines.add(line);
            if (liveLines.size() > MAX_LIVE_LINES) {
                liveLines.remove(0);
            }
        }
        void complete() { this.status = "done";   this.phase = "Complete"; }
        void fail(String msg) {
            this.status = "failed"; this.phase = "Failed";
            log.add("❌ " + msg); this.error = msg;
        }

        Map<String, Object> toMap(boolean includeLive) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("jobId",       jobId);
            m.put("action",      action);
            m.put("procedure",   req != null ? req.procedure()   : "");
            m.put("module",      req != null ? req.module()      : "");
            m.put("projectPath", req != null && req.projectPath() != null ? req.projectPath() : "");
            m.put("status",      status);
            m.put("phase",       phase);
            m.put("log",         new ArrayList<>(log));
            m.put("startedAt",   startedAt);
            m.put("elapsedMs",   System.currentTimeMillis() - startedAt);
            if (includeLive)     m.put("liveLines",    new ArrayList<>(liveLines));
            if (reportPath    != null) m.put("reportPath",    reportPath);
            if (instructionMd != null) m.put("instructionMd", instructionMd);
            if (error         != null) m.put("error",         error);
            return m;
        }

        @SuppressWarnings("unchecked")
        static JobState fromMap(Map<String, Object> m) {
            String jobId  = (String) m.getOrDefault("jobId",  "?");
            String action = (String) m.getOrDefault("action", "?");
            String proc   = (String) m.getOrDefault("procedure",   "");
            String mod    = (String) m.getOrDefault("module",      "");
            String path   = (String) m.getOrDefault("projectPath", "");
            ConversionRequest req = new ConversionRequest(proc, mod, null, null, null, path, null, false);
            JobState s = new JobState(jobId, action, req);
            s.phase  = (String) m.getOrDefault("phase",  "Unknown");
            s.status = (String) m.getOrDefault("status", "unknown");
            s.reportPath    = (String) m.get("reportPath");
            s.instructionMd = (String) m.get("instructionMd");
            s.error         = (String) m.get("error");
            Object st = m.get("startedAt");
            if (st instanceof Number n) s.startedAt = n.longValue();
            List<String> logs = (List<String>) m.get("log");
            if (logs != null) s.log.addAll(logs);
            List<String> live = (List<String>) m.get("liveLines");
            if (live != null) s.liveLines.addAll(live);
            return s;
        }
    }
}
