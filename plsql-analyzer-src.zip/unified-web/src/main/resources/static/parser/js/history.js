PA._allHistory = [];
PA._historySearchQuery = '';

PA.quickSubmit = {
    toggle() {
        var panel = document.getElementById('quickSubmitPanel');
        if (!panel) return;
        var shown = panel.style.display !== 'none';
        panel.style.display = shown ? 'none' : '';
        if (!shown) {
            var ta = document.getElementById('quickSubmitInput');
            if (ta) ta.focus();
        }
    },
    close() {
        var panel = document.getElementById('quickSubmitPanel');
        if (panel) panel.style.display = 'none';
    },
    async submitAll() {
        var ta = document.getElementById('quickSubmitInput');
        var statusEl = document.getElementById('quickSubmitStatus');
        var resultsEl = document.getElementById('quickSubmitResults');
        if (!ta) return;

        var lines = ta.value.split('\n').map(function(l) { return l.trim(); }).filter(function(l) { return l.length > 0; });
        if (lines.length === 0) { if (statusEl) statusEl.textContent = 'Nothing to submit'; return; }

        var formData = PA.home ? PA.home.getFormData() : {};
        if (statusEl) statusEl.textContent = 'Submitting ' + lines.length + ' job(s)…';
        if (resultsEl) resultsEl.innerHTML = '';

        var submitted = 0, failed = 0;
        var resultHtml = '';
        for (var i = 0; i < lines.length; i++) {
            var entry = lines[i];
            // Parse SCHEMA.PKG.PROC or PKG.PROC or PROC
            var parts = entry.split('.');
            var entryPoint = parts[parts.length - 1];
            var owner = formData.owner || '';
            // If 3 parts: SCHEMA.PKG → entryPoint = PKG.PROC, owner = SCHEMA
            if (parts.length === 3) {
                entryPoint = parts[1] + '.' + parts[2];
                if (!owner) owner = parts[0].toUpperCase();
            } else if (parts.length === 2) {
                entryPoint = entry; // PKG.PROC
            }

            var body = { entryPoint: entryPoint };
            if (owner) body.owner = owner;
            if (formData.project) body.project = formData.project;
            if (formData.environment) body.environment = formData.environment;
            // Forward dialect context so non-Oracle batches are not treated as Oracle.
            if (formData.dbType) body.dbType = formData.dbType;
            if (formData.connName) body.connName = formData.connName;
            // Use the selected object type; only default to PACKAGE for Oracle.
            body.objectType = formData.objectType
                || ((formData.dbType && formData.dbType !== 'ORACLE') ? 'PROCEDURE' : 'PACKAGE');

            try {
                var resp = await PA.api.runAnalysis(entryPoint, body);
                if (resp && resp.error) {
                    failed++;
                    resultHtml += '<div style="color:#f87171">&#10005; ' + PA.esc(entry) + ': ' + PA.esc(resp.error) + '</div>';
                } else {
                    submitted++;
                    resultHtml += '<div style="color:#4ade80">&#10003; ' + PA.esc(entry) + ' queued</div>';
                }
            } catch (e) {
                failed++;
                resultHtml += '<div style="color:#f87171">&#10005; ' + PA.esc(entry) + ': ' + PA.esc(e.message || 'error') + '</div>';
            }
        }

        if (statusEl) statusEl.textContent = submitted + ' queued' + (failed > 0 ? ', ' + failed + ' failed' : '');
        if (resultsEl) resultsEl.innerHTML = resultHtml;

        if (submitted > 0) {
            PA.switchHomeTab('queue');
            PA.toast(submitted + ' job(s) submitted to queue', 'success');
        }
    }
};

PA.loadHistory = async function() {
    try {
        var hist = await PA.api.listHistory();
        PA._allHistory = hist || [];
        PA._renderFilteredHistory();
        if (document.getElementById('homeTabPerfSummary') && document.getElementById('homeTabPerfSummary').style.display !== 'none') {
            PA.perfSummary.render();
        }
    } catch (e) {
        document.getElementById('historyList').innerHTML = '<div class="empty-msg">Could not load history</div>';
    }
};

PA._historyDsFilter = '';
PA._historyProjFilter = '';

// Datasource dialect from the persisted jdbcUrl (same rule as Performance Summary).
PA._dialectOf = function(item) {
    var u = (item.jdbcUrl || '').toLowerCase();
    if (u.indexOf('sqlserver') >= 0) return 'SQLSERVER';
    if (u.indexOf('oracle') >= 0)    return 'ORACLE';
    if (u.indexOf('mysql') >= 0)     return 'MYSQL';
    if (u.indexOf('db2') >= 0)       return 'DB2';
    if (u.indexOf('postgresql') >= 0) return 'POSTGRES';
    return (item.dbType || '').toUpperCase() || '—';
};
PA._DS_LABEL = { ORACLE: 'Oracle', SQLSERVER: 'SQL Server', MYSQL: 'MySQL', DB2: 'Db2', POSTGRES: 'PostgreSQL' };

PA.onHistorySearch = function(q) {
    PA._historySearchQuery = (q || '').toUpperCase();
    PA._renderFilteredHistory();
};
PA.onHistoryDs = function(v) {
    PA._historyDsFilter = v;
    if (!v) {
        // Datasource = All → reset project to All too.
        PA._historyProjFilter = '';
    } else {
        // Cascade: if the selected project doesn't belong to this datasource, clear it.
        var p = PA._historyProjFilter;
        if (p && PA._historyProjToDs && PA._historyProjToDs[p] !== v) PA._historyProjFilter = '';
    }
    PA._renderFilteredHistory();
};
PA.onHistoryProj = function(v) {
    PA._historyProjFilter = v;
    // Cascade: selecting a project auto-sets its datasource (a project has exactly one).
    if (v && PA._historyProjToDs && PA._historyProjToDs[v]) PA._historyDsFilter = PA._historyProjToDs[v];
    PA._renderFilteredHistory();
};

PA._renderHistoryFilters = function() {
    var host = document.getElementById('historyFilters');
    if (!host) return;
    var list = PA._allHistory || [];
    var dsSeen = {}, projToDs = {};
    list.forEach(function(it) {
        var dl = PA._dialectOf(it);
        dsSeen[dl] = 1;
        if (it.project) projToDs[it.project] = dl;   // project -> its datasource
    });
    PA._historyProjToDs = projToDs;
    // Drop a stale filter whose value no longer exists in the reloaded data, so the dropdown's
    // visible "All" matches what actually gets filtered (avoids a confusing empty list).
    if (PA._historyDsFilter && !dsSeen[PA._historyDsFilter]) PA._historyDsFilter = '';
    if (PA._historyProjFilter && !projToDs[PA._historyProjFilter]) PA._historyProjFilter = '';
    var ds = '<option value="">All datasources</option>';
    ['ORACLE', 'SQLSERVER', 'MYSQL', 'DB2'].forEach(function(k) {
        if (dsSeen[k]) ds += '<option value="' + k + '"' + (PA._historyDsFilter === k ? ' selected' : '') + '>' + PA._DS_LABEL[k] + '</option>';
    });
    var pr = '<option value="">All projects</option>';
    Object.keys(projToDs).sort().forEach(function(p) {
        // Cascade: when a datasource is selected, only list projects under it.
        if (PA._historyDsFilter && projToDs[p] !== PA._historyDsFilter) return;
        pr += '<option value="' + PA.esc(p) + '"' + (PA._historyProjFilter === p ? ' selected' : '') + '>' + PA.esc(p) + '</option>';
    });
    host.innerHTML = '<select class="ps-filter-select" onchange="PA.onHistoryDs(this.value)">' + ds + '</select>'
                   + '<select class="ps-filter-select" onchange="PA.onHistoryProj(this.value)">' + pr + '</select>';
};

PA._renderFilteredHistory = function() {
    var container = document.getElementById('historyList');
    var countEl = document.getElementById('historyCount');
    PA._renderHistoryFilters();
    var list = PA._allHistory || [];
    var q = PA._historySearchQuery, ds = PA._historyDsFilter, proj = PA._historyProjFilter;
    list = list.filter(function(item) {
        if (ds && PA._dialectOf(item) !== ds) return false;
        if (proj && item.project !== proj) return false;
        if (q) {
            var txt = ((item.entryPoint || '') + ' ' + (item.entrySchema || '') + ' ' + (item.name || '') + ' ' + (item.connectionName || '') + ' ' + (item.project || '')).toUpperCase();
            if (!txt.includes(q)) return false;
        }
        return true;
    });
    if (countEl) countEl.textContent = list.length;

    if (list.length === 0) {
        container.innerHTML = '<div class="empty-msg">No analyses found</div>';
        return;
    }

    var html = '';
    for (var i = 0; i < list.length; i++) {
        var item = list[i];
        var entry = item.entryPoint || item.name || '';
        var schema = item.entrySchema || '';
        var ts = item.timestamp ? new Date(item.timestamp).toLocaleString() : '';
        var procs = item.totalNodes || 0;
        var tables = item.totalTables || 0;
        var loc = item.totalLinesOfCode || 0;
        var errors = (item.errors && item.errors.length) || 0;
        var duration = PA.formatDurationShort(item.totalDurationMs || item.crawlTimeMs);
        var proj = item.project || '';
        var env = item.environment || '';
        var connName = item.connectionName || '';

        html += '<div class="history-card" onclick="PA.loadAnalysis(\'' + PA.escJs(item.name) + '\')">';
        html += '<div class="hc-info">';
        html += '<div class="hc-title">' + PA.esc(entry);
        if (schema) html += ' <span style="color:var(--text-muted);font-size:11px">(' + PA.esc(schema) + ')</span>';
        html += '</div>';
        if (proj || env) {
            html += '<div class="hc-env">';
            html += '<span class="hc-env-badge ds">' + PA.esc(PA._DS_LABEL[PA._dialectOf(item)] || PA._dialectOf(item)) + '</span>';
            if (proj) html += '<span class="hc-env-badge proj">' + PA.esc(proj) + '</span>';
            if (env) html += '<span class="hc-env-badge env">' + PA.esc(env) + '</span>';
            if (connName) html += '<span class="hc-env-badge conn">' + PA.esc(connName) + '</span>';
            html += '</div>';
        }
        if (ts) html += '<div class="hc-meta">' + PA.esc(ts) + '</div>';
        html += '<div class="hc-stats">' + procs + ' procs | ' + tables + ' tables | ' + loc.toLocaleString() + ' LOC';
        if (duration) html += ' | ' + PA.esc(duration);
        if (errors > 0) html += ' | <span style="color:#ef4444">' + errors + ' errors</span>';
        html += '</div></div>';
        html += '<div class="hc-actions">';
        html += '<button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); PA.loadAnalysis(\'' + PA.escJs(item.name) + '\')">Load</button>';
        html += '<button class="btn btn-sm btn-danger" onclick="event.stopPropagation(); PA.deleteAnalysis(\'' + PA.escJs(item.name) + '\')">Delete</button>';
        html += '</div></div>';
    }
    container.innerHTML = html;
};

PA.deleteAnalysis = async function(name) {
    if (!confirm('Delete analysis "' + name + '"?')) return;
    try {
        var res = await fetch('/api/parser/analyses/' + encodeURIComponent(name), { method: 'DELETE' });
        if (res.ok) {
            PA.toast('Deleted: ' + name, 'success');
            PA._allHistory = (PA._allHistory || []).filter(function(item) { return item.name !== name; });
            PA._renderFilteredHistory();
        } else {
            PA.toast('Could not delete', 'error');
        }
    } catch (e) {
        PA.toast('Delete failed: ' + (e.message || e), 'error');
    }
};

PA.startAnalysis = async function() {
    var formData = PA.home ? PA.home.getFormData() : {};
    var entryPoint = formData.entryPoint || '';
    if (!entryPoint) {
        var objectInput = document.getElementById('homeObject');
        entryPoint = objectInput ? objectInput.value.trim() : '';
    }
    if (!entryPoint) {
        PA.toast('Enter an object name (e.g. PKG_CUSTOMER or SCHEMA.PKG_NAME)', 'error');
        return;
    }

    var prog = document.getElementById('homeProgress');
    var progText = document.getElementById('homeProgressText');
    var progFill = document.getElementById('homeProgressFill');
    if (prog) { prog.style.display = 'block'; }
    if (progFill) progFill.style.width = '5%';
    if (progText) progText.textContent = 'Queuing ' + entryPoint + '...';

    try {
        var body = { entryPoint: entryPoint };
        if (formData.owner)       body.owner       = formData.owner;
        if (formData.objectType)  body.objectType  = formData.objectType;
        if (formData.project)     body.project     = formData.project;
        if (formData.environment) body.environment = formData.environment;
        if (formData.dbType)      body.dbType      = formData.dbType;
        if (formData.connName)    body.connName    = formData.connName;

        var resp = await PA.api.runAnalysis(entryPoint, body);
        if (resp && resp.error) { if (prog) prog.style.display = 'none'; PA.toast(resp.error, 'error'); return; }

        // Switch to Queue tab so user can watch progress
        PA.switchHomeTab('queue');

        var jobId = resp && resp.jobId;
        if (!jobId) {
            // Unexpected non-queued response — treat as instant complete (backward compat)
            if (prog) prog.style.display = 'none';
            PA.toast('Analysis submitted', 'success');
            await PA.loadHistory();
            return;
        }

        if (progText) progText.textContent = 'Queued — waiting to start...';
        if (progFill) progFill.style.width = '10%';

        // Poll job status via SSE until done
        await PA._waitForJob(jobId, prog, progText, progFill);

    } catch (e) {
        if (prog) prog.style.display = 'none';
        PA.toast('Failed: ' + (e.message || e), 'error');
    }
};

PA._waitForJob = function(jobId, prog, progText, progFill) {
    return new Promise(function(resolve) {
        var es = null;
        var done = false;

        function finish(resultName, failed, errMsg) {
            if (done) return;
            done = true;
            if (es) { try { es.close(); } catch(e){} es = null; }
            if (prog) prog.style.display = 'none';
            if (failed) {
                PA.toast('Analysis failed: ' + (errMsg || 'unknown error'), 'error');
            } else {
                PA.toast('Analysis complete', 'success');
            }
            PA.loadHistory().then(function() {
                if (resultName) PA.loadAnalysis(resultName);
            });
            resolve();
        }

        function poll() {
            fetch('/api/queue/' + encodeURIComponent(jobId))
                .then(function(r) { return r.json(); })
                .then(function(job) {
                    var status = (job.status || '').toUpperCase();
                    var pct = job.progressPercent || 0;
                    if (progFill) progFill.style.width = Math.max(10, pct) + '%';
                    if (progText) progText.textContent = job.currentStep || job.lastMessage || 'Running...';
                    if (status === 'COMPLETE') {
                        if (progFill) progFill.style.width = '100%';
                        finish(job.resultName, false, null);
                    } else if (status === 'FAILED' || status === 'CANCELLED') {
                        finish(null, true, job.error || status);
                    }
                })
                .catch(function() {});
        }

        // Listen for SSE queue events; fall back to polling
        try {
            es = new EventSource('/api/queue/events');
            var handleEvent = function(e) {
                try {
                    var data = JSON.parse(e.data);
                    if (!data || data.id !== jobId) return;
                    var status = (data.status || '').toUpperCase();
                    var pct = data.progressPercent || 0;
                    if (progFill) progFill.style.width = Math.max(10, pct) + '%';
                    if (progText) progText.textContent = data.currentStep || data.lastMessage || 'Running...';
                    if (status === 'COMPLETE') {
                        if (progFill) progFill.style.width = '100%';
                        finish(data.resultName, false, null);
                    } else if (status === 'FAILED' || status === 'CANCELLED') {
                        finish(null, true, data.error || status);
                    }
                } catch(ex) {}
            };
            ['job-progress', 'job-complete', 'job-failed'].forEach(function(evt) {
                es.addEventListener(evt, handleEvent);
            });
            es.onerror = function() {
                try { es.close(); } catch(e){} es = null;
                // Fall back to polling every 2s
                if (!done) {
                    poll();
                    var timer = setInterval(function() {
                        if (done) { clearInterval(timer); return; }
                        poll();
                    }, 2000);
                }
            };
        } catch(e) {
            // SSE not available — poll every 2s
            poll();
            var timer = setInterval(function() {
                if (done) { clearInterval(timer); return; }
                poll();
            }, 2000);
        }
    });
};
