window.PA = window.PA || {};

/**
 * Reusable client-side paginator for parser list/table views.
 *
 * Usage in a view's render():
 *   var pg = PA.pager.slice('myKey', items);          // slice to current page
 *   ...build table rows from pg.pageItems...
 *   container.innerHTML = tableHtml + pg.controls;     // append page controls
 *   PA.pager.register('myKey', function(){ MyView.render(); });  // once is fine (idempotent)
 * On search/filter/scope change call PA.pager.reset('myKey') before render() so paging
 * jumps back to page 1.
 */
PA.pager = {
    _state: {},
    _renderers: {},
    defaultSize: 25,

    get: function (key, size) {
        if (!this._state[key]) this._state[key] = { page: 1, size: size || this.defaultSize };
        return this._state[key];
    },
    reset: function (key) { if (this._state[key]) this._state[key].page = 1; },
    register: function (key, fn) { this._renderers[key] = fn; },

    /** Returns { pageItems, controls, page, pages, total }. */
    slice: function (key, items, size) {
        items = items || [];
        var st = this.get(key, size);
        var total = items.length;
        var pages = Math.max(1, Math.ceil(total / st.size));
        if (st.page > pages) st.page = pages;
        if (st.page < 1) st.page = 1;
        var start = (st.page - 1) * st.size;
        var pageItems = items.slice(start, start + st.size);
        return {
            pageItems: pageItems, page: st.page, pages: pages, total: total,
            controls: this._controls(key, st, total, pages, start, pageItems.length)
        };
    },

    // Emits the SAME markup as the shared PA.tf pager (.pagination-bar / .page-info /
    // .page-size / .page-btns) so it inherits the app's themed pagination.css and looks
    // identical to every other paginated view (light or dark theme).
    _controls: function (key, st, total, pages, start, shown) {
        if (total === 0) return '';
        var end = start + shown;
        function btn(label, page, disabled, active, title) {
            return '<button class="' + (active ? 'active' : '') + '"'
                + (disabled ? ' disabled' : '')
                + (title ? ' title="' + title + '"' : '')
                + ' onclick="PA.pager.go(\'' + key + '\',' + page + ')">' + label + '</button>';
        }
        var sizes = [10, 25, 50, 100].map(function (n) {
            return '<option value="' + n + '"' + (n === st.size ? ' selected' : '') + '>' + n + '/page</option>';
        }).join('') + '<option value="' + total + '"' + (st.size >= total ? ' selected' : '') + '>All</option>';
        var html = '<div class="pagination-bar">'
            + '<div class="page-info">' + (total ? (start + 1) : 0) + '–' + end + ' of ' + total + '</div>'
            + '<div class="page-size"><select onchange="PA.pager.setSize(\'' + key + '\', this.value)">' + sizes + '</select></div>';
        if (pages > 1) {
            var nums = '', win = 2, from = Math.max(1, st.page - win), to = Math.min(pages, st.page + win);
            if (from > 1) { nums += btn('1', 1, false, st.page === 1); if (from > 2) nums += '<span style="padding:0 2px">…</span>'; }
            for (var p = from; p <= to; p++) nums += btn(String(p), p, false, p === st.page);
            if (to < pages) { if (to < pages - 1) nums += '<span style="padding:0 2px">…</span>'; nums += btn(String(pages), pages, false, st.page === pages); }
            html += '<div class="page-btns">'
                + btn('«', 1, st.page <= 1, false, 'First') + btn('‹', st.page - 1, st.page <= 1, false, 'Prev')
                + nums
                + btn('›', st.page + 1, st.page >= pages, false, 'Next') + btn('»', pages, st.page >= pages, false, 'Last')
                + '</div>';
        }
        return html + '</div>';
    },

    go: function (key, page) { var st = this.get(key); st.page = page; this._rerender(key); },
    setSize: function (key, size) { var st = this.get(key); st.size = parseInt(size, 10) || this.defaultSize; st.page = 1; this._rerender(key); },
    _rerender: function (key) { var fn = this._renderers[key]; if (fn) fn(); }
};
// Styling reuses the app's themed css/pagination.css (.pagination-bar / .page-btns / …),
// so the pager matches every other view in both light and dark themes.
