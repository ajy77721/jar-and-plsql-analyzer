/**
 * PA.callTrace — Depth-indented HTML call trace (jar-analyzer style).
 * Renders call tree as nested rows with expand/collapse, breadcrumb, schema badges.
 */
window.PA = window.PA || {};

const SCHEMA_COLORS = {
    'CUSTOMER':   { bg: '#dbeafe', fg: '#1d4ed8' },
    'CUSTOMER_I': { bg: '#ccfbf1', fg: '#0f766e' },
    'OPUS_CORE':  { bg: '#dcfce7', fg: '#15803d' },
    'POLICY':     { bg: '#f3e8ff', fg: '#7e22ce' },
    'CLAIMS':     { bg: '#fee2e2', fg: '#b91c1c' },
    'ACCOUNTING': { bg: '#fef3c7', fg: '#a16207' },
    'DEFAULT':    { bg: '#f1f5f9', fg: '#475569' }
};

function getSchemaColor(schema) {
    if (!schema) return SCHEMA_COLORS.DEFAULT;
    return SCHEMA_COLORS[schema.toUpperCase()] || SCHEMA_COLORS.DEFAULT;
}

PA.getSchemaColor = getSchemaColor;

PA.callTrace = {
    treeData: null,
    breadcrumbStack: [],  // [{id, name}]
    stepCounter: 0,

    // ── Re-root state ──
    _gen: 0,                 // stale-request guard: every async re-root captures & re-checks this
    _originalRootId: null,   // the analysis's original entry point — never changes within an analysis
    _originalAnalysis: null, // which analysis _originalRootId belongs to (reset on analysis switch)

    /** Normalized node-id equality: uppercase + unify $/. separators + schema-prefix/endsWith fallback. */
    _sameNode(a, b) {
        if (!a || !b) return false;
        const na = String(a).toUpperCase().replace(/\$/g, '.');
        const nb = String(b).toUpperCase().replace(/\$/g, '.');
        if (na === nb) return true;
        const sa = na.indexOf('.') >= 0 ? na.substring(na.indexOf('.') + 1) : na;
        const sb = nb.indexOf('.') >= 0 ? nb.substring(nb.indexOf('.') + 1) : nb;
        return sa === sb || na.endsWith('.' + nb) || nb.endsWith('.' + na);
    },

    /** Load call tree for a procedure and render it (also establishes the analysis's original root). */
    async load(procId) {
        const myGen = ++PA.callTrace._gen;
        const data = await PA.api.getCallTree(procId);
        if (myGen !== PA.callTrace._gen) return;   // superseded by a newer re-root
        if (!data || !data.id) {
            document.getElementById('ctContainer').innerHTML = '<div class="empty-msg">No call tree data for: ' + PA.esc(procId) + '</div>';
            return;
        }
        // First load of a given analysis = its original root (survives re-rooting; reset on analysis switch).
        const analysis = (PA.api && PA.api._analysisName) || '';
        if (PA.callTrace._originalAnalysis !== analysis) {
            PA.callTrace._originalAnalysis = analysis;
            PA.callTrace._originalRootId = data.id;
        }
        PA.callTrace.treeData = data;
        PA.callTrace.breadcrumbStack = [{ id: data.id, name: data.name || data.id }];
        PA.callTrace.render(data);
    },

    /** Hard re-root ("Make Root"): treat this node as the new tree root, resetting the breadcrumb. */
    async makeRoot(procId) {
        const myGen = ++PA.callTrace._gen;
        const data = await PA.api.getCallTree(procId);
        if (myGen !== PA.callTrace._gen) return;   // superseded
        if (!data || !data.id) return;
        PA.callTrace.treeData = data;
        PA.callTrace.breadcrumbStack = [{ id: data.id, name: data.name || data.id }];
        PA.callTrace.render(data);
    },

    /** The analysis's original root node id — the real $-form id captured from the first render
     *  (NOT analysisData.entryPoint, which is the bare unqualified name and won't resolve a subtree). */
    _analysisEntry() {
        return PA.callTrace._originalRootId || (PA.analysisData && PA.analysisData.entryPoint) || null;
    },

    /** Whether the currently-shown node is the analysis's original entry point. */
    _atAnalysisRoot() {
        var entry = PA.callTrace._analysisEntry();
        var cur = (PA.context && PA.context.procId) || (PA.callTrace.treeData && PA.callTrace.treeData.id);
        return !entry || PA.callTrace._sameNode(cur, entry);
    },

    /** Show/hide the toolbar "Analysis Root" revert button based on current position. */
    _updateRootBtn() {
        var btn = document.getElementById('btnAnalysisRoot');
        if (btn) btn.style.display = PA.callTrace._atAnalysisRoot() ? 'none' : 'inline-flex';
    },

    /** Return to the analysis's original entry point via the canonical show-as-current fn. */
    goAnalysisRoot() {
        var entry = PA.callTrace._analysisEntry();
        if (entry) PA.showProcedure(entry);
    },

    /** Drill down into a child node (soft re-root: remembers the path in the breadcrumb). */
    async drillDown(procId) {
        const myGen = ++PA.callTrace._gen;
        const data = await PA.api.getCallTree(procId);
        if (myGen !== PA.callTrace._gen) return;   // superseded
        if (!data || !data.id) return;
        PA.callTrace.treeData = data;
        PA.callTrace.breadcrumbStack.push({ id: data.id, name: data.name || data.id });
        PA.callTrace.render(data);
    },

    /** Go to a specific breadcrumb position */
    async goTo(index) {
        if (index < 0 || index >= PA.callTrace.breadcrumbStack.length) return;
        const item = PA.callTrace.breadcrumbStack[index];
        if (!item) return;
        const myGen = ++PA.callTrace._gen;
        const data = await PA.api.getCallTree(item.id);
        if (myGen !== PA.callTrace._gen) return;   // superseded
        if (data) {
            PA.callTrace.breadcrumbStack = PA.callTrace.breadcrumbStack.slice(0, index + 1);
            PA.callTrace.treeData = data;
            PA.callTrace.render(data);
        }
    },

    /** Go back to root (first in breadcrumb) */
    goRoot() {
        if (PA.callTrace.breadcrumbStack.length > 0) {
            PA.callTrace.goTo(0);
        }
    },

    /** "Make Root" control handler — route through the ONE canonical show-as-current function
     *  so it behaves exactly like selecting the proc (tree + detail + tabs + breadcrumb + URL,
     *  with the built-in stale-request guard). */
    onMakeRoot(procId, event) {
        if (event) event.stopPropagation();
        PA.showProcedure(procId);
    },

    _nodeMap: {},
    _initialDepth: 1,
    _indexDataCache: null,

    _getNodeMetrics: function(nodeId) {
        if (!PA.analysisData || !PA.analysisData.nodes) return null;
        if (!PA.callTrace._indexDataCache) {
            var cache = {};
            var nodes = PA.analysisData.nodes;
            for (var i = 0; i < nodes.length; i++) {
                var n = nodes[i];
                cache[(n.nodeId || '').toUpperCase()] = n;
                if (n.name) cache[n.name.toUpperCase()] = n;
            }
            PA.callTrace._indexDataCache = cache;
        }
        var key = (nodeId || '').toUpperCase();
        return PA.callTrace._indexDataCache[key] || null;
    },

    _calcRisk: function(n) {
        if (!n || !PA.complexity || !PA.complexity.scoreRaw) return null;
        var c = n.counts || {};
        var stmts = c.statements || {};
        var dynSql = (stmts.EXECUTE_IMMEDIATE || 0) + (stmts.DBMS_SQL || 0);
        // Delegate to the ONE shared scorer so the badge always matches the complexity table,
        // including for non-linear formulas (log/exponential/balanced).
        var sr = PA.complexity.scoreRaw({
            loc: n.linesOfCode || 0, tables: c.tables || 0, callsOut: c.callsOut || 0,
            cursors: c.cursors || 0, dynSql: dynSql, depth: n.depth || 0
        });
        var cls = sr.risk === 'HIGH' ? 'high' : (sr.risk === 'MEDIUM' ? 'medium' : 'low');
        var label = sr.risk.charAt(0); // H / M / L
        return { label: label, cls: cls, score: sr.score };
    },

    /** Render the call tree as depth-indented HTML */
    render(data) {
        // Capture the analysis's original root id (the real $-form node id from the first render)
        // so "Analysis Root" can re-root back to it. Reset when the analysis changes.
        var analysis = (PA.api && PA.api._analysisName) || '';
        if (data && data.id && PA.callTrace._originalAnalysis !== analysis) {
            PA.callTrace._originalAnalysis = analysis;
            PA.callTrace._originalRootId = data.id;
        }
        PA.callTrace.updateBreadcrumb();
        PA.callTrace.stepCounter = 0;
        PA.callTrace._nodeMap = {};
        PA.callTrace._indexDataCache = null;
        const searchBox = document.getElementById('exploreSearch');
        if (searchBox) searchBox.value = '';
        const container = document.getElementById('ctContainer');

        if (!data || !data.id) {
            container.innerHTML = '<div class="empty-msg">Select a procedure from the left panel</div>';
            return;
        }

        PA.callTrace._indexNodes(data, null);
        let html = '';
        html += PA.callTrace.renderNode(data, 0, null);
        container.innerHTML = html;
    },

    _indexNodes(node, parentSourceFile) {
        PA.callTrace.stepCounter++;
        const step = PA.callTrace.stepCounter;
        node._step = step;
        node._parentSourceFile = parentSourceFile || '';
        const sf = node.sourceFile || (node.schemaName && node.packageName ? node.schemaName + '.' + node.packageName : '');
        PA.callTrace._nodeMap[step] = node;
        if (node.children && !node.circular) {
            for (const child of node.children) {
                PA.callTrace._indexNodes(child, sf);
            }
        }
    },

    /** Render a single node — children rendered only if within initial depth */
    renderNode(node, depth, parentSourceFile) {
        const step = node._step;
        const indent = depth * 20;
        const hasChildren = node.children && node.children.length > 0;
        const id = PA.escAttr(node.id || '');
        const name = node.name || node.id || '?';
        const schema = node.schemaName || '';
        const pkg = node.packageName || '';
        const fullName = [schema, pkg, name].filter(Boolean).join('.');
        const callType = node.callType || '';
        const startLine = node.startLine || 0;
        const endLine = node.endLine || 0;
        const callLine = node.callLineNumber || 0;
        const sourceFile = node.sourceFile || (schema && pkg ? schema + '.' + pkg : '');
        const isCircular = node.circular;
        const colorObj = getSchemaColor(schema);
        const childCount = hasChildren && !isCircular ? node.children.length : 0;

        let html = '';

        html += `<div class="ct-row" data-id="${id}" data-depth="${depth}" id="ct-${step}" title="Click: show details | Double-click: drill down into this procedure" onclick="PA.callTrace.onRowClick('${PA.escJs(node.id)}', event)" ondblclick="PA.callTrace.onRowDblClick('${PA.escJs(node.id)}', event)">`;
        html += `<div class="ct-indent" style="width:${indent}px"></div>`;

        if (hasChildren && !isCircular) {
            const collapsed = depth >= PA.callTrace._initialDepth;
            html += `<span class="ct-toggle" data-step="${step}" onclick="PA.callTrace.toggle(${step}, ${depth}, event)">${collapsed ? '&#9654;' : '&#9660;'}</span>`;
        } else {
            html += `<span class="ct-toggle" style="visibility:hidden">&#9660;</span>`;
        }

        html += `<span class="ct-depth-badge" data-tip="Call depth ${depth}">L${depth}</span>`;
        html += `<span class="ct-step" style="color:${colorObj.fg}">${step}</span>`;

        if (schema) {
            html += `<span class="ct-schema-badge" style="background:${colorObj.bg};color:${colorObj.fg}" data-tip="Owner schema">${PA.esc(schema)}</span>`;
        }

        if (node.readable === false) {
            html += `<span class="ct-lock" data-tip="Encrypted/wrapped source">&#128274;</span>`;
        }

        html += `<span class="ct-name" data-tip="Click to view source" onclick="PA.callTrace.onNameClick('${PA.escJs(node.id)}', event)">${PA.esc(fullName)}</span>`;

        // "Make Root" — re-root the tree at this node. Only on navigable, non-circular child rows
        // (circular refs and bare variable/cursor references have no independent subtree to show).
        if (!isCircular && depth > 0 && (schema || startLine > 0)) {
            html += `<span class="ct-makeroot" data-tip="Make this node the tree root" onclick="PA.callTrace.onMakeRoot('${PA.escJs(node.id)}', event)">&#9654; Make Root</span>`;
        }

        if (startLine > 0) {
            const bodyLabel = (endLine > 0 && endLine !== startLine) ? `L${startLine}-${endLine}` : `L${startLine}`;
            html += `<span class="ct-line" data-tip="Open source at line ${startLine}" onclick="PA.callTrace.onLineClick('${PA.escJs(sourceFile)}', ${startLine}, event)">${bodyLabel}</span>`;
        }
        if (callLine > 0 && parentSourceFile) {
            html += `<span class="ct-call-line" data-tip="Called at line ${callLine}" onclick="PA.callTrace.onLineClick('${PA.escJs(parentSourceFile)}', ${callLine}, event)">@${callLine}</span>`;
        }

        const callTypeTooltips = {
            'INTERNAL': 'Same module/schema — call stays within the analyzed unit',
            'EXTERNAL': 'Cross-module call — goes to a different package/module or schema',
            'TRIGGER': 'Database trigger — fires automatically on table DML',
            'DYNAMIC': 'Dynamic SQL — built at runtime via EXECUTE IMMEDIATE'
        };
        if (isCircular) {
            html += `<span class="ct-call-badge CIRCULAR" title="Circular reference — this procedure is already in the call chain above">CIRCULAR</span>`;
        } else if (callType) {
            html += `<span class="ct-call-badge ${PA.escAttr(callType)}" title="${callTypeTooltips[callType] || callType}">${PA.esc(callType)}</span>`;
        }

        const metrics = PA.callTrace._getNodeMetrics(node.id);
        const nodeLoc = metrics ? (metrics.linesOfCode || 0) : (endLine > startLine ? endLine - startLine + 1 : 0);
        if (nodeLoc > 0) {
            html += `<span class="ct-loc-badge" data-tip="Lines of code">${nodeLoc.toLocaleString()}</span>`;
        }
        const risk = PA.callTrace._calcRisk(metrics);
        if (risk) {
            html += `<span class="ct-cx-badge ${risk.cls}" data-tip="Complexity: ${risk.score} pts">${risk.label}</span>`;
        }

        if (childCount > 0) {
            html += `<span style="font-size:9px;color:var(--text-muted);margin-left:4px">(${childCount})</span>`;
        }

        html += `</div>`;

        if (hasChildren && !isCircular) {
            const renderNow = depth < PA.callTrace._initialDepth;
            if (renderNow) {
                html += `<div class="ct-children" id="ct-children-${step}" data-loaded="1">`;
                for (const child of node.children) {
                    html += PA.callTrace.renderNode(child, depth + 1, sourceFile);
                }
                html += `</div>`;
            } else {
                html += `<div class="ct-children" id="ct-children-${step}" data-loaded="0" style="display:none"></div>`;
            }
        }

        return html;
    },

    _renderChildrenLazy(step, depth) {
        const node = PA.callTrace._nodeMap[step];
        if (!node || !node.children) return;
        const container = document.getElementById('ct-children-' + step);
        if (!container || container.dataset.loaded === '1') return;
        const sf = node.sourceFile || (node.schemaName && node.packageName ? node.schemaName + '.' + node.packageName : '');
        let html = '';
        for (const child of node.children) {
            html += PA.callTrace.renderNode(child, depth + 1, sf);
        }
        container.innerHTML = html;
        container.dataset.loaded = '1';
    },

    /** Toggle expand/collapse */
    toggle(step, depth, event) {
        event.stopPropagation();
        const container = document.getElementById('ct-children-' + step);
        const icon = document.querySelector(`.ct-toggle[data-step="${step}"]`);
        if (!container) return;
        if (container.style.display === 'none') {
            if (container.dataset.loaded === '0') {
                PA.callTrace._renderChildrenLazy(step, depth);
            }
            container.style.display = '';
            if (icon) icon.innerHTML = '&#9660;';
        } else {
            container.style.display = 'none';
            if (icon) icon.innerHTML = '&#9654;';
        }
    },

    expandAll() {
        document.querySelectorAll('.ct-children').forEach(el => {
            if (el.dataset.loaded === '0') {
                const step = parseInt(el.id.replace('ct-children-', ''), 10);
                const row = document.getElementById('ct-' + step);
                const depth = row ? parseInt(row.dataset.depth || '0', 10) : 0;
                PA.callTrace._renderChildrenLazy(step, depth);
            }
            el.style.display = '';
        });
        document.querySelectorAll('.ct-toggle').forEach(el => { if (el.style.visibility !== 'hidden') el.innerHTML = '&#9660;'; });
    },

    collapseAll() {
        document.querySelectorAll('.ct-children').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.ct-toggle').forEach(el => { if (el.style.visibility !== 'hidden') el.innerHTML = '&#9654;'; });
    },

    /** Clicking a row: highlight it and load detail for this node */
    onRowClick(procId, event) {
        document.querySelectorAll('.ct-row.active').forEach(el => el.classList.remove('active'));
        const row = event.currentTarget;
        row.classList.add('active');

        // Load detail for this child node (header + stats) without re-rendering the tree
        PA.loadNodeDetail(procId);
    },

    /** Double-clicking a row: drill down (re-root tree at this node) */
    onRowDblClick(procId, event) {
        event.stopPropagation();
        PA.callTrace.drillDown(procId);
    },

    /** Clicking the procedure name: open source in a modal popup */
    onNameClick(procId, event) {
        event.stopPropagation();
        PA.loadNodeDetail(procId);
        PA.sourceView.openModal(procId);
    },

    /** Clicking a line number: open the source view at that line */
    onLineClick(sourceFile, line, event) {
        event.stopPropagation();
        if (sourceFile) {
            PA.sourceView.openAtLine(sourceFile, line);
        }
    },

    /** Search within the Explore tree — expands all lazy nodes first, then filters */
    search(query) {
        const q = (query || '').trim().toLowerCase();
        const rows = document.querySelectorAll('#ctContainer .ct-row');
        if (!q) {
            rows.forEach(r => { r.style.display = ''; r.classList.remove('ct-search-hit'); });
            document.querySelectorAll('#ctContainer .ct-children').forEach(el => el.style.display = '');
            return;
        }
        PA.callTrace.expandAll();
        const allRows = document.querySelectorAll('#ctContainer .ct-row');
        allRows.forEach(r => {
            const name = (r.querySelector('.ct-name')?.textContent || '').toLowerCase();
            const schema = (r.querySelector('.ct-schema-badge')?.textContent || '').toLowerCase();
            const hit = name.includes(q) || schema.includes(q);
            r.classList.toggle('ct-search-hit', hit);
            if (hit) {
                r.style.display = '';
                let parent = r.parentElement;
                while (parent && parent.id !== 'ctContainer') {
                    if (parent.classList.contains('ct-children')) parent.style.display = '';
                    parent = parent.parentElement;
                }
            } else {
                r.style.display = 'none';
            }
        });
    },

    /** Update breadcrumb bar */
    updateBreadcrumb() {
        PA.callTrace._updateRootBtn();
        const bc = document.getElementById('breadcrumb');
        let html = '';
        for (let i = 0; i < PA.callTrace.breadcrumbStack.length; i++) {
            const item = PA.callTrace.breadcrumbStack[i];
            if (i > 0) html += '<span class="bc-sep">&rsaquo;</span>';
            if (i === PA.callTrace.breadcrumbStack.length - 1) {
                html += `<span class="bc-item bc-current">${PA.esc(item.name)}</span>`;
            } else {
                html += `<span class="bc-item" onclick="PA.callTrace.goTo(${i})">${PA.esc(item.name)}</span>`;
            }
        }
        bc.innerHTML = html;
    }
};
