PA.perfSummary = {
    _sortCol: 'duration',
    _sortDir: 'desc',
    _data: [],
    _page: 1,
    _pageSize: 10,
    _filterText: '',
    _filterDs: '',
    _filterProj: '',

    // Derive the datasource dialect from the persisted jdbcUrl (grammar/regex-free,
    // works for every analysis since jdbcUrl is always stored in index.json).
    _dialect: function(it) {
        var u = (it.jdbcUrl || '').toLowerCase();
        if (u.indexOf('sqlserver') >= 0) return 'SQLSERVER';
        if (u.indexOf('oracle') >= 0)    return 'ORACLE';
        if (u.indexOf('mysql') >= 0)     return 'MYSQL';
        if (u.indexOf('db2') >= 0)       return 'DB2';
        if (u.indexOf('postgresql') >= 0) return 'POSTGRES';
        if (it.dbType) return String(it.dbType).toUpperCase();
        return 'ORACLE';
    },
    _dsMeta: {
        ORACLE:    { label: 'Oracle',     color: '#b45309', bg: '#fef3c7' },
        SQLSERVER: { label: 'SQL Server', color: '#b91c1c', bg: '#fee2e2' },
        MYSQL:     { label: 'MySQL',      color: '#0369a1', bg: '#e0f2fe' },
        DB2:       { label: 'Db2',        color: '#6d28d9', bg: '#ede9fe' },
        POSTGRES:  { label: 'PostgreSQL', color: '#336791', bg: '#e6eef5' }
    },

    _fmtWhen: function(ts) {
        if (!ts) return '—';
        try { return new Date(ts).toLocaleString(); } catch (e) { return '—'; }
    },

    // Build projToDs and drop any selected filter whose value no longer exists in the data,
    // so the visible "All" in the dropdown matches what actually gets filtered.
    _syncFilters: function(list) {
        var self = PA.perfSummary;
        var dsSeen = {}, projToDs = {};
        for (var i = 0; i < list.length; i++) {
            var dl = self._dialect(list[i]);
            dsSeen[dl] = true;
            if (list[i].project) projToDs[list[i].project] = dl;
        }
        self._projToDs = projToDs;
        if (self._filterDs && !dsSeen[self._filterDs]) self._filterDs = '';
        if (self._filterProj && !projToDs[self._filterProj]) self._filterProj = '';
    },

    render: function() {
        var list = PA._allHistory || [];
        PA.perfSummary._data = list;
        var container = document.getElementById('perfSummaryContainer');
        if (!container) return;
        if (list.length === 0) { container.innerHTML = '<div class="empty-msg">No analyses yet</div>'; return; }
        PA.perfSummary._syncFilters(list);

        // Overview stat cards reflect the CURRENT filter (recomputed in _renderBody on change).
        var html = '<div id="psOverview">' + PA.perfSummary._overviewHtml(PA.perfSummary._filtered(list)) + '</div>';

        // Top-right filter toolbar: datasource + project (cascading) + free-text.
        html += '<div class="ps-toolbar">';
        html += '<span class="ps-toolbar-title">Analyses</span>';
        html += '<div class="ps-toolbar-controls">';
        html += '<span id="psFilterSelects">' + PA.perfSummary._filterSelectsHtml(list) + '</span>';
        html += '<input class="ps-filter-input" type="text" placeholder="Filter entry / schema / conn…" value="' + PA.esc(PA.perfSummary._filterText) + '" oninput="PA.perfSummary.onFilterText(this.value)">';
        html += '</div></div>';

        html += '<div id="psTableHost"></div>';

        container.innerHTML = html;
        PA.perfSummary._renderBody();
    },

    /** Build the overview stat cards for a (filtered) list. */
    _overviewHtml: function(list) {
        var totalTime = 0, totalDb = 0, totalSuccess = 0, totalErrors = 0, totalProcs = 0, totalTables = 0, totalLoc = 0;
        for (var i = 0; i < list.length; i++) {
            var it = list[i];
            totalTime += (it.totalDurationMs || it.crawlTimeMs || 0);
            totalDb += (it.dbCallCount || 0);
            totalProcs += (it.totalNodes || 0);
            totalTables += (it.totalTables || 0);
            totalLoc += (it.totalLinesOfCode || 0);
            if (it.errors && it.errors.length > 0) totalErrors++; else totalSuccess++;
        }
        var h = '<div class="ps-overview">';
        h += PA.perfSummary._statCard(list.length, 'Analyses');
        h += PA.perfSummary._statCard(totalSuccess, 'Success', '#15803d');
        h += PA.perfSummary._statCard(totalErrors, 'With Errors', totalErrors > 0 ? '#b91c1c' : '#15803d');
        h += PA.perfSummary._statCard(PA.formatDuration(totalTime), 'Total Time');
        h += PA.perfSummary._statCard(totalDb, 'DB Calls');
        h += PA.perfSummary._statCard(totalProcs.toLocaleString(), 'Procedures');
        h += PA.perfSummary._statCard(totalTables.toLocaleString(), 'Tables');
        h += PA.perfSummary._statCard(totalLoc.toLocaleString(), 'LOC');
        h += '</div>';
        return h;
    },

    _statCard: function(value, label, color) {
        var style = color ? 'color:' + color : '';
        return '<div class="ps-stat-card"><div class="ps-stat-value" style="' + style + '">' + value + '</div><div class="ps-stat-label">' + PA.esc(label) + '</div></div>';
    },

    // Build the cascading datasource + project dropdowns. Project options are limited to the
    // selected datasource; a project maps to exactly one datasource (project -> _projToDs).
    _filterSelectsHtml: function(list) {
        var self = PA.perfSummary;
        var dsSeen = {}, projToDs = {};
        for (var i = 0; i < list.length; i++) {
            var dl = self._dialect(list[i]);
            dsSeen[dl] = true;
            if (list[i].project) projToDs[list[i].project] = dl;
        }
        self._projToDs = projToDs;
        var dsOpts = '<option value="">All datasources</option>';
        ['ORACLE', 'SQLSERVER', 'MYSQL', 'DB2'].forEach(function(k) {
            if (dsSeen[k]) dsOpts += '<option value="' + k + '"' + (self._filterDs === k ? ' selected' : '') + '>' + self._dsMeta[k].label + '</option>';
        });
        var prOpts = '<option value="">All projects</option>';
        Object.keys(projToDs).sort().forEach(function(p) {
            if (self._filterDs && projToDs[p] !== self._filterDs) return;  // cascade
            prOpts += '<option value="' + PA.esc(p) + '"' + (self._filterProj === p ? ' selected' : '') + '>' + PA.esc(p) + '</option>';
        });
        return '<select class="ps-filter-select" onchange="PA.perfSummary.onFilterDs(this.value)">' + dsOpts + '</select>'
             + '<select class="ps-filter-select" onchange="PA.perfSummary.onFilterProj(this.value)">' + prOpts + '</select>';
    },

    _refreshSelects: function() {
        var host = document.getElementById('psFilterSelects');
        if (host) host.innerHTML = PA.perfSummary._filterSelectsHtml(PA._allHistory || []);
    },

    _filtered: function(list) {
        var self = PA.perfSummary;
        var q = (self._filterText || '').toUpperCase();
        var ds = self._filterDs || '';
        var proj = self._filterProj || '';
        return list.filter(function(it) {
            if (ds && self._dialect(it) !== ds) return false;
            if (proj && (it.project || '') !== proj) return false;
            if (q) {
                var t = ((it.entryPoint || '') + ' ' + (it.entrySchema || '') + ' ' + (it.name || '') + ' ' + (it.connectionName || '') + ' ' + (it.project || '') + ' ' + self._fmtWhen(it.timestamp)).toUpperCase();
                if (t.indexOf(q) < 0) return false;
            }
            return true;
        });
    },

    onFilterText: function(v) { PA.perfSummary._filterText = v; PA.perfSummary._page = 1; PA.perfSummary._renderBody(); },
    onFilterDs: function(v) {
        var self = PA.perfSummary;
        self._filterDs = v;
        if (!v) {
            self._filterProj = '';                       // All datasources → All projects
        } else if (self._filterProj && self._projToDs && self._projToDs[self._filterProj] !== v) {
            self._filterProj = '';                       // project no longer under this datasource
        }
        self._page = 1;
        self._refreshSelects();
        self._renderBody();
    },
    onFilterProj: function(v) {
        var self = PA.perfSummary;
        self._filterProj = v;
        if (v && self._projToDs && self._projToDs[v]) self._filterDs = self._projToDs[v];  // auto-set datasource
        self._page = 1;
        self._refreshSelects();
        self._renderBody();
    },
    goPage:       function(p) { PA.perfSummary._page = p; PA.perfSummary._renderBody(); },

    // Re-renders ONLY the table + pager (keeps the toolbar/search-input focus intact).
    _renderBody: function() {
        var host = document.getElementById('psTableHost');
        if (!host) return;
        PA.perfSummary._syncFilters(PA._allHistory || []);
        var filtered = PA.perfSummary._filtered(PA._allHistory || []);
        // Keep the overview stat cards in sync with the filter.
        var ov = document.getElementById('psOverview');
        if (ov) ov.innerHTML = PA.perfSummary._overviewHtml(filtered);
        host.innerHTML = PA.perfSummary._renderPager(filtered.length)
                       + '<div class="ps-table-wrap ps-table-scroll">' + PA.perfSummary._renderTable(filtered) + '</div>';
    },

    _renderPager: function(total) {
        var self = PA.perfSummary;
        var pages = Math.max(1, Math.ceil(total / self._pageSize));
        if (self._page > pages) self._page = pages;
        var from = total === 0 ? 0 : (self._page - 1) * self._pageSize + 1;
        var to = Math.min(self._page * self._pageSize, total);
        var prevD = self._page <= 1 ? 'disabled' : '';
        var nextD = self._page >= pages ? 'disabled' : '';
        var h = '<div class="pagination-bar ps-pager">';
        h += '<span class="page-info">' + from + '–' + to + ' of ' + total + '</span>';
        h += '<span class="page-btns">';
        h += '<button ' + prevD + ' onclick="PA.perfSummary.goPage(1)">«</button>';
        h += '<button ' + prevD + ' onclick="PA.perfSummary.goPage(' + (self._page - 1) + ')">‹</button>';
        h += '<span class="page-info">Page ' + self._page + ' / ' + pages + '</span>';
        h += '<button ' + nextD + ' onclick="PA.perfSummary.goPage(' + (self._page + 1) + ')">›</button>';
        h += '<button ' + nextD + ' onclick="PA.perfSummary.goPage(' + pages + ')">»</button>';
        h += '</span></div>';
        return h;
    },

    _renderTable: function(list) {
        var self = PA.perfSummary;
        var sorted = list.slice().sort(self._comparator());
        var maxTime = 0;
        for (var i = 0; i < sorted.length; i++) {
            var _d = (sorted[i].totalDurationMs || sorted[i].crawlTimeMs || 0);
            if (_d > maxTime) maxTime = _d;
        }

        // page slice
        var pageStart = (self._page - 1) * self._pageSize;
        var pageRows = sorted.slice(pageStart, pageStart + self._pageSize);

        var sc = self._sortCol, sd = self._sortDir;
        var arrow = function(col) { return sc === col ? (sd === 'asc' ? ' ▲' : ' ▼') : ''; };

        var html = '<table class="ps-table"><thead><tr>';
        html += '<th onclick="PA.perfSummary._sort(\'name\')">#' + arrow('name') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'entry\')">Entry Point' + arrow('entry') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'datasource\')">Datasource' + arrow('datasource') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'when\')">Date / Time' + arrow('when') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'status\')">Status' + arrow('status') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'duration\')">Duration' + arrow('duration') + '</th>';
        html += '<th>Time Bar</th>';
        html += '<th onclick="PA.perfSummary._sort(\'db\')">DB Calls' + arrow('db') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'procs\')">Procs' + arrow('procs') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'tables\')">Tables' + arrow('tables') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'loc\')">LOC' + arrow('loc') + '</th>';
        html += '<th onclick="PA.perfSummary._sort(\'errors\')">Errors' + arrow('errors') + '</th>';
        html += '</tr></thead><tbody>';

        for (var i = 0; i < pageRows.length; i++) {
            var it = pageRows[i];
            var hasErr = it.errors && it.errors.length > 0;
            var errCount = hasErr ? it.errors.length : 0;
            var statusCls = hasErr ? (errCount > 0 && (it.totalNodes || 0) > 0 ? 'partial' : 'error') : 'success';
            var statusLabel = hasErr ? (statusCls === 'partial' ? 'Partial' : 'Error') : 'Success';
            var ms = it.totalDurationMs || it.crawlTimeMs || 0;
            var pct = maxTime > 0 ? Math.round(ms / maxTime * 100) : 0;
            var barColor = statusCls === 'success' ? '#22c55e' : statusCls === 'partial' ? '#f59e0b' : '#ef4444';
            var dk = self._dialect(it), dm = self._dsMeta[dk] || { label: dk, color: '#475569', bg: '#e2e8f0' };

            html += '<tr onclick="PA.perfSummary.showDetail(' + (pageStart + i) + ')" data-idx="' + (pageStart + i) + '">';
            html += '<td style="color:var(--text-muted);font-size:10px">' + (pageStart + i + 1) + '</td>';
            html += '<td style="font-weight:600;font-size:11px">' + PA.esc(it.entryPoint || it.name || '') + '</td>';
            html += '<td><span class="ps-ds-badge" style="color:' + dm.color + ';background:' + dm.bg + '">' + PA.esc(dm.label) + '</span></td>';
            html += '<td style="white-space:nowrap;font-size:11px;color:var(--text-muted)">' + PA.esc(self._fmtWhen(it.timestamp)) + '</td>';
            html += '<td><span class="ps-status ' + statusCls + '">' + statusLabel + '</span></td>';
            html += '<td style="white-space:nowrap;font-family:monospace;font-size:11px">' + PA.formatDuration(ms) + '</td>';
            html += '<td><div class="ps-bar"><div class="ps-bar-fill" style="width:' + pct + '%;background:' + barColor + '"></div></div></td>';
            html += '<td style="text-align:center;font-weight:600">' + (it.dbCallCount || 0) + '</td>';
            html += '<td style="text-align:center">' + (it.totalNodes || 0) + '</td>';
            html += '<td style="text-align:center">' + (it.totalTables || 0) + '</td>';
            html += '<td style="text-align:center">' + (it.totalLinesOfCode || 0).toLocaleString() + '</td>';
            html += '<td style="text-align:center">';
            if (errCount > 0) html += '<span style="color:#ef4444;font-weight:700">' + errCount + '</span>';
            else html += '<span style="color:#22c55e">0</span>';
            html += '</td></tr>';
        }
        if (pageRows.length === 0) {
            html += '<tr><td colspan="12" class="empty-msg" style="text-align:center">No analyses match the filter</td></tr>';
        }

        html += '</tbody></table>';
        return html;
    },

    _comparator: function() {
        var col = PA.perfSummary._sortCol, dir = PA.perfSummary._sortDir;
        var m = dir === 'asc' ? 1 : -1;
        return function(a, b) {
            var va, vb;
            switch (col) {
                case 'name': va = (a.name || ''); vb = (b.name || ''); return va.localeCompare(vb) * m;
                case 'entry': va = (a.entryPoint || ''); vb = (b.entryPoint || ''); return va.localeCompare(vb) * m;
                case 'datasource': va = PA.perfSummary._dialect(a); vb = PA.perfSummary._dialect(b); return va.localeCompare(vb) * m;
                case 'when': return ((a.timestamp || 0) - (b.timestamp || 0)) * m;
                case 'status':
                    va = (a.errors && a.errors.length) ? 1 : 0;
                    vb = (b.errors && b.errors.length) ? 1 : 0;
                    return (va - vb) * m;
                case 'duration': return ((a.totalDurationMs || a.crawlTimeMs || 0) - (b.totalDurationMs || b.crawlTimeMs || 0)) * m;
                case 'db': return ((a.dbCallCount || 0) - (b.dbCallCount || 0)) * m;
                case 'procs': return ((a.totalNodes || 0) - (b.totalNodes || 0)) * m;
                case 'tables': return ((a.totalTables || 0) - (b.totalTables || 0)) * m;
                case 'loc': return ((a.totalLinesOfCode || 0) - (b.totalLinesOfCode || 0)) * m;
                case 'errors':
                    va = (a.errors ? a.errors.length : 0);
                    vb = (b.errors ? b.errors.length : 0);
                    return (va - vb) * m;
                default: return 0;
            }
        };
    },

    _sort: function(col) {
        if (PA.perfSummary._sortCol === col) {
            PA.perfSummary._sortDir = PA.perfSummary._sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            PA.perfSummary._sortCol = col;
            PA.perfSummary._sortDir = col === 'name' || col === 'entry' || col === 'datasource' ? 'asc' : 'desc';
        }
        PA.perfSummary._renderBody();
    },

    showDetail: function(idx) {
        var sorted = PA.perfSummary._filtered(PA._allHistory || []).slice().sort(PA.perfSummary._comparator());
        var it = sorted[idx];
        if (!it) return;

        var hasErr = it.errors && it.errors.length > 0;
        var statusCls = hasErr ? 'error' : 'success';
        var statusLabel = hasErr ? 'Error' : 'Success';

        var html = '<div class="ps-detail-overlay" onclick="this.remove()">';
        html += '<div class="ps-detail-panel" onclick="event.stopPropagation()">';
        html += '<div class="ps-detail-header"><h3>' + PA.esc(it.entryPoint || it.name) + '</h3>';
        html += '<button class="btn btn-sm" onclick="this.closest(\'.ps-detail-overlay\').remove()">&times;</button></div>';
        html += '<div class="ps-detail-body">';

        html += '<div class="ps-detail-section"><div class="ps-detail-section-title">Analysis Overview</div>';
        html += '<div class="ps-detail-grid">';
        html += '<div class="ps-detail-kv"><span class="ps-k">Status</span><span class="ps-v"><span class="ps-status ' + statusCls + '">' + statusLabel + '</span></span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">Schema</span><span class="ps-v">' + PA.esc(it.entrySchema || '-') + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">Duration</span><span class="ps-v">' + PA.formatDuration(it.totalDurationMs || it.crawlTimeMs) + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">DB Calls</span><span class="ps-v">' + (it.dbCallCount || 0) + '</span></div>';
        html += '</div></div>';

        html += '<div class="ps-detail-section"><div class="ps-detail-section-title">Metrics</div>';
        html += '<div class="ps-detail-grid">';
        html += '<div class="ps-detail-kv"><span class="ps-k">Procedures</span><span class="ps-v">' + (it.totalNodes || 0) + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">Tables</span><span class="ps-v">' + (it.totalTables || 0) + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">Edges</span><span class="ps-v">' + (it.totalEdges || 0) + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">LOC</span><span class="ps-v">' + (it.totalLinesOfCode || 0).toLocaleString() + '</span></div>';
        html += '<div class="ps-detail-kv"><span class="ps-k">Max Depth</span><span class="ps-v">' + (it.maxDepth || 0) + '</span></div>';
        html += '</div></div>';

        html += '<div class="ps-detail-section" id="psClaudeStats"><div class="ps-detail-section-title">Claude Verification</div>';
        html += '<div class="ps-detail-grid" id="psClaudeGrid"><div style="color:var(--text-muted);font-size:11px;grid-column:span 2">Loading...</div></div></div>';

        if (hasErr) {
            html += '<div class="ps-detail-section"><div class="ps-detail-section-title">Errors (' + it.errors.length + ')</div>';
            html += '<ul class="ps-error-list">';
            for (var i = 0; i < it.errors.length; i++) {
                html += '<li>' + PA.esc(it.errors[i]) + '</li>';
            }
            html += '</ul></div>';
        }

        html += '<div style="text-align:right;margin-top:12px"><button class="btn btn-primary btn-sm" onclick="this.closest(\'.ps-detail-overlay\').remove(); PA.loadAnalysis(\'' + PA.escJs(it.name) + '\')">Open Analysis</button></div>';
        html += '</div></div></div>';

        document.body.insertAdjacentHTML('beforeend', html);
        var psEl = document.querySelector('.ps-detail-overlay:last-of-type');
        if (psEl && PA.modalStack) psEl.style.zIndex = PA.modalStack.nextZ();
        PA.perfSummary._loadClaudeStats(it.name);
    },

    _loadClaudeStats: function(name) {
        fetch('/api/analyses/' + encodeURIComponent(name) + '/claude/result')
            .then(function(r) { return r.ok ? r.json() : null; })
            .then(function(cr) {
                var grid = document.getElementById('psClaudeGrid');
                if (!grid) return;
                if (!cr) { grid.innerHTML = '<div style="color:var(--text-muted);font-size:11px;grid-column:span 2">No verification data</div>'; return; }
                var h = '';
                h += '<div class="ps-detail-kv"><span class="ps-k">Confirmed</span><span class="ps-v" style="color:#15803d">' + (cr.confirmedCount || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">Removed</span><span class="ps-v" style="color:#b91c1c">' + (cr.removedCount || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">New</span><span class="ps-v" style="color:#2563eb">' + (cr.newCount || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">Chunks</span><span class="ps-v">' + (cr.totalChunks || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">Error Chunks</span><span class="ps-v">' + (cr.errorChunks || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">Claude API Calls</span><span class="ps-v" style="font-weight:700">' + (cr.claudeCallCount || 0) + '</span></div>';
                h += '<div class="ps-detail-kv"><span class="ps-k">Claude Time</span><span class="ps-v">' + PA.formatDuration(cr.claudeTimeMs || 0) + '</span></div>';
                grid.innerHTML = h;
            })
            .catch(function() {
                var grid = document.getElementById('psClaudeGrid');
                if (grid) grid.innerHTML = '<div style="color:var(--text-muted);font-size:11px;grid-column:span 2">No verification data</div>';
            });
    }
};

PA.switchHomeTab = function(tab) {
    document.querySelectorAll('.home-tab').forEach(function(el) {
        el.classList.toggle('active', el.dataset.htab === tab);
    });
    var hist = document.getElementById('homeTabHistory');
    var perf = document.getElementById('homeTabPerfSummary');
    var queue = document.getElementById('homeTabQueue');
    var search = document.getElementById('historySearch');
    if (hist) { hist.style.display = tab === 'history' ? '' : 'none'; hist.classList.toggle('active', tab === 'history'); }
    if (perf) { perf.style.display = tab === 'perfSummary' ? '' : 'none'; perf.classList.toggle('active', tab === 'perfSummary'); }
    if (queue) { queue.style.display = tab === 'queue' ? '' : 'none'; queue.classList.toggle('active', tab === 'queue'); }
    if (search) search.style.display = tab === 'history' ? '' : 'none';
    // The top datasource/project filter row belongs to Analysis History only — hide it on
    // Performance Summary and Queue (those tabs have their own controls / none).
    var filters = document.getElementById('historyFilters');
    if (filters) filters.style.display = tab === 'history' ? '' : 'none';
    if (tab === 'history') PA.loadHistory();
    if (tab === 'perfSummary') PA.perfSummary.render();
    if (tab === 'queue') PA.queueTab.load();
};

PA.queueTab = {
    _timer: null,

    load: function() {
        PA.queueTab._render();
        clearInterval(PA.queueTab._timer);
        PA.queueTab._timer = setInterval(function() {
            var queueEl = document.getElementById('homeTabQueue');
            if (!queueEl || queueEl.style.display === 'none') {
                clearInterval(PA.queueTab._timer);
                return;
            }
            PA.queueTab._render();
        }, 2000);
    },

    _render: async function() {
        var container = document.getElementById('queueContainer');
        if (!container) return;
        try {
            var res = await fetch('/api/queue');
            if (!res.ok) { container.innerHTML = '<div class="empty-msg">Failed to load queue</div>'; return; }
            var data = await res.json();
            PA.queueTab._renderData(container, data);
        } catch (e) {
            container.innerHTML = '<div class="empty-msg">Error: ' + PA.esc(e.message || e) + '</div>';
        }
    },

    // Job types that belong to the PL/SQL analyser — filter out JAR/WAR jobs
    _PLSQL_TYPES: new Set([
        'PLSQL_ANALYSIS', 'PLSQL_FAST_ANALYSIS', 'PARSER_ANALYSIS', 'PLSQL_CLAUDE_VERIFY'
    ]),

    _isPlsql: function(job) {
        return PA.queueTab._PLSQL_TYPES.has((job.type || '').toUpperCase());
    },

    _renderData: function(container, data) {
        var rawRunning = data.current || data.running || null;
        var rawQueued  = data.queued  || [];
        var rawHistory = data.history || [];

        // Show only PL/SQL jobs on this home screen
        var running = rawRunning && PA.queueTab._isPlsql(rawRunning) ? rawRunning : null;
        var queued  = rawQueued.filter(PA.queueTab._isPlsql);
        var history = rawHistory.filter(PA.queueTab._isPlsql);

        var html = '';
        html += '<div style="margin-bottom:8px;font-size:11px;color:var(--text-muted)">Auto-refreshes every 2s</div>';

        html += '<div style="margin-bottom:4px;font-weight:600;font-size:12px;color:var(--text-primary)">Running</div>';
        if (running) {
            html += PA.queueTab._jobRow(running, 'running');
        } else {
            html += '<div class="empty-msg" style="margin:4px 0 8px">No job running</div>';
        }

        html += '<div style="margin:8px 0 4px;font-weight:600;font-size:12px;color:var(--text-primary)">Pending (' + queued.length + ')</div>';
        if (queued.length > 0) {
            for (var i = 0; i < queued.length; i++) html += PA.queueTab._jobRow(queued[i], 'queued');
        } else {
            html += '<div class="empty-msg" style="margin:4px 0 8px">Queue is empty</div>';
        }

        html += '<div style="margin:8px 0 4px;font-weight:600;font-size:12px;color:var(--text-primary)">Recent (' + Math.min(history.length, 20) + ')</div>';
        if (history.length > 0) {
            var recent = history.slice(0, 20);
            for (var j = 0; j < recent.length; j++) html += PA.queueTab._jobRow(recent[j], 'history');
        } else {
            html += '<div class="empty-msg" style="margin:4px 0 8px">No history</div>';
        }

        container.innerHTML = html;
    },

    _jobRow: function(job, section) {
        var statusColor = { RUNNING: '#2563eb', QUEUED: '#d97706', COMPLETE: '#16a34a', CANCELLED: '#6b7280', FAILED: '#dc2626' };
        var status = (job.status || '').toUpperCase();
        var color = statusColor[status] || '#6b7280';
        var elapsed = job.elapsedMs != null ? ' · ' + PA.formatDuration(job.elapsedMs) : '';
        var type = (job.type || '').replace(/_/g, ' ');
        var name = job.displayName || job.id || '';
        var step = job.currentStep ? ('<div style="color:var(--text-muted);font-size:10px;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + PA.esc(job.currentStep) + '</div>') : '';
        var progress = (status === 'RUNNING' && job.progressPercent > 0)
            ? '<div style="height:3px;background:var(--bg-tertiary);border-radius:2px;margin-top:3px"><div style="height:3px;background:#2563eb;border-radius:2px;width:' + job.progressPercent + '%"></div></div>'
            : '';
        var canCancel = (section === 'queued' || section === 'running' || status === 'RUNNING' || status === 'QUEUED');
        var cancelBtn = canCancel
            ? '<button onclick="PA.queueTab._cancel(\'' + PA.esc(job.id) + '\')" style="flex-shrink:0;margin-left:8px;font-size:10px;padding:1px 6px;background:#b91c1c;color:#fff;border:none;border-radius:3px;cursor:pointer">Cancel</button>'
            : '';
        return '<div style="padding:5px 8px;margin-bottom:4px;background:var(--bg-secondary);border-radius:4px;font-size:11px">'
            + '<div style="display:flex;align-items:center">'
            + '<span style="min-width:72px;color:' + color + ';font-weight:600">' + PA.esc(status) + '</span>'
            + '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + PA.esc(name) + '">' + PA.esc(name) + '</span>'
            + '<span style="color:var(--text-muted);margin-left:6px;flex-shrink:0">' + PA.esc(type) + elapsed + '</span>'
            + cancelBtn
            + '</div>'
            + step
            + progress
            + '</div>';
    },

    _cancel: async function(jobId) {
        try {
            await fetch('/api/queue/' + encodeURIComponent(jobId) + '/cancel', { method: 'POST' });
            PA.queueTab._render();
        } catch (e) {
            PA.toast('Cancel failed: ' + (e.message || e), 'error');
        }
    }
};
