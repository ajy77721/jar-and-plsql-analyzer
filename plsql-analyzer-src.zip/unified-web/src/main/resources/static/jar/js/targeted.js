/**
 * Targeted (developer) analysis — analyze a local JAR from specific entry points
 * (className / methodName / paramTypes) instead of the whole project.
 *
 * Additive: reuses the existing progress panel, job-queue polling, and result
 * renderers (JA.app._showAnalysis) so completed results look identical to a
 * normal analysis. Only the submit endpoint (analyze-targeted) differs.
 */
window.JA = window.JA || {};

JA.targeted = {

    _rowSeq: 0,

    showModal() {
        if (JA.app && JA.app._uploading) return;
        this._close();
        const overlay = document.createElement('div');
        overlay.id = 'targeted-modal-overlay';
        overlay.className = 'upload-modal-overlay';
        overlay.innerHTML = `
            <div class="upload-modal-panel" style="max-width:640px">
                <div class="upload-modal-header">
                    <span>Targeted Analysis <span class="upload-modal-optional">(developer)</span></span>
                    <button class="upload-modal-close" onclick="JA.targeted._close()">&#x2715;</button>
                </div>
                <div class="upload-modal-body">
                    <div class="upload-modal-field">
                        <label class="upload-modal-label">Local JAR Path</label>
                        <input type="text" id="tgt-jar-path" class="claude-path-input"
                            placeholder="Absolute path, e.g. /path/to/app-0.0.1-SNAPSHOT.jar">
                    </div>
                    <div class="upload-modal-field">
                        <label class="upload-modal-label">Name <span class="upload-modal-optional">(optional)</span></label>
                        <input type="text" id="tgt-name" class="claude-path-input" placeholder="Label for this analysis">
                    </div>
                    <div class="upload-modal-field">
                        <label class="upload-modal-label">Entry Points</label>
                        <div id="tgt-entries"></div>
                        <button class="btn-sm" style="margin-top:8px" onclick="JA.targeted.addRow()">+ Add Entry</button>
                    </div>
                </div>
                <div class="upload-modal-footer">
                    <button class="btn-sm" onclick="JA.targeted._close()">Cancel</button>
                    <button class="upload-btn upload-modal-submit-btn" onclick="JA.targeted.submit()">Analyze</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        overlay.addEventListener('click', e => { if (e.target === overlay) this._close(); });
        overlay.addEventListener('keydown', e => { if (e.key === 'Escape') this._close(); });
        this.addRow();
        setTimeout(() => overlay.querySelector('#tgt-jar-path')?.focus(), 50);
    },

    addRow() {
        const host = document.getElementById('tgt-entries');
        if (!host) return;
        const id = ++this._rowSeq;
        const row = document.createElement('div');
        row.className = 'targeted-entry-row';
        row.dataset.rowId = id;
        row.style.cssText = 'display:flex;gap:6px;margin-bottom:6px;align-items:center';
        row.innerHTML = `
            <input type="text" class="claude-path-input tgt-class" placeholder="className e.g. com.foo.Bar" style="flex:2">
            <input type="text" class="claude-path-input tgt-method" placeholder="method e.g. doIt" style="flex:1">
            <input type="text" class="claude-path-input tgt-params" placeholder="paramTypes (optional) e.g. int, java.lang.String" style="flex:2">
            <button class="btn-sm" title="Remove" onclick="JA.targeted.removeRow(${id})">&#x2715;</button>`;
        host.appendChild(row);
    },

    removeRow(id) {
        const host = document.getElementById('tgt-entries');
        if (!host) return;
        const rows = host.querySelectorAll('.targeted-entry-row');
        if (rows.length <= 1) { JA.toast?.info('At least one entry is required'); return; }
        host.querySelector(`.targeted-entry-row[data-row-id="${id}"]`)?.remove();
    },

    _collectEntries(overlay) {
        const entries = [];
        overlay.querySelectorAll('.targeted-entry-row').forEach(row => {
            const className = row.querySelector('.tgt-class').value.trim();
            const methodName = row.querySelector('.tgt-method').value.trim();
            const rawParams = row.querySelector('.tgt-params').value.trim();
            if (!className || !methodName) return;
            const paramTypes = rawParams
                ? rawParams.split(',').map(p => p.trim()).filter(p => p.length)
                : [];
            entries.push({ className, methodName, paramTypes });
        });
        return entries;
    },

    _close() {
        document.getElementById('targeted-modal-overlay')?.remove();
    },

    async submit() {
        const overlay = document.getElementById('targeted-modal-overlay');
        if (!overlay) return;
        const path = overlay.querySelector('#tgt-jar-path').value.trim();
        const name = overlay.querySelector('#tgt-name').value.trim();
        if (!path) { JA.toast?.error('Enter a JAR path'); return; }
        const entries = this._collectEntries(overlay);
        if (!entries.length) { JA.toast?.error('Add at least one entry (className + methodName)'); return; }

        this._close();
        const app = JA.app;
        app._uploading = true;
        document.querySelector('.sidebar')?.classList.add('sidebar-blocked');
        app._showLoading(true);
        app._showProgressPanel(true);
        const log = document.getElementById('progress-log');
        if (log) { log.innerHTML = ''; app._progressLines = []; }
        JA.toast?.info('Submitting targeted analysis (' + entries.length + ' entr' + (entries.length === 1 ? 'y' : 'ies') + ')...');

        try {
            const body = { path, mode: 'static', entries };
            if (name) body.name = name;
            const res = await fetch('/api/jar/jars/analyze-targeted', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.message || data.error || res.statusText);

            const jobId = data.jobId;
            const jarId = data.id || data.jarName;
            app._addProgressLine('step', 'Queued for targeted analysis (job ' + jobId + ')...');
            app._updateStatusButton('pending', 'Queued...');

            await this._pollJob(jobId);

            await app.loadJars();
            app._addProgressLine('complete', 'Loading results...');
            let analysis;
            try { analysis = await JA.api.getSummaryHeaders(jarId); }
            catch (e) { analysis = await JA.api.getSummary(jarId); }
            app._showAnalysis(analysis);
            app._updateStatusButton('static-done', 'Analysis Complete');
            JA.toast?.success('Targeted analysis complete — ' + (analysis.totalEndpoints || 0) + ' endpoints', 4000);
            if (JA.chatToggle) JA.chatToggle.onJarChanged(jarId);
        } catch (err) {
            console.error('Targeted analysis error:', err);
            JA.toast?.error('Targeted analysis failed: ' + err.message, 5000);
            app._updateStatusButton('error', 'Failed');
            app._addProgressLine('error', 'Failed: ' + err.message);
            setTimeout(() => app._showProgressPanel(false), 3000);
        } finally {
            app._uploading = false;
            document.querySelector('.sidebar')?.classList.remove('sidebar-blocked');
            app._showLoading(false);
        }
    },

    /** Poll /api/queue/{jobId} every 2s until terminal state (same mechanism as analyze-local). */
    _pollJob(jobId) {
        return new Promise((resolve, reject) => {
            let notFound = 0;
            const timer = setInterval(async () => {
                try {
                    const d = await fetch('/api/queue/' + jobId).then(r => r.json());
                    if (!d) return;
                    if (d.error) {
                        if (++notFound >= 3) { clearInterval(timer); reject(new Error('Job lost (server may have restarted).')); }
                        return;
                    }
                    notFound = 0;
                    if (d.status === 'RUNNING') {
                        JA.app._addProgressLine('step', d.currentStep || '');
                        if (d.progressPercent > 0) JA.app._updateStatusButton('pending', d.progressPercent + '%');
                    } else if (d.status === 'COMPLETE') {
                        JA.app._addProgressLine('complete', 'Analysis complete!');
                        clearInterval(timer); resolve();
                    } else if (d.status === 'FAILED') {
                        clearInterval(timer); reject(new Error(d.error || 'Analysis failed'));
                    } else if (d.status === 'CANCELLED') {
                        clearInterval(timer); reject(new Error('Job cancelled'));
                    }
                } catch (e) { /* retry next interval */ }
            }, 2000);
        });
    }
};
