package com.plsql.parser.multidb;

import com.plsql.mysql.engine.MySqlGrammarEngine;
import com.plsql.mysql.model.*;
import com.plsql.parser.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 * MySQL stored-procedure parser — adapter layer.
 *
 * Delegates all grammar work to the dedicated mysql-parser module
 * (MySqlGrammarEngine, ANTLR4-based, completely separate grammar from Oracle).
 * This class owns only the conversion from MySqlRoutineInfo → shared ParseResult.
 */
public class MySqlProcedureParser implements StoredProcedureParser {

    private static final MySqlGrammarEngine ENGINE = new MySqlGrammarEngine();

    @Override
    public ParseResult parse(String source, String objectName, String schema) {
        long start = System.currentTimeMillis();
        MySqlRoutineInfo info = ENGINE.parse(source, objectName, schema);

        ParseResult result = new ParseResult();
        result.setFileName(info.getName() + ".sql");
        result.getErrors().addAll(info.getErrors());

        ParsedObject obj = new ParsedObject();
        obj.setName(info.getName());
        obj.setSchema(info.getSchema());
        obj.setType(info.getType() == MySqlRoutineInfo.RoutineType.FUNCTION ? "FUNCTION" : "PROCEDURE");
        obj.setLineStart(info.getLineStart());
        obj.setLineEnd(info.getLineEnd() > 0 ? info.getLineEnd() : countLines(source));
        obj.setParameters(toParams(info.getParams()));
        obj.setGlobalVariables(toVars(info.getVariables(), info.getCursors()));
        obj.setCalls(toCalls(info.getCalls()));
        obj.setTableOperations(toTableOps(info.getTableOps()));
        obj.setCursors(toCursors(info.getCursors()));
        obj.setDynamicSql(toDynamicSql(info.getDynamicSql()));
        obj.setStatements(toStatements(info.getStatements()));

        result.getObjects().add(obj);
        result.setParseTimeMs(System.currentTimeMillis() - start);
        return result;
    }

    // ── Converters ────────────────────────────────────────────────────────────

    private List<ParameterInfo> toParams(List<MySqlParamInfo> src) {
        List<ParameterInfo> out = new ArrayList<>();
        for (MySqlParamInfo p : src) {
            ParameterInfo pi = new ParameterInfo();
            pi.setName(p.getName());
            pi.setDataType(p.getDataType());
            pi.setDirection(p.getDirection().name());
            out.add(pi);
        }
        return out;
    }

    private List<VariableInfo> toVars(List<MySqlVariableInfo> vars, List<MySqlCursorInfo> cursors) {
        List<VariableInfo> out = new ArrayList<>();
        for (MySqlVariableInfo v : vars) {
            VariableInfo vi = new VariableInfo();
            vi.setName(v.getName());
            vi.setDataType(v.getDataType());
            vi.setDefaultValue(v.getDefaultValue());
            vi.setLine(v.getLine());
            out.add(vi);
        }
        for (MySqlCursorInfo c : cursors) {
            VariableInfo vi = new VariableInfo();
            vi.setName(c.getName());
            vi.setDataType("CURSOR");
            vi.setLine(c.getLine());
            out.add(vi);
        }
        return out;
    }

    private List<CallInfo> toCalls(List<MySqlCallInfo> src) {
        List<CallInfo> out = new ArrayList<>();
        for (MySqlCallInfo c : src) {
            CallInfo ci = new CallInfo();
            ci.setName(c.getName());
            ci.setSchema(c.getSchema());
            ci.setType("EXTERNAL");
            ci.setLine(c.getLine());
            out.add(ci);
        }
        return out;
    }

    private List<TableOperationInfo> toTableOps(List<MySqlTableOpInfo> src) {
        List<TableOperationInfo> out = new ArrayList<>();
        for (MySqlTableOpInfo op : src) {
            TableOperationInfo ti = new TableOperationInfo();
            ti.setOperation(op.getDmlType().name());
            ti.setTableName(op.getTableName());
            ti.setSchema(op.getSchemaName());
            ti.setAlias(op.getAlias());
            ti.setLine(op.getLine());
            if (op.getJoins() != null && !op.getJoins().isEmpty()) {
                List<JoinInfo> joins = new ArrayList<>();
                for (MySqlJoinInfo j : op.getJoins()) {
                    JoinInfo ji = new JoinInfo();
                    ji.setJoinType(j.getJoinType());
                    // Bare joined-table name (no schema prefix) so the UI's per-table Joins tab
                    // resolves both sides by name — mirrors the SqlServer converter.
                    ji.setJoinedTable(j.getJoinedTable());
                    ji.setJoinedTableAlias(j.getJoinedTableAlias());
                    ji.setLeftTable(j.getLeftTable());
                    ji.setLeftTableAlias(j.getLeftTableAlias());
                    ji.setCondition(j.getCondition());
                    ji.setLine(j.getLine());
                    ji.setQueryId(j.getQueryId());
                    joins.add(ji);
                }
                ti.setJoins(joins);
            }
            out.add(ti);
        }
        return out;
    }

    private List<CursorInfo> toCursors(List<MySqlCursorInfo> src) {
        List<CursorInfo> out = new ArrayList<>();
        for (MySqlCursorInfo c : src) {
            CursorInfo ci = new CursorInfo();
            ci.setName(c.getName());
            ci.setQuery(c.getSelectText());
            ci.setLine(c.getLine());
            out.add(ci);
        }
        return out;
    }

    private List<DynamicSqlInfo> toDynamicSql(List<MySqlDynamicSqlInfo> src) {
        List<DynamicSqlInfo> out = new ArrayList<>();
        for (MySqlDynamicSqlInfo d : src) {
            DynamicSqlInfo di = new DynamicSqlInfo();
            di.setType(d.getKind() != null ? d.getKind().name() : "DYNAMIC");
            di.setSqlExpression(d.getSqlSource());
            di.setLine(d.getLine());
            out.add(di);
        }
        return out;
    }

    private List<StatementInfo> toStatements(List<MySqlStatementInfo> src) {
        List<StatementInfo> out = new ArrayList<>();
        for (MySqlStatementInfo s : src) {
            StatementInfo si = new StatementInfo();
            si.setType(s.getType());
            si.setLine(s.getLine());
            if (s.getSavepointName() != null) si.setSavepointName(s.getSavepointName());
            out.add(si);
        }
        return out;
    }

    private int countLines(String src) {
        int n = 1;
        for (char c : src.toCharArray()) if (c == '\n') n++;
        return n;
    }
}
