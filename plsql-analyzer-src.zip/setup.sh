#!/usr/bin/env bash
# ============================================================================
# setup.sh  —  One-command end-to-end bring-up of the analyzer.
#
#   1. Verify Docker (binary + daemon)
#   2. Create/start + seed all 5 demo databases (Oracle, MySQL, SQL Server,
#      PostgreSQL, DB2)  [delegates to db-setup/setup-databases.sh]
#   3. Create the Oracle second schema/user ANALYZER_REF (multi-schema demo)
#   4. Build the application (mvn clean install -DskipTests)
#   5. Start the web app (port 8083) and wait until ready
#   6. Trigger a fresh analysis for all 5 datasources (demo projects already
#      configured in data/config/plsql-config.yaml)
#
# Usage:   ./setup.sh                # full setup, all 5 DBs
#          ./setup.sh --no-analyze   # setup + build + app, skip analysis
#          ./setup.sh --db-only      # only bring up + seed databases
#
# Safe to re-run. Requires: Docker Desktop/engine, Java 17, Maven.
# ============================================================================
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

JAR="unified-web/target/unified-web-1.0.0-SNAPSHOT.jar"
PORT="${PORT:-8083}"
BASE="http://localhost:${PORT}"
MAC_DOCKER_BIN="/Applications/Docker.app/Contents/Resources/bin"
DATA_DIR="${DATA_DIR:-data}"
JVM_OPTS="${JVM_OPTS:--Xms512m -Xmx4g -XX:MaxMetaspaceSize=256m -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${DATA_DIR}/heap-dump.hprof}"

info(){ printf '\033[1;34m[INFO]\033[0m  %s\n' "$*"; }
ok(){   printf '\033[1;32m[ OK ]\033[0m  %s\n' "$*"; }
warn(){ printf '\033[1;33m[WARN]\033[0m  %s\n' "$*"; }
err(){  printf '\033[1;31m[FAIL]\033[0m  %s\n' "$*" >&2; }
step(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }

NO_ANALYZE=0; DB_ONLY=0; SKIP_BUILD=0; SKIP_DB=0
for a in "$@"; do
  case "$a" in
    --no-analyze) NO_ANALYZE=1 ;;
    --db-only)    DB_ONLY=1 ;;
    --skip-build) SKIP_BUILD=1 ;;     # start from the existing jar (no mvn)
    --skip-db)    SKIP_DB=1 ;;        # don't touch the databases, just build+start
    --start)      SKIP_BUILD=1; SKIP_DB=1; NO_ANALYZE=1 ;;  # just start the app
    -h|--help)
      echo "Usage: ./setup.sh [--db-only|--skip-db|--skip-build|--no-analyze|--start]"; exit 0 ;;
    *) warn "unknown flag: $a" ;;
  esac
done

# Java required for build/start
if ! command -v java >/dev/null 2>&1; then err "Java 17 not found on PATH."; exit 1; fi
# docker onto PATH (macOS) if needed
if ! command -v docker >/dev/null 2>&1 && [[ -x "$MAC_DOCKER_BIN/docker" ]]; then
  export PATH="$MAC_DOCKER_BIN:$PATH"
fi

# ---------------------------------------------------------------- 1+2. databases
if [[ $SKIP_DB -eq 0 ]]; then
  step "1-2. Databases (Docker) — create + seed all 5"
  bash "$SCRIPT_DIR/db-setup/setup-databases.sh" || { err "database setup failed"; exit 1; }
else
  info "skipping database setup (--skip-db)"
fi

# ---------------------------------------------------------------- 3. Oracle 2nd schema
step "3. Oracle second schema (ANALYZER_REF) — multi-schema demo"
if [[ $SKIP_DB -eq 0 ]] && [[ -f "$SCRIPT_DIR/db-setup/seed/oracle_ref.sql" ]] && command -v docker >/dev/null 2>&1 \
   && docker ps --format '{{.Names}}' | grep -qx oracle-free; then
  docker cp "$SCRIPT_DIR/db-setup/seed/oracle_ref.sql" oracle-free:/tmp/oracle_ref.sql >/dev/null 2>&1
  if docker exec -i oracle-free bash -lc "sqlplus / as sysdba @/tmp/oracle_ref.sql" >/dev/null 2>&1; then
    ok "ANALYZER_REF created (or refreshed)."
    # Recompile ANALYZER so any proc referencing ANALYZER_REF (created after the main seed) is VALID.
    docker exec -i oracle-free bash -lc \
      "echo 'EXEC DBMS_UTILITY.COMPILE_SCHEMA(schema => '\''ANALYZER'\'', compile_all => FALSE);' | sqlplus -s analyzer/Password123!@//localhost:1521/FREEPDB1" >/dev/null 2>&1 || true
  else
    warn "ANALYZER_REF setup skipped/failed (sysdba OS-auth unavailable) — cross-schema Oracle demo will be partial."
  fi
else
  warn "oracle_ref.sql or oracle-free container not found — skipping Oracle 2nd schema."
fi

if [[ $DB_ONLY -eq 1 ]]; then ok "Databases ready (--db-only)."; exit 0; fi

# ---------------------------------------------------------------- 4. build
if [[ $SKIP_BUILD -eq 0 ]]; then
  step "4. Build application (mvn clean install -DskipTests)"
  if ! command -v mvn >/dev/null 2>&1; then err "Maven (mvn) not found on PATH."; exit 1; fi
  if mvn clean install -DskipTests -o >/tmp/analyzer-build.log 2>&1 \
     || mvn clean install -DskipTests >/tmp/analyzer-build.log 2>&1; then
    ok "Build succeeded."
  else
    err "Build failed — see /tmp/analyzer-build.log"; tail -20 /tmp/analyzer-build.log; exit 1
  fi
else
  info "skipping build (--skip-build) — using existing jar"
fi
[[ -f "$JAR" ]] || { err "jar not found: $JAR (build first, or drop --skip-build)"; exit 1; }

# ---------------------------------------------------------------- 5. start app
step "5. Start web app on port ${PORT}"
# stop any prior instance
pkill -f 'unified-web-1.0.0-SNAPSHOT.jar' 2>/dev/null || true
for _ in $(seq 1 20); do lsof -nP -iTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1 || break; sleep 1; done
mkdir -p data/logs
nohup java $JVM_OPTS -jar "$JAR" --server.port=${PORT} --app.data-dir=${DATA_DIR} > "data/logs/app-$(date +%s).log" 2>&1 &
disown || true
info "waiting for ${BASE}/parser/ ..."
UP=0
for _ in $(seq 1 90); do
  if [[ "$(curl -s -o /dev/null -w '%{http_code}' ${BASE}/parser/ 2>/dev/null)" == "200" ]]; then UP=1; break; fi
  sleep 1
done
[[ $UP -eq 1 ]] && ok "App is up: ${BASE}/parser/" || { err "App did not become ready on ${PORT}"; exit 1; }

if [[ $NO_ANALYZE -eq 1 ]]; then ok "Setup complete (--no-analyze). Open ${BASE}/parser/"; exit 0; fi

# ---------------------------------------------------------------- 6. trigger analysis
# Warm up first (connection pools) then trigger; retry only datasources that come
# back empty — avoids the "entry not found" race when analysis fires before a
# DB connection is warm.
step "6. Trigger analysis for all 5 datasources"
info "warming up database connections..."
sleep 12
PROJECTS="OracleDemo MysqlDemo SqlServerDemo PostgresDemo Db2Demo"
payload_for(){
  case "$1" in
    OracleDemo)    echo '{"entryPoint":"ERP_USP_RUN_CYCLE","owner":"ANALYZER","objectType":"PROCEDURE","project":"OracleDemo","environment":"local","dbType":"ORACLE","connName":"oracle-free-conn"}' ;;
    MysqlDemo)     echo '{"entryPoint":"ERP_USP_RUN_CYCLE","owner":"analyzerdb","objectType":"PROCEDURE","project":"MysqlDemo","environment":"local","dbType":"MYSQL","connName":"mysql-local-conn"}' ;;
    SqlServerDemo) echo '{"entryPoint":"USP_RUNMRPCYCLE","owner":"erp","objectType":"PROCEDURE","project":"SqlServerDemo","environment":"local","dbType":"SQLSERVER","connName":"analyzer-db-conn"}' ;;
    PostgresDemo)  echo '{"entryPoint":"erp_usp_run_cycle","owner":"erp","objectType":"PROCEDURE","project":"PostgresDemo","environment":"local","dbType":"POSTGRES","connName":"postgres-local-conn"}' ;;
    Db2Demo)       echo '{"entryPoint":"ERP_USP_RUN_CYCLE","owner":"DB2INST1","objectType":"PROCEDURE","project":"Db2Demo","environment":"local","dbType":"DB2","connName":"db2-local-conn"}' ;;
  esac
}
latest_nodes(){
  curl -s "${BASE}/api/parser/analyses" | python3 -c "
import sys,json
p='$1'
try: d=json.load(sys.stdin)
except: d=[]
r=[a for a in d if a.get('project')==p]; r.sort(key=lambda a:a.get('timestamp',0))
print(r[-1].get('totalNodes',0) if r else 0)" 2>/dev/null
}
analyze(){ curl -s -X POST "${BASE}/api/parser/analyze" -H 'Content-Type: application/json' -d "$1" >/dev/null; }
for attempt in 1 2 3; do
  pending=""
  for p in $PROJECTS; do
    n=$(latest_nodes "$p"); [[ "${n:-0}" -le 0 ]] && { analyze "$(payload_for "$p")"; pending="$pending $p"; }
  done
  [[ -z "$pending" ]] && break
  info "analyzing (attempt $attempt) —$pending"; sleep 25
done
step "Results (nodes per datasource)"
for p in $PROJECTS; do printf '   %-14s %s nodes\n' "$p" "$(latest_nodes "$p")"; done

step "Done"
ok "Analyzer ready at ${BASE}/parser/  (5 datasources configured + analyzed)"
