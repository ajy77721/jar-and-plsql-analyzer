@echo off
REM ============================================================================
REM setup.bat  -  One-command end-to-end bring-up of the analyzer (Windows).
REM
REM   1. Verify Docker (daemon)
REM   2. Create/start + seed all 5 demo databases  [db-setup\setup-databases.bat]
REM   3. Create the Oracle second schema/user ANALYZER_REF (multi-schema demo)
REM   4. Build the application (mvn clean install -DskipTests)
REM   5. Start the web app (port 8083) and wait until ready
REM   6. Trigger a fresh analysis for all 5 datasources
REM
REM Usage:  setup.bat                 full setup
REM         setup.bat --no-analyze    setup + build + app, skip analysis
REM         setup.bat --db-only       only databases
REM
REM Requires: Docker Desktop, Java 17, Maven, curl (built into Win10+).
REM ============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "JAR=unified-web\target\unified-web-1.0.0-SNAPSHOT.jar"
set "PORT=8083"
set "BASE=http://localhost:%PORT%"
set "JVM_OPTS=-Xms512m -Xmx4g -XX:MaxMetaspaceSize=256m -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+HeapDumpOnOutOfMemoryError"
set "NO_ANALYZE=0"
set "DB_ONLY=0"
set "SKIP_BUILD=0"
set "SKIP_DB=0"
for %%A in (%*) do (
  if "%%A"=="--no-analyze" set "NO_ANALYZE=1"
  if "%%A"=="--db-only" set "DB_ONLY=1"
  if "%%A"=="--skip-build" set "SKIP_BUILD=1"
  if "%%A"=="--skip-db" set "SKIP_DB=1"
  if "%%A"=="--start" ( set "SKIP_BUILD=1" & set "SKIP_DB=1" & set "NO_ANALYZE=1" )
)

if "%SKIP_DB%"=="1" ( echo [INFO] skipping database setup ^(--skip-db^) & goto after_db )
echo.
echo ==^> 1-2. Databases (Docker) - create + seed all 5
docker info >nul 2>&1
if errorlevel 1 (
  echo [FAIL] Docker daemon not running. Start Docker Desktop and re-run.
  exit /b 1
)
call "%~dp0db-setup\setup-databases.bat"
if errorlevel 1 ( echo [FAIL] database setup failed & exit /b 1 )

echo.
echo ==^> 3. Oracle second schema (ANALYZER_REF)
if exist "db-setup\seed\oracle_ref.sql" (
  docker ps --format "{{.Names}}" | findstr /x "oracle-free" >nul 2>&1
  if not errorlevel 1 (
    docker cp "db-setup\seed\oracle_ref.sql" oracle-free:/tmp/oracle_ref.sql >nul 2>&1
    docker exec -i oracle-free bash -lc "sqlplus / as sysdba @/tmp/oracle_ref.sql" >nul 2>&1
    if errorlevel 1 ( echo [WARN] ANALYZER_REF setup skipped/failed ) else ( echo [ OK ] ANALYZER_REF created )
  ) else ( echo [WARN] oracle-free container not found - skipping )
) else ( echo [WARN] oracle_ref.sql not found - skipping )
:after_db

if "%DB_ONLY%"=="1" ( echo [ OK ] Databases ready ^(--db-only^) & exit /b 0 )

if "%SKIP_BUILD%"=="1" ( echo [INFO] skipping build ^(--skip-build^) & goto after_build )
echo.
echo ==^> 4. Build application (mvn clean install -DskipTests)
where mvn >nul 2>&1
if errorlevel 1 ( echo [FAIL] Maven not on PATH & exit /b 1 )
call mvn clean install -DskipTests -o > "%TEMP%\analyzer-build.log" 2>&1
if errorlevel 1 (
  call mvn clean install -DskipTests > "%TEMP%\analyzer-build.log" 2>&1
  if errorlevel 1 ( echo [FAIL] Build failed - see %TEMP%\analyzer-build.log & exit /b 1 )
)
echo [ OK ] Build succeeded
:after_build
if not exist "%JAR%" ( echo [FAIL] jar not found: %JAR% ^(build first, or drop --skip-build^) & exit /b 1 )

echo.
echo ==^> 5. Start web app on port %PORT%
taskkill /F /FI "WINDOWTITLE eq analyzer-app*" >nul 2>&1
if not exist data\logs mkdir data\logs
start "analyzer-app" /min cmd /c "java %JVM_OPTS% -jar "%JAR%" --server.port=%PORT% > data\logs\app.log 2>&1"
echo [INFO] waiting for %BASE%/parser/ ...
set "UP=0"
for /L %%i in (1,1,90) do (
  if "!UP!"=="0" (
    for /f %%C in ('curl -s -o nul -w "%%{http_code}" %BASE%/parser/ 2^>nul') do set "CODE=%%C"
    if "!CODE!"=="200" ( set "UP=1" ) else ( timeout /t 1 /nobreak >nul )
  )
)
if "%UP%"=="1" ( echo [ OK ] App is up: %BASE%/parser/ ) else ( echo [FAIL] App not ready on %PORT% & exit /b 1 )

if "%NO_ANALYZE%"=="1" ( echo [ OK ] Setup complete ^(--no-analyze^). Open %BASE%/parser/ & exit /b 0 )

echo.
echo ==^> 6. Trigger analysis for all 5 datasources
call :analyze "{\"entryPoint\":\"ERP_USP_RUN_CYCLE\",\"owner\":\"ANALYZER\",\"objectType\":\"PROCEDURE\",\"project\":\"OracleDemo\",\"environment\":\"local\",\"dbType\":\"ORACLE\",\"connName\":\"oracle-free-conn\"}"
call :analyze "{\"entryPoint\":\"ERP_USP_RUN_CYCLE\",\"owner\":\"analyzerdb\",\"objectType\":\"PROCEDURE\",\"project\":\"MysqlDemo\",\"environment\":\"local\",\"dbType\":\"MYSQL\",\"connName\":\"mysql-local-conn\"}"
call :analyze "{\"entryPoint\":\"USP_RUNMRPCYCLE\",\"owner\":\"erp\",\"objectType\":\"PROCEDURE\",\"project\":\"SqlServerDemo\",\"environment\":\"local\",\"dbType\":\"SQLSERVER\",\"connName\":\"analyzer-db-conn\"}"
call :analyze "{\"entryPoint\":\"erp_usp_run_cycle\",\"owner\":\"erp\",\"objectType\":\"PROCEDURE\",\"project\":\"PostgresDemo\",\"environment\":\"local\",\"dbType\":\"POSTGRES\",\"connName\":\"postgres-local-conn\"}"
call :analyze "{\"entryPoint\":\"ERP_USP_RUN_CYCLE\",\"owner\":\"DB2INST1\",\"objectType\":\"PROCEDURE\",\"project\":\"Db2Demo\",\"environment\":\"local\",\"dbType\":\"DB2\",\"connName\":\"db2-local-conn\"}"
echo [INFO] analyses queued. Open %BASE%/parser/ to view results.

echo.
echo ==^> Done
echo [ OK ] Analyzer ready at %BASE%/parser/  (5 datasources configured + analyzed)
exit /b 0

:analyze
curl -s -X POST "%BASE%/api/parser/analyze" -H "Content-Type: application/json" -d %1 >nul
exit /b 0
