// Validation script for export.js changes
const http = require('http');

const BASE = 'http://localhost:8083';
const ANALYSIS_BASE = '/api/parser';

function get(path) {
    return new Promise((resolve, reject) => {
        http.get(BASE + path, (res) => {
            let data = '';
            res.on('data', d => data += d);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch(e) { resolve(data); }
            });
        }).on('error', reject);
    });
}

function pass(msg) { console.log('  PASS ' + msg); }
function fail(msg) { console.log('  FAIL ' + msg); }
function section(msg) { console.log('\n=== ' + msg + ' ==='); }

async function main() {
    // Discover analysis name
    let analyses;
    try {
        analyses = await get(ANALYSIS_BASE + '/analyses');
    } catch(e) {
        console.log('ERROR connecting to server: ' + e.message);
        process.exit(1);
    }

    if (!Array.isArray(analyses) || analyses.length === 0) {
        console.log('No analyses found. Run an analysis first.');
        process.exit(1);
    }

    const analysis = analyses[0];
    const name = analysis.name;
    console.log('Using analysis: ' + name);
    console.log('Entry: ' + analysis.entryPoint);
    console.log('Nodes: ' + analysis.totalNodes + ', Tables: ' + analysis.totalTables + ', Edges: ' + analysis.totalEdges);

    const API = ANALYSIS_BASE + '/analyses/' + name;

    // Fetch all data
    let index, tablesRaw, joins, cursors, sequences, callGraph;
    try {
        [index, tablesRaw, joins, cursors, sequences, callGraph] = await Promise.all([
            get(API + '/index'),
            get(API + '/tables'),
            get(API + '/joins'),
            get(API + '/cursors'),
            get(API + '/sequences'),
            get(API + '/call-graph')
        ]);
    } catch(e) {
        console.log('ERROR fetching data: ' + e.message);
        process.exit(1);
    }

    // Transform tables exactly as api.js getTableOperations() does
    const tables = (tablesRaw && tablesRaw.tables ? tablesRaw.tables : []).map(t => ({
        tableName: t.name,
        tableSchema: t.schema || '',
        objectType: t.objectType || 'TABLE',
        triggers: t.triggers || [],
        operations: t.allOperations || [],
        accessCount: (t.usedBy || []).reduce((sum, u) => {
            return sum + Object.values(u.operations || {}).reduce((s, lines) => s + lines.length, 0);
        }, 0),
        accessDetails: (t.usedBy || []).flatMap(u => {
            return Object.entries(u.operations || {}).flatMap(([op, lines]) => {
                return (lines || []).map(line => ({
                    operation: op,
                    procedureId: u.nodeId || '',
                    procedureName: u.nodeName || '',
                    lineNumber: line
                }));
            });
        })
    }));

    // ============================================================
    section('INDEX / META');
    console.log('  entryPoint: ' + index.entryPoint);
    console.log('  totalNodes: ' + index.totalNodes);
    console.log('  totalEdges: ' + index.totalEdges);
    if (index.entryPoint) pass('entryPoint present');
    else fail('entryPoint missing');

    // ============================================================
    section('TABLE OPERATIONS API');
    if (!Array.isArray(tables)) { fail('tables not an array'); }
    else {
        console.log('  tables count: ' + tables.length);
        pass('tables is array with ' + tables.length + ' entries');

        // Check first table structure
        if (tables.length > 0) {
            const t0 = tables[0];
            const hasName = !!t0.tableName;
            const hasObjType = !!t0.objectType;
            const hasAccess = Array.isArray(t0.accessDetails);
            const hasTriggers = Array.isArray(t0.triggers);
            if (hasName) pass('tableName present');
            else fail('tableName missing on first table: ' + JSON.stringify(Object.keys(t0)));
            if (hasObjType) pass('objectType present: ' + t0.objectType);
            else fail('objectType missing');
            if (hasAccess) pass('accessDetails present (' + t0.accessDetails.length + ' entries)');
            else fail('accessDetails missing');
            if (hasTriggers) pass('triggers present (' + t0.triggers.length + ' triggers)');
            else fail('triggers missing');
        }

        // Count by type
        const tableCnt = tables.filter(t => (t.objectType||'TABLE').toUpperCase().replace(/ /g,'_') === 'TABLE').length;
        const viewCnt  = tables.filter(t => (t.objectType||'').toUpperCase().replace(/ /g,'_') === 'VIEW').length;
        const mvCnt    = tables.filter(t => (t.objectType||'').toUpperCase().replace(/ /g,'_') === 'MATERIALIZED_VIEW').length;
        console.log('  TABLE: ' + tableCnt + ', VIEW: ' + viewCnt + ', MV: ' + mvCnt);

        // Count triggers
        const trigSet = new Set();
        tables.forEach(t => (t.triggers||[]).forEach(tr => { if(tr.name) trigSet.add(tr.name); }));
        console.log('  Unique trigger names: ' + trigSet.size + ' -> ' + Array.from(trigSet).join(', '));

        // Table ops trigger columns
        const tablesWithTriggers = tables.filter(t => (t.triggers||[]).length > 0);
        console.log('  Tables with triggers: ' + tablesWithTriggers.length);
        if (tablesWithTriggers.length > 0) {
            pass('trigger data present on ' + tablesWithTriggers.length + ' table(s)');
            tablesWithTriggers.forEach(t => {
                console.log('    ' + t.tableName + ' -> ' + t.triggers.map(tr=>tr.name).join(', '));
            });
        }
    }

    // ============================================================
    section('ROOT PROCEDURE QUICK STATS');
    if (!index.entryPoint) { fail('No entryPoint for quick stats'); }
    else {
        const rootNodeName = index.entryPoint.toUpperCase();
        console.log('  Matching against rootNodeName: ' + rootNodeName);

        let rootTableCnt = 0, rootViewCnt = 0, rootMVCnt = 0;
        const rootTrigSet = new Set();

        (tables||[]).forEach(t => {
            const usedByRoot = (t.accessDetails||[]).some(ad =>
                (ad.procedureName||'').toUpperCase() === rootNodeName
            );
            if (!usedByRoot) return;
            const tp = (t.objectType||'TABLE').toUpperCase().replace(/ /g,'_');
            if (tp === 'TABLE') rootTableCnt++;
            else if (tp === 'VIEW') rootViewCnt++;
            else if (tp === 'MATERIALIZED_VIEW') rootMVCnt++;
            (t.triggers||[]).forEach(tr => { if(tr.name) rootTrigSet.add(tr.name); });
        });

        console.log('  Tables Accessed (root): ' + rootTableCnt);
        console.log('  Views Accessed (root): ' + rootViewCnt);
        console.log('  MVs Accessed (root): ' + rootMVCnt);
        console.log('  Triggers on root tables: ' + rootTrigSet.size);

        // Nodes for proc/func counts — root node is nodes[0], calledNodes = all others
        const nodes = index.nodes || [];
        const rootNode = nodes[0];
        const cnt = (rootNode && rootNode.counts) || {};
        const calledNodes = nodes.slice(1);
        const uniqProcCnt = calledNodes.filter(n => (n.objectType||'').toUpperCase() === 'PROCEDURE').length;
        const uniqFuncCnt = calledNodes.filter(n => (n.objectType||'').toUpperCase() === 'FUNCTION').length;
        const totalInt = cnt.internalCalls || 0;
        const totalExt = cnt.externalCalls || 0;

        console.log('  Procedures Called: ' + uniqProcCnt);
        console.log('  Functions Called: ' + uniqFuncCnt);
        console.log('  Internal Calls: ' + totalInt);
        console.log('  External Calls: ' + totalExt);

        if (rootTableCnt > 0) pass('Tables Accessed populated');
        else fail('Tables Accessed is 0 - check procedureName matching');
    }

    // ============================================================
    section('CALL GRAPH API FIELDS');
    if (!callGraph) { fail('callGraph null'); }
    else {
        const edges = callGraph.edges || [];
        console.log('  edges count: ' + edges.length);
        if (edges.length > 0) {
            const e0 = edges[0];
            console.log('  First edge keys: ' + Object.keys(e0).join(', '));
            if (e0.count !== undefined) pass('count field present: ' + e0.count);
            else fail('count field missing (old: callCount)');
            if (Array.isArray(e0.lines)) pass('lines[] field present: ' + JSON.stringify(e0.lines));
            else if (e0.lines !== undefined) fail('lines is not array: ' + typeof e0.lines);
            else fail('lines field missing (old: lineNumber)');
            if (e0.backEdge !== undefined) pass('backEdge field present: ' + e0.backEdge);
            else fail('backEdge missing');
        }
    }

    // ============================================================
    section('JOINS API');
    if (!Array.isArray(joins)) { fail('joins not array'); }
    else {
        console.log('  joins count: ' + joins.length);
        if (joins.length > 0) {
            const j0 = joins[0];
            console.log('  First join keys: ' + Object.keys(j0).join(', '));
            pass('joins is array with ' + joins.length + ' entries');
        } else {
            console.log('  (no joins found)');
        }

        // joinsByProc simulation (used in Complexity sheet) — matches export.js logic
        // joins[].accessDetails[].procedureName is the correct field
        const joinsByProc = {};
        joins.forEach(j => {
            (j.accessDetails || []).forEach(ad => {
                const proc = (ad.procedureName || '').toUpperCase();
                if (proc) joinsByProc[proc] = (joinsByProc[proc] || 0) + 1;
            });
        });
        const topJoinProcs = Object.entries(joinsByProc).sort((a,b)=>b[1]-a[1]).slice(0,3);
        if (topJoinProcs.length > 0) {
            pass('joinsByProc built: ' + topJoinProcs.map(([k,v])=>k+'='+v).join(', '));
        }
    }

    // ============================================================
    section('COMPLEXITY SCORING');
    const nodes2 = index.nodes || [];
    if (nodes2.length === 0) { fail('no nodes for complexity'); }
    else {
        // Simulate complexity for first 3 nodes
        const joinsByProc2 = {};
        (joins||[]).forEach(j => {
            (j.accessDetails || []).forEach(ad => {
                const proc = (ad.procedureName || '').toUpperCase();
                if (proc) joinsByProc2[proc] = (joinsByProc2[proc] || 0) + 1;
            });
        });

        const results = nodes2.slice(0, 3).map(n => {
            const c    = n.counts || {};
            const stm  = c.statements || {};
            const loc  = n.linesOfCode || 0;
            const tbls = c.tables || 0;
            const curs = c.cursors || 0;
            const ops  = (stm.SELECT||0)+(stm.INSERT||0)+(stm.UPDATE||0)+(stm.DELETE||0)+(stm.MERGE||0);
            const procKey = (n.name||'').toUpperCase();
            const jcnt = joinsByProc2[procKey] || 0;
            const dyn  = (stm.EXECUTE_IMMEDIATE||0)+(stm.DBMS_SQL||0);
            const score = loc*1 + tbls*5 + curs*2 + ops*2 + jcnt*3 + dyn*10;
            const risk  = score > 2000 ? 'HIGH' : score > 500 ? 'MEDIUM' : 'LOW';
            return { name: n.name || n.id, score, risk, loc, tbls, curs, ops, jcnt, dyn };
        });

        console.log('  Top 3 nodes complexity:');
        results.forEach(r => {
            console.log('    ' + r.name + ': score=' + r.score + ' risk=' + r.risk +
                ' (loc=' + r.loc + ' tbls=' + r.tbls + ' curs=' + r.curs +
                ' ops=' + r.ops + ' j=' + r.jcnt + ' dyn=' + r.dyn + ')');
        });
        pass('complexity scoring simulated for ' + results.length + ' nodes');
    }

    // ============================================================
    section('CURSORS API');
    if (!Array.isArray(cursors)) { fail('cursors not array'); }
    else {
        console.log('  cursors count: ' + cursors.length);
        if (cursors.length > 0) {
            pass('cursors present: ' + cursors.length);
            console.log('  First cursor keys: ' + Object.keys(cursors[0]).join(', '));
        } else {
            console.log('  (no cursors found)');
        }
    }

    // ============================================================
    section('SEQUENCES API');
    if (!Array.isArray(sequences)) { fail('sequences not array'); }
    else {
        console.log('  sequences count: ' + sequences.length);
        if (sequences.length > 0) {
            pass('sequences present: ' + sequences.length);
        } else {
            console.log('  (no sequences found)');
        }
    }

    // ============================================================
    section('SUMMARY');
    console.log('\nAll checks complete. Review FAILs above for issues.');
}

main().catch(e => {
    console.log('FATAL: ' + e.message);
    console.log(e.stack);
    process.exit(1);
});
