package com.jaranalyzer.service;

import com.jaranalyzer.model.*;
import com.jaranalyzer.util.SpringAnnotations;
import com.jaranalyzer.util.TypeUtils;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.*;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Stateless bytecode parser: accepts raw class bytes and returns a ClassInfo.
 * All annotation, endpoint, and path helpers live here.
 */
@Component
public class BytecodeClassParser {

    // Mirrors MongoMethodDetector.BULK_COLLECTOR_METHODS — duplicated here (rather than a shared
    // dependency) since this parser is intentionally stateless/dependency-free; both sets must be
    // kept in sync if BulkWriteCollector's buffering method names ever change.
    private static final Set<String> BULK_COLLECTOR_ADD_METHODS = Set.of("addInsert", "addUpdate", "addDelete");

    public ClassInfo parseClass(byte[] bytecode) {
        try {
            org.objectweb.asm.ClassReader reader = new org.objectweb.asm.ClassReader(bytecode);
            ClassNode classNode = new ClassNode();
            reader.accept(classNode, 0);

            if ((classNode.access & Opcodes.ACC_SYNTHETIC) != 0) return null;

            ClassInfo info = new ClassInfo();
            String fqn = classNode.name.replace('/', '.');

            info.setFullyQualifiedName(fqn);
            int lastDot = fqn.lastIndexOf('.');
            String pkg = lastDot > 0 ? fqn.substring(0, lastDot) : "";
            info.setPackageName(pkg);
            info.setSimpleName(lastDot > 0 ? fqn.substring(lastDot + 1) : fqn);
            info.setSuperClass(classNode.superName != null ? classNode.superName.replace('/', '.') : null);
            info.setAccessFlags(classNode.access);

            // Reconstruct source path from SourceFile bytecode attribute + package
            if (classNode.sourceFile != null && !classNode.sourceFile.isEmpty()) {
                String pkgPath = pkg.isEmpty() ? "" : pkg.replace('.', '/') + "/";
                info.setSourcePath("src/main/java/" + pkgPath + classNode.sourceFile);
            }
            info.setIsInterface((classNode.access & Opcodes.ACC_INTERFACE) != 0);
            info.setIsAbstract((classNode.access & Opcodes.ACC_ABSTRACT) != 0);
            info.setIsEnum((classNode.access & Opcodes.ACC_ENUM) != 0);

            if (classNode.interfaces != null) {
                for (String iface : classNode.interfaces) {
                    info.getInterfaces().add(iface.replace('/', '.'));
                }
            }

            List<AnnotationInfo> classAnnotations = parseAnnotationNodes(classNode.visibleAnnotations);
            info.setAnnotations(classAnnotations);
            info.setStereotype(determineStereotype(classAnnotations, info.getInterfaces()));

            // Extract entity type from generic signature for repository interfaces
            // e.g. MongoRepository<ClaimEntity, String> → "com.example.model.ClaimEntity"
            if ("REPOSITORY".equals(info.getStereotype()) && classNode.signature != null) {
                String entityType = extractRepositoryEntityType(classNode.signature, info.getInterfaces());
                if (entityType != null) info.setRepositoryEntityType(entityType);
            }

            String basePath = extractBasePath(classNode.visibleAnnotations);

            // Fields
            if (classNode.fields != null) {
                for (FieldNode field : classNode.fields) {
                    if ((field.access & Opcodes.ACC_SYNTHETIC) != 0) continue;
                    FieldInfo fi = new FieldInfo();
                    fi.setName(field.name);
                    fi.setType(TypeUtils.cleanTypeName(Type.getType(field.desc).getClassName()));
                    fi.setAccessFlags(field.access);
                    fi.setAnnotations(parseAnnotationNodes(field.visibleAnnotations));
                    // Extract generic element type for collection fields (List<T>, Set<T>, Map<K,V>)
                    if (field.signature != null) {
                        String elem = extractCollectionElementType(field.desc, field.signature);
                        if (elem != null) fi.setGenericElementType(elem);
                    }
                    // Capture static final String constant values (collection names, etc.)
                    if (field.value instanceof String) {
                        fi.setConstantValue((String) field.value);
                    }
                    // Extract MongoDB field name from @Field, @BsonProperty, @JsonProperty
                    extractMongoFieldName(fi);
                    // Extract JPA column name from @Column
                    extractJpaColumnName(fi);
                    info.getFields().add(fi);
                }
            }

            // Same-class static final String constants, keyed by field name — used to resolve
            // GETSTATIC-loaded call arguments (e.g. bulkCollector.addInsert(SOME_CONSTANT, doc))
            // inline as if they were LDC literals, without needing the cross-class enumConstantsMap
            // resolution that CollectionResolver performs later for constants declared elsewhere.
            Map<String, String> classConstantsByFieldName = new HashMap<>();
            for (FieldInfo fi : info.getFields()) {
                if (fi.getConstantValue() != null) {
                    classConstantsByFieldName.put(fi.getName(), fi.getConstantValue());
                }
            }

            // Methods
            if (classNode.methods != null) {
                for (MethodNode method : classNode.methods) {
                    if ("<clinit>".equals(method.name)) continue;
                    if ((method.access & Opcodes.ACC_BRIDGE) != 0) continue;

                    MethodInfo mi = new MethodInfo();
                    mi.setName(method.name);
                    mi.setDescriptor(method.desc);
                    mi.setAccessFlags(method.access);
                    mi.setReturnType(TypeUtils.cleanTypeName(Type.getReturnType(method.desc).getClassName()));

                    Type[] paramTypes = Type.getArgumentTypes(method.desc);
                    List<ParameterInfo> params = new ArrayList<>();
                    for (int i = 0; i < paramTypes.length; i++) {
                        ParameterInfo pi = new ParameterInfo();
                        pi.setType(TypeUtils.cleanTypeName(paramTypes[i].getClassName()));
                        pi.setName("arg" + i);
                        params.add(pi);
                    }

                    // Map local-variable-table slot index -> parameter slot, so ALOAD tracking
                    // below can tell a method-parameter load (PARAM) apart from a true local
                    // variable load (LOCAL_VAR) using the exact same slot arithmetic as the
                    // parameter-naming loop above.
                    Set<Integer> paramSlots = new HashSet<>();
                    if (method.localVariables != null) {
                        int slotIndex = (method.access & Opcodes.ACC_STATIC) != 0 ? 0 : 1;
                        for (int i = 0; i < paramTypes.length && i < params.size(); i++) {
                            int slot = slotIndex;
                            paramSlots.add(slot);
                            for (LocalVariableNode lv : method.localVariables) {
                                if (lv.index == slot) {
                                    params.get(i).setName(lv.name);
                                    break;
                                }
                            }
                            slotIndex += paramTypes[i].getSize();
                        }
                    }

                    if (method.visibleParameterAnnotations != null) {
                        for (int i = 0; i < method.visibleParameterAnnotations.length && i < params.size(); i++) {
                            List<AnnotationNode> paramAnns = method.visibleParameterAnnotations[i];
                            if (paramAnns != null) {
                                params.get(i).setAnnotations(parseAnnotationNodes(paramAnns));
                            }
                        }
                    }

                    mi.setParameters(params);
                    mi.setAnnotations(parseAnnotationNodes(method.visibleAnnotations));
                    extractEndpointInfo(mi, basePath);

                    if (method.instructions != null) {
                        List<String> stringLits = new ArrayList<>();
                        List<FieldAccessInfo> fieldAccesses = new ArrayList<>();
                        // Track GETFIELD on 'this' to link interface calls to their DI-injected field
                        String pendingReceiverField = null;
                        // Declared type of the pending receiver field (used to prevent builder-chain
                        // INVOKEVIRTUAL calls from consuming the pending receiver prematurely)
                        String pendingReceiverType = null;
                        // Rolling window of LDC strings between consecutive method calls.
                        // Attached to each MethodCallInfo so we can correlate string args
                        // with specific invocations (e.g. BulkWriteCollector.addInsert("COLL", ...))
                        List<String> pendingStringArgs = new ArrayList<>();
                        // Stack of saved pendingStringArgs snapshots, pushed at each NEW (object
                        // construction start) and popped at the matching INVOKESPECIAL <init> call.
                        // Needed so a NESTED constructor's own LDC literals (e.g. the inner
                        // `new Document("into", targetCollectionName)` in
                        // `new Document("$merge", new Document("into", targetCollectionName))`)
                        // are scoped separately from literals already pending for the OUTER
                        // constructor call that hasn't been invoked yet (e.g. the outer's own
                        // "$merge" literal). Without this, the inner <init> call greedily drains
                        // ALL currently-pending literals — including the outer's "$merge" pushed
                        // before the inner NEW — producing a bogus ["$merge","into"] on the inner
                        // call and nothing left for the outer call.
                        Deque<List<String>> pendingStringArgsScopeStack = new ArrayDeque<>();
                        // Collection-name string arg captured from a getCollection("X") call, held
                        // until the immediately-chained method call on its return value (e.g.
                        // db.getCollection("X").insertOne(doc)) so that chained call also sees "X".
                        // Without this, getCollection and insertOne are two separate InvocationRefs
                        // with no automatic linkage (each MethodInsnNode produces its own
                        // MethodCallInfo, and pendingStringArgs is drained by getCollection itself),
                        // so MongoMethodDetector's insertOne/aggregate/etc. detection never resolves
                        // a collection name for the common fluent-chaining idiom.
                        String pendingChainedCollectionArg = null;
                        // Non-literal (ALOAD/GETFIELD/GETSTATIC) argument sources captured between
                        // the previous call and this one — parallel to pendingStringArgs, but for
                        // values whose origin is a variable/field rather than an LDC. Consumed the
                        // same way, at each MethodInsnNode, so detectors can still report WHICH
                        // variable was used when the collection-name argument isn't a literal.
                        List<MethodCallInfo.DynamicArgSource> pendingDynamicArgs = new ArrayList<>();
                        // Parallel to pendingChainedCollectionArg, for the case where getCollection(x)
                        // was called with a variable/field rather than a literal — propagates the
                        // dynamic source onto the immediately-chained call (e.g.
                        // db.getCollection(sourceCollection).aggregate(pipeline)). Mutually exclusive
                        // with pendingChainedCollectionArg: getCollection's argument is either a
                        // resolved literal or a dynamic source, never both.
                        MethodCallInfo.DynamicArgSource pendingChainedDynamicArg = null;
                        // Declared return type of the getCollection(...) call that produced
                        // pendingChainedCollectionArg/pendingChainedDynamicArg (e.g.
                        // "com.mongodb.client.MongoCollection") — the receiver type the chained
                        // call must actually be invoked ON. Needed because a fluent BUILDER
                        // argument constructed in between (e.g. `new BulkWriteOptions().ordered
                        // (false)` as bulkWrite's 2nd arg in `getCollection(x).bulkWrite(ops, new
                        // BulkWriteOptions().ordered(false))`) is ALSO an INVOKEVIRTUAL — so the
                        // opcode-only check isn't enough to identify the real chained call;
                        // `.ordered(false)` would otherwise consume and clear the pending arg
                        // before bulkWrite (the actual MongoCollection-receiver call) is reached.
                        String pendingChainedReceiverType = null;

                        // Pre-scan: count ASTORE occurrences per local-variable slot, and record the
                        // last LDC-derived literal string stored to each slot. Used below so an ALOAD
                        // of a slot with EXACTLY ONE ASTORE in the whole method can be resolved inline
                        // as a real literal (common "String coll = "X"; ...; use(coll);" idiom),
                        // while a slot reassigned more than once (e.g. across if/else branches) is
                        // correctly left as a dynamic reference rather than guessing which branch ran.
                        Map<Integer, Integer> astoreCountBySlot = new HashMap<>();
                        Map<Integer, String> literalOnlySlotValue = new HashMap<>();
                        Set<Integer> slotEverStoredFromNonLiteral = new HashSet<>();
                        {
                            String pendingLiteral = null;
                            for (AbstractInsnNode scanInsn = method.instructions.getFirst(); scanInsn != null; scanInsn = scanInsn.getNext()) {
                                if (scanInsn instanceof LdcInsnNode scanLdc && scanLdc.cst instanceof String s) {
                                    pendingLiteral = s;
                                } else if (scanInsn instanceof VarInsnNode scanVar && scanVar.getOpcode() == Opcodes.ASTORE) {
                                    astoreCountBySlot.merge(scanVar.var, 1, Integer::sum);
                                    if (pendingLiteral != null) {
                                        literalOnlySlotValue.put(scanVar.var, pendingLiteral);
                                    } else {
                                        // Stored value did not come directly from an LDC (e.g. a method
                                        // call result) — this slot can never be trusted as literal-only.
                                        slotEverStoredFromNonLiteral.add(scanVar.var);
                                    }
                                    pendingLiteral = null;
                                } else if (scanInsn instanceof MethodInsnNode) {
                                    pendingLiteral = null;
                                }
                            }
                        }

                        // Pre-scan: for each addInsert/addUpdate/addDelete call on a BulkWriteCollector
                        // owner, walk BACKWARD to the nearest preceding LDC string literal, stopping at
                        // any other MethodInsnNode/ASTORE/NEW in between (those signal an argument was
                        // built by a nested call, not this literal). This directly answers "what literal
                        // did THIS specific call push as its collection-name arg", independent of how
                        // many non-consuming argument-builder calls (e.g. this.buildDoc(...)) run between
                        // the LDC and the actual addInsert/addUpdate invocation — those calls evaluate
                        // AFTER the collection-name arg is pushed but BEFORE addInsert/addUpdate itself
                        // (JVM stack-based argument evaluation order), and would otherwise steal the
                        // pending literal via the generic pendingStringArgs draining below.
                        Map<MethodInsnNode, String> bulkCollectorLiteralOverride = new IdentityHashMap<>();
                        {
                            String pendingLdc = null;
                            for (AbstractInsnNode scanInsn = method.instructions.getFirst(); scanInsn != null; scanInsn = scanInsn.getNext()) {
                                if (scanInsn instanceof LdcInsnNode scanLdc && scanLdc.cst instanceof String s) {
                                    pendingLdc = s;
                                } else if (scanInsn instanceof FieldInsnNode scanField && scanField.getOpcode() == Opcodes.GETSTATIC
                                        && scanField.owner.replace('/', '.').equals(fqn)) {
                                    // Same-class static-final constant (e.g. `private static final
                                    // String WIP_TABLE = "WIP_UWFI_..."`) used directly as the arg —
                                    // resolves the same way the main loop's GETSTATIC handling below does.
                                    String constVal = classConstantsByFieldName.get(scanField.name);
                                    if (constVal != null) pendingLdc = constVal;
                                } else if (scanInsn instanceof MethodInsnNode scanCall) {
                                    if (pendingLdc != null && BULK_COLLECTOR_ADD_METHODS.contains(scanCall.name)
                                            && scanCall.owner.toLowerCase().contains("bulkwritecollector")) {
                                        bulkCollectorLiteralOverride.put(scanCall, pendingLdc);
                                        pendingLdc = null;
                                    }
                                    // else: leave pendingLdc pending — a non-bulk-collector call in
                                    // between (e.g. this.convertDoc(bean) building addInsert's 2nd
                                    // arg) is an argument-BUILDER call, not a consumer of the literal;
                                    // it must not clear the literal before the real addInsert/addUpdate
                                    // call (which comes right after it in bytecode) gets a chance to
                                    // match. Only ASTORE/NEW/a fresh LDC end this literal's candidacy.
                                } else if (scanInsn instanceof VarInsnNode scanVar && scanVar.getOpcode() == Opcodes.ASTORE) {
                                    pendingLdc = null;
                                } else if (scanInsn instanceof TypeInsnNode scanType && scanType.getOpcode() == Opcodes.NEW) {
                                    pendingLdc = null;
                                }
                            }
                        }

                        int currentLine = 0;
                        int minLine = Integer.MAX_VALUE, maxLine = 0;

                        for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                            // Track current line number from LineNumberNode
                            if (insn instanceof LineNumberNode lineNode) {
                                currentLine = lineNode.line;
                                if (currentLine < minLine) minLine = currentLine;
                                if (currentLine > maxLine) maxLine = currentLine;
                                continue;
                            }

                            // Track NEW (object construction start) so a nested constructor call's
                            // own LDC literals (e.g. inner `new Document("into", ...)`) are scoped
                            // separately from literals already pending for an outer constructor call
                            // that hasn't been INVOKESPECIAL <init>'d yet (e.g. outer's "$merge").
                            // Save-and-clear here; restored on the matching <init> below.
                            if (insn instanceof TypeInsnNode typeInsn && typeInsn.getOpcode() == Opcodes.NEW) {
                                pendingStringArgsScopeStack.push(new ArrayList<>(pendingStringArgs));
                                pendingStringArgs.clear();
                            }

                            // Capture LDC constants (strings and class literals)
                            if (insn instanceof LdcInsnNode ldc) {
                                if (ldc.cst instanceof String s) {
                                    // Collection-like strings (UPPER_CASE) go to the method's stringLiterals
                                    if (s.length() >= 4 && s.length() <= 60
                                            && s.matches("[A-Z][A-Z0-9_]+")) {
                                        stringLits.add(s);
                                    }
                                    // SQL strings (any SQL keyword prefix) also go to stringLiterals for fallback scanning
                                    if (s.length() >= 6) {
                                        String up = s.stripLeading().toUpperCase();
                                        if (up.startsWith("SELECT ") || up.startsWith("INSERT ")
                                                || up.startsWith("UPDATE ") || up.startsWith("DELETE ")
                                                || up.startsWith("MERGE ") || up.startsWith("WITH ")
                                                || up.startsWith("BEGIN ") || up.startsWith("CALL ")
                                                || up.startsWith("{CALL") || up.startsWith("EXEC ")) {
                                            stringLits.add(s);
                                        }
                                    }
                                    // All non-trivial strings go to the pending args window for next call
                                    // Limit raised to 8000 to capture multi-line SQL text blocks
                                    if (s.length() >= 2 && s.length() <= 8000) {
                                        pendingStringArgs.add(s);
                                    }
                                } else if (ldc.cst instanceof Type t && t.getSort() == Type.OBJECT) {
                                    // Class literal (Bean.class) → add FQN to pending args
                                    // Enables MongoMethodDetector to resolve mongoOps.updateMulti(q, u, Bean.class)
                                    String className = t.getClassName();
                                    if (className != null && className.contains(".")) {
                                        pendingStringArgs.add("__class:" + className);
                                    }
                                }
                            }

                            // Capture ALOAD of a local variable/parameter as a potential dynamic
                            // (non-literal) call argument — e.g. bulkCollector.addInsert(coll, doc)
                            // where 'coll' is a loop variable, parameter, or local. Slot 0 on an
                            // instance method is 'this' and is never a collection-name variable.
                            if (insn instanceof VarInsnNode varInsn && varInsn.getOpcode() == Opcodes.ALOAD) {
                                boolean isStaticMethod = (method.access & Opcodes.ACC_STATIC) != 0;
                                if (isStaticMethod || varInsn.var != 0) {
                                    // Same-method single-assignment literal resolution: if this slot
                                    // was ASTORE'd from an LDC exactly once in the whole method, treat
                                    // it as if the literal itself were loaded here (safe: a slot
                                    // reassigned across branches is excluded by the ASTORE-count/
                                    // non-literal-store checks below, so we never guess between branches).
                                    Integer storeCount = astoreCountBySlot.get(varInsn.var);
                                    String resolvedLiteral = literalOnlySlotValue.get(varInsn.var);
                                    if (resolvedLiteral != null && storeCount != null && storeCount == 1
                                            && !slotEverStoredFromNonLiteral.contains(varInsn.var)) {
                                        pendingStringArgs.add(resolvedLiteral);
                                    } else {
                                        // Only track String-typed locals/params as dynamic ARGUMENT
                                        // candidates — same reasoning as the GETFIELD filter above:
                                        // a MongoTemplate/Repository-typed local can never be String,
                                        // so this cannot mistake a receiver variable for an argument.
                                        String varName = resolveLocalVarName(method, varInsn.var, true, varInsn);
                                        if (varName != null) {
                                            String kind = paramSlots.contains(varInsn.var) ? "PARAM" : "LOCAL_VAR";
                                            pendingDynamicArgs.add(new MethodCallInfo.DynamicArgSource(kind, varName, null));
                                        }
                                    }
                                }
                            }

                            // Capture field accesses (GETFIELD, PUTFIELD, GETSTATIC, PUTSTATIC)
                            if (insn instanceof FieldInsnNode fieldInsn) {
                                FieldAccessInfo fai = new FieldAccessInfo();
                                fai.setOwnerClass(fieldInsn.owner.replace('/', '.'));
                                fai.setFieldName(fieldInsn.name);
                                fai.setFieldType(TypeUtils.cleanTypeName(Type.getType(fieldInsn.desc).getClassName()));
                                fai.setLineNumber(currentLine);
                                switch (fieldInsn.getOpcode()) {
                                    case Opcodes.GETFIELD -> fai.setAccessType("GET");
                                    case Opcodes.PUTFIELD -> fai.setAccessType("PUT");
                                    case Opcodes.GETSTATIC -> fai.setAccessType("GET_STATIC");
                                    case Opcodes.PUTSTATIC -> fai.setAccessType("PUT_STATIC");
                                }
                                fieldAccesses.add(fai);
                                // Track GETFIELD on 'this' as pending receiver for next interface/virtual call.
                                // Record the field's declared type so we can reject intermediate builder-chain
                                // INVOKEVIRTUAL calls (e.g. RequestBuilder.metric()) that are not the target.
                                // Only PUTFIELD / GETSTATIC / PUTSTATIC reset the pending state; a GETFIELD on a
                                // non-this object does NOT clear it (it just pushes another value to the stack
                                // as an argument and the original receiver is still underneath).
                                if (fieldInsn.getOpcode() == Opcodes.GETFIELD
                                        && fieldInsn.owner.replace('/', '.').equals(fqn)) {
                                    pendingReceiverField = fieldInsn.name;
                                    pendingReceiverType = Type.getType(fieldInsn.desc).getClassName().replace('/', '.');
                                } else if (fieldInsn.getOpcode() == Opcodes.PUTFIELD
                                        || fieldInsn.getOpcode() == Opcodes.GETSTATIC
                                        || fieldInsn.getOpcode() == Opcodes.PUTSTATIC) {
                                    pendingReceiverField = null;
                                    pendingReceiverType = null;
                                    pendingChainedCollectionArg = null;
                                    pendingChainedDynamicArg = null;
                                    pendingChainedReceiverType = null;
                                }
                                // GETFIELD on a non-this object: leave the pending receiver intact

                                // Additionally (independent of the receiver-linkage logic above) record
                                // GETFIELD/GETSTATIC as a potential dynamic call-argument source — e.g.
                                // bulkCollector.addInsert(this.targetCollection, doc) or
                                // addInsert(SomeConstants.COLLECTION_NAME, doc). This may overlap with the
                                // receiver field captured above for the SAME field access (we can't cheaply
                                // disambiguate "receiver" vs "argument" without a full stack simulator); any
                                // false-positive capture here is harmless because detectors only consult
                                // this list on call sites already known (by method name + owner) to expect
                                // a collection-name argument, so unrelated field captures are simply ignored.
                                if (fieldInsn.getOpcode() == Opcodes.GETSTATIC) {
                                    String ownerFqn = fieldInsn.owner.replace('/', '.');
                                    String sameClassConst = ownerFqn.equals(fqn)
                                            ? classConstantsByFieldName.get(fieldInsn.name) : null;
                                    if (sameClassConst != null) {
                                        // Same-class static final String constant — resolve inline as a
                                        // literal, exactly as if it had been loaded via LDC.
                                        pendingStringArgs.add(sameClassConst);
                                    } else {
                                        // Cross-class (or non-constant) static field — leave for
                                        // CollectionResolver's enumConstantsMap resolution attempt.
                                        pendingDynamicArgs.add(new MethodCallInfo.DynamicArgSource(
                                                "STATIC_FIELD", fieldInsn.name, ownerFqn));
                                    }
                                } else if (fieldInsn.getOpcode() == Opcodes.GETFIELD
                                        && isStringDesc(fieldInsn.desc)) {
                                    // Only track String-typed fields as dynamic ARGUMENT candidates.
                                    // This is what disambiguates a receiver field load (e.g.
                                    // this.mongoTemplate, type MongoTemplate) from a genuine
                                    // collection-name-holding field (e.g. this.targetCollection, type
                                    // String) without needing a full stack simulator: a
                                    // MongoTemplate/Repository-typed field can never be String-typed,
                                    // so this filter cannot mistake a receiver for an argument.
                                    pendingDynamicArgs.add(new MethodCallInfo.DynamicArgSource(
                                            "FIELD", fieldInsn.name, fieldInsn.owner.replace('/', '.')));
                                }
                            }

                            if (insn instanceof MethodInsnNode call) {
                                MethodCallInfo mci = new MethodCallInfo();
                                mci.setOwnerClass(call.owner.replace('/', '.'));
                                mci.setMethodName(call.name);
                                mci.setDescriptor(call.desc);
                                mci.setReturnType(TypeUtils.cleanTypeName(Type.getReturnType(call.desc).getClassName()));
                                mci.setOpcode(call.getOpcode());
                                mci.setLineNumber(currentLine);
                                // Link interface/virtual calls to the DI-injected field loaded via GETFIELD.
                                // INVOKESPECIAL (opcode 183) is used for constructors (e.g. new MapSqlParameterSource())
                                // called as arguments to the field method — do NOT clear pendingReceiverField for these,
                                // so it survives to the actual INVOKEINTERFACE/INVOKEVIRTUAL on the field object.
                                // Only INVOKEINTERFACE / INVOKEVIRTUAL consume the field object from the stack
                                // and therefore clear the pending receiver.
                                // INVOKESPECIAL (<init>) and INVOKESTATIC are called to build arguments —
                                // they do not consume the field object, so the pending receiver survives.
                                boolean isVirtualOrInterface = call.getOpcode() == Opcodes.INVOKEINTERFACE
                                        || call.getOpcode() == Opcodes.INVOKEVIRTUAL;
                                if (pendingReceiverField != null && isVirtualOrInterface) {
                                    String callOwner = call.owner.replace('/', '.');
                                    // Only consume the pending receiver when the call's owner matches the
                                    // field's declared type. Builder-chain calls (e.g. RequestBuilder.metric())
                                    // have a different owner and must leave the pending receiver intact so it
                                    // survives to the actual target INVOKEINTERFACE/INVOKEVIRTUAL.
                                    if (pendingReceiverType == null || callOwner.equals(pendingReceiverType)) {
                                        mci.setReceiverFieldName(pendingReceiverField);
                                        pendingReceiverField = null;
                                        pendingReceiverType = null;
                                    }
                                    // else: type mismatch — builder-chain call; leave pending receiver intact
                                }
                                if (!pendingStringArgs.isEmpty()) {
                                    mci.setRecentStringArgs(new ArrayList<>(pendingStringArgs));
                                    pendingStringArgs.clear();
                                }
                                // Bulk-collector call-site override (see bulkCollectorLiteralOverride
                                // pre-scan above): collector.addInsert("WIP_X", this.buildDoc(...)) pushes
                                // "WIP_X" via LDC, then evaluates buildDoc(...) — an argument-BUILDER call
                                // that runs BEFORE addInsert itself per JVM stack-based argument order and
                                // greedily steals "WIP_X" from pendingStringArgs above. The identity-keyed
                                // pre-scan below sidesteps that ambiguity by directly matching each LDC to
                                // its enclosing addInsert/addUpdate/addDelete call in the raw instruction
                                // stream, so the override always wins regardless of what pendingStringArgs
                                // got drained into on the way there.
                                String bulkOverride = bulkCollectorLiteralOverride.get(call);
                                if (bulkOverride != null) {
                                    List<String> args = mci.getRecentStringArgs();
                                    if (args == null) {
                                        mci.setRecentStringArgs(new ArrayList<>(List.of(bulkOverride)));
                                    } else if (!args.contains(bulkOverride)) {
                                        args.add(bulkOverride);
                                    }
                                }
                                // Matching <init> for a NEW pushed earlier — restore the caller's
                                // (outer) pendingStringArgs scope now that this constructor call has
                                // consumed its own literals above. This is what keeps a nested
                                // `new Document("into", ...)` constructor's "into" literal from
                                // leaking onto the outer `new Document("$merge", ...)` constructor
                                // call (and vice versa) — see pendingStringArgsScopeStack declaration.
                                if ("<init>".equals(call.name) && !pendingStringArgsScopeStack.isEmpty()) {
                                    pendingStringArgs.addAll(pendingStringArgsScopeStack.pop());
                                }
                                if (!pendingDynamicArgs.isEmpty()) {
                                    mci.setDynamicArgSources(new ArrayList<>(pendingDynamicArgs));
                                    pendingDynamicArgs.clear();
                                }
                                // Propagate a collection name captured from an immediately-preceding
                                // getCollection("X") call onto THIS call — the fluent-chain idiom
                                // db.getCollection("X").insertOne(doc) produces two separate
                                // MethodInsnNodes (getCollection, then insertOne on its return
                                // value), so without this the collection name never reaches the
                                // insertOne/aggregate/etc. invocation that actually needs it.
                                // Consumed exactly once — always cleared after this point, so it
                                // never leaks past the single call chained directly onto getCollection.
                                //
                                // Only INVOKEINTERFACE/INVOKEVIRTUAL calls actually consume the
                                // MongoCollection reference off the stack and are eligible to be the
                                // "chained" call. Require the call's owner to match the declared return
                                // type of the getCollection(...) call that produced the pending arg, so
                                // an intermediate builder-chain call on a differently-typed argument
                                // (e.g. `new BulkWriteOptions().ordered(false)`) doesn't steal it.
                                boolean isChainConsumingCall = (call.getOpcode() == Opcodes.INVOKEINTERFACE
                                        || call.getOpcode() == Opcodes.INVOKEVIRTUAL)
                                        && (pendingChainedReceiverType == null
                                            || call.owner.replace('/', '.').equals(pendingChainedReceiverType));
                                if (isChainConsumingCall && pendingChainedCollectionArg != null) {
                                    List<String> args = mci.getRecentStringArgs();
                                    if (args == null) {
                                        mci.setRecentStringArgs(new ArrayList<>(List.of(pendingChainedCollectionArg)));
                                    } else if (!args.contains(pendingChainedCollectionArg)) {
                                        args.add(pendingChainedCollectionArg);
                                    }
                                    pendingChainedCollectionArg = null;
                                    pendingChainedReceiverType = null;
                                }
                                // Same propagation for the dynamic (variable-sourced) case — e.g.
                                // db.getCollection(sourceCollection).aggregate(pipeline) where
                                // sourceCollection is a method parameter. Only applies when getCollection
                                // did NOT resolve a literal (the two chains are mutually exclusive).
                                if (isChainConsumingCall && pendingChainedDynamicArg != null) {
                                    List<MethodCallInfo.DynamicArgSource> dynArgs = mci.getDynamicArgSources();
                                    if (dynArgs == null) {
                                        mci.setDynamicArgSources(new ArrayList<>(List.of(pendingChainedDynamicArg)));
                                    } else if (!dynArgs.contains(pendingChainedDynamicArg)) {
                                        dynArgs.add(pendingChainedDynamicArg);
                                    }
                                    pendingChainedDynamicArg = null;
                                    pendingChainedReceiverType = null;
                                }
                                // If THIS call is getCollection("X"), remember "X" for the next call
                                // that's actually invoked on its return value (the MongoCollection).
                                // Use the call's DECLARED RETURN TYPE (mci.getReturnType(), already
                                // cleaned by TypeUtils above) as the expected receiver type for the
                                // chained call — NOT call.owner, which is getCollection's OWNER
                                // (e.g. MongoTemplate), not what it returns.
                                if ("getCollection".equals(call.name) && mci.getRecentStringArgs() != null
                                        && !mci.getRecentStringArgs().isEmpty()) {
                                    pendingChainedCollectionArg = mci.getRecentStringArgs().get(0);
                                    pendingChainedReceiverType = mci.getReturnType();
                                } else if ("getCollection".equals(call.name)
                                        && (mci.getRecentStringArgs() == null || mci.getRecentStringArgs().isEmpty())
                                        && mci.getDynamicArgSources() != null && !mci.getDynamicArgSources().isEmpty()) {
                                    // getCollection(variable) — no literal resolved, but a dynamic
                                    // source was captured; propagate that instead.
                                    pendingChainedDynamicArg = mci.getDynamicArgSources().get(0);
                                    pendingChainedReceiverType = mci.getReturnType();
                                }
                                mi.getInvocations().add(mci);
                            } else if (insn instanceof InvokeDynamicInsnNode dynInsn) {
                                pendingReceiverField = null;
                                pendingReceiverType = null;
                                pendingChainedCollectionArg = null;
                                pendingChainedDynamicArg = null;
                                pendingDynamicArgs.clear();
                                if (dynInsn.bsmArgs != null) {
                                    for (Object arg : dynInsn.bsmArgs) {
                                        if (arg instanceof Handle handle) {
                                            // Map ASM Handle tag to the corresponding invoke opcode
                                            // so CallTreeBuilder can build the correct method key
                                            int resolvedOpcode = switch (handle.getTag()) {
                                                case Opcodes.H_INVOKESTATIC    -> Opcodes.INVOKESTATIC;    // 184
                                                case Opcodes.H_INVOKEVIRTUAL   -> Opcodes.INVOKEVIRTUAL;   // 182
                                                case Opcodes.H_INVOKEINTERFACE -> Opcodes.INVOKEINTERFACE; // 185
                                                case Opcodes.H_INVOKESPECIAL,
                                                     Opcodes.H_NEWINVOKESPECIAL -> Opcodes.INVOKESPECIAL;  // 183
                                                default -> -1;
                                            };
                                            MethodCallInfo mci = new MethodCallInfo();
                                            mci.setOwnerClass(handle.getOwner().replace('/', '.'));
                                            mci.setMethodName(handle.getName());
                                            mci.setDescriptor(handle.getDesc());
                                            mci.setReturnType(TypeUtils.cleanTypeName(
                                                    Type.getReturnType(handle.getDesc()).getClassName()));
                                            mci.setOpcode(resolvedOpcode);
                                            mci.setLineNumber(currentLine);
                                            // Mark as lambda/method-reference invocation with target info
                                            mci.setLambdaInvocation(true);
                                            mci.setLambdaTargetClass(handle.getOwner().replace('/', '.'));
                                            mci.setLambdaTargetMethod(handle.getName());
                                            mci.setLambdaTargetDescriptor(handle.getDesc());
                                            if (!pendingStringArgs.isEmpty()) {
                                                mci.setRecentStringArgs(new ArrayList<>(pendingStringArgs));
                                                pendingStringArgs.clear();
                                            }
                                            mi.getInvocations().add(mci);
                                        }
                                    }
                                }
                                pendingStringArgs.clear();
                            }
                        }
                        mi.setStringLiterals(stringLits);
                        mi.setFieldAccesses(fieldAccesses);
                        if (minLine != Integer.MAX_VALUE) {
                            mi.setStartLine(minLine);
                            mi.setEndLine(maxLine);
                        }
                    }

                    // Capture local variable table (name -> type)
                    if (method.localVariables != null) {
                        Map<String, String> localVars = new LinkedHashMap<>();
                        boolean isStatic = (method.access & Opcodes.ACC_STATIC) != 0;
                        for (LocalVariableNode lv : method.localVariables) {
                            if (lv.index == 0 && !isStatic) continue; // skip 'this'
                            // Skip parameters (already captured in parameters list)
                            boolean isParam = false;
                            int slotIdx = isStatic ? 0 : 1;
                            Type[] ptypes = Type.getArgumentTypes(method.desc);
                            for (Type pt : ptypes) {
                                if (lv.index == slotIdx) { isParam = true; break; }
                                slotIdx += pt.getSize();
                            }
                            if (!isParam) {
                                localVars.put(lv.name, TypeUtils.cleanTypeName(Type.getType(lv.desc).getClassName()));
                            }
                        }
                        mi.setLocalVariables(localVars);
                    }

                    info.getMethods().add(mi);
                }
            }

            return info;
        } catch (Exception e) {
            return null;
        }
    }

    /* ---- dynamic (variable-sourced) argument helpers ---- */

    /** True when a field/local-variable bytecode descriptor is exactly java.lang.String. */
    private boolean isStringDesc(String desc) {
        return "Ljava/lang/String;".equals(desc);
    }

    /**
     * Resolves a local-variable-table slot index to its declared name, restricted to slots
     * whose type is String (so a MongoTemplate/Repository-typed receiver variable is never
     * mistaken for a collection-name-holding argument). Slot-index matching only (no
     * start/end-label scope check).
     *
     * @deprecated Slot-only matching is unsafe when a single slot is reused for two DIFFERENT
     * (non-overlapping-scope) variables in the same method. Prefer
     * {@link #resolveLocalVarName(MethodNode, int, boolean, AbstractInsnNode)} which
     * disambiguates using the local-variable-table's start/end label range around the actual
     * ALOAD site. Kept only for the ASTORE pre-scan's whole-method ambiguity checks, which
     * intentionally look at the slot in the abstract (not at any specific instruction).
     */
    private String resolveLocalVarName(MethodNode method, int slot, boolean requireStringType) {
        if (method.localVariables == null) return null;
        for (LocalVariableNode lv : method.localVariables) {
            if (lv.index == slot) {
                if (requireStringType && !isStringDesc(lv.desc)) return null;
                return lv.name;
            }
        }
        return null;
    }

    /**
     * Resolves a local-variable-table slot index to its declared name AT A SPECIFIC ALOAD SITE,
     * disambiguating slot reuse by checking the local-variable-table entry's [start, end) label
     * range against the ALOAD instruction's position in the method.
     *
     * Without this, a slot reused for two unrelated variables in different (non-overlapping)
     * scopes of the same method resolves EVERY ALOAD of that slot to whichever LocalVariableNode
     * happens to appear first in method.localVariables, regardless of which scope the ALOAD site
     * is actually in. That produces a bogus dynamic-arg capture (the stale out-of-scope variable
     * name) attached to a call site that has nothing to do with it.
     *
     * Falls back to the slot-only match (old behavior) if the local-variable-table has no usable
     * start/end labels for a candidate entry (defensive — shouldn't happen for javac-compiled
     * classes, but avoids regressing to "no match" for edge-case bytecode).
     */
    private String resolveLocalVarName(MethodNode method, int slot, boolean requireStringType,
                                        AbstractInsnNode site) {
        if (method.localVariables == null) return null;
        List<LocalVariableNode> candidates = new ArrayList<>();
        for (LocalVariableNode lv : method.localVariables) {
            if (lv.index == slot) candidates.add(lv);
        }
        if (candidates.isEmpty()) return null;
        if (candidates.size() == 1) {
            LocalVariableNode lv = candidates.get(0);
            if (requireStringType && !isStringDesc(lv.desc)) return null;
            return lv.name;
        }
        // Multiple LocalVariableNode entries share this slot (scope reuse) — find the one whose
        // [start, end) range actually contains the ALOAD site, walking the instruction list once.
        for (LocalVariableNode lv : candidates) {
            if (isWithinRange(lv.start, lv.end, site)) {
                if (requireStringType && !isStringDesc(lv.desc)) return null;
                return lv.name;
            }
        }
        // No candidate's range contained the site (shouldn't normally happen) — be conservative
        // and report nothing rather than guessing the wrong scope.
        return null;
    }

    /** True when `site` appears at or after `start` and before `end` in the instruction list. */
    private boolean isWithinRange(LabelNode start, LabelNode end, AbstractInsnNode site) {
        if (start == null) return false;
        boolean afterStart = false;
        for (AbstractInsnNode n = start; n != null; n = n.getNext()) {
            if (n == site) { afterStart = true; break; }
            if (n == end) break; // reached end label before finding site
        }
        return afterStart;
    }

    /* ---- annotation helpers ---- */

    private List<AnnotationInfo> parseAnnotationNodes(List<AnnotationNode> annotationNodes) {
        if (annotationNodes == null) return new ArrayList<>();
        List<AnnotationInfo> result = new ArrayList<>();
        for (AnnotationNode ann : annotationNodes) {
            AnnotationInfo ai = new AnnotationInfo();
            String readable = SpringAnnotations.resolve(ann.desc);
            if (readable != null) {
                ai.setName(readable);
            } else {
                String typeName = Type.getType(ann.desc).getClassName();
                ai.setName(typeName.substring(typeName.lastIndexOf('.') + 1));
            }
            if (ann.values != null) {
                for (int i = 0; i < ann.values.size(); i += 2) {
                    String key = (String) ann.values.get(i);
                    Object value = ann.values.get(i + 1);
                    ai.getAttributes().put(key, convertAnnotationValue(value));
                }
            }
            result.add(ai);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private Object convertAnnotationValue(Object value) {
        if (value instanceof String[]) {
            String[] arr = (String[]) value;
            return arr.length > 1 ? arr[1] : Arrays.toString(arr);
        }
        if (value instanceof List) {
            List<?> list = (List<?>) value;
            List<Object> result = new ArrayList<>();
            for (Object item : list) { result.add(convertAnnotationValue(item)); }
            return result;
        }
        if (value instanceof AnnotationNode nested) {
            Map<String, Object> map = new LinkedHashMap<>();
            String typeName = Type.getType(nested.desc).getClassName();
            map.put("@type", typeName.substring(typeName.lastIndexOf('.') + 1));
            if (nested.values != null) {
                for (int i = 0; i < nested.values.size(); i += 2) {
                    map.put((String) nested.values.get(i), convertAnnotationValue(nested.values.get(i + 1)));
                }
            }
            return map;
        }
        if (value instanceof Type) { return TypeUtils.cleanTypeName(((Type) value).getClassName()); }
        return value;
    }

    private String determineStereotype(List<AnnotationInfo> annotations, List<String> interfaces) {
        // @Aspect wins over the stereotype annotations, and is therefore tested before the loop
        // rather than as another case in it. An aspect is nearly always also a @Component, and the
        // loop below returns on the first *annotation* in bytecode order, not by case order — so a
        // case inside it would make the result depend on how the compiler happened to emit them.
        // Reporting an aspect as COMPONENT hides that it is cross-cutting advice which appears in
        // no call tree; AdviceDetector carries the detail.
        for (AnnotationInfo ann : annotations) {
            if ("Aspect".equals(ann.getName())) return "ASPECT";
        }
        for (AnnotationInfo ann : annotations) {
            switch (ann.getName()) {
                case "RestController": return "REST_CONTROLLER";
                case "Controller": return "CONTROLLER";
                case "Service": return "SERVICE";
                case "Repository": return "REPOSITORY";
                case "Component": return "COMPONENT";
                case "Configuration": return "CONFIGURATION";
                case "Entity": return "ENTITY";
                case "Document": return "ENTITY";  // MongoDB @Document beans are data classes
                case "FeignClient": return "HTTP_CLIENT";  // declarative HTTP client interface
            }
        }
        // Detect Spring Data repository interfaces (often used without @Repository). Direct
        // (one-hop) case only -- multi-level chains (interface B extends A extends
        // MongoRepository<...>) are handled transitively by RepositoryStereotypeResolver, which
        // runs as a post-pass over the whole classesFile using this exact same per-hop rule.
        if (interfaces != null) {
            for (String iface : interfaces) {
                if (SpringDataRepositoryInterfaces.MARKER_INTERFACES.contains(iface)
                        || SpringDataRepositoryInterfaces.looksLikeRepositoryByName(iface)) {
                    return "REPOSITORY";
                }
            }
        }
        return "OTHER";
    }

    private String extractBasePath(List<AnnotationNode> annotations) {
        if (annotations == null) return "";
        for (AnnotationNode ann : annotations) {
            String name = SpringAnnotations.resolve(ann.desc);
            if ("RequestMapping".equals(name)) return extractPathFromAnnotationNode(ann);
        }
        return "";
    }

    @SuppressWarnings("unchecked")
    private String extractPathFromAnnotationNode(AnnotationNode ann) {
        if (ann.values == null) return "";
        for (int i = 0; i < ann.values.size(); i += 2) {
            String key = (String) ann.values.get(i);
            if ("value".equals(key) || "path".equals(key)) {
                Object val = ann.values.get(i + 1);
                if (val instanceof List) {
                    List<?> list = (List<?>) val;
                    return list.isEmpty() ? "" : list.get(0).toString();
                }
                return val.toString();
            }
        }
        return "";
    }

    @SuppressWarnings("unchecked")
    private void extractEndpointInfo(MethodInfo method, String basePath) {
        for (AnnotationInfo ann : method.getAnnotations()) {
            String httpMethod = SpringAnnotations.httpMethodFor(ann.getName());
            if (httpMethod != null) {
                method.setHttpMethod(httpMethod);
                String path = extractPathFromAttributes(ann.getAttributes());
                method.setPath(normalizePath(basePath) + normalizePath(path));
                return;
            }
            if ("RequestMapping".equals(ann.getName())) {
                Object methodAttr = ann.getAttributes().get("method");
                String hm = "ALL";
                if (methodAttr instanceof List && !((List<?>) methodAttr).isEmpty()) {
                    hm = ((List<?>) methodAttr).get(0).toString();
                } else if (methodAttr instanceof String) { hm = (String) methodAttr; }
                method.setHttpMethod(hm);
                String path = extractPathFromAttributes(ann.getAttributes());
                method.setPath(normalizePath(basePath) + normalizePath(path));
                return;
            }
        }
    }

    @SuppressWarnings("unchecked")
    private String extractPathFromAttributes(Map<String, Object> attrs) {
        Object pathVal = attrs.get("value");
        if (pathVal == null) pathVal = attrs.get("path");
        if (pathVal instanceof List && !((List<?>) pathVal).isEmpty()) {
            return ((List<?>) pathVal).get(0).toString();
        } else if (pathVal instanceof String) { return (String) pathVal; }
        return "";
    }

    private String normalizePath(String path) {
        if (path == null || path.isEmpty()) return "";
        if (!path.startsWith("/")) path = "/" + path;
        if (path.endsWith("/") && path.length() > 1) path = path.substring(0, path.length() - 1);
        return path;
    }

    /**
     * Extract MongoDB field name from field-level annotations.
     * Priority: @Field > @BsonProperty > @JsonProperty (first non-blank wins).
     * Also detects @Id / @BsonId for _id mapping.
     */
    private void extractMongoFieldName(FieldInfo fi) {
        // Annotations that map Java field name → MongoDB field name
        // @Field("PART_ID"), @Field(name="PART_ID"), @Field(value="PART_ID")
        // @BsonProperty("_id"), @BsonProperty(value="_id")
        // @JsonProperty("access_token"), @JsonProperty(value="access_token")
        String fieldName = null;
        boolean isId = false;

        for (AnnotationInfo ann : fi.getAnnotations()) {
            String name = ann.getName();
            Map<String, Object> attrs = ann.getAttributes();

            switch (name) {
                case "Field" -> {
                    // Spring Data MongoDB: @Field("name") or @Field(name="name") or @Field(value="name")
                    String val = extractStringAttr(attrs, "value");
                    if (val == null) val = extractStringAttr(attrs, "name");
                    if (val != null && !val.isBlank() && fieldName == null) fieldName = val;
                }
                case "BsonProperty" -> {
                    String val = extractStringAttr(attrs, "value");
                    if (val != null && !val.isBlank() && fieldName == null) fieldName = val;
                }
                case "JsonProperty" -> {
                    String val = extractStringAttr(attrs, "value");
                    if (val != null && !val.isBlank() && fieldName == null) fieldName = val;
                }
                case "Id", "BsonId" -> isId = true;
                case "Indexed" -> {
                    // @Indexed doesn't change field name, but confirms it's a DB field
                }
            }
        }

        if (fieldName != null) fi.setMongoFieldName(fieldName);
        if (isId) fi.setIdField(true);
    }

    /**
     * Parses a bytecode field signature to extract the element/value type from collection generics.
     * Handles List&lt;T&gt;, Set&lt;T&gt;, Collection&lt;T&gt;, Map&lt;K,V&gt; (returns V), and ? extends T.
     * Returns null for non-collection types, raw types, java.* element types, or arrays.
     */
    private static String extractCollectionElementType(String desc, String signature) {
        String rawType;
        try { rawType = Type.getType(desc).getClassName(); } catch (Exception e) { return null; }
        boolean isList = rawType.equals("java.util.List") || rawType.equals("java.util.Set")
                || rawType.equals("java.util.Collection") || rawType.equals("java.util.Queue")
                || rawType.equals("java.util.Deque") || rawType.equals("java.util.SortedSet")
                || rawType.equals("java.util.NavigableSet") || rawType.equals("java.util.LinkedList")
                || rawType.equals("java.util.ArrayList") || rawType.equals("java.util.HashSet")
                || rawType.equals("java.util.LinkedHashSet") || rawType.equals("java.util.TreeSet");
        boolean isMap = rawType.equals("java.util.Map") || rawType.equals("java.util.SortedMap")
                || rawType.equals("java.util.NavigableMap") || rawType.equals("java.util.LinkedHashMap")
                || rawType.equals("java.util.HashMap") || rawType.equals("java.util.TreeMap");
        if (!isList && !isMap) return null;

        int ltPos = signature.indexOf('<');
        if (ltPos < 0) return null;
        int typeStart = ltPos + 1;

        if (isMap) {
            // Skip the key type (first type param) to get to the value type
            if (typeStart >= signature.length() || signature.charAt(typeStart) != 'L') return null;
            int firstEnd = signature.indexOf(';', typeStart);
            if (firstEnd < 0) return null;
            typeStart = firstEnd + 1;
        }

        // Skip wildcard indicators: + (? extends) or - (? super)
        if (typeStart < signature.length()
                && (signature.charAt(typeStart) == '+' || signature.charAt(typeStart) == '-')) {
            typeStart++;
        }
        if (typeStart >= signature.length() || signature.charAt(typeStart) != 'L') return null;
        typeStart++; // skip the 'L' object descriptor prefix
        int typeEnd = signature.indexOf(';', typeStart);
        if (typeEnd < 0) return null;
        String internal = signature.substring(typeStart, typeEnd);
        // Skip parameterised nested types (e.g. List<Map<K,V>>)
        if (internal.isEmpty() || internal.contains("<") || internal.contains(">")) return null;
        String fqn = internal.replace('/', '.');
        // Only return application types — skip java.*, javax.*, org.springframework.*
        if (fqn.startsWith("java.") || fqn.startsWith("javax.")
                || fqn.startsWith("org.springframework.") || fqn.startsWith("org.slf4j.")) return null;
        return fqn;
    }

    private String extractStringAttr(Map<String, Object> attrs, String key) {
        if (attrs == null) return null;
        Object val = attrs.get(key);
        if (val instanceof String s) return s;
        return null;
    }

    private void extractJpaColumnName(FieldInfo fi) {
        for (AnnotationInfo ann : fi.getAnnotations()) {
            if ("Column".equals(ann.getName())) {
                String val = extractStringAttr(ann.getAttributes(), "name");
                if (val != null && !val.isBlank()) {
                    fi.setJpaColumnName(val);
                    return;
                }
            }
            if ("JoinColumn".equals(ann.getName())) {
                String val = extractStringAttr(ann.getAttributes(), "name");
                if (val != null && !val.isBlank()) {
                    fi.setJpaColumnName(val);
                    return;
                }
            }
        }
    }

    /**
     * Parse generic signature to extract the entity type from MongoRepository&lt;Entity, ID&gt;.
     * ASM signature format: "Ljava/lang/Object;Lorg/springframework/data/.../MongoRepository&lt;Lcom/example/Entity;Ljava/lang/String;&gt;;"
     * We look for a known repo interface in the signature, then extract the first type parameter.
     * Direct (one-hop) case only -- see RepositoryStereotypeResolver for the multi-level chain case.
     */
    private String extractRepositoryEntityType(String signature, List<String> interfaces) {
        if (signature == null) return null;

        for (String iface : interfaces) {
            if (!SpringDataRepositoryInterfaces.MARKER_INTERFACES.contains(iface)
                    && !SpringDataRepositoryInterfaces.looksLikeRepositoryByName(iface)) {
                continue;
            }
            // Convert interface FQN to internal format for signature matching
            String internalName = iface.replace('.', '/');
            // Look for "L<internalName><...;" pattern in signature
            int idx = signature.indexOf("L" + internalName + "<");
            if (idx < 0) continue;

            // Extract first type parameter: everything between first '<L' and next ';'
            int typeStart = idx + ("L" + internalName + "<L").length();
            if (typeStart >= signature.length()) continue;
            int typeEnd = signature.indexOf(';', typeStart);
            if (typeEnd < 0) continue;

            String entityInternal = signature.substring(typeStart, typeEnd);
            return entityInternal.replace('/', '.');
        }
        return null;
    }
}
