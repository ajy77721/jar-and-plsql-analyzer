package com.jaranalyzer.service;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.model.CallNode;
import com.jaranalyzer.model.EndpointInfo;
import com.jaranalyzer.model.JarAnalysis;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

@Primary
@Service("jarPersistenceService")
public class PersistenceService {

    private static final Logger log = LoggerFactory.getLogger(PersistenceService.class);

    private final ObjectMapper objectMapper;
    private final JarDataPaths paths;

    private final com.analyzer.storage.ArtifactStore store;

    public PersistenceService(JarDataPaths paths, com.analyzer.storage.ArtifactStore store) {
        this.objectMapper = new ObjectMapper();
        this.paths = paths;
        this.store = store;
    }
    /** Every write in this class goes through the store; the key decides where it lands. */
    private java.io.OutputStream openWrite(com.analyzer.storage.ArtifactKey key) throws IOException {
        return store.write(key);
    }

    /** Reads via the store. Callers must close. */
    /**
     * Length-aware variant. Backends that must declare a size up front (a single-shot S3 PUT
     * rather than a multipart upload) use it; local ignores it.
     */
    private java.io.OutputStream openWrite(com.analyzer.storage.ArtifactKey key, long contentLength)
            throws IOException {
        return store.write(key, contentLength);
    }

    private InputStream openRead(com.analyzer.storage.ArtifactKey key) throws IOException {
        return store.read(key);
    }

    public JarDataPaths getPaths() { return paths; }

    /* ---- JAR file storage ---- */

    public Path storeJar(Path tempJar, String jarName) throws IOException {
        paths.ensureJarRoot(jarName);
        var key = paths.storedJarKey(jarName);
        try (InputStream in = Files.newInputStream(tempJar); OutputStream out = openWrite(key)) {
            in.transferTo(out);
        }
        log.info("Stored JAR: {} ({} MB)", key, store.size(key) / (1024 * 1024));
        return paths.storedJarFile(jarName);
    }

    public Path getJarFilePath(String id) {
        return store.exists(paths.storedJarKey(id)) ? paths.storedJarFile(id) : null;
    }

    /* ---- Per-JAR domain config storage ---- */

    public Path storeDomainConfig(Path tempConfig, String jarName) throws IOException {
        paths.ensureJarRoot(jarName);
        var key = paths.domainConfigKey(jarName);
        try (InputStream in = Files.newInputStream(tempConfig); OutputStream out = openWrite(key)) {
            in.transferTo(out);
        }
        log.info("Stored per-JAR domain config: {}", key);
        return paths.domainConfigFile(jarName);
    }

    public Path getDomainConfigPath(String jarName) {
        return store.exists(paths.domainConfigKey(jarName)) ? paths.domainConfigFile(jarName) : null;
    }

    /* ---- Connection info storage ---- */

    public void storeConnections(String jarName, Map<String, Object> info) {
        try {
            paths.ensureJarRoot(jarName);
            Path dest = paths.connectionsFile(jarName);
            try (java.io.OutputStream out = openWrite(paths.connectionsKey(jarName))) {
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(out, info);
            }
            log.info("Stored connections.json for {}", jarName);
        } catch (IOException e) {
            log.warn("Failed to store connections.json for {}: {}", jarName, e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> loadConnections(String jarName) {
        var key = paths.connectionsKey(jarName);
        if (!store.exists(key)) return null;
        try (InputStream in = openRead(key)) {
            return objectMapper.readValue(in, Map.class);
        } catch (Exception e) {
            log.warn("Failed to load connections.json for {}: {}", jarName, e.getMessage());
            return null;
        }
    }

    /* ---- Streaming write (upload time — always writes STATIC) ---- */

    public void writeAnalysisStreaming(String jarName, long jarSize, String analyzedAt,
                                       int totalClasses, int totalEndpoints,
                                       Path classesJsonlFile,
                                       List<EndpointInfo> endpoints) throws IOException {
        writeAnalysisStreaming(jarName, null, jarSize, analyzedAt, totalClasses, totalEndpoints, classesJsonlFile, endpoints);
    }

    public void writeAnalysisStreaming(String jarName, String projectName, long jarSize, String analyzedAt,
                                       int totalClasses, int totalEndpoints,
                                       Path classesJsonlFile,
                                       List<EndpointInfo> endpoints) throws IOException {
        writeAnalysisStreaming(jarName, projectName, jarSize, analyzedAt, totalClasses, totalEndpoints, classesJsonlFile, endpoints, "STATIC");
    }

    public void writeAnalysisStreaming(String jarName, String projectName, long jarSize, String analyzedAt,
                                       int totalClasses, int totalEndpoints,
                                       Path classesJsonlFile,
                                       List<EndpointInfo> endpoints, String analysisMode) throws IOException {
        writeAnalysisStreaming(jarName, projectName, jarSize, analyzedAt, totalClasses, totalEndpoints,
                classesJsonlFile, endpoints, analysisMode, null);
    }

    public void writeAnalysisStreaming(String jarName, String projectName, long jarSize, String analyzedAt,
                                       int totalClasses, int totalEndpoints,
                                       Path classesJsonlFile,
                                       List<EndpointInfo> endpoints, String analysisMode,
                                       String basePackage) throws IOException {
        writeAnalysisStreaming(jarName, projectName, jarSize, analyzedAt, totalClasses, totalEndpoints,
                classesJsonlFile, endpoints, analysisMode, basePackage, null);
    }

    /**
     * @param scopeTarget non-null only when this analysis was scoped to a single endpoint/method
     *                    (see CallGraphService.buildScopedEndpointFromIndex) rather than a full
     *                    scan of every discovered endpoint. Persisted so the UI can show a
     *                    "partial analysis" banner instead of implying full coverage.
     */
    public void writeAnalysisStreaming(String jarName, String projectName, long jarSize, String analyzedAt,
                                       int totalClasses, int totalEndpoints,
                                       Path classesJsonlFile,
                                       List<EndpointInfo> endpoints, String analysisMode,
                                       String basePackage, String scopeTarget) throws IOException {
        paths.ensureJarRoot(jarName);
        writeAnalysisStreamingTo(paths.analysisFile(jarName), jarName, projectName, jarSize, analyzedAt,
                totalClasses, totalEndpoints, classesJsonlFile, endpoints, analysisMode, basePackage, scopeTarget);
        invalidateSummaryCache(jarName);
        preGenerateSummaryCache(jarName, true);
    }

    public void writeAnalysisStreamingCorrected(String jarName, String projectName, long jarSize, String analyzedAt,
                                                 int totalClasses, int totalEndpoints,
                                                 Path classesJsonlFile,
                                                 List<EndpointInfo> endpoints, String analysisMode) throws IOException {
        paths.ensureJarRoot(jarName);
        writeAnalysisStreamingTo(paths.correctedFile(jarName), jarName, projectName, jarSize, analyzedAt,
                totalClasses, totalEndpoints, classesJsonlFile, endpoints, analysisMode, null, null);
        invalidateSummaryCache(jarName);
        preGenerateSummaryCache(jarName, false);
    }

    private void writeAnalysisStreamingTo(Path outPath, String jarName, String projectName, long jarSize,
                                           String analyzedAt, int totalClasses, int totalEndpoints,
                                           Path classesJsonlFile, List<EndpointInfo> endpoints,
                                           String analysisMode, String basePackage,
                                           String scopeTarget) throws IOException {
        log.info("Streaming analysis to {} ...", outPath);

        // The analysis document is the largest artifact by far (1 GB observed in production), so
        // it is streamed rather than buffered — openWrite returns an S3 multipart stream in s3
        // mode and a buffered file stream locally, and the generator below cannot tell.
        com.analyzer.storage.ArtifactKey outKey = outPath.equals(paths.correctedFile(jarName))
                ? paths.correctedKey(jarName) : paths.analysisKey(jarName);

        // Flatten every endpoint's call tree into a content-addressed node dictionary BEFORE
        // opening the output. In memory a call tree is a DAG — a method reached by N paths is one
        // CallNode referenced N times — but JSON cannot say "this node again", so serialising it
        // nested re-emits each shared subtree once per path and the file grows with the number of
        // PATHS rather than the number of METHODS. That is what produced a 69 GB analysis.json for
        // unified-web that never finished writing. See CallTreeFlattener for the id scheme.
        // Scratch space for the dictionary while it is being built, so peak memory stays flat
        // regardless of how many distinct nodes the JAR has. Goes through the store like every
        // other byte this service writes, and is removed below.
        com.analyzer.storage.ArtifactKey spillKey =
                paths.jarRootKey(jarName).resolve("_calltree-nodes.spill.jsonl");
        try (CallTreeFlattener flattener =
                     new CallTreeFlattener(objectMapper, openWrite(spillKey), () -> openRead(spillKey))) {
            List<String> rootIds = new ArrayList<>(endpoints.size());
            List<com.fasterxml.jackson.databind.node.ObjectNode> fragIds = new ArrayList<>(endpoints.size());
            for (EndpointInfo ep : endpoints) {
                rootIds.add(flattener.flatten(ep.getCallTree()));
                fragIds.add(flattener.flattenFragments(ep.getFragments()));
            }
            log.info("  call tree flattened to {} distinct nodes across {} endpoints",
                    flattener.nodeCount(), endpoints.size());

            writeDocument(outKey, outPath, jarName, projectName, jarSize, analyzedAt, totalClasses,
                    totalEndpoints, classesJsonlFile, endpoints, analysisMode, basePackage, scopeTarget,
                    flattener, rootIds, fragIds);
        } finally {
            try {
                store.delete(spillKey);
            } catch (Exception ignored) {
                // scratch only — a leftover file must never fail an otherwise-complete analysis
            }
        }

        // Ask the STORE for the size, not the filesystem: in s3 mode the bytes went to an object
        // and no local file exists, so Files.size() threw NoSuchFileException and failed the whole
        // analysis — from a logging line. Size is informational, so a failure to obtain it must
        // never propagate.
        long sizeBytes = -1;
        try {
            sizeBytes = store.size(outKey);
        } catch (Exception ignored) {
            // not worth failing an otherwise-successful analysis over
        }
        log.info("Analysis saved: {} ({})", outPath.getFileName(),
                sizeBytes >= 0 ? (sizeBytes / (1024 * 1024)) + " MB" : "size unknown");

        // Write lightweight header sidecar for fast listing
        writeHeaderSidecar(jarName, projectName, jarSize, analyzedAt,
                totalClasses, totalEndpoints, analysisMode, basePackage, scopeTarget);
    }

    /**
     * Turns {@code methods[].invocationRefs} back into {@code invocations} and drops the pool.
     *
     * <p>After this, the POJO graph is indistinguishable from one loaded from a pre-pooling
     * document, so the correction pipeline, the collections view and everything else downstream of
     * {@code load()} need no knowledge of pooling. A document with no pool is left alone.
     */
    private void resolveInvocationPool(JarAnalysis analysis) {
        var poolNode = analysis.getInvocationPool();
        if (poolNode == null || !poolNode.isArray() || poolNode.isEmpty()) return;

        // Deliberately kept as nodes and converted PER REFERENCE rather than converted once and
        // shared. Before pooling, every method owned distinct MethodCallInfo instances; sharing one
        // instance across the methods that reference it would make a mutation by any downstream
        // consumer — the Claude correction pipeline mutates this graph — visible in every other
        // method that happens to make the same call. The pool is a storage optimisation, and it must
        // not change object identity semantics in memory.
        List<com.fasterxml.jackson.databind.JsonNode> pool = new ArrayList<>(poolNode.size());
        poolNode.forEach(pool::add);

        long resolved = 0;
        for (var cls : analysis.getClasses()) {
            for (var m : cls.getMethods()) {
                var refs = m.getInvocationRefs();
                if (refs == null || refs.isEmpty()) continue;
                List<com.jaranalyzer.model.MethodCallInfo> invs = new ArrayList<>(refs.size());
                for (Integer ref : refs) {
                    // A ref outside the pool loses that one call rather than failing the load;
                    // a truncated document should still open.
                    if (ref != null && ref >= 0 && ref < pool.size()) {
                        invs.add(objectMapper.convertValue(
                                pool.get(ref), com.jaranalyzer.model.MethodCallInfo.class));
                    }
                }
                m.setInvocations(invs);
                m.setInvocationRefs(new ArrayList<>());
                resolved += invs.size();
            }
        }
        analysis.setInvocationPool(null);
        log.info("  resolved {} invocation references from a pool of {}", resolved, pool.size());
    }

    /**
     * Turns the {@code *Refs} ordinals on each endpoint back into their objects and drops the pool.
     *
     * <p>After this the POJO graph is indistinguishable from one loaded from a pre-pooling
     * document, so the correction pipeline and everything else downstream of {@code load()} needs
     * no knowledge of pooling. A document with no pool is left alone.
     */
    private void resolveEndpointPool(JarAnalysis analysis) {
        var poolNode = analysis.getEndpointPool();
        if (poolNode == null || !poolNode.isObject() || poolNode.isEmpty()) return;

        long resolved = 0;
        for (EndpointInfo ep : analysis.getEndpoints()) {
            resolved += resolveOne(poolNode, "externalCalls", ep.getExternalCallsRefs(),
                    new TypeReference<Map<String, String>>() {}, ep::setExternalCalls);
            ep.setExternalCallsRefs(new ArrayList<>());
            resolved += resolveOne(poolNode, "beans", ep.getBeansRefs(),
                    new TypeReference<Map<String, String>>() {}, ep::setBeans);
            ep.setBeansRefs(new ArrayList<>());
            resolved += resolveOne(poolNode, "dynamicFlows", ep.getDynamicFlowsRefs(),
                    new TypeReference<Map<String, Object>>() {}, ep::setDynamicFlows);
            ep.setDynamicFlowsRefs(new ArrayList<>());
        }
        analysis.setEndpointPool(null);
        log.info("  resolved {} endpoint aggregate references from the pool", resolved);
    }

    /**
     * Resolves one field's ordinals.
     *
     * <p>Converted PER REFERENCE rather than once and shared: before pooling every endpoint owned
     * distinct maps, and sharing one instance across the endpoints referencing it would make a
     * mutation by any downstream consumer visible in all of them. The pool is a storage
     * optimisation and must not change in-memory identity semantics.
     */
    private <T> long resolveOne(com.fasterxml.jackson.databind.JsonNode poolNode, String field,
                                List<Integer> refs, TypeReference<T> type,
                                java.util.function.Consumer<List<T>> setter) {
        if (refs == null || refs.isEmpty()) return 0;
        var pool = poolNode.get(field);
        if (pool == null || !pool.isArray()) return 0;
        List<T> out = new ArrayList<>(refs.size());
        for (Integer ref : refs) {
            // A ref outside the pool loses that one entry rather than failing the load.
            if (ref != null && ref >= 0 && ref < pool.size()) {
                out.add(objectMapper.convertValue(pool.get(ref), type));
            }
        }
        setter.accept(out);
        return out.size();
    }

    /**
     * The single owner of reads on the classes JSONL scratch file.
     *
     * <p>This file is pipeline-local scratch, not an artifact: it is produced and consumed inside
     * one analysis and never served, so it stays on the filesystem rather than going through
     * {@code ArtifactStore} — which is why it is a budgeted exception in the storage gate. Both
     * passes over it (advice detection, then the classes array) come through here so that
     * exception has one site rather than one per pass.
     */
    private static BufferedReader openClassesJsonl(Path classesJsonlFile) throws IOException {
        return Files.newBufferedReader(classesJsonlFile);
    }

    /**
     * Emits the analysis document. The node dictionary is written BEFORE {@code classes} and
     * {@code endpoints} on purpose: every reader is a single forward-only streaming pass, so the
     * dictionary has to arrive before the endpoints that reference it.
     */
    private void writeDocument(com.analyzer.storage.ArtifactKey outKey, Path outPath, String jarName,
                               String projectName, long jarSize, String analyzedAt, int totalClasses,
                               int totalEndpoints, Path classesJsonlFile, List<EndpointInfo> endpoints,
                               String analysisMode, String basePackage, String scopeTarget,
                               CallTreeFlattener flattener, List<String> rootIds,
                               List<com.fasterxml.jackson.databind.node.ObjectNode> fragIds)
            throws IOException {
        commitAtomically(outKey, staging ->
                writeDocumentTo(staging, jarName, projectName, jarSize, analyzedAt, totalClasses,
                        totalEndpoints, classesJsonlFile, endpoints, analysisMode, basePackage,
                        scopeTarget, flattener, rootIds, fragIds));
    }

    /** What to write, given the staging key to write it to. */
    @FunctionalInterface
    private interface StagedWrite {
        void writeTo(com.analyzer.storage.ArtifactKey staging) throws IOException;
    }

    /**
     * Writes via a staging key and commits with a single {@code move}, so a failure mid-write
     * cannot damage the analysis that is already stored.
     *
     * <p>This is not hypothetical. An encoder error thrown 23.7 MB into a 53 MB document left
     * <b>three</b> analyses truncated ({@code Unexpected end-of-input}), and because
     * {@code reanalyze-all} reads its metadata out of the very file that had just been destroyed,
     * it then found <b>0</b> JARs to re-queue — the failure took out both the data and the means of
     * rebuilding it. A complete old analysis is worth far more than a partial new one.
     *
     * <p>{@code move} is part of the frozen {@code ArtifactStore} SPI, so this needs no interface
     * change. It is a rename locally and a copy+delete on S3; the only guarantee relied on here is
     * that the destination never observes a partial body, which holds for all three backends.
     */
    private void commitAtomically(com.analyzer.storage.ArtifactKey target, StagedWrite write)
            throws IOException {
        com.analyzer.storage.ArtifactKey staging =
                target.parent().resolve(target.leaf() + ".partial");
        try {
            write.writeTo(staging);
        } catch (IOException | RuntimeException e) {
            try {
                store.delete(staging);
            } catch (Exception ignored) {
                // A leftover staging object is inert — nothing reads it. Losing the real failure
                // behind a cleanup error would be worse.
            }
            throw e;
        }
        store.move(staging, target);
    }

    /** The document body itself. Always writes to {@code target}, which is a staging key. */
    private void writeDocumentTo(com.analyzer.storage.ArtifactKey outKey, String jarName,
                                 String projectName, long jarSize, String analyzedAt, int totalClasses,
                                 int totalEndpoints, Path classesJsonlFile, List<EndpointInfo> endpoints,
                                 String analysisMode, String basePackage, String scopeTarget,
                                 CallTreeFlattener flattener, List<String> rootIds,
                                 List<com.fasterxml.jackson.databind.node.ObjectNode> fragIds)
            throws IOException {
        try (OutputStream os = openWrite(outKey);
             JsonGenerator gen = objectMapper.getFactory().createGenerator(os)) {

            gen.writeStartObject();
            gen.writeStringField("jarName", jarName);
            if (projectName != null) gen.writeStringField("projectName", projectName);
            gen.writeNumberField("jarSize", jarSize);
            gen.writeStringField("analyzedAt", analyzedAt);
            gen.writeNumberField("totalClasses", totalClasses);
            gen.writeNumberField("totalEndpoints", totalEndpoints);
            gen.writeStringField("analysisMode", analysisMode != null ? analysisMode : "STATIC");
            if (basePackage != null && !basePackage.isBlank()) gen.writeStringField("basePackage", basePackage);
            if (scopeTarget != null && !scopeTarget.isBlank()) {
                gen.writeBooleanField("scoped", true);
                gen.writeStringField("scopeTarget", scopeTarget);
            }

            gen.writeStringField(CallTreeFlattener.FORMAT_FIELD, CallTreeFlattener.FORMAT);
            flattener.streamNodes(gen);

            // Cross-cutting advice: aspects, interceptors and filters that appear in NO call tree,
            // because interception happens through a proxy and leaves no static call edge. Written
            // before classes/endpoints so a forward-only reader has it first, and omitted entirely
            // when the JAR has none, so no existing consumer sees a new field.
            // Pool the duplicated per-endpoint arrays. Built before `endpoints` for the same
            // forward-only-reader reason as every other pool here. externalCalls is 4.6% unique:
            // the same external call reachable from many endpoints was written once per endpoint.
            EndpointArrayPool endpointPool = new EndpointArrayPool(objectMapper);
            for (EndpointInfo ep : endpoints) {
                endpointPool.scan(endpointNode(ep));
            }
            if (!endpointPool.isEmpty()) {
                endpointPool.streamPool(gen);
            }

            List<com.jaranalyzer.model.AdviceInfo> advice;
            try (BufferedReader adviceReader = openClassesJsonl(classesJsonlFile)) {
                advice = AdviceDetector.detect(adviceReader, objectMapper);
            }
            if (!advice.isEmpty()) {
                gen.writeFieldName("advice");
                objectMapper.writeValue(gen, advice);
            }

            // Pool distinct invocations — the largest field in the document, and 42.6% of its
            // entries are repeats of another. The pool must precede `classes`, but is only known
            // after every class has been seen, hence the separate scan pass. Same ordering
            // constraint and same solution as the call-tree node dictionary above.
            InvocationPool invocationPool = new InvocationPool(objectMapper);
            try (BufferedReader poolScan = openClassesJsonl(classesJsonlFile)) {
                invocationPool.scan(poolScan);
            }
            if (!invocationPool.isEmpty()) {
                invocationPool.streamPool(gen);
            }

            gen.writeFieldName("classes");
            gen.writeStartArray();
            int classCount = 0;
            try (BufferedReader reader = openClassesJsonl(classesJsonlFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.isBlank()) {
                        // Unchanged classes keep their original bytes; a pooled class is written
                        // through the generator so its string escaping matches what produced the
                        // JSONL (a lone surrogate written raw fails the UTF-8 encoder).
                        var pooled = invocationPool.rewrite(line);
                        if (pooled == null) {
                            gen.writeRawValue(line);
                        } else {
                            objectMapper.writeValue(gen, pooled);
                        }
                        classCount++;
                        if (classCount % 500 == 0) {
                            gen.flush();
                            log.info("  ... {} classes written to JSON", classCount);
                        }
                    }
                }
            }
            gen.writeEndArray();
            log.info("  {} classes written", classCount);

            gen.writeFieldName("endpoints");
            gen.writeStartArray();
            int epCount = 0;
            for (EndpointInfo ep : endpoints) {
                writeEndpoint(gen, ep, rootIds.get(epCount), fragIds.get(epCount), endpointPool);
                epCount++;
                if (epCount % 100 == 0) {
                    gen.flush();
                }
            }
            gen.writeEndArray();
            log.info("  {} endpoints written", epCount);

            gen.writeEndObject();
            gen.flush();
        }
    }

    /**
     * Serialises one endpoint with its call tree replaced by dictionary references.
     *
     * <p>{@code callTree} and {@code fragments} are nulled for the duration of the conversion
     * rather than suppressed with a mixin, so the reference fields land in the exact slots the
     * tree fields occupied. Readers that skip {@code callTree} positionally (see the
     * {@code @JsonPropertyOrder} on {@code EndpointInfo}, which deliberately puts it last so
     * {@code streamSummary} sees the precomputed aggregates first) keep working unchanged.
     */
    /**
     * One endpoint as a tree, with the call tree and fragments detached.
     *
     * <p>Shared by the {@link EndpointArrayPool} pre-pass and {@link #writeEndpoint} so both see
     * exactly the same node — if they disagreed, a pooled entry would not match its interned key
     * and the field would silently stay inline.
     *
     * <p>The detach-and-restore is why this is not simply {@code valueToTree}: the tree is written
     * separately as a shared node dictionary, and serialising it per endpoint is what produced a
     * 69 GB document.
     */
    private com.fasterxml.jackson.databind.node.ObjectNode endpointNode(EndpointInfo ep) {
        var callTree = ep.getCallTree();
        var fragments = ep.getFragments();
        try {
            ep.setCallTree(null);
            ep.setFragments(null);
            return objectMapper.valueToTree(ep);
        } finally {
            ep.setCallTree(callTree);
            ep.setFragments(fragments);
        }
    }

    private void writeEndpoint(JsonGenerator gen, EndpointInfo ep, String rootId,
                               com.fasterxml.jackson.databind.node.ObjectNode fragIds,
                               EndpointArrayPool endpointPool) throws IOException {
        com.fasterxml.jackson.databind.node.ObjectNode on = endpointNode(ep);
        // Ordinals replace the objects under the SAME keys, so field order — and therefore the
        // bytes of an inflated endpoint — are unchanged.
        endpointPool.rewrite(on);

        gen.writeStartObject();
        var fields = on.fields();
        boolean placed = false;
        while (fields.hasNext()) {
            var e = fields.next();
            if ("callTree".equals(e.getKey())) {
                writeRefFields(gen, rootId, fragIds);
                placed = true;
            } else if ("fragments".equals(e.getKey())
                    || CallTreeFlattener.ROOT_ID_FIELD.equals(e.getKey())
                    || CallTreeFlattener.FRAGMENT_IDS_FIELD.equals(e.getKey())) {
                // dropped — the reference fields are written by writeRefFields, in callTree's slot
            } else {
                gen.writeFieldName(e.getKey());
                gen.writeTree(e.getValue());
            }
        }
        if (!placed) writeRefFields(gen, rootId, fragIds);
        gen.writeEndObject();
    }

    private void writeRefFields(JsonGenerator gen, String rootId,
                                com.fasterxml.jackson.databind.node.ObjectNode fragIds) throws IOException {
        gen.writeFieldName(CallTreeFlattener.ROOT_ID_FIELD);
        if (rootId == null) gen.writeNull(); else gen.writeString(rootId);
        if (fragIds != null && fragIds.size() > 0) {
            gen.writeFieldName(CallTreeFlattener.FRAGMENT_IDS_FIELD);
            gen.writeTree(fragIds);
        }
    }

    // NOTE: the leading `Path jarRoot` these overloads used to take was dead — the sidecar is
    // written through paths.headerKey(jarName), never relative to that Path. It is gone rather
    // than kept "for context": a Path on a migrated signature invites the next caller to resolve
    // against it and silently drop back to the local filesystem.
    private void writeHeaderSidecar(String jarName, String projectName,
                                     long jarSize, String analyzedAt,
                                     int totalClasses, int totalEndpoints, String analysisMode,
                                     String basePackage) {
        writeHeaderSidecar(jarName, projectName, jarSize, analyzedAt, totalClasses, totalEndpoints, analysisMode, basePackage, null);
    }

    private void writeHeaderSidecar(String jarName, String projectName,
                                     long jarSize, String analyzedAt,
                                     int totalClasses, int totalEndpoints, String analysisMode,
                                     String basePackage, String scopeTarget) {
        try {
            Map<String, Object> header = new LinkedHashMap<>();
            header.put("jarName", jarName);
            if (projectName != null) header.put("projectName", projectName);
            header.put("jarSize", jarSize);
            header.put("analyzedAt", analyzedAt);
            header.put("totalClasses", totalClasses);
            header.put("totalEndpoints", totalEndpoints);
            header.put("analysisMode", analysisMode != null ? analysisMode : "STATIC");
            if (basePackage != null && !basePackage.isBlank()) header.put("basePackage", basePackage);
            if (scopeTarget != null && !scopeTarget.isBlank()) {
                header.put("scoped", true);
                header.put("scopeTarget", scopeTarget);
            }
            try (java.io.OutputStream out = openWrite(paths.headerKey(jarName))) {
                objectMapper.writeValue(out, header);
            }
        } catch (IOException e) {
            log.debug("Failed to write header sidecar: {}", e.getMessage());
        }
    }

    /* ---- Load / Save ---- */

    public void save(JarAnalysis analysis) throws IOException {
        paths.ensureJarRoot(analysis.getJarName());
        var key = paths.analysisKey(analysis.getJarName());
        log.info("Saving static analysis to {} ...", key);
        // Staged and committed, like the streaming path: a failure here would otherwise replace a
        // complete analysis with a truncated one.
        commitAtomically(key, staging -> {
            try (OutputStream out = openWrite(staging)) {
                writeFlattened(out, analysis);
            }
        });
        log.info("Saved {} ({} MB)", key, store.size(key) / (1024 * 1024));
        writeHeaderSidecar(analysis.getJarName(), analysis.getProjectName(),
                analysis.getJarSize(), analysis.getAnalyzedAt(),
                analysis.getTotalClasses(), analysis.getTotalEndpoints(), analysis.getAnalysisMode(),
                analysis.getBasePackage());
    }

    public void saveCorrected(JarAnalysis analysis) throws IOException {
        paths.ensureJarRoot(analysis.getJarName());
        var key = paths.correctedKey(analysis.getJarName());
        log.info("Saving corrected analysis to {} ...", key);
        // The most damaging of the three to lose: this overwrites the corrected document that the
        // Claude pipeline has already invested work in producing.
        commitAtomically(key, staging -> {
            try (OutputStream out = openWrite(staging)) {
                writeFlattened(out, analysis);
            }
        });
        log.info("Saved corrected {} ({} MB)", key, store.size(key) / (1024 * 1024));
        writeHeaderSidecar(analysis.getJarName(), analysis.getProjectName(),
                analysis.getJarSize(), analysis.getAnalyzedAt(),
                analysis.getTotalClasses(), analysis.getTotalEndpoints(), analysis.getAnalysisMode(),
                analysis.getBasePackage());
        invalidateSummaryCache(analysis.getJarName());
    }

    public JarAnalysis load(String jarName) throws IOException {
        for (var key : List.of(paths.correctedKey(jarName), paths.analysisKey(jarName))) {
            if (!store.exists(key)) continue;
            log.info("Loading analysis from {} ({} MB)...", key, store.size(key) / (1024 * 1024));
            try (InputStream in = openRead(key)) {
                return rehydrate(objectMapper.readValue(in, JarAnalysis.class));
            }
        }
        return null;
    }

    public JarAnalysis loadStatic(String jarName) throws IOException {
        var key = paths.analysisKey(jarName);
        if (store.exists(key)) {
            log.info("Loading static analysis from {} ({} MB)...", key, store.size(key) / (1024 * 1024));
            try (InputStream in = openRead(key)) {
                return rehydrate(objectMapper.readValue(in, JarAnalysis.class));
            }
        }
        return null;
    }

    /**
     * Expands a flat-format document back into ordinary nested {@code CallNode} trees.
     *
     * <p>Everything downstream of {@code load()} — the Claude correction pipeline, the collections
     * view, the chat context — works on {@code EndpointInfo.getCallTree()}. Rehydrating here means
     * none of it has to know the storage format changed, and a load/modify/{@code saveCorrected}
     * round trip keeps the trees it started with. Legacy documents already carry inline trees and
     * pass through untouched.
     */
    private JarAnalysis rehydrate(JarAnalysis analysis) throws IOException {
        if (analysis == null) return analysis;

        // Invocations first, and independently of the call-tree format: a document can carry a
        // pool without flattened trees, and returning early on a null callTreeNodes (as this used
        // to) would leave every method holding ordinals instead of invocations.
        resolveInvocationPool(analysis);
        resolveEndpointPool(analysis);

        if (analysis.getCallTreeNodes() == null) return analysis;

        var parser = objectMapper.treeAsTokens(analysis.getCallTreeNodes());
        parser.nextToken();
        CallTreeInflater inflater = CallTreeInflater.read(parser, objectMapper);

        for (EndpointInfo ep : analysis.getEndpoints()) {
            var tree = inflater.toTree(ep.getCallTreeRootId(), objectMapper);
            ep.setCallTree(tree == null ? null : objectMapper.treeToValue(tree, CallNode.class));
            Map<String, List<CallNode>> frags = new LinkedHashMap<>();
            if (ep.getFragmentChildIds() != null) {
                for (var e : ep.getFragmentChildIds().entrySet()) {
                    List<CallNode> kids = new ArrayList<>();
                    for (String id : e.getValue()) {
                        var t = inflater.toTree(id, objectMapper);
                        if (t != null) kids.add(objectMapper.treeToValue(t, CallNode.class));
                    }
                    frags.put(e.getKey(), kids);
                }
            }
            ep.setFragments(frags);
            ep.setCallTreeRootId(null);
            ep.setFragmentChildIds(null);
        }
        // Cleared so the rehydrated object is indistinguishable from one loaded from a legacy
        // document, and so a later save() rebuilds the dictionary from the (possibly corrected)
        // trees rather than re-emitting a stale one.
        analysis.setCallTreeNodes(null);
        analysis.setCallTreeFormat(null);
        return analysis;
    }

    /**
     * POJO counterpart of {@link #writeAnalysisStreaming}: flattens the trees into the shared
     * dictionary, writes, then restores the object so the caller can keep using it.
     */
    private void writeFlattened(OutputStream out, JarAnalysis analysis) throws IOException {
        List<CallNode> savedTrees = new ArrayList<>();
        List<Map<String, List<CallNode>>> savedFragments = new ArrayList<>();
        var sidecars = new java.util.ArrayList<com.fasterxml.jackson.databind.node.ObjectNode>();
        var dict = objectMapper.createObjectNode();

        try {
            for (EndpointInfo ep : analysis.getEndpoints()) {
                savedTrees.add(ep.getCallTree());
                savedFragments.add(ep.getFragments());
                var sc = CallTreeFlattener.sidecar(objectMapper, ep.getCallTree());
                sidecars.add(sc);
                var nodes = sc.get(CallTreeFlattener.NODES_FIELD);
                nodes.fields().forEachRemaining(e -> dict.set(e.getKey(), e.getValue()));
                var rootId = sc.get(CallTreeFlattener.ROOT_ID_FIELD);
                ep.setCallTreeRootId(rootId == null || rootId.isNull() ? null : rootId.asText());

                if (ep.getFragments() != null && !ep.getFragments().isEmpty()) {
                    Map<String, List<String>> fragIds = new LinkedHashMap<>();
                    for (var e : ep.getFragments().entrySet()) {
                        List<String> ids = new ArrayList<>();
                        for (CallNode kid : e.getValue()) {
                            var ks = CallTreeFlattener.sidecar(objectMapper, kid);
                            ks.get(CallTreeFlattener.NODES_FIELD).fields()
                                    .forEachRemaining(n -> dict.set(n.getKey(), n.getValue()));
                            ids.add(ks.get(CallTreeFlattener.ROOT_ID_FIELD).asText());
                        }
                        fragIds.put(e.getKey(), ids);
                    }
                    ep.setFragmentChildIds(fragIds);
                }
                ep.setCallTree(null);
                ep.setFragments(null);
            }
            analysis.setCallTreeFormat(CallTreeFlattener.FORMAT);
            analysis.setCallTreeNodes(dict);
            objectMapper.writeValue(out, analysis);
        } finally {
            analysis.setCallTreeFormat(null);
            analysis.setCallTreeNodes(null);
            for (int i = 0; i < analysis.getEndpoints().size() && i < savedTrees.size(); i++) {
                EndpointInfo ep = analysis.getEndpoints().get(i);
                ep.setCallTree(savedTrees.get(i));
                ep.setFragments(savedFragments.get(i));
                ep.setCallTreeRootId(null);
                ep.setFragmentChildIds(null);
            }
        }
    }

    public void invalidateSummaryCache(String jarName) {
        try {
            var root = paths.jarRootKey(jarName);
            store.delete(paths.summaryCacheKey(jarName));
            store.delete(root.resolve("_summary.json.gz"));
            store.delete(paths.summaryCacheStaticKey(jarName));
            store.delete(root.resolve("_summary_static.json.gz"));
            store.delete(paths.classTreeCacheKey(jarName, null));
            store.delete(root.resolve("_class-tree.json.tmp"));
            // Versioned class-tree caches too — deleting only the default left the "corrected"
            // variant behind, so after applying corrections the UI could still be served the
            // pre-correction class tree. List rather than enumerate: the version suffix is
            // caller-supplied (see classTreeCacheKey(jarName, version)), so there is no fixed list.
            try (var s = store.list(root, false)) {
                for (var entry : s.filter(e -> e.key().leaf().startsWith("_class-tree_")).toList()) {
                    store.delete(entry.key());
                }
            }
        } catch (IOException e) { log.debug("Failed to invalidate summary cache: {}", e.getMessage()); }
    }

    /**
     * Pre-generate summary cache from the analysis file so first UI open is instant.
     * Called after saving analysis.json — adds ~20-30s to upload but saves that on every first open.
     */
    public void preGenerateSummaryCache(String jarName, boolean isStatic) {
        var analysisKey = isStatic ? paths.analysisKey(jarName) : paths.correctedKey(jarName);
        var cacheKey = isStatic ? paths.summaryCacheStaticKey(jarName) : paths.summaryCacheKey(jarName);
        var gzKey = cacheKey.parent().resolve(cacheKey.leaf() + ".gz");
        if (!store.exists(analysisKey)) return;
        try {
            log.info("Pre-generating summary cache for {} ...", jarName);
            long start = System.currentTimeMillis();
            AnalysisDataProvider provider = isStatic
                    ? new StaticAnalysisProvider(analysisKey, objectMapper, paths, jarName)
                    : new ClaudeAnalysisProvider(analysisKey, objectMapper, paths, jarName, "claude");
            // Streamed to BOTH outputs in one pass rather than buffered.
            //
            // This used to build the whole summary in a ByteArrayOutputStream so it could be written
            // twice — plain and gzipped. The summary grows with class and endpoint count (430 KB
            // measured at 119 classes, ~35 MB projected at 1,597), so on a very large analysis that
            // buffer is the process's peak memory and eventually an OutOfMemoryError. A tee writes
            // both copies as the generator produces bytes, so memory is constant regardless of how
            // large the analysis is — which is the property the rest of this class already has.
            long written;
            try (OutputStream plain = openWrite(cacheKey);
                 OutputStream gz = new java.util.zip.GZIPOutputStream(
                         new java.io.BufferedOutputStream(openWrite(gzKey), 64 * 1024));
                 CountingOutputStream counting = new CountingOutputStream(new TeeOutputStream(plain, gz));
                 InputStream src = openRead(analysisKey);
                 var parser = objectMapper.getFactory().createParser(src);
                 var gen = objectMapper.getFactory().createGenerator(counting)) {
                provider.streamSummary(parser, gen);
                gen.flush();
                written = counting.count();
            }
            long ms = System.currentTimeMillis() - start;
            log.info("Summary cache pre-generated: {} ({} MB, {}ms)", cacheKey,
                    written / (1024 * 1024), ms);
        } catch (Exception e) {
            log.warn("Failed to pre-generate summary cache: {}", e.getMessage());
        }
    }


    /**
     * Writes every byte to two streams, so a document can be produced once and stored in two forms.
     *
     * <p>Both are closed even if the first close throws — otherwise a failure writing the plain copy
     * would leak the gzip stream and, with a store whose writes publish on close, leave a half-written
     * artifact visible.
     */
    private static final class TeeOutputStream extends OutputStream {
        private final OutputStream a;
        private final OutputStream b;

        TeeOutputStream(OutputStream a, OutputStream b) {
            this.a = a;
            this.b = b;
        }

        @Override public void write(int x) throws IOException { a.write(x); b.write(x); }

        @Override public void write(byte[] buf, int off, int len) throws IOException {
            a.write(buf, off, len);
            b.write(buf, off, len);
        }

        @Override public void flush() throws IOException { a.flush(); b.flush(); }

        @Override public void close() throws IOException {
            try { a.close(); } finally { b.close(); }
        }
    }

    /** Counts bytes passing through, so a streamed artifact can still report its size. */
    private static final class CountingOutputStream extends java.io.FilterOutputStream {
        private long count;

        CountingOutputStream(OutputStream out) { super(out); }

        long count() { return count; }

        @Override public void write(int x) throws IOException { out.write(x); count++; }

        @Override public void write(byte[] buf, int off, int len) throws IOException {
            // FilterOutputStream's default writes byte-at-a-time through write(int); overriding is
            // what makes this usable on a multi-GB stream.
            out.write(buf, off, len);
            count += len;
        }
    }

    /* ---- File path getters for streaming responses ---- */

    public Path getFilePath(String jarName) {
        if (store.exists(paths.correctedKey(jarName))) return paths.correctedFile(jarName);
        return store.exists(paths.analysisKey(jarName)) ? paths.analysisFile(jarName) : null;
    }

    public Path getStaticFilePath(String jarName) {
        return store.exists(paths.analysisKey(jarName)) ? paths.analysisFile(jarName) : null;
    }

    public Path getCorrectedFilePath(String jarName) {
        return store.exists(paths.correctedKey(jarName)) ? paths.correctedFile(jarName) : null;
    }

    public Path getCorrectedPrevFilePath(String jarName) {
        return store.exists(paths.correctedPrevKey(jarName)) ? paths.correctedPrevFile(jarName) : null;
    }

    /* ---- Key twins of the getters above ----
     *
     * The Path getters are still used by callers that hand a file name to a response header. The
     * analysis PROVIDERS take a key, so they use these: no keyForPath() round-trip, and therefore
     * no way for a provider to be built from a path outside the data root. Same existence
     * semantics as the Path twins — null when the artifact is absent. */

    /** Best available document: corrected first, then static. Null if neither exists. */
    public com.analyzer.storage.ArtifactKey getDocumentKey(String jarName) {
        if (store.exists(paths.correctedKey(jarName))) return paths.correctedKey(jarName);
        return store.exists(paths.analysisKey(jarName)) ? paths.analysisKey(jarName) : null;
    }

    public com.analyzer.storage.ArtifactKey getStaticDocumentKey(String jarName) {
        return store.exists(paths.analysisKey(jarName)) ? paths.analysisKey(jarName) : null;
    }

    public com.analyzer.storage.ArtifactKey getCorrectedDocumentKey(String jarName) {
        return store.exists(paths.correctedKey(jarName)) ? paths.correctedKey(jarName) : null;
    }

    public com.analyzer.storage.ArtifactKey getCorrectedPrevDocumentKey(String jarName) {
        return store.exists(paths.correctedPrevKey(jarName)) ? paths.correctedPrevKey(jarName) : null;
    }

    /* ---- Version management ---- */

    public void rotateCorrected(String jarName) throws IOException {
        var current = paths.correctedKey(jarName);
        if (!store.exists(current)) return;
        var prev = paths.correctedPrevKey(jarName);
        store.move(current, prev);
        log.info("Rotated corrected -> prev: {}", prev);
    }

    public void revertCorrected(String jarName) throws IOException {
        var prev = paths.correctedPrevKey(jarName);
        if (!store.exists(prev)) {
            throw new IOException("No previous corrected version to revert to");
        }
        var current = paths.correctedKey(jarName);
        store.move(prev, current);
        log.info("Reverted: prev -> corrected: {}", current);
    }

    public Map<String, Object> getVersionInfo(String jarName) {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("hasStatic", store.exists(paths.analysisKey(jarName)));
        info.put("hasCorrected", store.exists(paths.correctedKey(jarName)));
        info.put("hasCorrectedPrev", store.exists(paths.correctedPrevKey(jarName)));
        var correctedKey = paths.correctedKey(jarName);
        if (store.exists(correctedKey)) {
            try {
                Map<String, Object> header = readHeaderOnly(correctedKey);
                if (header != null) {
                    if (header.containsKey("claudeIteration"))
                        info.put("claudeIteration", header.get("claudeIteration"));
                    if (header.containsKey("correctionAppliedAt"))
                        info.put("correctionAppliedAt", header.get("correctionAppliedAt"));
                    if (header.containsKey("correctionCount"))
                        info.put("correctionCount", header.get("correctionCount"));
                }
            } catch (IOException e) { /* defaults */ }
        }
        info.putIfAbsent("claudeIteration", 0);
        return info;
    }

    /* ---- Listing ---- */

    /**
     * Storage-backed listing, used when an ArtifactStore is wired.
     *
     * <p>Needed because the write path now targets the store: with s3 mode the header sidecars
     * are objects, not files, so the filesystem walk below finds nothing and the dashboard shows
     * an empty list even though every analysis uploaded correctly.
     *
     * <p>ONE {@code statPrefix} call covers the whole tree. Walking per-JAR with exists()/size()
     * would be 9 metadata round trips each — ~12.5 s at 50 analyses over S3 versus ~140 ms here.
     */
    private List<Map<String, Object>> listJarsFromStore() {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            com.analyzer.storage.ArtifactKey jarsRoot = com.analyzer.storage.ArtifactKey.of("jar");
            var all = store.statPrefix(jarsRoot);

            // Group keys by the analysis id (the segment right under jar/).
            Map<String, List<com.analyzer.storage.ArtifactKey>> byId = new LinkedHashMap<>();
            for (var k : all.keySet()) {
                var segs = k.segments();
                if (segs.size() < 3) continue;              // jar/<id>/<file> at minimum
                byId.computeIfAbsent(segs.get(1), x -> new ArrayList<>()).add(k);
            }

            for (var e : byId.entrySet()) {
                String id = e.getKey();
                boolean hasAnalysis = e.getValue().stream().anyMatch(k ->
                        k.leaf().equals("analysis.json") || k.leaf().equals("analysis_corrected.json"));
                if (!hasAnalysis) continue;                 // same filter as listJarRoots()

                com.analyzer.storage.ArtifactKey headerKey = paths.headerKey(id);
                Map<String, Object> entry = null;
                if (all.containsKey(headerKey)) {
                    try (InputStream in = store.read(headerKey)) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> h = objectMapper.readValue(in, LinkedHashMap.class);
                        entry = h;
                    } catch (Exception ex) {
                        log.debug("Unreadable header for {}: {}", id, ex.getMessage());
                    }
                }
                if (entry == null) {
                    // No sidecar (analysis written by an older build, or the sidecar was lost).
                    // Recover it by streaming the header fields out of the analysis file and
                    // writing the sidecar back, so this costs the full parse only once. Skipping
                    // instead would silently drop the JAR from the dashboard.
                    for (var src : List.of(paths.correctedKey(id), paths.analysisKey(id))) {
                        if (!all.containsKey(src)) continue;
                        try {
                            entry = readHeaderOnly(src);
                        } catch (IOException ex) {
                            log.debug("Unreadable analysis for {}: {}", id, ex.getMessage());
                        }
                        if (entry != null) break;
                    }
                    if (entry == null) continue;            // nothing listable here
                    try (OutputStream out = openWrite(headerKey)) {
                        objectMapper.writeValue(out, entry);
                    } catch (IOException ignore) { /* cache miss next time, not fatal */ }
                }
                entry.putIfAbsent("analysisMode",
                        all.containsKey(paths.correctedKey(id)) ? "CORRECTED" : "STATIC");
                entry.put("id", id);
                entry.putIfAbsent("jarName", id + ".jar");
                entry.put("hasPerJarConfig", all.containsKey(paths.domainConfigKey(id)));
                entry.put("hasConnections", all.containsKey(paths.connectionsKey(id)));
                entry.putIfAbsent("claudeStatus", "IDLE");
                result.add(entry);
            }
        } catch (Exception e) {
            log.warn("Store-backed listJars failed: {}", e.toString());
        }
        return result;
    }

    /**
     * Every JAR the store knows about. Backed entirely by {@link #listJarsFromStore()}: one prefix
     * listing rather than a directory walk plus a stat per candidate file, which is what made this
     * slow — and what made it wrong once writes stopped landing on the local disk.
     */
    public List<Map<String, Object>> listJars() {
        return listJarsFromStore();
    }

    private Map<String, Object> readHeaderOnly(com.analyzer.storage.ArtifactKey key)
            throws IOException {
        try (InputStream in = openRead(key);
             com.fasterxml.jackson.core.JsonParser parser =
                     objectMapper.getFactory().createParser(in)) {
            Map<String, Object> entry = new LinkedHashMap<>();
            if (parser.nextToken() != com.fasterxml.jackson.core.JsonToken.START_OBJECT) return null;

            while (parser.nextToken() != com.fasterxml.jackson.core.JsonToken.END_OBJECT) {
                String field = parser.currentName();
                parser.nextToken();

                switch (field) {
                    case "jarName" -> {
                        if (parser.currentToken() != com.fasterxml.jackson.core.JsonToken.VALUE_NULL)
                            entry.put("jarName", parser.getText());
                    }
                    case "projectName" -> {
                        if (parser.currentToken() != com.fasterxml.jackson.core.JsonToken.VALUE_NULL)
                            entry.put("projectName", parser.getText());
                    }
                    case "jarSize" -> entry.put("jarSize", parser.getLongValue());
                    case "analyzedAt" -> {
                        if (parser.currentToken() != com.fasterxml.jackson.core.JsonToken.VALUE_NULL)
                            entry.put("analyzedAt", parser.getText());
                    }
                    case "totalClasses" -> entry.put("totalClasses", parser.getIntValue());
                    case "totalEndpoints" -> entry.put("totalEndpoints", parser.getIntValue());
                    case "analysisMode" -> {
                        if (parser.currentToken() != com.fasterxml.jackson.core.JsonToken.VALUE_NULL)
                            entry.put("analysisMode", parser.getText());
                    }
                    case "correctionAppliedAt" -> {
                        if (parser.currentToken() != com.fasterxml.jackson.core.JsonToken.VALUE_NULL)
                            entry.put("correctionAppliedAt", parser.getText());
                    }
                    case "correctionCount" -> entry.put("correctionCount", parser.getIntValue());
                    case "claudeIteration" -> entry.put("claudeIteration", parser.getIntValue());
                    case "classes", "endpoints" -> {
                        parser.skipChildren();
                        if (entry.containsKey("jarName") && entry.containsKey("totalEndpoints")) return entry;
                    }
                    default -> parser.skipChildren();
                }
            }
            return entry.isEmpty() ? null : entry;
        }
    }

    /* ---- Resource files ---- */

    public void storeResourceFiles(String jarId, Map<String, String> resources) {
        if (resources == null || resources.isEmpty()) return;
        try {
            var dir = paths.resourcesDirKey(jarId);
            for (Map.Entry<String, String> entry : resources.entrySet()) {
                // Names come from inside the JAR, so they are untrusted: keep the traversal guard.
                if (entry.getKey().contains("..")) continue;
                byte[] body = entry.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                try (OutputStream out = openWrite(dir.resolve(entry.getKey()), body.length)) {
                    out.write(body);
                }
            }
            log.info("Stored {} resource file(s) for {}", resources.size(), jarId);
        } catch (IOException e) {
            log.warn("Failed to store resource files for {}: {}", jarId, e.getMessage());
        }
    }

    public List<String> listResourceFiles(String jarId) {
        var dir = paths.resourcesDirKey(jarId);
        try (var stream = store.list(dir, false)) {
            return stream.filter(e -> !e.directory())
                    .map(e -> e.key().leaf())
                    .sorted()
                    .collect(java.util.stream.Collectors.toList());
        } catch (IOException e) {
            log.warn("Failed to list resource files for {}: {}", jarId, e.getMessage());
            return Collections.emptyList();
        }
    }

    public String loadResourceFile(String jarId, String filename) throws IOException {
        if (filename.contains("..")) return null;
        var key = paths.resourcesDirKey(jarId).resolve(filename);
        if (!store.exists(key)) return null;
        try (InputStream in = openRead(key)) {
            return new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /* ---- Bundled JAR info ---- */

    public void storeBundledJarInfo(String jarId, List<JarParserService.BundledJarInfo> jars) {
        if (jars == null || jars.isEmpty()) return;
        try {
            paths.ensureJarRoot(jarId);
            Path dest = paths.jarRoot(jarId).resolve("bundled-jars.json");
            try (java.io.OutputStream out = openWrite(paths.bundledJarsKey(jarId))) {
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(out, jars);
            }
            log.info("Stored bundled-jars.json for {} ({} JARs)", jarId, jars.size());
        } catch (IOException e) {
            log.warn("Failed to store bundled-jars.json for {}: {}", jarId, e.getMessage());
        }
    }

    public List<JarParserService.BundledJarInfo> loadBundledJarInfo(String jarId) {
        var key = paths.bundledJarsKey(jarId);
        if (!store.exists(key)) return Collections.emptyList();
        try (InputStream in = openRead(key)) {
            return objectMapper.readValue(in,
                    new TypeReference<List<JarParserService.BundledJarInfo>>() {});
        } catch (Exception e) {
            log.warn("Failed to load bundled-jars.json for {}: {}", jarId, e.getMessage());
            return Collections.emptyList();
        }
    }

    /* ---- JAR dependency map ---- */

    public void storeJarDepsMap(String jarId, Map<String, Set<String>> depMap) {
        if (depMap == null || depMap.isEmpty()) return;
        try {
            paths.ensureJarRoot(jarId);
            try (java.io.OutputStream out = openWrite(paths.jarDepMapKey(jarId))) {
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(out, depMap);
            }
            log.info("Stored jar-dep-map.json for {} ({} entries)", jarId, depMap.size());
        } catch (IOException e) {
            log.warn("Failed to store jar-dep-map.json for {}: {}", jarId, e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Set<String>> loadJarDepsMap(String jarId) {
        var key = paths.jarDepMapKey(jarId);
        if (!store.exists(key)) return Collections.emptyMap();
        try (InputStream in = openRead(key)) {
            return objectMapper.readValue(in,
                    new TypeReference<Map<String, Set<String>>>() {});
        } catch (Exception e) {
            log.warn("Failed to load jar-dep-map.json for {}: {}", jarId, e.getMessage());
            return Collections.emptyMap();
        }
    }

    /* ---- Delete ---- */

    public boolean delete(String jarName) throws IOException {
        var root = paths.jarRootKey(jarName);
        return store.deletePrefix(root) > 0;
    }
}
