package com.jaranalyzer.service;

import com.jaranalyzer.model.CallNode;
import com.jaranalyzer.service.CallGraphIndex.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Resolves repository-to-collection mappings and populates collection data on CallNodes.
 * Extracted from CallTreeBuilder to keep files focused and under 300 lines.
 */
@Component
class CollectionResolver {

    private static final Logger log = LoggerFactory.getLogger(CollectionResolver.class);

    private final DomainConfigLoader configLoader;
    private final MongoMethodDetector mongoMethodDetector;
    private final AggregationDetector aggregationDetector;
    private final JpaMethodDetector jpaMethodDetector;
    private final MyBatisMethodDetector myBatisMethodDetector;
    private final RedisMethodDetector redisMethodDetector;
    private final CassandraMethodDetector cassandraMethodDetector;
    private final ElasticsearchMethodDetector elasticsearchMethodDetector;
    private final CollectionLifecycleDetector collectionLifecycleDetector;

    CollectionResolver(DomainConfigLoader configLoader, MongoMethodDetector mongoMethodDetector,
                       AggregationDetector aggregationDetector, JpaMethodDetector jpaMethodDetector,
                       MyBatisMethodDetector myBatisMethodDetector, RedisMethodDetector redisMethodDetector,
                       CassandraMethodDetector cassandraMethodDetector,
                       ElasticsearchMethodDetector elasticsearchMethodDetector,
                       CollectionLifecycleDetector collectionLifecycleDetector) {
        this.configLoader = configLoader;
        this.mongoMethodDetector = mongoMethodDetector;
        this.aggregationDetector = aggregationDetector;
        this.jpaMethodDetector = jpaMethodDetector;
        this.myBatisMethodDetector = myBatisMethodDetector;
        this.redisMethodDetector = redisMethodDetector;
        this.cassandraMethodDetector = cassandraMethodDetector;
        this.elasticsearchMethodDetector = elasticsearchMethodDetector;
        this.collectionLifecycleDetector = collectionLifecycleDetector;
    }

    /**
     * Tag a just-built CHILD node with the collection resolved at the CALL SITE that produced it
     * (as opposed to collectCollections above, which resolves collections from signals found
     * INSIDE a method's own body). Needed for methods like BulkWriteCollector.addInsert/addUpdate
     * whose own body never references the collection at all — it only arrives as a parameter, so
     * collectCollections finds nothing for that node's OWN method; the collection name is only
     * visible at the caller's literal/resolved argument, one level up in the tree. Additive only:
     * never overwrites collections already found on the node by its own body (e.g. a wrapper
     * method that both calls addInsert AND does other DB work in the same body).
     *
     * Returns null when the call is not a BulkWriteCollector buffering call (the common case —
     * callers should keep the original node), or the caller-tagged CallNode otherwise. The
     * returned node is always CallNode.copyForCallSiteTagging()'d off the original BEFORE this
     * method mutates it — see that method's docs for why buildCallTree's memoization makes this
     * mandatory (the original may be shared across unrelated call sites via the memo map).
     */
    CallNode tagCallSiteCollection(CallNode original, InvocationRef call) {
        MongoMethodDetector.CallSiteCollection csc = mongoMethodDetector.resolveBulkCollectorCallSite(call);
        if (csc == null) return null;
        CallNode child = original.copyForCallSiteTagging();
        if (csc.collectionName() != null) {
            if (!child.getCollectionsAccessed().contains(csc.collectionName())) {
                child.getCollectionsAccessed().add(csc.collectionName());
                child.getCollectionDomains().put(csc.collectionName(), configLoader.detectCollectionDomain(csc.collectionName()));
                child.getCollectionSources().put(csc.collectionName(), "BULK_WRITE_COLLECTOR_CALL_SITE");
            }
        } else if (csc.dynamicArg() != null) {
            Map<String, Object> ref = new LinkedHashMap<>();
            ref.put("variableName", csc.dynamicArg().name());
            ref.put("varKind", csc.dynamicArg().kind());
            ref.put("pattern", "BULK_WRITE_COLLECTOR_CALL_SITE_DYNAMIC");
            ref.put("source", "BULK_WRITE_COLLECTOR");
            ref.put("operationType", csc.operationType());
            if (!child.getDynamicCollectionRefs().contains(ref)) {
                child.getDynamicCollectionRefs().add(ref);
            }
        }
        if (csc.operationType() != null) {
            child.getOperationTypes().add(csc.operationType());
            if (child.getOperationType() == null) child.setOperationType(csc.operationType());
        }
        child.setHasDbInteraction(true);
        return child;
    }

    // ========== Base Package Auto-Detection ==========

    /**
     * Fallback: detect the most common top-level package (e.g. "com.acme") from indexed classes.
     * Uses the first two segments of class FQNs and picks the most frequent one.
     */
    List<String> autoDetectBasePackages(ResolutionContext ctx) {
        Map<String, Integer> pkgCount = new HashMap<>();
        for (String fqn : ctx.classMap.keySet()) {
            String[] parts = fqn.split("\\.");
            if (parts.length >= 2) {
                String base = parts[0] + "." + parts[1];
                pkgCount.merge(base, 1, Integer::sum);
            }
        }
        if (pkgCount.isEmpty()) return List.of();

        String topPkg = pkgCount.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);

        if (topPkg != null) {
            log.info("Auto-detected base package '{}' from {} indexed classes", topPkg, pkgCount.get(topPkg));
            return List.of(topPkg);
        }
        return List.of();
    }

    // ========== Repository -> Collection Resolution ==========

    void resolveRepositoryCollections(ResolutionContext ctx) {
        for (IndexedClass ic : ctx.classMap.values()) {
            if (!"REPOSITORY".equals(ic.stereotype) && !"SPRING_DATA".equals(ic.stereotype)) continue;

            // Priority 1: Direct entity type from generic signature (MongoRepository<Entity, ID>)
            if (ic.repositoryEntityType != null) {
                String coll = ctx.entityCollectionMap.get(ic.repositoryEntityType);
                // Also try simple name
                if (coll == null) {
                    String simpleName = ic.repositoryEntityType.contains(".")
                            ? ic.repositoryEntityType.substring(ic.repositoryEntityType.lastIndexOf('.') + 1)
                            : ic.repositoryEntityType;
                    coll = ctx.entityCollectionMap.get(simpleName);
                }
                if (coll != null) {
                    ctx.repoCollectionMap.put(ic.fqn, coll);
                    ctx.repoCollectionMap.put(ic.simpleName, coll);
                    log.debug("Repo {} → entity {} → collection {} (generic signature)",
                            ic.simpleName, ic.repositoryEntityType, coll);
                }
            }

            // Priority 1.5: Entity type known but not in entityCollectionMap —
            // try CamelCase → UPPER_SNAKE convention (e.g., ClmTransEntity → CLM_TRANS)
            if (!ctx.repoCollectionMap.containsKey(ic.simpleName) && ic.repositoryEntityType != null) {
                String entitySimple = ic.repositoryEntityType.contains(".")
                        ? ic.repositoryEntityType.substring(ic.repositoryEntityType.lastIndexOf('.') + 1)
                        : ic.repositoryEntityType;
                String entityStem = entitySimple.replaceAll("(Entity|Document|Model|Dto|DO)$", "");
                String upperSnake = entityStem.replaceAll("([a-z])([A-Z])", "$1_$2").toUpperCase();
                if (configLoader.isLikelyCollectionName(upperSnake)) {
                    ctx.repoCollectionMap.put(ic.fqn, upperSnake);
                    ctx.repoCollectionMap.put(ic.simpleName, upperSnake);
                    log.debug("Repo {} → entity {} → derived collection {} (name convention)",
                            ic.simpleName, ic.repositoryEntityType, upperSnake);
                }
            }

            // Priority 2: Stem-based matching (ClaimRepository → Claim → entityCollectionMap)
            if (!ctx.repoCollectionMap.containsKey(ic.simpleName)) {
                List<String> stems = new ArrayList<>();
                for (String suffix : configLoader.getRepositorySuffixes()) {
                    if (ic.simpleName.endsWith(suffix)) {
                        stems.add(ic.simpleName.substring(0, ic.simpleName.length() - suffix.length()));
                    }
                }
                for (String stem : stems) {
                    for (Map.Entry<String, String> entry : ctx.entityCollectionMap.entrySet()) {
                        if (entry.getKey().endsWith(stem) || entry.getKey().equals(stem)) {
                            ctx.repoCollectionMap.put(ic.fqn, entry.getValue());
                            ctx.repoCollectionMap.put(ic.simpleName, entry.getValue());
                            break;
                        }
                    }
                    if (ctx.repoCollectionMap.containsKey(ic.simpleName)) break;
                }
            }

            for (IndexedMethod m : ic.methods.values()) {
                for (AnnotationData ad : m.annotationDetailList) {
                    if (configLoader.getQueryAnnotations().contains(ad.name())) {
                        for (Object val : ad.attributes().values()) {
                            for (String s : configLoader.flattenAnnotationValue(val)) {
                                // Only use targeted pipeline extraction (from/into/coll contexts)
                                // Do NOT use extractCollectionRefs — it matches foreignField, $project aliases, etc.
                                for (String ref : configLoader.extractPipelineCollectionRefs(s)) {
                                    if (!"Other".equals(configLoader.detectCollectionDomain(ref))) {
                                        ctx.repoCollectionMap.putIfAbsent(ic.fqn, ref);
                                        ctx.repoCollectionMap.putIfAbsent(ic.simpleName, ref);
                                    }
                                }
                            }
                        }
                    }
                }
                for (String lit : m.stringLiterals) {
                    if (lit.contains("_") && !"Other".equals(configLoader.detectCollectionDomain(lit))) {
                        ctx.repoCollectionMap.putIfAbsent(ic.fqn, lit);
                        ctx.repoCollectionMap.putIfAbsent(ic.simpleName, lit);
                    }
                }
            }
            for (String fc : ic.fieldConstants) {
                if (!"Other".equals(configLoader.detectCollectionDomain(fc))) {
                    ctx.repoCollectionMap.putIfAbsent(ic.fqn, fc);
                    ctx.repoCollectionMap.putIfAbsent(ic.simpleName, fc);
                }
            }
        }

        // JPA Repository → Table resolution (parallel to MongoDB repo-collection above)
        for (IndexedClass ic : ctx.classMap.values()) {
            if (!"REPOSITORY".equals(ic.stereotype)) continue;
            if (ctx.repoTableMap.containsKey(ic.simpleName)) continue;
            if (ic.repositoryEntityType != null && !ctx.entityTableMap.isEmpty()) {
                String table = ctx.entityTableMap.get(ic.repositoryEntityType);
                if (table == null) {
                    String simpleName = ic.repositoryEntityType.contains(".")
                            ? ic.repositoryEntityType.substring(ic.repositoryEntityType.lastIndexOf('.') + 1)
                            : ic.repositoryEntityType;
                    table = ctx.entityTableMap.get(simpleName);
                }
                if (table != null) {
                    ctx.repoTableMap.put(ic.fqn, table);
                    ctx.repoTableMap.put(ic.simpleName, table);
                    log.debug("JPA Repo {} → entity {} → table {} (generic signature)",
                            ic.simpleName, ic.repositoryEntityType, table);
                }
            }
        }

        log.info("Resolved {} entity-collection, {} repo-collection, {} entity-table, {} repo-table mappings",
                ctx.entityCollectionMap.size(), ctx.repoCollectionMap.size(),
                ctx.entityTableMap.size(), ctx.repoTableMap.size());
    }

    // ========== Populate collection data on a CallNode ==========

    // Methods whose string arguments are NOT collection names (sequence IDs, log strings, etc.)
    private static final Set<String> NON_COLLECTION_METHODS = Set.of(
            // Sequence generators
            "getSequenceId", "getNextSequenceValue", "getNextVal", "nextVal",
            "getNextId", "generateSequence", "incrementAndGet",
            // Extension/API handlers
            "handleClaimAPIExtensions", "handleAPIExtensions",
            // Logging
            "info", "debug", "warn", "error", "trace", "log", "logError", "logWarning", "logInfo",
            // String formatting / IO
            "format", "printf", "println", "append", "write", "print",
            // Reflection / metadata access (not DB operations)
            "getCollectionName", "getCollectionNameFromClass",
            // In-memory utility methods
            "createBatches", "createSavepoint", "partitionList",
            // Object utilities
            "toString", "hashCode", "equals", "valueOf", "compareTo", "fromString", "parse",
            // Property/config access
            "getProperty", "setProperty", "containsKey", "containsValue",
            "getConfig", "loadProperty", "resolveProperty", "getValue", "getEnv",
            // Cache/session operations
            "put", "get", "remove", "evict", "putIfAbsent", "getIfPresent",
            // In-memory membership checks — e.g. List.of("A", COLL_LIKE_CONST, "B").contains(x) is a
            // pure guard-clause comparison, not a DB call; never a real Mongo/JPA collection method.
            // The literals themselves are captured as List.of/Set.of's OWN stringArgs (the receiver
            // collection-literal construction), not contains()'s — "of" is what actually needs
            // excluding; "contains"/"containsAll" kept too in case of alternate bytecode shapes.
            "contains", "containsAll", "of",
            // Event/messaging (string args are event names, not collections)
            "sendMessage", "publishEvent", "emit", "publish", "send", "broadcast",
            "addEventListener", "addListener", "removeListener", "removeEventListener",
            // Validation/exception
            "validate", "check", "throwException", "assertNotNull", "requireNonNull",
            // Enum/constant lookup
            "getEnumValue", "lookup", "resolve", "forName",
            // Annotation/metadata
            "annotation", "with", "metadata", "getAttribute", "setAttribute"
    );

    // Suffixes that disqualify a string literal from being a collection name.
    // E.g., "CLM_TRANS_TIMEOUT", "CLM_TRANS_ERROR" — these are config/error constants, not collections.
    private static final Set<String> NON_COLLECTION_SUFFIXES = Set.of(
            "_TIMEOUT", "_CONFIG", "_PROPERTY", "_PROPERTIES", "_MESSAGE", "_MSG",
            "_EVENT", "_EXCEPTION", "_ERROR", "_ERRORS", "_CONSTANT", "_CACHE",
            "_SESSION", "_KEY", "_KEYS", "_PREFIX", "_SUFFIX", "_FORMAT",
            "_LOG", "_LOGGER", "_HANDLER", "_LISTENER", "_FACTORY", "_BUILDER",
            "_TYPE", "_STATUS", "_STATE", "_FLAG", "_MODE", "_LEVEL",
            "_FAILED", "_SUCCESS", "_ACTIVE", "_INACTIVE", "_PENDING",
            "_COUNT", "_LIMIT", "_SIZE", "_LENGTH", "_INDEX", "_OFFSET",
            "_PATH", "_URL", "_URI", "_HOST", "_PORT", "_NAME", "_LABEL",
            "_TEMPLATE", "_PATTERN", "_REGEX", "_SEPARATOR", "_DELIMITER",
            "_QUERY", "_CONTEXT", "_CRITERIA", "_FILTER", "_SORT", "_PROJECTION",
            "_HEADER", "_FOOTER", "_BODY", "_PAYLOAD", "_RESPONSE", "_REQUEST",
            "_DESCRIPTION", "_REASON", "_DETAIL", "_DETAILS", "_REPORT"
    );

    void collectCollections(IndexedClass cls, IndexedMethod method, CallNode node, ResolutionContext ctx) {
        List<String> collections = new ArrayList<>();
        Map<String, String> collDomains = new LinkedHashMap<>();
        Map<String, String> collSources = new LinkedHashMap<>();
        Set<String> detectedOpTypes = new HashSet<>();

        // Known entity field names (from @Field/@BsonProperty) — these are NOT collections.
        Set<String> fieldNameExclusions = ctx.knownEntityFieldNames;

        // Build exclusion set: strings used as arguments to sequence/logging/utility methods
        Set<String> nonCollectionArgs = buildNonCollectionArgs(method);

        // From repository mapping
        if ("REPOSITORY".equals(cls.stereotype) || "SPRING_DATA".equals(cls.stereotype)) {
            String coll = ctx.repoCollectionMap.get(cls.fqn);
            if (coll == null) coll = ctx.repoCollectionMap.get(cls.simpleName);
            if (coll != null && !collections.contains(coll) && !fieldNameExclusions.contains(coll)) {
                collections.add(coll);
                collDomains.put(coll, configLoader.detectCollectionDomain(coll));
                collSources.put(coll, "REPOSITORY_MAPPING");
            }
        }

        // From @Document on class — always trust this (explicit annotation)
        if (cls.documentCollection != null && !collections.contains(cls.documentCollection)) {
            collections.add(cls.documentCollection);
            collDomains.put(cls.documentCollection, configLoader.detectCollectionDomain(cls.documentCollection));
            collSources.put(cls.documentCollection, "DOCUMENT_ANNOTATION");
        }

        // From method string literals -- only if they match a known domain prefix (not "Other")
        // AND are not known entity field names AND not arguments to sequence/log methods
        // AND don't end with a non-collection suffix (e.g., _TIMEOUT, _ERROR, _CONFIG)
        for (String lit : method.stringLiterals) {
            if (lit.contains("_") && !collections.contains(lit)
                    && !fieldNameExclusions.contains(lit) && !nonCollectionArgs.contains(lit)
                    && !hasNonCollectionSuffix(lit)) {
                String domain = configLoader.detectCollectionDomain(lit);
                if (!"Other".equals(domain)) {
                    collections.add(lit);
                    collDomains.put(lit, domain);
                    collSources.put(lit, "STRING_LITERAL");
                }
            }
        }

        // From class field constants — only for REPOSITORY/SPRING_DATA classes where
        // static final String constants genuinely hold collection names.
        // Skip for SERVICE/COMPONENT classes where constants may be used for other purposes
        // (e.g. field names, config keys) and leak as false positives to all methods.
        if ("REPOSITORY".equals(cls.stereotype) || "SPRING_DATA".equals(cls.stereotype)) {
            for (String fc : cls.fieldConstants) {
                if (!collections.contains(fc) && !fieldNameExclusions.contains(fc)) {
                    String domain = configLoader.detectCollectionDomain(fc);
                    if (!"Other".equals(domain)) {
                        collections.add(fc);
                        collDomains.put(fc, domain);
                        collSources.put(fc, "FIELD_CONSTANT");
                    }
                }
            }
        }

        // From annotation values (@Query, @Aggregation, etc.)
        // ONLY use extractPipelineCollectionRefs (targeted: from/into/coll contexts).
        // Do NOT use extractCollectionRefs here — it matches ANY UPPER_CASE_STRING
        // which causes false positives from foreignField, localField, $project aliases, etc.
        for (AnnotationData ad : method.annotationDetailList) {
            for (Object val : ad.attributes().values()) {
                for (String s : configLoader.flattenAnnotationValue(val)) {
                    for (String ref : configLoader.extractPipelineCollectionRefs(s)) {
                        if (!collections.contains(ref) && !fieldNameExclusions.contains(ref)) {
                            String domain = configLoader.detectCollectionDomain(ref);
                            if (!"Other".equals(domain)) {
                                collections.add(ref);
                                collDomains.put(ref, domain);
                                collSources.put(ref, "PIPELINE_ANNOTATION");
                            }
                        }
                    }
                }
            }
        }

        // From MongoMethodDetector: BulkWriteCollector, MongoTemplate, native driver, reactive.
        // Unlike the string-literal/field-constant scans above (which need the domain-prefix
        // filter to reject false positives like foreignField/$project aliases), these collection
        // names come from actual resolved API invocations (addInsert/addUpdate/getCollection/etc.)
        // so they are added unconditionally — matching the JpaMethodDetector loop below. Domain is
        // still computed for display/grouping but "Other" must not drop the collection, or any
        // collection whose prefix isn't yet in domain-config.json's module_types (e.g. WIP_*)
        // silently vanishes even though detection correctly found it.
        // Dynamic (variable-sourced) collection references — collected from both detectors below,
        // merged onto CallNode.dynamicCollectionRefs, and NEVER folded into collections/
        // collDomains/collSources (those three must stay "resolved literal" ground truth).
        List<Map<String, Object>> dynamicRefs = new ArrayList<>();

        MongoMethodDetector.DetectionResult mongoResult = mongoMethodDetector.detect(method, cls, ctx.entityCollectionMap);
        for (MongoMethodDetector.DetectedCollection dc : mongoResult.resolved()) {
            if (dc.operationType() != null) detectedOpTypes.add(dc.operationType());
            // dc.collectionName() is null for NATIVE_COMMAND_DEFAULT (runCommand default-READ
            // classification, e.g. collStats/admin commands) — that entry exists purely to carry
            // an operationType signal (handled above) and must never be added to
            // collectionsAccessed as a bogus "null" entry.
            if (dc.collectionName() == null) continue;
            if (!collections.contains(dc.collectionName()) && !fieldNameExclusions.contains(dc.collectionName())) {
                collections.add(dc.collectionName());
                collDomains.put(dc.collectionName(), configLoader.detectCollectionDomain(dc.collectionName()));
                collSources.put(dc.collectionName(), dc.source());
            }
        }
        for (CallGraphIndex.DetectedDynamicCollection ddc : mongoResult.dynamic()) {
            mergeDynamicResult(ddc, ctx, collections, collDomains, collSources, fieldNameExclusions,
                    dynamicRefs, detectedOpTypes);
        }

        // From AggregationDetector: pipeline stages ($lookup, $merge, $out), Spring Aggregation API.
        // Same reasoning as the MongoMethodDetector loop above: these are resolved invocations,
        // not heuristic string scans, so they must not be dropped for having an unmapped prefix.
        AggregationDetector.PipelineDetail pipelineDetail = new AggregationDetector.PipelineDetail();
        for (AggregationDetector.DetectedPipelineCollection dc : aggregationDetector.detect(method, cls, ctx, pipelineDetail)) {
            if (dc.operationType() != null) detectedOpTypes.add(dc.operationType());
            if (!collections.contains(dc.collectionName()) && !fieldNameExclusions.contains(dc.collectionName())) {
                collections.add(dc.collectionName());
                collDomains.put(dc.collectionName(), configLoader.detectCollectionDomain(dc.collectionName()));
                collSources.put(dc.collectionName(), dc.source());
            }
        }
        for (CallGraphIndex.DetectedDynamicCollection ddc : pipelineDetail.dynamicRefs) {
            mergeDynamicResult(ddc, ctx, collections, collDomains, collSources, fieldNameExclusions,
                    dynamicRefs, detectedOpTypes);
        }
        // Attach rich pipeline detail to CallNode if any stages were detected
        if (!pipelineDetail.stages.isEmpty() || !pipelineDetail.lookupTargets.isEmpty()
                || !pipelineDetail.pipelineSourceMethods.isEmpty()) {
            Map<String, Object> pipeline = new LinkedHashMap<>();
            if (pipelineDetail.baseCollection != null)
                pipeline.put("baseCollection", pipelineDetail.baseCollection);
            pipeline.put("stages", pipelineDetail.stages);
            if (!pipelineDetail.lookupTargets.isEmpty())
                pipeline.put("lookupTargets", pipelineDetail.lookupTargets);
            if (!pipelineDetail.matchFields.isEmpty())
                pipeline.put("matchFields", new ArrayList<>(pipelineDetail.matchFields));
            if (!pipelineDetail.groupFields.isEmpty())
                pipeline.put("groupFields", new ArrayList<>(pipelineDetail.groupFields));
            if (!pipelineDetail.projectionFields.isEmpty())
                pipeline.put("projectionFields", new ArrayList<>(pipelineDetail.projectionFields));
            if (!pipelineDetail.sortFields.isEmpty())
                pipeline.put("sortFields", new ArrayList<>(pipelineDetail.sortFields));
            if (!pipelineDetail.companionUsage.isEmpty())
                pipeline.put("companionUsage", pipelineDetail.companionUsage);
            if (!pipelineDetail.detectionSources.isEmpty())
                pipeline.put("detectionSources", new ArrayList<>(pipelineDetail.detectionSources));
            if (pipelineDetail.isDynamic)
                pipeline.put("isDynamic", true);
            if (!pipelineDetail.pipelineSourceMethods.isEmpty())
                pipeline.put("pipelineSourceMethods", pipelineDetail.pipelineSourceMethods);
            node.setAggregationPipeline(pipeline);
        }

        // Collection-lifecycle-workflow stage tagging (e.g. blue-green collection swap). Matches
        // real MongoDB driver method invocations (createCollection/createIndex/renameCollection/
        // drop) already scanned above via method.invocations, plus the pipelineDetail.stages
        // just populated by aggregationDetector — deliberately independent of whatever
        // application-defined wrapper method this node's own methodName is, since that can be
        // renamed freely. See CollectionLifecycleDetector for the aggregation pass that groups
        // these tags across the tree into workflow instances.
        List<String> lifecycleStageTags = collectionLifecycleDetector.detectStages(method, pipelineDetail);
        if (!lifecycleStageTags.isEmpty()) {
            node.setLifecycleStageTags(lifecycleStageTags);
        }

        // From MyBatisMethodDetector: SqlSession, @Mapper annotations
        for (MyBatisMethodDetector.DetectedTable dt : myBatisMethodDetector.detect(method, cls, ctx.namedQueryMap)) {
            if (dt.operationType() != null) detectedOpTypes.add(dt.operationType());
            if (!"?".equals(dt.tableName()) && !collections.contains(dt.tableName())) {
                collections.add(dt.tableName());
                String domain = configLoader.detectCollectionDomain(dt.tableName());
                collDomains.put(dt.tableName(), domain);
                collSources.put(dt.tableName(), dt.source());
            }
        }

        // From RedisMethodDetector: RedisTemplate, StringRedisTemplate operations
        for (RedisMethodDetector.DetectedCollection dc : redisMethodDetector.detect(cls, method, method.invocations)) {
            if (dc.operationType() != null) detectedOpTypes.add(dc.operationType());
            // Redis keys are not "collection names" in the MongoDB/JPA sense — we skip domain filtering
            // and always include them when detected. They use source=REDIS_TEMPLATE.
            if (!collections.contains(dc.collectionName())) {
                collections.add(dc.collectionName());
                collDomains.put(dc.collectionName(), "Redis");
                collSources.put(dc.collectionName(), dc.source());
            }
        }

        // From CassandraMethodDetector: CassandraTemplate, CqlSession operations
        for (CassandraMethodDetector.DetectedCollection dc : cassandraMethodDetector.detect(cls, method, method.invocations)) {
            if (dc.operationType() != null) detectedOpTypes.add(dc.operationType());
            if (!collections.contains(dc.collectionName()) && !fieldNameExclusions.contains(dc.collectionName())) {
                String domain = configLoader.detectCollectionDomain(dc.collectionName());
                collections.add(dc.collectionName());
                collDomains.put(dc.collectionName(), domain);
                collSources.put(dc.collectionName(), dc.source());
            }
        }

        // From ElasticsearchMethodDetector: ElasticsearchOperations, RestHighLevelClient
        for (ElasticsearchMethodDetector.DetectedCollection dc : elasticsearchMethodDetector.detect(cls, method, method.invocations, ctx.entityCollectionMap)) {
            if (dc.operationType() != null) detectedOpTypes.add(dc.operationType());
            if (!collections.contains(dc.collectionName()) && !fieldNameExclusions.contains(dc.collectionName())) {
                String domain = configLoader.detectCollectionDomain(dc.collectionName());
                collections.add(dc.collectionName());
                collDomains.put(dc.collectionName(), domain);
                collSources.put(dc.collectionName(), dc.source());
            }
        }

        // From JpaMethodDetector: JdbcTemplate, EntityManager, @Query, derived queries
        List<String> capturedSql = new ArrayList<>();
        for (JpaMethodDetector.DetectedTable dt : jpaMethodDetector.detect(method, cls, ctx.entityTableMap, ctx.namedQueryMap)) {
            if (dt.operationType() != null) detectedOpTypes.add(dt.operationType());
            if (!collections.contains(dt.tableName())) {
                collections.add(dt.tableName());
                String domain = configLoader.detectCollectionDomain(dt.tableName());
                collDomains.put(dt.tableName(), domain);
                collSources.put(dt.tableName(), dt.source());
            }
            // Capture raw SQL text for display in UI
            if (dt.sqlText() != null && !dt.sqlText().isBlank() && !capturedSql.contains(dt.sqlText())) {
                capturedSql.add(dt.sqlText());
            }
        }
        if (!capturedSql.isEmpty()) node.setSqlStatements(capturedSql);

        // From JPA repository mapping (parallel to MongoDB repo mapping above)
        if ("REPOSITORY".equals(cls.stereotype)) {
            String table = ctx.repoTableMap.get(cls.fqn);
            if (table == null) table = ctx.repoTableMap.get(cls.simpleName);
            if (table != null && !collections.contains(table)) {
                collections.add(table);
                collDomains.put(table, configLoader.detectCollectionDomain(table));
                collSources.put(table, "JPA_REPOSITORY_MAPPING");
            }
        }

        // From @Entity @Table on the class itself
        if (cls.isJpaEntity && cls.jpaTableName != null && !collections.contains(cls.jpaTableName)) {
            collections.add(cls.jpaTableName);
            collDomains.put(cls.jpaTableName, configLoader.detectCollectionDomain(cls.jpaTableName));
            collSources.put(cls.jpaTableName, "JPA_TABLE_ANNOTATION");
        }

        // Mark node as DB-interacting when collections were resolved OR when direct
        // MongoTemplate/JDBC/JPA calls were detected. The guard on collections.isEmpty()
        // was incorrect: Oracle JDBC nodes detect stored-procedure collections (e.g.
        // PROC_ARCHIVE_ORDERS) so the list is never empty, yet the flag was never set.
        // Also true for a BulkWriteCollector's own addInsert/addUpdate/addDelete methods —
        // these buffer an operation for a LATER flush (execute()/runCommand()) rather than
        // calling Mongo directly, so neither collections nor mongoMethodDetector.hasDbInvocations
        // would otherwise catch them, letting the post-build cleanup pass null out or
        // re-derive their operationType from unrelated child calls.
        // Also true when AggregationDetector saw pipeline-builder-class usage (MatchOperation,
        // GroupOperation, SortOperation, Filters/Projections/Sorts/Accumulators companions, etc.)
        // even though no individual stage carried a resolvable collection-name string — e.g. a
        // helper method that only assembles $match/$group criteria for a pipeline executed
        // elsewhere. Without this, such helpers have zero collections and get their AGGREGATE
        // operationType wiped as a false positive by the cleanup pass.
        // Also true when a dynamic (variable-sourced) collection reference was captured —
        // a real DB call happened, we just couldn't resolve the literal collection name.
        // Also true when this method passes a lambda/method-reference DIRECTLY as an argument
        // to a higher-order method and that lambda's own body itself does real DB work — see
        // hasDirectLambdaDbInteraction below for the deliberately narrow (single-hop) scope.
        node.setHasDbInteraction(!collections.isEmpty()
                || mongoMethodDetector.hasDbInvocations(method)
                || jpaMethodDetector.hasJpaInvocations(method)
                || myBatisMethodDetector.hasMyBatisInvocations(method)
                || redisMethodDetector.hasRedisInvocations(method)
                || cassandraMethodDetector.hasCassandraInvocations(method)
                || elasticsearchMethodDetector.hasElasticsearchInvocations(method)
                || mongoMethodDetector.isBulkCollectorOwnMethod(cls, method)
                || pipelineDetail.hasPipelineInvolvement
                || !dynamicRefs.isEmpty()
                || hasDirectLambdaDbInteraction(method, ctx));

        // From @Value property keys resolved via config files
        if (!cls.valuePropertyKeys.isEmpty() && ctx.configProperties != null && !ctx.configProperties.isEmpty()) {
            for (String key : cls.valuePropertyKeys) {
                String resolved = ctx.configProperties.get(key);
                if (resolved != null && !collections.contains(resolved) && !fieldNameExclusions.contains(resolved)) {
                    String domain = configLoader.detectCollectionDomain(resolved);
                    if (!"Other".equals(domain)) {
                        collections.add(resolved);
                        collDomains.put(resolved, domain);
                        collSources.put(resolved, "VALUE_PROPERTY");
                    }
                }
            }
        }

        // From Environment.getProperty() calls — resolve property key from config
        if (ctx.configProperties != null && !ctx.configProperties.isEmpty()) {
            for (InvocationRef inv : method.invocations) {
                if ("getProperty".equals(inv.methodName())
                        && inv.ownerClass() != null
                        && (inv.ownerClass().endsWith("Environment") || inv.ownerClass().endsWith("ConfigurableEnvironment"))) {
                    for (String arg : inv.stringArgs()) {
                        String resolved = ctx.configProperties.get(arg);
                        if (resolved != null && !collections.contains(resolved) && !fieldNameExclusions.contains(resolved)) {
                            String domain = configLoader.detectCollectionDomain(resolved);
                            if (!"Other".equals(domain)) {
                                collections.add(resolved);
                                collDomains.put(resolved, domain);
                                collSources.put(resolved, "ENV_PROPERTY");
                            }
                        }
                    }
                }
            }
        }

        // From enum/constants class references — resolve GETSTATIC on enum fields to their values
        if (!ctx.enumConstantsMap.isEmpty()) {
            // Check method invocation targets (calls to enum/constants class methods)
            Set<String> constantOwners = new HashSet<>();
            for (InvocationRef inv : method.invocations) {
                if (ctx.enumConstantsMap.containsKey(inv.ownerClass())) {
                    constantOwners.add(inv.ownerClass());
                }
            }
            // Check GETSTATIC field references (direct access to constants fields)
            if (method.staticFieldRefOwners != null) {
                for (String owner : method.staticFieldRefOwners) {
                    if (ctx.enumConstantsMap.containsKey(owner)) {
                        constantOwners.add(owner);
                    }
                }
            }
            for (String owner : constantOwners) {
                for (String val : ctx.enumConstantsMap.get(owner)) {
                    if (!collections.contains(val) && !fieldNameExclusions.contains(val)) {
                        String domain = configLoader.detectCollectionDomain(val);
                        if (!"Other".equals(domain)) {
                            collections.add(val);
                            collDomains.put(val, domain);
                            collSources.put(val, "ENUM_CONSTANT");
                        }
                    }
                }
            }
        }

        // From implicit collection mappings (known cross-JAR patterns like validators, sequence service)
        Map<String, List<Map<String, String>>> implicitMap = configLoader.getImplicitCollections();
        if (implicitMap != null && !implicitMap.isEmpty()) {
            // Check current node: ClassName.methodName
            String nodeKey = cls.simpleName + "." + method.name;
            addImplicitCollections(nodeKey, implicitMap, collections, collDomains, collSources, fieldNameExclusions);
            // Check invocations: if this method calls a known implicit method
            for (InvocationRef inv : method.invocations) {
                String owner = inv.ownerClass();
                if (owner == null || owner.isEmpty()) continue;
                String simpleName = owner.contains(".")
                        ? owner.substring(owner.lastIndexOf('.') + 1) : owner;
                String invKey = simpleName + "." + inv.methodName();
                addImplicitCollections(invKey, implicitMap, collections, collDomains, collSources, fieldNameExclusions);
            }
        }

        // From repository interface invocations — inherit the repo's collection.
        // Handles service.search() → repo.customMethod() patterns not reachable in the call tree,
        // and service.raiseSalary() → repo.bulkUpdate() delegations.
        if (!ctx.repoCollectionMap.isEmpty()) {
            for (InvocationRef inv : method.invocations) {
                String owner = inv.ownerClass();
                if (owner == null || owner.isEmpty()) continue;
                String simpleOwner = owner.contains(".") ? owner.substring(owner.lastIndexOf('.') + 1) : owner;
                String repoColl = ctx.repoCollectionMap.get(simpleOwner);
                if (repoColl == null) repoColl = ctx.repoCollectionMap.get(owner);
                if (repoColl != null && !collections.contains(repoColl) && !fieldNameExclusions.contains(repoColl)) {
                    collections.add(repoColl);
                    collDomains.put(repoColl, configLoader.detectCollectionDomain(repoColl));
                    collSources.put(repoColl, "REPOSITORY_CALL");
                }
            }
        }

        // When MongoTemplate calls detected but collection unresolved (e.g. insertAll(List<T>)
        // with generic type erased), infer from injected repository fields on the enclosing class.
        // e.g. EmployeeService has field EmployeeRepository → "employees"
        // Skipped when we already captured a dynamic reference for this method — a named
        // variable/field source is strictly better information than a repo-field guess, and
        // guessing here would silently overwrite/mask the dynamic ref with an unrelated
        // collection (the same class of bug fixed for the WIP_* domain-filter case).
        if (collections.isEmpty() && dynamicRefs.isEmpty()
                && mongoMethodDetector.hasDbInvocations(method) && !ctx.repoCollectionMap.isEmpty()) {
            for (CallGraphIndex.FieldDIInfo fi : cls.injectedFields.values()) {
                String simpleType = fi.fieldType().contains(".")
                        ? fi.fieldType().substring(fi.fieldType().lastIndexOf('.') + 1) : fi.fieldType();
                String coll = ctx.repoCollectionMap.get(simpleType);
                if (coll == null) coll = ctx.repoCollectionMap.get(fi.fieldType());
                if (coll != null && !fieldNameExclusions.contains(coll)) {
                    collections.add(coll);
                    collDomains.put(coll, configLoader.detectCollectionDomain(coll));
                    collSources.put(coll, "INJECTED_REPO_INFERENCE");
                }
            }
        }

        // Post-filter: when catalog is available, remove STRING_LITERAL-sourced items
        // that are NOT in the live database (sequence names, log strings, etc.)
        if (ctx.mongoCatalogCollections != null && !collections.isEmpty()) {
            List<String> toRemove = new ArrayList<>();
            for (String coll : collections) {
                String source = collSources.get(coll);
                if (!catalogContains(ctx.mongoCatalogCollections, coll)
                        && ("STRING_LITERAL".equals(source) || "FIELD_CONSTANT".equals(source)
                            || "ENUM_CONSTANT".equals(source))) {
                    toRemove.add(coll);
                }
            }
            for (String coll : toRemove) {
                collections.remove(coll);
                collDomains.remove(coll);
                collSources.remove(coll);
            }
        }

        node.setCollectionsAccessed(collections);
        node.setCollectionDomains(collDomains);
        node.setCollectionSources(collSources);
        if (!dynamicRefs.isEmpty()) {
            node.setDynamicCollectionRefs(dynamicRefs);
        }

        // Pipeline-builder-only involvement (no specific WRITE/AGGREGATE op resolved above via a
        // named stage keyword like $out/$merge, e.g. a method that only builds MatchOperation/
        // GroupOperation stages) still counts as an AGGREGATE operation on this node.
        if (pipelineDetail.hasPipelineInvolvement) {
            detectedOpTypes.add("AGGREGATE");
        }

        // Always add all detected operation types to the node's set
        node.getOperationTypes().addAll(detectedOpTypes);
        // Set primary operationType if not already set
        if (node.getOperationType() == null && !detectedOpTypes.isEmpty()) {
            node.setOperationType(pickHighestPriorityOp(detectedOpTypes));
        }

        // Verify collections against live MongoDB catalog (supplementary — not a gate)
        // Uses case-insensitive matching: @Document("clm_child_locks") matches catalog "CLM_CHILD_LOCKS"
        if (!collections.isEmpty()) {
            Map<String, String> verification = new LinkedHashMap<>();
            if (ctx.mongoCatalogCollections != null) {
                for (String coll : collections) {
                    verification.put(coll, catalogContains(ctx.mongoCatalogCollections, coll) ? "VERIFIED" : "NOT_IN_DB");
                }
            } else {
                for (String coll : collections) {
                    verification.put(coll, "NO_CATALOG");
                }
            }
            node.setCollectionVerification(verification);
        }

        // Attach entity field mappings for collections that have them
        Map<String, Map<String, String>> fieldMaps = null;
        for (String coll : collections) {
            Map<String, String> mapping = ctx.collectionFieldMappings.get(coll);
            if (mapping != null && !mapping.isEmpty()) {
                if (fieldMaps == null) fieldMaps = new LinkedHashMap<>();
                fieldMaps.put(coll, mapping);
            }
        }
        if (fieldMaps != null) node.setEntityFieldMappings(fieldMaps);
    }

    /** Add implicit collections from known cross-JAR patterns (validators, sequence service, etc.). */
    private void addImplicitCollections(String key, Map<String, List<Map<String, String>>> implicitMap,
                                         List<String> collections, Map<String, String> collDomains,
                                         Map<String, String> collSources, Set<String> fieldNameExclusions) {
        List<Map<String, String>> mappings = implicitMap.get(key);
        if (mappings == null) return;
        for (Map<String, String> mapping : mappings) {
            String coll = mapping.get("collection");
            String source = mapping.get("source");
            if (coll != null && !collections.contains(coll) && !fieldNameExclusions.contains(coll)) {
                collections.add(coll);
                collDomains.put(coll, configLoader.detectCollectionDomain(coll));
                collSources.put(coll, source != null ? source : "IMPLICIT");
            }
        }
    }

    /** Check if a string literal ends with a non-collection suffix (e.g., _TIMEOUT, _ERROR). */
    private boolean hasNonCollectionSuffix(String literal) {
        String upper = literal.toUpperCase();
        for (String suffix : NON_COLLECTION_SUFFIXES) {
            if (upper.endsWith(suffix)) return true;
        }
        return false;
    }

    /** Build set of strings that are arguments to sequence/log/utility methods (not collections). */
    private Set<String> buildNonCollectionArgs(IndexedMethod method) {
        Set<String> excluded = new HashSet<>();
        for (InvocationRef inv : method.invocations) {
            if (NON_COLLECTION_METHODS.contains(inv.methodName())) {
                for (String arg : inv.stringArgs()) {
                    if (!arg.startsWith("__class:")) excluded.add(arg);
                }
            }
        }
        return excluded;
    }

    /** Case-insensitive check if catalog contains a collection name. */
    private static boolean catalogContains(Set<String> catalog, String collName) {
        if (catalog.contains(collName)) return true;
        return catalog.contains(collName.toUpperCase()) || catalog.contains(collName.toLowerCase());
    }

    /** Pick highest-priority operation type from a set of detected types.
     *  Order must stay in sync with EndpointInfo.opPri(): WRITE > UPDATE > DELETE > UPSERT > AGGREGATE > READ > COUNT */
    private static String pickHighestPriorityOp(Set<String> ops) {
        for (String op : List.of("WRITE", "UPDATE", "DELETE", "UPSERT", "AGGREGATE", "READ", "COUNT")) {
            if (ops.contains(op)) return op;
        }
        return null;
    }

    /**
     * Merge a single dynamic (variable-sourced) detection: attempt one last cheap resolution
     * via ctx.enumConstantsMap for cross-class STATIC_FIELD refs (same-class constants and
     * single-assignment locals were already resolved inline by BytecodeClassParser, so only
     * cross-class constant-holder references reach here unresolved). If that resolves to
     * exactly one literal, promote it into the resolved collections/domains/sources maps —
     * otherwise record it as a genuine dynamic reference.
     */
    private void mergeDynamicResult(CallGraphIndex.DetectedDynamicCollection ddc, ResolutionContext ctx,
                                     List<String> collections, Map<String, String> collDomains,
                                     Map<String, String> collSources, Set<String> fieldNameExclusions,
                                     List<Map<String, Object>> dynamicRefs, Set<String> detectedOpTypes) {
        if (ddc.operationType() != null) detectedOpTypes.add(ddc.operationType());
        String resolved = tryResolveDynamicViaEnumConstants(ddc, ctx);
        // Gate the resolved value through the same "does this actually look like a collection
        // name" check used for every other resolution path (isCollectionName/isLikelyCollectionName)
        // — a resolved static-final-String value could just as easily be an unrelated constant
        // (an error message, a header name, etc.), and this call site has no other content filter.
        if (resolved != null && configLoader.isLikelyCollectionName(resolved)) {
            if (!collections.contains(resolved) && !fieldNameExclusions.contains(resolved)) {
                collections.add(resolved);
                collDomains.put(resolved, configLoader.detectCollectionDomain(resolved));
                collSources.put(resolved, "ENUM_CONSTANT_DYNAMIC_RESOLVED");
            }
        } else {
            dynamicRefs.add(toDynamicRefMap(ddc));
        }
    }

    /** Attempt to resolve a cross-class STATIC_FIELD dynamic reference to its literal value.
     *  Tries the EXACT field first via ctx.fieldConstantsMap (ownerClass -> fieldName -> value,
     *  built for every indexed class) — this is unambiguous regardless of how many other
     *  constants the owner class declares. Falls back to the coarser ctx.enumConstantsMap
     *  (owner class -> ALL its string constants) ONLY when the owner class maps to EXACTLY one
     *  literal value overall — an ambiguous (multi-value) owner with no exact-field match is left
     *  as a dynamic reference rather than guessing which constant applies. */
    private String tryResolveDynamicViaEnumConstants(CallGraphIndex.DetectedDynamicCollection ddc,
                                                       ResolutionContext ctx) {
        if (!"STATIC_FIELD".equals(ddc.varKind())) return null;
        if (ddc.ownerClass() != null && ctx.fieldConstantsMap != null) {
            Map<String, String> byField = ctx.fieldConstantsMap.get(ddc.ownerClass());
            if (byField != null) {
                String exact = byField.get(ddc.variableName());
                if (exact != null) return exact;
            }
        }
        if (ctx.enumConstantsMap == null || ctx.enumConstantsMap.isEmpty() || ddc.ownerClass() == null) return null;
        List<String> values = ctx.enumConstantsMap.get(ddc.ownerClass());
        if (values != null && values.size() == 1) return values.get(0);
        return null;
    }

    /** Build the JSON-serializable shape for a dynamic collection reference (see CallNode.dynamicCollectionRefs). */
    private Map<String, Object> toDynamicRefMap(CallGraphIndex.DetectedDynamicCollection ddc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("variableName", ddc.variableName());
        m.put("varKind", ddc.varKind());
        m.put("pattern", ddc.pattern());
        m.put("source", ddc.source());
        m.put("operationType", ddc.operationType());
        return m;
    }

    /**
     * True when this method invokes a higher-order method with a lambda/method-reference
     * argument (invokedynamic-sourced InvocationRef with isLambdaInvocation()=true), and that
     * lambda's own target method (resolved the same way CallTreeBuilder resolves lambda targets
     * for tree-building) itself performs real DB work.
     *
     * Deliberately scoped to a SINGLE hop: only the DIRECT lambda target method is inspected via
     * mongoMethodDetector.hasDbInvocations/jpaMethodDetector.hasJpaInvocations/collection
     * detection — it does not recurse into what THAT method calls. This covers the concrete bug
     * (a wrapper passing a lambda straight into a higher-order bypass/executor method) without
     * the added complexity/regression risk of a full transitive DB-interaction propagation
     * across arbitrary call depth.
     */
    private boolean hasDirectLambdaDbInteraction(IndexedMethod method, ResolutionContext ctx) {
        for (InvocationRef inv : method.invocations) {
            if (!inv.isLambdaInvocation() || inv.lambdaTargetClass() == null) continue;
            String lambdaTargetCls = inv.lambdaTargetClass();
            String lambdaTargetMtd = inv.lambdaTargetMethod();
            String lambdaTargetDesc = inv.lambdaTargetDescriptor();
            if (lambdaTargetMtd == null || lambdaTargetDesc == null) continue;

            IndexedClass lambdaCls = ctx.classMap.get(lambdaTargetCls);
            if (lambdaCls == null) continue;

            boolean isSyntheticLambda = lambdaTargetMtd.startsWith("lambda$");
            // Synthetic lambda bodies are typically static; method-reference targets can be
            // either — try both key forms the same way CallTreeBuilder's lambda resolution does.
            IndexedMethod lambdaMethod = lambdaCls.methods.get((isSyntheticLambda ? "S:" : "") + lambdaTargetMtd + lambdaTargetDesc);
            if (lambdaMethod == null) {
                lambdaMethod = lambdaCls.methods.get((isSyntheticLambda ? "" : "S:") + lambdaTargetMtd + lambdaTargetDesc);
            }
            if (lambdaMethod == null) continue;

            if (mongoMethodDetector.hasDbInvocations(lambdaMethod)
                    || jpaMethodDetector.hasJpaInvocations(lambdaMethod)
                    || mongoMethodDetector.isBulkCollectorOwnMethod(lambdaCls, lambdaMethod)) {
                return true;
            }
        }
        return false;
    }
}
