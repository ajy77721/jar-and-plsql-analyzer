package com.jaranalyzer.service;

import com.jaranalyzer.service.CallGraphIndex.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Detects Elasticsearch index access from method invocations in bytecode.
 * Analyzes InvocationRefs to find index names from:
 *
 *   A. ElasticsearchRestTemplate / ElasticsearchTemplate / ElasticsearchOperations / Reactive variants
 *   B. ElasticsearchClient (new Java client)
 *
 * Index name extraction:
 *   - From first string arg (direct index-name string)
 *   - From @Document(indexName="X") on the entity type via entityCollectionMap
 */
@Component
class ElasticsearchMethodDetector {

    private static final Logger log = LoggerFactory.getLogger(ElasticsearchMethodDetector.class);

    /** Result of detecting an Elasticsearch index access from a method invocation. */
    record DetectedCollection(String collectionName, String source, String operationType) {}

    // Owner class name patterns for Template / Operations types
    private static final List<String> TEMPLATE_OWNERS = List.of(
            "ElasticsearchRestTemplate", "ElasticsearchTemplate",
            "ElasticsearchOperations", "ReactiveElasticsearchOperations"
    );

    // Owner class name patterns for the new Java client
    private static final List<String> CLIENT_OWNERS = List.of(
            "ElasticsearchClient"
    );

    // Method → operation type mapping
    private static final Map<String, String> METHOD_OP_MAP = Map.ofEntries(
            // WRITE
            Map.entry("index",                "WRITE"),
            Map.entry("save",                 "WRITE"),
            Map.entry("bulkIndex",            "WRITE"),
            // READ
            Map.entry("get",                  "READ"),
            Map.entry("search",               "READ"),
            Map.entry("searchForStream",      "READ"),
            Map.entry("multiGet",             "READ"),
            Map.entry("searchScrollContinue", "READ"),
            Map.entry("count",                "READ"),
            // DELETE
            Map.entry("delete",               "DELETE"),
            Map.entry("bulkDelete",           "DELETE"),
            // UPDATE
            Map.entry("update",               "UPDATE"),
            Map.entry("bulkUpdate",           "UPDATE")
    );

    private static final Set<String> ALL_METHODS = METHOD_OP_MAP.keySet();

    /**
     * Scan all invocations in a method for Elasticsearch index access patterns.
     *
     * @param entityCollectionMap  entity FQN / simple name → index name
     *                             (populated from @Document(indexName="X") on entity classes)
     */
    List<DetectedCollection> detect(IndexedClass cls, IndexedMethod method,
                                    List<InvocationRef> invocations,
                                    Map<String, String> entityCollectionMap) {
        List<DetectedCollection> results = new ArrayList<>();

        for (InvocationRef inv : invocations) {
            String owner = inv.ownerClass();
            String methodName = inv.methodName();
            List<String> stringArgs = inv.stringArgs();

            if (!ALL_METHODS.contains(methodName)) continue;

            boolean isTemplate = ownerMatchesAny(owner, TEMPLATE_OWNERS);
            boolean isClient   = ownerMatchesAny(owner, CLIENT_OWNERS);
            if (!isTemplate && !isClient) continue;

            String opType = METHOD_OP_MAP.get(methodName);
            String source = isClient ? "ELASTICSEARCH_CLIENT" : "ELASTICSEARCH_TEMPLATE";

            // Attempt 1: direct string arg (index name passed explicitly)
            String indexName = firstStringArg(stringArgs);

            // Attempt 2: entity class literal → entityCollectionMap (@Document indexName)
            if (indexName == null && stringArgs != null && !entityCollectionMap.isEmpty()) {
                for (String arg : stringArgs) {
                    if (arg != null && arg.startsWith("__class:")) {
                        String fqn = arg.substring(8);
                        indexName = resolveIndex(fqn, entityCollectionMap);
                        if (indexName != null) break;
                    }
                }
            }

            // Attempt 3: entity class from the enclosing class @Document (for save(entity) patterns)
            if (indexName == null && cls.documentCollection != null) {
                indexName = cls.documentCollection;
            }

            if (indexName == null) {
                indexName = "es:unknown-index";
            }

            results.add(new DetectedCollection(indexName, source, opType));
            log.debug("Elasticsearch detected: index={} op={} owner={} method={}", indexName, opType, owner, methodName);
        }

        return results;
    }

    /**
     * Quick check: does this method invoke any Elasticsearch methods?
     */
    boolean hasElasticsearchInvocations(IndexedMethod method) {
        for (InvocationRef inv : method.invocations) {
            String owner = inv.ownerClass();
            String mn = inv.methodName();
            if (ALL_METHODS.contains(mn)
                    && (ownerMatchesAny(owner, TEMPLATE_OWNERS) || ownerMatchesAny(owner, CLIENT_OWNERS))) {
                return true;
            }
        }
        return false;
    }

    /** Resolve an entity FQN or simple name to an Elasticsearch index via entityCollectionMap. */
    private String resolveIndex(String fqn, Map<String, String> entityCollectionMap) {
        if (fqn == null) return null;
        String index = entityCollectionMap.get(fqn);
        if (index != null) return index;
        int dot = fqn.lastIndexOf('.');
        if (dot >= 0) index = entityCollectionMap.get(fqn.substring(dot + 1));
        return index;
    }

    /** Return first non-blank, non-class string argument. */
    private String firstStringArg(List<String> stringArgs) {
        if (stringArgs == null) return null;
        for (String arg : stringArgs) {
            if (arg != null && !arg.startsWith("__class:") && !arg.isBlank()) return arg;
        }
        return null;
    }

    /** Check if the owner class name ends with any of the given patterns. */
    private boolean ownerMatchesAny(String owner, List<String> patterns) {
        if (owner == null) return false;
        for (String pattern : patterns) {
            if (owner.endsWith(pattern) || owner.endsWith("." + pattern)) return true;
        }
        return false;
    }
}
