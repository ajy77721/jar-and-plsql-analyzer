package com.flowpoc;

import com.flowpoc.ProgressCallback;
import com.flowpoc.analyzer.AnalyzerPipeline;
import com.flowpoc.config.PocConfig;
import com.flowpoc.engine.FlowWalker;
import com.flowpoc.engine.SqlPredicateExtractor;
import com.flowpoc.engine.visitor.CallTreeVisitor;
import com.flowpoc.engine.visitor.MongoOperationVisitor;
import com.flowpoc.engine.visitor.SqlOperationVisitor;
import com.flowpoc.fetch.DataFetcher;
import com.flowpoc.fetch.MongoDataFetcher;
import com.flowpoc.layer2.BeanFactoryLoader;
import com.flowpoc.layer2.CollectingQueryInterceptor;
import com.flowpoc.layer2.DynamicFlowExecutor;
import com.flowpoc.layer2.JarClassLoader;
import com.flowpoc.model.ExtractedQuery;
import com.flowpoc.model.FlowResult;
import com.flowpoc.model.FlowStep;
import com.flowpoc.model.TestDataSet;
import com.flowpoc.report.FlowReporter;
import com.flowpoc.testdata.EntitySchemaBuilder;
import com.flowpoc.testdata.TestDataBuilder;
import com.flowpoc.report.JsonReporter;
import com.flowpoc.report.MarkdownReporter;
import com.mongodb.client.MongoClients;

import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;
import com.analyzer.storage.LocalHandle;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Main orchestrator (Facade pattern): wires engine + analyzers + fetcher + reporter.
 *
 * Typical usage:
 *
 *   PocConfig config = PocConfig.builder()
 *       .analysis(store, ArtifactKey.of("jar", "my-app", "analysis.json"))
 *       .mongo("mongodb://localhost:27017", "mydb")
 *       .sampleSize(10)
 *       .build();
 *
 *   new PocRunner(config).run(System.out);
 */
public class PocRunner {

    private final PocConfig config;

    public PocRunner(PocConfig config) {
        this.config = config;
    }

    /**
     * Run the full pipeline and return results — callers can generate any report format.
     * Populated fields per FlowResult:
     *   - flowSteps  (always)
     *   - optimizations (always, via AnalyzerPipeline)
     *   - testDataSets  (only when MongoDB is configured)
     */
    public List<FlowResult> runAndReturn() throws Exception {
        // 1. Walk call trees
        List<CallTreeVisitor> visitors = new ArrayList<>();
        visitors.add(new MongoOperationVisitor());
        visitors.add(new SqlOperationVisitor(new SqlPredicateExtractor()));

        FlowWalker walker = new FlowWalker(visitors);
        // Pass selectedEndpoints into the walker so it skips non-matching endpoints at parse time.
        // Streamed straight out of the store — analysis documents run to several GB, so this is
        // never read into a byte[] or copied to a temp file.
        List<FlowResult> results;
        try (InputStream in = openAnalysis()) {
            results = walker.walk(in, config.getSelectedEndpoints());
        }

        if (config.getMaxEndpoints() > 0 && results.size() > config.getMaxEndpoints()) {
            results = results.subList(0, config.getMaxEndpoints());
        }

        // 2. Run optimization analyzers
        ProgressCallback cb = config.getProgressCallback();
        AnalyzerPipeline pipeline;
        if (config.getClaudeInvoker() != null) {
            pipeline = AnalyzerPipeline.builder().withMongoDefaultsAndClaude(config.getClaudeInvoker(), cb).build();
        } else if (config.isClaudeEnabled()) {
            pipeline = AnalyzerPipeline.builder().withMongoDefaultsAndClaude(config.getClaudeApiKey(), cb).build();
        } else {
            pipeline = AnalyzerPipeline.builder().withMongoDefaults().build();
        }

        int total = results.size();
        for (int i = 0; i < results.size(); i++) {
            FlowResult r = results.get(i);
            String ep = r.getEndpointMethod() + " " + r.getEndpointPath();
            if (cb != null) cb.onEndpointStart(i + 1, total, ep);
            pipeline.runAndAttach(r);
            if (cb != null) cb.onEndpointDone(i + 1, total, ep, r);
        }

        // 3. Fetch real test data from MongoDB
        if (config.isEnableMongo() && config.getMongoDatabase() != null) {
            try (DataFetcher fetcher = new MongoDataFetcher(
                    MongoClients.create(config.getMongoUri()), config.getMongoDatabase())) {
                for (FlowResult r : results) {
                    fetchAndAttach(r, fetcher);
                }
            }
        }

        // 3b. Generate static edge cases — use entity schema from analysis.json as synthetic sample source
        Map<String, Map<String, Object>> entitySamples;
        try (InputStream in = openAnalysis()) {
            entitySamples = com.flowpoc.testdata.EntitySchemaBuilder.buildCollectionSamples(in);
        }
        for (FlowResult r : results) {
            for (TestDataSet tds : r.getTestDataSets()) {
                if (tds.getTestCases().isEmpty()) {
                    Map<String, Object> sample = entitySamples.get(tds.getTable());
                    TestDataBuilder.appendStaticEdgeCases(tds, tds.getAppliedPredicates(), sample);
                }
            }
        }

        // 4. Layer 2: dynamic execution
        if (config.isLayer2Enabled() && config.getJarKey() != null) {
            var preReadClient = config.isEnableMongo() && config.getMongoUri() != null
                    ? MongoClients.create(config.getMongoUri()) : null;
            // materialize(): JarClassLoader opens the archive as a JarFile, which needs a real
            // seekable file. Documented ArtifactStore escape hatch — zero-copy in local mode, a
            // temp download that close() removes otherwise.
            try (LocalHandle jar = config.getStore().materialize(config.getJarKey())) {
                JarClassLoader jarClassLoader = new JarClassLoader(jar.path().toFile());
                CollectingQueryInterceptor queryInterceptor = new CollectingQueryInterceptor();
                BeanFactoryLoader bfl = new BeanFactoryLoader(
                        jarClassLoader, Collections.emptyList(), queryInterceptor,
                        preReadClient, config.getMongoDatabase());
                DynamicFlowExecutor executor = new DynamicFlowExecutor(bfl, queryInterceptor, config);
                for (FlowResult r : results) {
                    executor.execute(r);
                }
            } catch (Exception ignored) {
            } finally {
                if (preReadClient != null) preReadClient.close();
            }
        }

        return results;
    }

    public void run(OutputStream out) throws Exception {
        List<FlowResult> results = runAndReturn();

        // Write JSON report
        new JsonReporter().write(results, out);

        // Write the Markdown report as an artifact if configured. No directory to create:
        // ArtifactStore.write() materializes any missing parents itself, and on an object store
        // there are no directories to make.
        ArtifactKey reportKey = config.getReportKey();
        if (reportKey != null) {
            try (OutputStream md = config.getStore().write(reportKey)) {
                new MarkdownReporter().write(results, md);
            } catch (Exception ignored) {}
        }
    }

    /** Fresh sequential read of the analysis document. The caller closes it. */
    private InputStream openAnalysis() throws java.io.IOException {
        return config.getStore().read(config.getAnalysisKey());
    }

    private void fetchAndAttach(FlowResult result, DataFetcher fetcher) {
        // Collect all queries in flow order
        List<ExtractedQuery> orderedQueries = result.allSteps().stream()
                .flatMap(s -> s.getQueries().stream())
                .filter(fetcher::supports)
                .collect(Collectors.toList());

        if (orderedQueries.isEmpty()) return;

        // Chain fetch: each step's output feeds the next step's predicates
        List<TestDataSet> chain = fetcher.fetchChain(orderedQueries, config.getSampleSize());
        chain.forEach(result::addTestDataSet);

        // Also back-fill step.queries with sample rows for reporting
        int i = 0;
        outer:
        for (FlowStep step : result.allSteps()) {
            for (ExtractedQuery eq : step.getQueries()) {
                if (i >= chain.size()) break outer;
                if (fetcher.supports(eq)) {
                    eq.setFetchedSample(chain.get(i++).getSampleRows());
                }
            }
        }
    }

    // --- convenience static entry point ---

    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            System.err.println("Usage: PocRunner <data-root> <analysis-key> <mongo-db-name> "
                    + "[mongo-uri] [max-endpoints]");
            System.err.println("  <analysis-key> is '/'-separated and relative to <data-root>, "
                    + "e.g. jar/my-app/analysis.json");
            System.exit(1);
        }
        String dataRoot  = args[0];
        String keyText   = args[1];
        String mongoDb   = args[2];
        String mongoUri  = args.length > 3 ? args[3] : "mongodb://localhost:27017";
        int    maxEp     = args.length > 4 ? Integer.parseInt(args[4]) : 0;

        // The one filesystem reference left in this class, and it is store CONSTRUCTION rather
        // than artifact I/O: a CLI has no Spring context, so the data root arrives as argv and is
        // handed to StorageFactory exactly as StorageConfig does for the web app. Every read and
        // write below goes through the resulting ArtifactStore.
        ArtifactStore store = com.analyzer.storage.StorageFactory.create(
                com.analyzer.storage.StorageFactory.settingsFor(
                        System.getProperty("app.storage.mode"), java.nio.file.Path.of(dataRoot)));

        PocConfig config = PocConfig.builder()
                .analysis(store, keyOf(keyText))
                .mongo(mongoUri, mongoDb)
                .sampleSize(10)
                .maxEndpoints(maxEp)
                .build();

        new PocRunner(config).run(System.out);
    }

    /**
     * Parses a '/'-separated key. Rejects "." and ".." segments outright rather than normalizing
     * them, so a key can only ever name something under the data root.
     */
    static ArtifactKey keyOf(String text) {
        List<String> segs = new ArrayList<>();
        for (String raw : text.replace('\\', '/').split("/")) {
            if (raw.isBlank()) continue;
            if (raw.equals(".") || raw.equals("..")) {
                throw new IllegalArgumentException("Key escapes the data root: " + text);
            }
            segs.add(raw);
        }
        if (segs.isEmpty()) throw new IllegalArgumentException("Key is empty");
        return ArtifactKey.of(segs.toArray(new String[0]));
    }
}
