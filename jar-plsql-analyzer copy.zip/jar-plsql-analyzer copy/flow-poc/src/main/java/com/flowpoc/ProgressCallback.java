package com.flowpoc;

import com.flowpoc.model.FlowResult;

/**
 * Optional live-progress listener for a PocRunner run.
 * All methods default to no-ops — implement only what you need.
 */
public interface ProgressCallback {

    /** Called just before a single endpoint's pipeline starts. */
    default void onEndpointStart(int index, int total, String endpoint) {}

    /** Called after a single endpoint's pipeline (static + Claude + fetch) completes. */
    default void onEndpointDone(int index, int total, String endpoint, FlowResult result) {}

    /** Called once per endpoint after the static analyzers finish and before Claude starts,
     *  giving the total number of call-tree nodes Claude will process for this endpoint. */
    default void onClaudePlanReady(String endpoint, int totalNodes) {}

    /** Called just before Claude enriches a specific node (chunk 1 only). */
    default void onClaudeNodeStart(String endpoint, String node, int nodeIndex, int totalNodes) {}

    /** Called after all chunks for a node have been sent to Claude. */
    default void onClaudeNodeDone(String endpoint, String node, int enrichedFindings) {}
}
