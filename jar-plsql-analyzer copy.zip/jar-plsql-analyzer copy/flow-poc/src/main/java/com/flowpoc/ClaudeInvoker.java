package com.flowpoc;

/**
 * Abstraction for calling Claude — decouples ClaudeFlowAnalyzer from any specific
 * transport (HTTP API vs CLI process).  The unified-web layer injects a CLI-based
 * implementation backed by the existing ClaudeProcessRunner bean.
 */
@FunctionalInterface
public interface ClaudeInvoker {
    /**
     * Send a prompt and return Claude's response text.
     * @return response text, or null if the call failed / timed out.
     */
    String invoke(String prompt);
}
