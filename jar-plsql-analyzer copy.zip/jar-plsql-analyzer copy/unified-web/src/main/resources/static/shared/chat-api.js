/**
 * ChatAPI — REST client for chat endpoints.
 */
const ChatAPI = {
    async createSession(name, scope, scopeContext, chatType) {
        const res = await fetch('/api/chat/sessions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, scope, scopeContext, chatType: chatType || 'classic' })
        });
        return res.json();
    },

    async listSessions(scope, chatType) {
        const params = new URLSearchParams();
        if (scope) params.set('scope', scope);
        if (chatType) params.set('chatType', chatType);
        const qs = params.toString();
        const res = await fetch('/api/chat/sessions' + (qs ? '?' + qs : ''));
        if (!res.ok) return [];
        return res.json();
    },

    async getSession(id) {
        const res = await fetch('/api/chat/sessions/' + encodeURIComponent(id));
        if (!res.ok) return null;
        return res.json();
    },

    /**
     * One backward page of a session's transcript (Q67).
     *
     * `before` is the oldest `seq` already on screen, so the next call returns the messages just
     * above it — the cursor is the server's, echoed back, never computed here.
     *
     * @param opts {before, limit, q}
     */
    async getMessages(id, opts) {
        var o = opts || {};
        var params = new URLSearchParams();
        params.set('sort', 'SEQ_DESC');
        if (o.limit) params.set('limit', o.limit);
        if (o.before !== null && o.before !== undefined) params.set('before', o.before);
        if (o.q) params.set('q', o.q);
        const res = await fetch('/api/chat/sessions/' + encodeURIComponent(id)
            + '/messages?' + params.toString());
        if (!res.ok) return null;
        // Through the shim, so a server that has not been updated (a bare array) still renders.
        return PA.normalizePage(await res.json());
    },

    async deleteSession(id) {
        const res = await fetch('/api/chat/sessions/' + encodeURIComponent(id), { method: 'DELETE' });
        return res.json();
    },

    async sendMessage(sessionId, message, pageContext) {
        const payload = { message };
        if (pageContext) payload.pageContext = pageContext;
        const res = await fetch('/api/chat/sessions/' + encodeURIComponent(sessionId) + '/messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return res.json();
    },

    async readFile(sessionId, path) {
        const res = await fetch('/api/chat/files/read', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId, path })
        });
        return res.json();
    },

    async writeFile(sessionId, path, content) {
        const res = await fetch('/api/chat/files/write', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId, path, content })
        });
        return res.json();
    },

    getReportUrl(sessionId) {
        return '/api/chat/sessions/' + encodeURIComponent(sessionId) + '/report';
    }
};
