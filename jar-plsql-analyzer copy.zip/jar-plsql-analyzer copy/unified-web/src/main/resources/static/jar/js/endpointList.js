/**
 * Endpoint list panel — left side of the Endpoint Flows tab.
 */
window.JA = window.JA || {};

JA.endpointList = {

    render(endpoints) {
        const container = document.getElementById('endpoint-list');
        if (!endpoints || endpoints.length === 0) {
            container.innerHTML = '<p class="empty-state" style="padding:20px">No endpoints found in this JAR</p>';
            return;
        }

        // Stamp original index on each endpoint so sorting/filtering doesn't break call tree fetch
        endpoints.forEach((ep, i) => { if (ep._origIdx == null) ep._origIdx = i; });
        this._endpoints = endpoints;
        this._renderFiltered(endpoints, container, '');
    },

    filterEndpoints(query) {
        const container = document.getElementById('endpoint-list');
        // SearchQuery.norm rather than a hand-rolled `.toLowerCase().trim()`. This is a
        // consistency change only, and the limit of it is worth stating: the padding marker
        // already worked here, because the delegated listener in shared/ui-busy.js marks any
        // text-or-search input in the capture phase regardless of what the filter code calls.
        // What this fixes is that normalisation was defined in two places, so a future change to
        // what "normalised" means would have silently missed this box.
        const q = (window.SearchQuery ? SearchQuery.norm(query) : (query || '').toLowerCase().trim());
        // A new filter starts capped again: "show all" applies to the list you asked for, not
        // permanently, or one click would make every later search slow.
        this._showAll = false;
        this._renderFiltered(this._endpoints || [], container, q);
    },

    /**
     * Rows painted in one pass.
     *
     * <p>This list had no limit at all: every endpoint in the JAR became a card, and the JARs this
     * tool is aimed at have thousands. The cap and its disclosure follow `cross-ref.js`, which
     * already does exactly this ("Showing 200 of N — type to narrow") — same wording, so the two
     * lists behave alike.
     *
     * <p>"Show all" is offered rather than only a filter, because a cap you cannot lift turns a
     * slow screen into a screen that silently lies about how many endpoints exist — the defect
     * recorded in PLAN-12 §4.6.
     */
    _cap: 200,

    /** Set by "Show all" for the current render only; reset by any new filter. */
    _showAll: false,

    showAll() {
        this._showAll = true;
        const container = document.getElementById('endpoint-list');
        const inp = container && container.querySelector('.endpoint-search');
        this._renderFiltered(this._endpoints || [], container,
            (inp && (window.SearchQuery ? SearchQuery.norm(inp.value)
                                        : inp.value.toLowerCase().trim())) || '');
    },

    _renderFiltered(endpoints, container, query) {
        // Group by controller
        const grouped = {};
        for (const ep of endpoints) {
            const key = ep.controllerSimpleName || ep.controllerClass;
            (grouped[key] = grouped[key] || []).push(ep);
        }

        let html = `<div style="padding:0 0 12px 0">
            <input type="text" class="endpoint-search" placeholder="Filter endpoints..."
                   oninput="JA.endpointList.filterEndpoints(this.value)" value="${JA.utils.escapeHtml(query)}">
        </div>`;
        let count = 0;

        for (const [ctrl, eps] of Object.entries(grouped)) {
            const filtered = query
                ? eps.filter(ep => {
                    const text = (ep.httpMethod + ' ' + ep.fullPath + ' ' + ep.methodName + ' ' + ctrl).toLowerCase();
                    return text.includes(query);
                })
                : eps;
            if (filtered.length === 0) continue;

            html += `<div style="margin-bottom:16px">
                <div style="font-weight:600;font-size:13px;margin-bottom:6px;color:var(--text-muted)">${JA.utils.escapeHtml(ctrl)} <span style="font-weight:400;font-size:11px">(${filtered.length})</span></div>`;

            // The group header above always shows the TRUE count; only the cards are windowed.
            const visible = this._showAll ? filtered : filtered.slice(0, Math.max(0, this._cap - count));
            for (const ep of visible) {
                const params = (ep.parameters || []).map(p => p.type).join(', ');
                const origIdx = ep._origIdx != null ? ep._origIdx : endpoints.indexOf(ep);
                html += `
                    <div class="endpoint-card" data-idx="${origIdx}" onclick="JA.endpointList.select(this)">
                        <div>
                            <span class="endpoint-method method-${ep.httpMethod}">${ep.httpMethod}</span>
                            <span class="endpoint-path">${JA.utils.escapeHtml(ep.fullPath || '/')}</span>
                        </div>
                        <div class="endpoint-detail">
                            ${JA.utils.escapeHtml(ep.methodName)}(${JA.utils.escapeHtml(params)})
                            &rarr; ${JA.utils.escapeHtml(ep.returnType)}
                        </div>
                    </div>`;
                count++;
            }
            html += '</div>';
        }

        if (count === 0 && query) {
            html += '<p class="empty-state" style="padding:20px">No endpoints match filter</p>';
        }

        // Total across every group, so the figure is the truth and not the windowed count.
        let matched = 0;
        for (const eps of Object.values(grouped)) {
            matched += query
                ? eps.filter(ep => ((ep.httpMethod + ' ' + ep.fullPath + ' ' + ep.methodName + ' '
                        + (ep.controllerSimpleName || ep.controllerClass)).toLowerCase()).includes(query)).length
                : eps.length;
        }
        if (matched > count) {
            html += `<div style="padding:8px 12px;font-size:.75rem;color:var(--text-muted);text-align:center">`
                + `Showing ${count} of ${matched} \u2014 type to narrow, or `
                + `<a href="#" onclick="event.preventDefault();JA.endpointList.showAll()">show all</a></div>`;
        }

        container.innerHTML = html;
        const inp = container.querySelector('.endpoint-search');
        if (inp && query !== undefined) {
            inp.focus();
            inp.setSelectionRange(inp.value.length, inp.value.length);
        }
    },

    async select(el) {
        // Stale-response guard (§B5): the .active card is set synchronously but the graph is
        // painted after a fetch, so clicking card A then card B could leave B highlighted while
        // #graph-container shows A's call tree.
        const isCurrent = UIBusy.seq(JA.endpointList, '_selectSeq');

        // Deselect all
        document.querySelectorAll('.endpoint-card').forEach(c => c.classList.remove('active'));
        el.classList.add('active');

        const idx = parseInt(el.dataset.idx, 10);
        const analysis = JA.app.currentAnalysis;
        if (!analysis || !analysis.endpoints[idx]) return;

        const endpoint = analysis.endpoints[idx];

        if (!endpoint.callTree) {
            document.getElementById('graph-container').innerHTML =
                '<p class="graph-placeholder">Loading call tree...</p>';
            try {
                const jarId = JA.app.currentJarId;
                const version = JA.app._currentVersion || undefined;
                const tree = await JA.api.getCallTree(jarId, idx, version);
                if (!isCurrent()) return;
                endpoint.callTree = tree;
            } catch (e) {
                if (!isCurrent()) return;
                document.getElementById('graph-container').innerHTML =
                    '<p class="graph-placeholder">Failed to load call tree: ' + JA.utils.escapeHtml(e.message) + '</p>';
                return;
            }
        }
        if (!isCurrent()) return;

        if (endpoint.callTree) {
            JA.callGraph.render(endpoint.callTree, 'graph-container', endpoint);
        } else {
            document.getElementById('graph-container').innerHTML =
                '<p class="graph-placeholder">No call tree data for this endpoint</p>';
            const bar = document.getElementById('graph-breadcrumb-bar');
            if (bar) bar.style.display = 'none';
        }
    }
};
