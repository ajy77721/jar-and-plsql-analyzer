/**
 * JAR Dashboard — overview of all analyzed JARs with stats and Claude status.
 * Shown in the main content area when no JAR is selected.
 */
window.JA = window.JA || {};

JA.dashboard = {

    render(jars) {
        const container = document.getElementById('dashboard-content');
        if (!container) return;
        if (!jars || !jars.length) {
            container.innerHTML = this._renderEmpty();
            return;
        }
        container.innerHTML = this._renderDashboard(jars);
    },

    _renderEmpty() {
        return `<div class="dash-empty">
            <p>No JARs analyzed yet. Upload a JAR to get started.</p>
        </div>`;
    },

    _renderDashboard(jars) {
        const esc = JA.utils.escapeHtml;

        // Aggregate stats
        let totalClasses = 0, totalEndpoints = 0, totalSize = 0;
        let claudeRunning = 0, claudeComplete = 0;
        for (const j of jars) {
            totalClasses += j.totalClasses || 0;
            totalEndpoints += j.totalEndpoints || 0;
            totalSize += j.jarSize || 0;
            if (j.claudeStatus === 'RUNNING') claudeRunning++;
            if (j.claudeStatus === 'COMPLETE') claudeComplete++;
        }

        let html = '<div class="dash-page">';

        // Stats bar
        html += '<div class="dash-stats">';
        html += this._stat(jars.length, 'JARs');
        html += this._stat(totalClasses, 'Classes');
        html += this._stat(totalEndpoints, 'Endpoints');
        html += this._stat(JA.utils.formatSize(totalSize), 'Total Size');
        if (claudeRunning > 0) html += this._stat(claudeRunning, 'Claude Running', 'dash-stat-running');
        if (claudeComplete > 0) html += this._stat(claudeComplete, 'Claude Done', 'dash-stat-ok');
        html += '</div>';

        // Actions
        html += '<div class="dash-actions">';
        html += `<button class="btn-sm" onclick="JA.sessions.show()">Claude Sessions</button>`;
        html += '</div>';

        // JAR cards
        html += '<div class="dash-jars">';
        for (const j of jars) {
            html += this._renderJarCard(j, esc);
        }
        html += '</div>';

        // Claude Usage Stats — loaded async after render
        html += '<div id="dash-claude-usage-wrap" style="margin-top:20px"></div>';

        html += '</div>';

        // Fetch and render Claude stats after dashboard is in DOM
        setTimeout(() => this._loadClaudeStats(jars), 100);

        return html;
    },

    async _loadClaudeStats(jars) {
        const wrap = document.getElementById('dash-claude-usage-wrap');
        if (!wrap) return;
        wrap.innerHTML = '<div style="color:var(--text-muted);font-size:12px;padding:8px 0">Loading Claude stats…</div>';

        try {
            const results = await Promise.allSettled(
                jars.map(j => JA.api.getClaudeStats(JA.app._jarName(j.id)).then(s => ({ jar: j, stats: s })))
            );

            let totalCalls = 0, totalSessions = 0, totalPromptKb = 0, totalResponseKb = 0;
            let totalErrors = 0, totalDurMs = 0, durCount = 0;
            const allSessions = [];

            for (const r of results) {
                if (r.status !== 'fulfilled' || !r.value.stats) continue;
                const s = r.value.stats;
                const jarName = r.value.jar.projectName || r.value.jar.jarName || r.value.jar.id;
                totalCalls      += s.totalCalls         || 0;
                totalSessions   += s.sessionCount       || 0;
                totalPromptKb   += s.totalPromptSizeKb  || 0;
                totalResponseKb += s.totalResponseSizeKb|| 0;
                totalErrors     += s.errorCount         || 0;
                if (s.avgDurationMs) { totalDurMs += s.avgDurationMs; durCount++; }
                if (s.sessions) {
                    for (const sess of s.sessions) allSessions.push({ _jarName: jarName, ...sess });
                }
            }

            if (totalCalls === 0) { wrap.innerHTML = ''; return; }

            const avgDurMs = durCount > 0 ? Math.round(totalDurMs / durCount) : 0;
            const esc = JA.utils.escapeHtml;

            // Store for modal reuse
            JA.dashboard._claudeStatsCache = { totalCalls, totalSessions, avgDurMs, totalPromptKb, totalResponseKb, totalErrors, allSessions };

            // Compact summary strip with "View Details" button
            const errBadge = totalErrors > 0
                ? `<span style="background:var(--badge-red-bg);color:var(--badge-red);padding:1px 8px;border-radius:var(--radius-sm);font-weight:700">${totalErrors} errors</span>`
                : '';
            wrap.innerHTML =
                '<div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:10px 14px;background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius-md);border-left:3px solid var(--accent-hover)">' +
                '<span class="claude-badge" style="background:var(--accent-hover)">USAGE</span>' +
                '<span style="font-size:13px;font-weight:700;color:var(--text)">Claude API Statistics</span>' +
                '<span style="font-size:12px;color:var(--text-muted)">' + totalCalls + ' calls · ' + totalSessions + ' sessions · ' + JA.summary._formatSizeKb(totalPromptKb) + ' prompt</span>' +
                (errBadge ? errBadge : '') +
                '<button onclick="JA.dashboard._openStatsModal()" style="margin-left:auto;padding:4px 14px;font-size:12px;font-weight:600;background:var(--accent-hover);color:var(--text-inverse);border:none;border-radius:var(--radius);cursor:pointer">View Details</button>' +
                '</div>';
        } catch (e) {
            wrap.innerHTML = '';
        }
    },

    _openStatsModal() {
        const d = JA.dashboard._claudeStatsCache;
        if (!d) return;
        const esc = JA.utils.escapeHtml;

        // Remove stale modal
        const old = document.getElementById('claudeStatsModal');
        if (old) old.remove();

        const el = document.createElement('div');
        el.id = 'claudeStatsModal';
        el.style.cssText = 'position:fixed;inset:0;z-index:19000;background:var(--bg-overlay);backdrop-filter:blur(2px);display:flex;align-items:center;justify-content:center;padding:16px';
        el.addEventListener('click', e => { if (e.target === el) el.remove(); });

        // KPI cards
        // bg MUST be the tinted --badge-*-bg token and accent the saturated --badge-* token.
        // Previously several cards used the same solid token for both, e.g. background var(--blue)
        // with color var(--blue) — blue text on blue, i.e. an unreadable solid block. The paired
        // badge tokens are designed for exactly this and stay legible in light and dark.
        const cards = [
            { label: 'Total API Calls',      value: d.totalCalls,                              bg: 'var(--badge-blue-bg)',   accent: 'var(--badge-blue)' },
            { label: 'Total Sessions',       value: d.totalSessions,                           bg: 'var(--badge-green-bg)',  accent: 'var(--badge-green)' },
            { label: 'Avg Call Duration',    value: JA.summary._formatDuration(d.avgDurMs),    bg: 'var(--badge-teal-bg)',   accent: 'var(--badge-teal)' },
            { label: 'Total Prompt Size',    value: JA.summary._formatSizeKb(d.totalPromptKb), bg: 'var(--badge-purple-bg)', accent: 'var(--badge-purple)' },
            { label: 'Total Response Size',  value: JA.summary._formatSizeKb(d.totalResponseKb), bg: 'var(--badge-orange-bg)', accent: 'var(--badge-orange)' },
            { label: 'Errors',               value: d.totalErrors,
              bg: d.totalErrors > 0 ? 'var(--badge-red-bg)' : 'var(--badge-gray-bg)',
              accent: d.totalErrors > 0 ? 'var(--badge-red)' : 'var(--badge-gray)' },
        ];
        let kpiHtml = '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">';
        for (const c of cards) {
            kpiHtml += `<div style="flex:1;min-width:110px;background:${c.bg};border-radius:var(--radius-md);padding:14px 16px;border:1px solid var(--border)">` +
                `<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:${c.accent};margin-bottom:4px">${esc(c.label)}</div>` +
                `<div style="font-size:22px;font-weight:700;color:${c.accent}">${esc(String(c.value))}</div>` +
                `</div>`;
        }
        kpiHtml += '</div>';

        // Sessions table
        let tableHtml = '';
        if (d.allSessions.length) {
            const sorted = [...d.allSessions].sort((a, b) => (b.startedAt || '').localeCompare(a.startedAt || ''));
            // Tint background + saturated foreground, never two saturated tokens together.
            const typeColors = {
                CORRECT: { bg: 'var(--badge-blue-bg)',   fg: 'var(--badge-blue)' },
                ENRICH:  { bg: 'var(--badge-green-bg)',  fg: 'var(--badge-green)' },
                RESCAN:  { bg: 'var(--badge-purple-bg)', fg: 'var(--badge-purple)' },
                VERIFY:  { bg: 'var(--badge-teal-bg)',   fg: 'var(--badge-teal)' }
            };
            tableHtml = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:12px">';
            tableHtml += '<thead><tr style="background:var(--sidebar-bg)">';
            for (const h of ['JAR', 'Session ID', 'Type', 'Calls', 'Duration', 'Started', 'Status']) {
                tableHtml += `<th style="padding:8px 12px;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);border-bottom:1px solid var(--sidebar-border);white-space:nowrap">${h}</th>`;
            }
            tableHtml += '</tr></thead><tbody>';
            for (let i = 0; i < sorted.length; i++) {
                const s = sorted[i];
                const sid = esc(s.sessionId || '');
                const shortSid = sid.length > 12 ? sid.substring(0, 12) + '…' : sid;
                const dur = JA.summary._formatDuration(s.durationMs);
                const started = JA.summary._formatShortDate(s.startedAt);
                const hasEnd = !!s.endedAt;
                const rowBg = i % 2 === 0 ? 'var(--sidebar-bg)' : 'var(--sidebar-bg)';
                const typeKey = (s.sessionType || '').toUpperCase();
                const tc = typeColors[typeKey] || { bg: 'var(--sidebar-bg)', fg: 'var(--text-muted)' };
                // Paired tint + ink. Previously bg and fg were both --green
                // (green-on-green, 1:1) for the running state.
                const statusBg = hasEnd ? 'var(--badge-green-bg)' : 'var(--badge-blue-bg)';
                const statusFg = hasEnd ? 'var(--badge-green)'    : 'var(--badge-blue)';
                tableHtml += `<tr style="background:${rowBg}">`;
                tableHtml += `<td style="padding:8px 12px;color: var(--text-secondary);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-bottom:1px solid var(--sidebar-border)" title="${esc(s._jarName)}">${esc(s._jarName)}</td>`;
                tableHtml += `<td style="padding:8px 12px;color:var(--text-muted);font-family:monospace;border-bottom:1px solid var(--sidebar-border)" title="${sid}">${shortSid}</td>`;
                tableHtml += `<td style="padding:8px 12px;border-bottom:1px solid var(--sidebar-border)"><span style="background:${tc.bg};color:${tc.fg};padding:2px 8px;border-radius:var(--radius-sm);font-size:10px;font-weight:700">${esc(s.sessionType || '-')}</span></td>`;
                tableHtml += `<td style="padding:8px 12px;color:var(--text);font-weight:600;text-align:right;border-bottom:1px solid var(--sidebar-border)">${s.callCount || 0}</td>`;
                tableHtml += `<td style="padding:8px 12px;color: var(--text-secondary);border-bottom:1px solid var(--sidebar-border)">${dur}</td>`;
                tableHtml += `<td style="padding:8px 12px;color:var(--text-muted);white-space:nowrap;border-bottom:1px solid var(--sidebar-border)">${started}</td>`;
                tableHtml += `<td style="padding:8px 12px;border-bottom:1px solid var(--sidebar-border)"><span style="background:${statusBg};color:${statusFg};padding:2px 8px;border-radius:var(--radius-sm);font-size:10px;font-weight:700">${hasEnd ? 'OK' : 'Running'}</span></td>`;
                tableHtml += '</tr>';
            }
            tableHtml += '</tbody></table></div>';
        }

        el.innerHTML =
            '<div style="background:var(--sidebar-bg);border-radius:var(--radius-xl);width:900px;max-width:96vw;max-height:88vh;display:flex;flex-direction:column;box-shadow: var(--shadow-lg);border:1px solid var(--sidebar-border)">' +
            '  <div style="display:flex;align-items:center;padding:14px 20px;border-bottom:1px solid var(--sidebar-border)">' +
            '    <span class="claude-badge" style="background:var(--accent-hover);margin-right:10px">USAGE</span>' +
            '    <span style="flex:1;font-size:14px;font-weight:700;color:var(--text)">Claude API Call Statistics</span>' +
            '    <button onclick="document.getElementById(\'claudeStatsModal\').remove()" style="background:none;border:none;color:var(--text-muted);font-size:18px;cursor:pointer;padding:0 4px;line-height:1">&times;</button>' +
            '  </div>' +
            '  <div style="padding:20px;overflow-y:auto">' +
            kpiHtml + tableHtml +
            '  </div>' +
            '</div>';

        document.body.appendChild(el);
    },

    _usageCard(label, value, isError) {
        const esc = JA.utils.escapeHtml;
        const valCls = isError ? 'value error' : 'value';
        return '<div class="claude-usage-card"><div class="label">' + esc(label) + '</div><div class="' + valCls + '">' + esc(String(value)) + '</div></div>';
    },

    _stat(num, label, cls) {
        return `<div class="dash-stat-card ${cls || ''}">
            <div class="dash-stat-num">${num}</div>
            <div class="dash-stat-lbl">${label}</div>
        </div>`;
    },

    _renderJarCard(j, esc) {
        const id = j.id;
        const safeId = (id || '').replace(/'/g, "\\'");
        const claudeStatus = j.claudeStatus || 'IDLE';
        const claudeCls = 'dash-claude-' + claudeStatus.toLowerCase();

        let html = `<div class="dash-jar-card" onclick="JA.app.selectJar('${safeId}')">`;

        // Header
        html += '<div class="dash-jar-header">';
        html += `<span class="dash-jar-name">${esc(j.projectName || j.jarName || id)}</span>`;
        if (claudeStatus !== 'IDLE') {
            html += `<span class="dash-claude-badge ${claudeCls}">${esc(claudeStatus)}</span>`;
        }
        if (j.analysisMode === 'CORRECTED') {
            const iter = j.claudeIteration || '';
            const iterLabel = iter > 1 ? ' (iter ' + iter + ')' : '';
            html += '<span class="jar-mode-badge jar-mode-corrected">CORRECTED' + iterLabel + '</span>';
        }
        html += '</div>';

        // Stats
        html += '<div class="dash-jar-stats">';
        html += `<span>${j.totalClasses || 0} classes</span>`;
        html += `<span>${j.totalEndpoints || 0} endpoints</span>`;
        if (j.jarSize) html += `<span>${JA.utils.formatSize(j.jarSize)}</span>`;
        if (j.hasConnections) html += `<span class="dash-conn-badge" title="DB connections found in config">🔗 Connections</span>`;
        html += '</div>';

        // Claude progress
        if (claudeStatus === 'RUNNING' && j.claudeTotal > 0) {
            const pct = Math.round((j.claudeCompleted / j.claudeTotal) * 100);
            html += '<div class="dash-jar-progress">';
            html += `<div class="dash-progress-bar"><div class="dash-progress-fill" style="width:${pct}%"></div></div>`;
            html += `<span class="dash-progress-text">${j.claudeCompleted}/${j.claudeTotal} (${pct}%)</span>`;
            html += '</div>';
        }

        // Date
        if (j.analyzedAt) {
            html += `<div class="dash-jar-date">${this._formatDate(j.analyzedAt)}</div>`;
        }

        // Actions
        html += '<div class="dash-jar-actions">';
        html += `<button class="btn-sm btn-explore" onclick="JA.app.selectJar('${safeId}');event.stopPropagation()">Open</button>`;
        // §B4: both start a request, so the card's button is disabled until it settles. The
        // stopPropagation stays first so the card's own onclick (selectJar) never also fires.
        html += `<button class="btn-sm" onclick="event.stopPropagation();UIBusy.run(this, function(){ return JA.dashboard.triggerClaude('${safeId}'); })">Claude</button>`;
        html += `<button class="btn-sm" onclick="event.stopPropagation();UIBusy.run(this, function(){ return JA.app.deleteJar('${safeId}'); })" style="color:var(--red)">Delete</button>`;
        html += '</div>';

        html += '</div>';
        return html;
    },

    async triggerClaude(jarId) {
        // Re-entry guard as well as the element guard: the card is re-rendered by loadJars, so the
        // node that was disabled may be replaced while the confirm dialog is still open.
        if (this._starting.has(jarId)) return;
        this._starting.add(jarId);
        try {
            await this._triggerClaudeInner(jarId);
        } finally {
            this._starting.delete(jarId);
        }
    },

    /** jar ids with a Claude scan start in flight — see triggerClaude */
    _starting: new Set(),

    async _triggerClaudeInner(jarId) {
        // Check if a scan is already running for this JAR
        if (!(await JA.app._confirmScanOverride(jarId))) return;

        const confirmed = await JA.utils.confirm({
            title: 'Full Claude Correction Scan',
            message: `<p>Run full Claude scan on <strong>${JA.utils.escapeHtml(jarId)}</strong>?</p>`
                + `<p>Claude will verify each endpoint's collections and operation types `
                + `and save corrected data separately.</p>`
                + `<p>The static version is always preserved. You can switch between versions at any time.</p>`,
            confirmLabel: 'Start Full Scan',
            confirmClass: 'confirm-btn-claude'
        });
        if (!confirmed) return;

        try {
            const j = (JA.app.jars || []).find(j => j.id === jarId);
            const name = j ? (j.projectName || j.jarName || jarId) : jarId;
            const result = await JA.api.claudeFullScan(jarId, false);
            JA.toast?.success('Full scan started for ' + name + ' — ' + result.totalEndpoints + ' endpoints queued');
        } catch (e) {
            const j = (JA.app.jars || []).find(j => j.id === jarId);
            const name = j ? (j.projectName || j.jarName || jarId) : jarId;
            JA.toast?.error('Failed to start scan for ' + name + ': ' + e.message);
        }
    },

    _formatDate(isoStr) {
        if (!isoStr) return '';
        try {
            const d = new Date(isoStr);
            if (isNaN(d.getTime())) return '';
            return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
                + ' ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
        } catch (e) { return ''; }
    }
};
