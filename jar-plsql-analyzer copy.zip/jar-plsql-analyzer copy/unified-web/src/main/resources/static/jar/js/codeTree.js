/**
 * Code Structure tab — lazy-rendered tree.
 * Only package+class headers are rendered initially.
 * Class contents (fields/methods) render on expand.
 * Method invocations render on expand.
 * Keeps DOM small even with 8000+ classes.
 */
window.JA = window.JA || {};

JA.codeTree = {

    _classes: [],       // full class data (stored for lazy render)
    _history: [],
    _historyIndex: -1,
    _viewMode: 'package', // 'package' | 'project' | 'visual'

    _loaded: false,
    _resources: [],
    _resourcesLoaded: false,
    _bundledJars: [],
    _bundledJarsLoaded: false,
    _jarDepMap: {},
    _jarDepMapLoaded: false,

    /* ---- public API ---- */

    setLazy() {
        this._classes = [];
        this._loaded = false;
        this._resources = [];
        this._resourcesLoaded = false;
        this._bundledJars = [];
        this._bundledJarsLoaded = false;
        this._jarDepMap = {};
        this._jarDepMapLoaded = false;
        const container = document.getElementById('class-tree');
        if (container) container.innerHTML = '<p style="padding:20px;color:var(--text-muted,var(--text-muted))">Switch to Code Structure tab to load classes</p>';
    },

    /** Rows per class-tree request. Matches the endpoint's default (PLAN-08 §3.2: 200 for trees). */
    _pageSize: 200,

    /**
     * Loads the class tree a page at a time (Q40 / L1).
     *
     * <p>Every page is appended and the tree is rendered once, at the end. That is deliberate: the
     * three view modes, the JAR-source filter, and cross-tab navigation (`findAndHighlight`, used
     * when the Endpoints and Call Graph tabs jump to a class) all read the whole `_classes` array,
     * and a class that had not been paged in yet would simply not be found. Paging still earns its
     * keep — the response no longer carries `methodSummaries` (475 KB of the 656 KB measured here,
     * read by nobody) and no single response can be unbounded, which is what a jar with the 8 000+
     * classes this file was written for would otherwise produce.
     */
    async loadAndRender() {
        if (this._loaded) return;
        const container = document.getElementById('class-tree');
        if (container) container.innerHTML = '<p style="padding:20px;color:var(--text-muted,var(--text-muted))">Loading code structure...</p>';
        try {
            const jarId = JA.app.currentJarId;
            const version = JA.app._currentVersion || undefined;
            const classTree = await this._fetchAllClassPages(jarId, version, container);
            this.render(classTree);
            this._loaded = true;
        } catch (e) {
            console.error('Failed to load class tree:', e);
            if (container) container.innerHTML = '<p style="padding:20px;color:var(--red)">Failed to load code structure: ' + (e.message || e) + '</p>';
        }
        this._loadResources();
        this._loadBundledJars();
        this._loadJarDepMap();
    },

    /**
     * Walks the whole cursor chain, with a progress line so a large jar does not look hung.
     *
     * <p>Falls back to the unpaged endpoint if the paged one is unavailable — the shim
     * (`PA.normalizePage`) already tolerates a bare array, so an older server answers correctly
     * without this file knowing which side of the migration it is on.
     */
    async _fetchAllClassPages(jarId, version, container) {
        // Guard the PRODUCT, not just the factory. Checking `PA.pageSource` exists is not enough:
        // a browser holding a stale `page-envelope.js` (the `?v=` never changed when `fetchPage`
        // was added) has the factory but gets back an object without it, and the tab died with
        // "source.fetchPage is not a function" instead of quietly falling back.
        const source = (window.PA && PA.pageSource)
                ? JA.api.classTreePages(jarId, version, null) : null;
        if (!source || typeof source.fetchPage !== 'function') {
            if (source) {
                console.warn('classTreePages returned no fetchPage (stale page-envelope.js?) '
                        + '- falling back to the unpaged class tree');
            }
            return JA.api.getClassTree(jarId, version);
        }
        const classes = [];
        let total = -1;
        // Bounded, so a server that always reports hasMore cannot spin forever.
        for (let page = 0; page < 500; page++) {
            const env = await source.fetchPage(this._pageSize);
            for (const cls of env.items) classes.push(cls);
            if (total < 0 && env.page && env.page.totalIsExact) total = env.page.total;
            if (!env.page || !env.page.hasMore) break;
            if (container) {
                container.innerHTML = '<p style="padding:20px;color:var(--text-muted)">Loading code structure… '
                    + classes.length + (total >= 0 ? ' / ' + total : '') + ' classes</p>';
            }
        }
        return classes;
    },

    async _loadResources() {
        if (this._resourcesLoaded) return;
        const jarId = JA.app.currentJarId;
        if (!jarId) return;
        try {
            const res = await fetch('/api/jar/jars/' + encodeURIComponent(jarId) + '/resources', { cache: 'no-store' });
            if (!res.ok) return;
            this._resources = await res.json();
            this._resourcesLoaded = true;
            this._appendResourcesSection();
        } catch (e) {
            console.warn('Failed to load resource files:', e);
        }
    },

    _appendResourcesSection() {
        if (!this._resources || !this._resources.length) return;
        const container = document.getElementById('class-tree');
        if (!container) return;
        const existing = container.querySelector('.resources-section');
        if (existing) existing.remove();

        const grouped = {};
        for (const f of this._resources) {
            const ext = f.filename.includes('.') ? f.filename.slice(f.filename.lastIndexOf('.')).toLowerCase() : 'other';
            (grouped[ext] = grouped[ext] || []).push(f);
        }

        const extIcon = ext => {
            if (ext === '.properties') return '📄';
            if (ext === '.yml' || ext === '.yaml') return '📋';
            if (ext === '.json') return '📊';
            if (ext === '.xml') return '📝';
            if (ext === '.sql') return '🗄️';
            return '📃';
        };

        const esc = JA.utils.escapeHtml;
        let inner = '';
        const sortedExts = Object.keys(grouped).sort();
        for (const ext of sortedExts) {
            const files = grouped[ext];
            let fileItems = '';
            for (const f of files) {
                const safeName = f.filename.replace(/'/g, "\\'");
                fileItems += `<div class="tree-node tree-resource-file">
                    <div class="tree-leaf" style="cursor:pointer" onclick="JA.codeTree._openResourceFile('${esc(safeName)}')">
                        <span class="leaf-icon" style="margin-right:4px">${extIcon(ext)}</span>
                        <span class="resource-filename">${esc(f.filename)}</span>
                        <span class="tree-count" style="margin-left:auto">${JA.utils.formatSize ? JA.utils.formatSize(f.size) : f.size + 'B'}</span>
                    </div>
                </div>`;
            }
            const label = ext === 'other' ? 'other' : ext.slice(1);
            inner += `<div class="tree-node">
                <div class="tree-toggle expanded" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span style="margin-right:4px">${extIcon(ext)}</span>
                    <strong class="pkg-name">${esc(label)}</strong>
                    <span class="tree-count">${files.length}</span>
                </div>
                <div class="tree-children">${fileItems}</div>
            </div>`;
        }

        const section = document.createElement('div');
        section.className = 'tree-node resources-section';
        section.innerHTML = `<div class="jar-separator" style="margin-top:12px">Resources (${this._resources.length} files)</div>
            <div class="tree-node">
                <div class="tree-toggle expanded" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span class="jar-group-icon">&#128193;</span>
                    <strong class="jar-group-name">Resource Files</strong>
                    <span class="tree-count">${this._resources.length}</span>
                </div>
                <div class="tree-children">${inner}</div>
            </div>`;
        container.appendChild(section);
    },

    async _openResourceFile(filename) {
        const panel = document.getElementById('code-panel');
        if (!panel) return;
        const jarId = JA.app.currentJarId;
        if (!jarId) return;
        panel.innerHTML = '<div class="cp-loading"><div class="cm-spinner"></div><div>Loading...</div></div>';
        try {
            const res = await fetch('/api/jar/jars/' + encodeURIComponent(jarId) + '/resources/' + encodeURIComponent(filename));
            if (!res.ok) throw new Error('Not found');
            const text = await res.text();
            const esc = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            panel.innerHTML = `<div class="cm-info-bar">
                <span class="cm-classname">${esc(filename)}</span>
                <span class="cm-src-badge cm-badge-recon">RESOURCE</span>
                <button class="btn-sm cm-copy-btn" onclick="navigator.clipboard.writeText(document.getElementById('res-content-pre').textContent)" title="Copy to clipboard">Copy</button>
            </div>
            <div class="cm-content" style="padding:12px;overflow:auto;height:calc(100% - 40px);background:var(--sidebar-bg)">
                <pre id="res-content-pre" style="margin:0;white-space:pre-wrap;font-size:12px;font-family:monospace;tab-size:2;color:var(--sidebar-text)">${esc(text)}</pre>
            </div>`;
        } catch (e) {
            panel.innerHTML = '<div style="padding:20px;color:var(--red)">Failed to load resource: ' + (e.message || e) + '</div>';
        }
    },

    render(classes) {
        this._classes = classes;
        this._loaded = true;
        this._history = [];
        this._historyIndex = -1;
        this._renderCurrentView();
        this._updateNavState();
        if (JA.codeTreePanel) JA.codeTreePanel.clear();
        if (JA.codeTreeViews) JA.codeTreeViews.initJarSourceFilter(classes);
        if (this._resourcesLoaded) this._appendResourcesSection();
        if (this._bundledJarsLoaded) this._appendBundledJarsSection();
        if (this._jarDepMapLoaded) this._appendJarDepMapSection();
    },

    setViewMode(mode) {
        this._viewMode = mode;
        document.querySelectorAll('.view-mode-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.mode === mode);
        });
        const treeButtons = document.getElementById('tree-view-actions');
        if (treeButtons) treeButtons.style.display = mode === 'visual' ? 'none' : '';
        if (JA.codeTreeViews && JA.codeTreeViews._activeJarSources !== null) {
            JA.codeTreeViews._applyJarSourceFilter();
        } else {
            this._renderCurrentView();
        }
        if (this._resourcesLoaded) this._appendResourcesSection();
        if (this._bundledJarsLoaded) this._appendBundledJarsSection();
        if (this._jarDepMapLoaded) this._appendJarDepMapSection();
    },

    _renderCurrentView() {
        const container = document.getElementById('class-tree');
        if (!container || !this._classes.length) return;

        if (this._viewMode === 'project') {
            JA.codeTreeViews.renderProjectView(this._classes, container);
        } else if (this._viewMode === 'visual') {
            JA.codeTreeViews.renderVisualView(this._classes, container);
        } else {
            this._renderPackageView(container);
        }
    },

    _renderPackageView(container) {
        const { main, deps } = this._groupBySourceJar(this._classes);
        let html = '';

        // Main app classes
        if (main.length) {
            const packages = this._groupByPackage(main);
            const sorted = Object.keys(packages).sort();
            for (const pkg of sorted) {
                const pkgClasses = packages[pkg].sort((a, b) => a.simpleName.localeCompare(b.simpleName));
                html += this._renderPackage(pkg, pkgClasses);
            }
        }

        // Dependency JARs
        const jarNames = Object.keys(deps).sort();
        if (jarNames.length) {
            html += '<div class="jar-separator">Internal Dependencies (' + jarNames.length + ' JARs)</div>';
            for (const jarName of jarNames) {
                const jarClasses = deps[jarName];
                const project = JA.summary._jarToProject ? JA.summary._jarToProject(jarName) : jarName;
                const domain = JA.summary._jarToDomain ? JA.summary._jarToDomain(jarName) : '';
                const packages = this._groupByPackage(jarClasses);
                const sorted = Object.keys(packages).sort();
                let inner = '';
                for (const pkg of sorted) {
                    const pkgClasses = packages[pkg].sort((a, b) => a.simpleName.localeCompare(b.simpleName));
                    inner += this._renderPackage(pkg, pkgClasses);
                }
                html += `<div class="tree-node jar-group" data-jar="${JA.utils.escapeHtml(jarName)}">
                    <div class="tree-toggle jar-group-toggle" onclick="JA.codeTree.togglePkg(this)">
                        <span class="arrow">&#9654;</span>
                        <span class="jar-group-icon">&#128230;</span>
                        <strong class="jar-group-name">${JA.utils.escapeHtml(project)}</strong>
                        ${domain ? '<span class="sum-domain-tag" style="font-size:9px">' + JA.utils.escapeHtml(domain) + '</span>' : ''}
                        <span class="tree-count">${jarClasses.length} classes</span>
                    </div>
                    <div class="tree-children collapsed">${inner}</div>
                </div>`;
            }
        }

        container.innerHTML = html || '<p class="empty-state">No classes found</p>';
    },

    _renderFilteredPackageView(container, classes) {
        const { main, deps } = this._groupBySourceJar(classes);
        let html = '';
        if (main.length) {
            const packages = this._groupByPackage(main);
            const sorted = Object.keys(packages).sort();
            for (const pkg of sorted) {
                const pkgClasses = packages[pkg].sort((a, b) => a.simpleName.localeCompare(b.simpleName));
                html += this._renderPackage(pkg, pkgClasses);
            }
        }
        const jarNames = Object.keys(deps).sort();
        if (jarNames.length) {
            html += '<div class="jar-separator">Internal Dependencies (' + jarNames.length + ' JARs)</div>';
            for (const jarName of jarNames) {
                const jarClasses = deps[jarName];
                const project = JA.summary._jarToProject ? JA.summary._jarToProject(jarName) : jarName;
                const domain = JA.summary._jarToDomain ? JA.summary._jarToDomain(jarName) : '';
                const packages = this._groupByPackage(jarClasses);
                const sorted = Object.keys(packages).sort();
                let inner = '';
                for (const pkg of sorted) {
                    const pkgClasses = packages[pkg].sort((a, b) => a.simpleName.localeCompare(b.simpleName));
                    inner += this._renderPackage(pkg, pkgClasses);
                }
                html += `<div class="tree-node jar-group" data-jar="${JA.utils.escapeHtml(jarName)}">
                    <div class="tree-toggle jar-group-toggle" onclick="JA.codeTree.togglePkg(this)">
                        <span class="arrow">&#9654;</span>
                        <span class="jar-group-icon">&#128230;</span>
                        <strong class="jar-group-name">${JA.utils.escapeHtml(project)}</strong>
                        ${domain ? '<span class="sum-domain-tag" style="font-size:9px">' + JA.utils.escapeHtml(domain) + '</span>' : ''}
                        <span class="tree-count">${jarClasses.length} classes</span>
                    </div>
                    <div class="tree-children collapsed">${inner}</div>
                </div>`;
            }
        }
        container.innerHTML = html || '<p class="empty-state">No classes match the selected sources</p>';
    },

    _groupBySourceJar(classes) {
        const main = [];
        const deps = {};
        for (const cls of classes) {
            if (!cls.sourceJar) {
                main.push(cls);
            } else {
                (deps[cls.sourceJar] = deps[cls.sourceJar] || []).push(cls);
            }
        }
        return { main, deps };
    },

    /* ---- lazy expand ---- */

    togglePkg(el) {
        const children = el.nextElementSibling;
        if (!children) return;
        el.classList.toggle('expanded');
        children.classList.toggle('collapsed');
    },

    /**
     * Fetches one class's members and renders them into an already-open node.
     *
     * <p>Guarded two ways. `dataset.rendered` is only set on success, so a failed load can be
     * retried by collapsing and reopening rather than leaving a permanently empty node. And the
     * class identity is re-checked on arrival: collapsing and expanding a different class while
     * this is in flight must not paint one class's members under another's row.
     */
    _loadClassMembers(cls, classIndex, children) {
        const jarId = JA.app.currentJarId || '';
        const want = cls.fullyQualifiedName || cls.simpleName;
        // Fetched BY NAME, not by index. `/classes/by-index/{idx}` indexes analysis.json's own
        // class order, while classIndex indexes this tree's PACKAGE-sorted array — the two do not
        // agree, so an index fetch would quietly return a different class and render its methods
        // under this row.
        const url = '/api/jar/jars/' + encodeURIComponent(jarId)
                + '/decompile?class=' + encodeURIComponent(want);
        fetch(url, { cache: 'no-store' })
            .then(r => r.ok ? r.json() : null)
            .then(payload => {
                const full = payload && (payload.classData || payload);
                if (!full) throw new Error('empty');
                // Belt and braces: only accept a response that is actually this class.
                const got = full.fullyQualifiedName || full.simpleName;
                if (got && got !== want && full.simpleName !== cls.simpleName) {
                    throw new Error('identity mismatch');
                }
                // Cache on the class object so a second expand costs nothing.
                if (full.methods) cls.methods = full.methods;
                if (full.methodSummaries) cls.methodSummaries = full.methodSummaries;
                if (full.fields && !cls.fields) cls.fields = full.fields;
                const still = this._classes[classIndex];
                if (!still || (still.fullyQualifiedName || still.simpleName) !== want) return;
                children.innerHTML = this._renderClassBody(cls, classIndex);
                children.dataset.rendered = '1';
            })
            .catch(() => {
                children.innerHTML = '<div class="tree-node"><div class="tree-leaf">'
                    + 'Could not load members \u2014 collapse and reopen to retry</div></div>';
            });
    },

    toggleClass(el, classIndex) {
        const children = el.nextElementSibling;
        if (!children) return;

        // Lazy render: if children are empty, render fields+methods now.
        //
        // The tree is fetched with members=false — methodSummaries and fields are 93.8% of that
        // response (11.8 MB -> ~760 KB for 1,623 classes), and nothing on screen needs them until
        // a class is opened. So the first expand of a class fetches just that class and caches the
        // members on it; every later expand is instant.
        if (!children.dataset.rendered) {
            const cls = this._classes[classIndex];
            if (cls) {
                // Test for METHODS specifically, not "any members". The paged row carries `fields`
                // but not `methodSummaries` — so a check for either would be satisfied by fields,
                // render a body with no methods, and never fetch. That is precisely how the Methods
                // section came to be permanently empty in the first place.
                const hasMethods = (cls.methodSummaries && cls.methodSummaries.length)
                        || (cls.methods && cls.methods.length);
                const expectsMethods = (cls.methodCount || 0) > 0;
                if (hasMethods || !expectsMethods) {
                    children.innerHTML = this._renderClassBody(cls, classIndex);
                    children.dataset.rendered = '1';
                } else {
                    children.innerHTML = '<div class="tree-node"><div class="tree-leaf">Loading\u2026</div></div>';
                    this._loadClassMembers(cls, classIndex, children);
                }
            }
        }

        el.classList.toggle('expanded');
        children.classList.toggle('collapsed');

        // Show code in inline panel when expanding
        if (el.classList.contains('expanded') && JA.codeTreePanel) {
            const cls = this._classes[classIndex];
            if (cls) JA.codeTreePanel.show(cls.fullyQualifiedName || cls.simpleName);
        }
    },

    toggleMethod(el, classIndex, methodIndex) {
        const children = el.nextElementSibling;
        if (!children) return;

        // Lazy render invocations
        if (!children.dataset.rendered) {
            const cls = this._classes[classIndex];
            if (cls) {
                const method = cls.methods[methodIndex];
                if (method) {
                    children.innerHTML = this._renderInvocations(method);
                    children.dataset.rendered = '1';
                }
            }
        }

        el.classList.toggle('expanded');
        children.classList.toggle('collapsed');
    },

    expandAll() {
        // Only expand already-rendered nodes
        document.querySelectorAll('.class-tree .tree-toggle').forEach(t => t.classList.add('expanded'));
        document.querySelectorAll('.class-tree .tree-children').forEach(c => c.classList.remove('collapsed'));
    },

    collapseAll() {
        document.querySelectorAll('.class-tree .tree-toggle').forEach(t => t.classList.remove('expanded'));
        document.querySelectorAll('.class-tree .tree-children').forEach(c => c.classList.add('collapsed'));
    },

    filter(query) {
        if (this._viewMode === 'project') {
            JA.codeTreeViews.filterProjectView(query);
            return;
        }
        if (this._viewMode === 'visual') {
            JA.codeTreeViews.filterVisualView(query);
            return;
        }

        const q = (query || '').toLowerCase().trim();
        const tree = document.querySelector('.class-tree');
        if (!tree) return;

        // Reset visibility
        if (!q) {
            tree.querySelectorAll('.tree-node').forEach(n => n.style.display = '');
            tree.querySelectorAll('.jar-separator').forEach(n => n.style.display = '');
            return;
        }

        // Filter class nodes matching query
        const classNodes = tree.querySelectorAll('.tree-node[data-class-name]');
        const visiblePkgs = new Set();
        const visibleJarGroups = new Set();

        classNodes.forEach(cls => {
            const text = cls.getAttribute('data-search') || '';
            if (text.includes(q)) {
                cls.style.display = '';
                // Expand parent package
                let parent = cls.parentElement;
                while (parent && parent !== tree) {
                    if (parent.classList.contains('tree-children')) {
                        parent.classList.remove('collapsed');
                        const t = parent.previousElementSibling;
                        if (t && t.classList.contains('tree-toggle')) t.classList.add('expanded');
                    }
                    if (parent.classList.contains('tree-node') && !parent.hasAttribute('data-class-name')) {
                        visiblePkgs.add(parent);
                        if (parent.classList.contains('jar-group')) visibleJarGroups.add(parent);
                    }
                    parent = parent.parentElement;
                }
            } else {
                cls.style.display = 'none';
            }
        });

        // Hide packages / jar groups with no matches
        tree.querySelectorAll(':scope > .tree-node, :scope > .tree-node .tree-node:not([data-class-name])').forEach(node => {
            if (node.hasAttribute('data-class-name')) return;
            node.style.display = visiblePkgs.has(node) ? '' : 'none';
        });

        // Show jar separator only if any jar groups visible
        tree.querySelectorAll('.jar-separator').forEach(sep => {
            sep.style.display = visibleJarGroups.size > 0 ? '' : 'none';
        });
    },

    /* ---- navigation ---- */

    navigateTo(className, methodName, el) {
        if (this._historyIndex < this._history.length - 1) {
            this._history = this._history.slice(0, this._historyIndex + 1);
        }
        this._history.push({ className, methodName, element: el });
        this._historyIndex = this._history.length - 1;
        this._highlightAndScroll(el);
        this._updateNavState();
        if (JA.codeTreePanel) JA.codeTreePanel.show(className, methodName);
    },

    findAndHighlight(className, methodName) {
        setTimeout(() => {
            const tree = document.getElementById('class-tree');
            if (!tree) return;

            // First, find the class node and expand it (triggers lazy render)
            const classNodes = tree.querySelectorAll('.tree-node[data-class-name]');
            let classNode = null;
            for (const node of classNodes) {
                if (node.getAttribute('data-class-name') === className) {
                    classNode = node;
                    break;
                }
            }

            if (classNode) {
                // Expand the class to trigger lazy rendering of methods
                const toggle = classNode.querySelector(':scope > .tree-toggle');
                const children = classNode.querySelector(':scope > .tree-children');
                if (toggle && children && !children.dataset.rendered) {
                    const idx = parseInt(classNode.getAttribute('data-class-index'), 10);
                    this.toggleClass(toggle, idx);
                } else if (toggle && children) {
                    toggle.classList.add('expanded');
                    children.classList.remove('collapsed');
                }

                // Expand parent package
                let parent = classNode.parentElement;
                while (parent) {
                    if (parent.classList && parent.classList.contains('tree-children')) {
                        parent.classList.remove('collapsed');
                        const t = parent.previousElementSibling;
                        if (t && t.classList.contains('tree-toggle')) t.classList.add('expanded');
                    }
                    parent = parent.parentElement;
                }

                // Now find the method inside the expanded class
                setTimeout(() => {
                    const methods = classNode.querySelectorAll('.tree-method');
                    let found = null;
                    for (const m of methods) {
                        if (m.getAttribute('data-method') === methodName) { found = m; break; }
                    }
                    if (!found && methods.length > 0) found = methods[0];

                    if (found) {
                        const clickEl = found.querySelector('.tree-method-click');
                        this.navigateTo(className, methodName, clickEl || found);
                        JA.toast.info('Jumped to ' + className + '.' + methodName, 2000);
                    } else {
                        // Scroll to class at least
                        classNode.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        JA.toast.info('Jumped to class ' + className, 2000);
                    }
                }, 50);
            } else {
                JA.toast.warn('Class not found: ' + className, 3000);
            }
        }, 150);
    },

    jumpToInvocation(ownerClass, methodName, event) {
        JA.nav.goTo(ownerClass, methodName, 'structure', event);
    },

    goToEndpointFlow(httpMethod, path) {
        switchTab('endpoints');
        JA.toast.info('Switching to Endpoint Flow...', 1500);
        setTimeout(() => {
            const cards = document.querySelectorAll('.endpoint-card');
            for (const card of cards) {
                const methodSpan = card.querySelector('.endpoint-method');
                const pathSpan = card.querySelector('.endpoint-path');
                if (methodSpan && pathSpan) {
                    if (methodSpan.textContent.trim() === httpMethod && pathSpan.textContent.trim() === path) {
                        card.click();
                        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        JA.toast.success('Showing flow for ' + httpMethod + ' ' + path, 2000);
                        return;
                    }
                }
            }
            JA.toast.warn('Endpoint not found', 3000);
        }, 200);
    },

    goBack() {
        if (this._historyIndex <= 0) return;
        this._historyIndex--;
        const entry = this._history[this._historyIndex];
        this._highlightAndScroll(entry.element);
        this._updateNavState();
        if (JA.codeTreePanel) JA.codeTreePanel.show(entry.className, entry.methodName);
    },

    goForward() {
        if (this._historyIndex >= this._history.length - 1) return;
        this._historyIndex++;
        const entry = this._history[this._historyIndex];
        this._highlightAndScroll(entry.element);
        this._updateNavState();
        if (JA.codeTreePanel) JA.codeTreePanel.show(entry.className, entry.methodName);
    },

    goToHistoryEntry(index) {
        if (index < 0 || index >= this._history.length) return;
        this._historyIndex = index;
        const entry = this._history[this._historyIndex];
        this._highlightAndScroll(entry.element);
        this._updateNavState();
        this.toggleHistory();
        if (JA.codeTreePanel) JA.codeTreePanel.show(entry.className, entry.methodName);
    },

    toggleHistory() {
        const panel = document.getElementById('nav-history-panel');
        if (!panel) return;
        if (panel.style.display === 'none') {
            this._renderHistoryPanel();
            panel.style.display = '';
        } else {
            // A closing panel must not keep a query it has stopped applying (SearchQuery.resetWithin).
            if (window.SearchQuery) SearchQuery.resetWithin(panel);
            panel.style.display = 'none';
        }
    },

    _highlightAndScroll(el) {
        if (!el) return;
        document.querySelectorAll('.tree-node.nav-highlight').forEach(n => n.classList.remove('nav-highlight'));
        const node = el.closest('.tree-node');
        if (!node) return;

        let parent = node.parentElement;
        while (parent) {
            if (parent.classList && parent.classList.contains('tree-children')) {
                parent.classList.remove('collapsed');
                const t = parent.previousElementSibling;
                if (t && t.classList.contains('tree-toggle')) t.classList.add('expanded');
            }
            parent = parent.parentElement;
        }

        node.classList.add('nav-highlight');
        node.scrollIntoView({ behavior: 'smooth', block: 'center' });
    },

    _updateNavState() {
        const backBtn = document.getElementById('nav-back');
        const fwdBtn = document.getElementById('nav-forward');
        const crumb = document.getElementById('nav-breadcrumb');
        const histBtn = document.getElementById('nav-history-toggle');

        if (backBtn) backBtn.disabled = this._historyIndex <= 0;
        if (fwdBtn) fwdBtn.disabled = this._historyIndex >= this._history.length - 1;

        if (crumb) {
            if (this._historyIndex >= 0) {
                const entry = this._history[this._historyIndex];
                crumb.innerHTML = `<span class="crumb-current">${JA.utils.escapeHtml(entry.className + '.' + entry.methodName)}</span>`;
            } else {
                crumb.innerHTML = '';
            }
        }

        if (histBtn) {
            histBtn.textContent = this._history.length > 0 ? `History (${this._history.length})` : 'History';
        }
    },

    _renderHistoryPanel() {
        const panel = document.getElementById('nav-history-panel');
        if (!panel) return;

        if (this._history.length === 0) {
            panel.innerHTML = '<div class="history-empty">No navigation history yet</div>';
            return;
        }

        let html = '<div class="history-list">';
        for (let i = this._history.length - 1; i >= 0; i--) {
            const entry = this._history[i];
            const active = i === this._historyIndex ? ' history-active' : '';
            html += `<div class="history-item${active}" onclick="JA.codeTree.goToHistoryEntry(${i})">
                <span class="history-idx">${i + 1}</span>
                <span class="history-label">${JA.utils.escapeHtml(entry.className + '.' + entry.methodName)}</span>
            </div>`;
        }
        html += '</div>';
        panel.innerHTML = html;
    },

    /* ---- render helpers ---- */

    _groupByPackage(classes) {
        const map = {};
        for (const cls of classes) {
            const pkg = cls.packageName || '(default)';
            (map[pkg] = map[pkg] || []).push(cls);
        }
        return map;
    },

    /** Render package header + collapsed class headers (no method/field details yet) */
    _renderPackage(pkg, classes) {
        const esc = JA.utils.escapeHtml;
        let classHeaders = '';
        for (const cls of classes) {
            classHeaders += this._renderClassHeader(cls);
        }

        return `
            <div class="tree-node" data-search="${pkg.toLowerCase()}">
                <div class="tree-toggle expanded" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span class="pkg-icon">&#128230;</span>
                    <strong class="pkg-name">${esc(pkg)}</strong>
                    <span class="tree-count">${classes.length}</span>
                </div>
                <div class="tree-children">
                    ${classHeaders}
                </div>
            </div>`;
    },

    /** Render just the class toggle header — body is empty until user expands */
    _renderClassHeader(cls) {
        const esc = JA.utils.escapeHtml;
        const stereotype = cls.stereotype || 'OTHER';
        const badgeCls = JA.utils.stereotypeBadgeClass(stereotype);

        const typeBadges = [];
        if (cls.isInterface) typeBadges.push('<span class="badge badge-interface">IF</span>');
        else if (cls.isAbstract) typeBadges.push('<span class="badge badge-abstract">ABS</span>');
        if (cls.isEnum) typeBadges.push('<span class="badge badge-enum">ENUM</span>');
        typeBadges.push(`<span class="badge ${badgeCls}">${stereotype.replace('REST_', '')}</span>`);

        const annotations = cls.annotations || [];
        const stereoAnns = annotations
            .filter(a => ['RestController','Controller','Service','Repository','Component','Configuration','Entity'].includes(a.name))
            .map(a => `<span class="method-ann">@${a.name}</span>`).join(' ');

        const searchKey = [
            cls.fullyQualifiedName,
            cls.simpleName,
            annotations.map(a => a.name).join(' '),
            (cls.methods || []).map(m => m.name).join(' ')
        ].join(' ').toLowerCase();

        const classIcon = cls.isInterface ? '&#9671;' : cls.isEnum ? '&#9670;' : '&#9632;';
        const memberCount = (cls.fields || []).length + (cls.methods || []).length;
        const classIndex = this._classes.indexOf(cls);

        return `
            <div class="tree-node" data-search="${searchKey}" data-class-name="${esc(cls.simpleName)}" data-class-index="${classIndex}">
                <div class="tree-toggle" onclick="JA.codeTree.toggleClass(this, ${classIndex})">
                    <span class="arrow">&#9654;</span>
                    <span class="class-icon" style="color:${JA.utils.stereotypeColor(stereotype)}">${classIcon}</span>
                    ${stereoAnns}
                    <strong class="class-name">${esc(cls.simpleName)}</strong>
                    ${typeBadges.join('')}
                    <span class="tree-count">${memberCount}</span>
                </div>
                <div class="tree-children collapsed"></div>
            </div>`;
    },

    /** Render class body (fields + methods) — called lazily on expand */
    /** Methods drawn per class before the cap engages. */
    _methodCap: 200,

    /** Fields drawn per class before the cap engages. Max observed on one class: 3,704. */
    _fieldCap: 200,

    /** Per-class override set by "show all"; keyed by class index. */
    _expandedAll: {},

    /**
     * Lifts the per-class method cap and repaints just that class's body.
     *
     * <p>Scoped to one class on purpose: opening a 2,419-method generated class should not make
     * every other class expensive for the rest of the session.
     */
    showAllMethods(classIndex, anchor) {
        this._expandedAll[classIndex] = true;
        const cls = this._classes[classIndex];
        const children = anchor && anchor.closest('.tree-children');
        if (cls && children) children.innerHTML = this._renderClassBody(cls, classIndex);
    },

    _renderClassBody(cls, classIndex) {
        const esc = JA.utils.escapeHtml;
        const fields = cls.fields || [];
        // `methodSummaries` is what /classes/tree actually sends; `methods` is the field name in
        // analysis.json. This read had only ever checked `methods`, so the Methods section of the
        // Code Structure tree rendered EMPTY for every class since the streaming provider began
        // renaming the field — 60 methods on WarAnalyzerController showed as none. Nothing failed
        // loudly: `[]` is a legitimate value for a class with no methods.
        // `methods` is kept as a fallback so a payload carrying the raw name still renders.
        const methods = cls.methodSummaries || cls.methods || [];
        let html = '';

        // Implementations section for interfaces / abstract classes (IntelliJ Ctrl+Alt+B style)
        if (cls.isInterface || cls.isAbstract) {
            if (JA.nav && !JA.nav._implMap) JA.nav.init();
            const fqn = cls.fullyQualifiedName || '';
            const impls = (JA.nav && JA.nav._implMap)
                ? (JA.nav._implMap[fqn] || JA.nav._implMap[cls.simpleName] || [])
                : [];
            if (impls.length > 0) {
                html += '<div class="tree-section-label tree-impls-label">Implementations (' + impls.length + ')</div>';
                for (const impl of impls) {
                    const color = JA.utils.stereotypeColor(impl.stereotype);
                    const stereo = (impl.stereotype || '').replace('REST_', '');
                    const safeName = (impl.simpleName || '').replace(/'/g, "\\'");
                    html += `<div class="tree-node tree-impl-item">
                        <div class="tree-leaf" onclick="JA.codeTree.findAndHighlight('${safeName}','')" style="cursor:pointer">
                            <span class="leaf-icon" style="color:${color}">&#9658;</span>
                            <span class="impl-name" style="color:${color};font-weight:600">${esc(impl.simpleName || '?')}</span>
                            ${stereo ? `<span class="badge badge-xs" style="color:${color};border-color:${color};opacity:0.8">${esc(stereo)}</span>` : ''}
                            <span class="cg-src-btn code-view-btn" onclick="event.stopPropagation();JA.summary.showClassCode('${(impl.fullyQualifiedName||impl.simpleName||'').replace(/'/g,"\\'")}','')" title="View decompiled code">Code</span>
                        </div>
                    </div>`;
                }
            }
        }

        if (fields.length > 0) {
            // Fields need the same cap as methods: the maximum on this JAR is 3,704 on a single
            // class (three exceed 200), even though the 99th percentile is 18. A percentile is not
            // a bound, and the outlier is precisely the class that stalls.
            const fCap = (this._expandedAll && this._expandedAll[classIndex])
                    ? fields.length : this._fieldCap;
            const fShown = Math.min(fCap, fields.length);
            html += '<div class="tree-section-label">Fields</div>';
            for (const f of fields.slice(0, fShown)) {
                const anns = (f.annotations || []).map(a => `<span class="method-ann">@${a.name}</span>`).join(' ');
                html += `<div class="tree-node tree-field">
                    <div class="tree-leaf">
                        <span class="leaf-icon field-icon">F</span>
                        ${anns}
                        <span class="field-type">${esc(f.type)}</span>
                        <span class="field-name">${esc(f.name)}</span>
                    </div>
                </div>`;
            }
            if (fShown < fields.length) {
                html += '<div class="tree-node"><div class="tree-leaf" style="opacity:.8">'
                    + 'Showing ' + fShown + ' of ' + fields.length + ' fields \u2014 '
                    + '<a href="#" onclick="event.preventDefault();'
                    + 'JA.codeTree.showAllMethods(' + classIndex + ',this)">show all</a>'
                    + '</div></div>';
            }
        }

        if (methods.length > 0) {
            // Capped per class, disclosed, same idiom as the endpoint list and cross-ref.
            // Generated code makes this real rather than theoretical: on this JAR, 7 classes
            // exceed 1,000 methods and PlSqlParserBaseListener has 2,419 — that many rows built
            // into one innerHTML is a visible stall when a single class is opened.
            const cap = (this._expandedAll && this._expandedAll[classIndex])
                    ? methods.length : this._methodCap;
            const shown = Math.min(cap, methods.length);
            html += '<div class="tree-section-label">Methods</div>';
            for (let mi = 0; mi < shown; mi++) {
                html += this._renderMethodHeader(methods[mi], cls, classIndex, mi);
            }
            if (shown < methods.length) {
                html += '<div class="tree-node"><div class="tree-leaf" style="opacity:.8">'
                    + 'Showing ' + shown + ' of ' + methods.length + ' methods \u2014 '
                    + '<a href="#" onclick="event.preventDefault();'
                    + 'JA.codeTree.showAllMethods(' + classIndex + ',this)">show all</a>'
                    + '</div></div>';
            }
        }

        return html;
    },

    /** Render method header — invocations are empty until user expands */
    _renderMethodHeader(method, cls, classIndex, methodIndex) {
        const esc = JA.utils.escapeHtml;
        const anns = (method.annotations || []).map(a => {
            let text = '@' + a.name;
            const attrs = a.attributes || {};
            const keys = Object.keys(attrs);
            if (keys.length > 0) {
                const vals = keys.map(k => k + '=' + JSON.stringify(attrs[k])).join(', ');
                text += '(' + vals + ')';
            }
            return `<span class="method-ann">${esc(text)}</span>`;
        }).join(' ');

        const params = (method.parameters || []).map(p => {
            const pAnns = (p.annotations || []).map(a => '@' + a.name + ' ').join('');
            return pAnns + p.type + ' ' + p.name;
        }).join(', ');

        const displayName = method.name === '<init>' ? 'constructor' : method.name;
        const className = cls ? cls.simpleName : '';

        const httpBadge = method.httpMethod
            ? `<span class="endpoint-method method-${method.httpMethod}" style="font-size:9px;padding:1px 5px">${method.httpMethod}</span>`
            : '';

        const fqn = cls ? (cls.fullyQualifiedName || cls.simpleName) : '';
        const safeFqn = fqn.replace(/'/g, "\\'");
        const safeDisplay = displayName.replace(/'/g, "\\'");
        const codeBtn = `<span class="cg-src-btn code-view-btn" onclick="event.stopPropagation();JA.codeTreePanel.show('${esc(safeFqn)}','${esc(safeDisplay)}')" title="View decompiled code">Code</span>`;

        const invocations = (method.invocations || []).filter(inv =>
            inv.methodName !== '<init>' && inv.methodName !== '<clinit>'
        );
        const hasInvocations = invocations.length > 0;

        return `
            <div class="tree-node tree-method" data-method="${esc(displayName)}" data-class="${esc(className)}">
                <div class="${hasInvocations ? 'tree-toggle' : 'tree-leaf'} tree-method-click"
                     onclick="${hasInvocations ? 'JA.codeTree.toggleMethod(this,' + classIndex + ',' + methodIndex + ');' : ''}JA.codeTree.navigateTo('${esc(className)}','${esc(displayName)}',this)">
                    ${hasInvocations ? '<span class="arrow">&#9654;</span>' : ''}
                    <span class="leaf-icon method-icon">M</span>
                    <span class="method-sig">
                        ${anns} ${httpBadge}
                        <span class="method-return">${esc(method.returnType)}</span>
                        <span class="method-name">${esc(displayName)}</span>(<span class="method-params">${esc(params)}</span>)
                    </span>
                    ${hasInvocations ? '<span class="tree-count">' + invocations.length + ' calls</span>' : ''}
                    ${codeBtn}
                </div>
                ${hasInvocations ? '<div class="tree-children collapsed"></div>' : ''}
            </div>`;
    },

    /**
     * Bundled libraries (Q41 / L2) — one page at a time, headers only.
     *
     * <p>The unpaged response is 3.03 MB for 94 rows, of which 2.84 MB is manifest text and
     * resource file bodies that this section does not render until a leaf is clicked. Asking for
     * the projected page instead brings it to 16 KB; the body of a file is fetched by
     * `_openBundledContent` when it is actually opened.
     */
    async _loadBundledJars() {
        if (this._bundledJarsLoaded) return;
        const jarId = JA.app.currentJarId;
        if (!jarId) return;
        try {
            if (!window.PA || !PA.pageSource) {
                const res = await fetch('/api/jar/jars/' + encodeURIComponent(jarId) + '/bundled-jars', { cache: 'no-store' });
                if (!res.ok) return;
                this._bundledJars = await res.json();
            } else {
                const source = JA.api.bundledJarPages(jarId, null);
                const jars = [];
                for (let page = 0; page < 500; page++) {
                    const env = await source.fetchPage(100);
                    for (const j of env.items) jars.push(j);
                    if (!env.page || !env.page.hasMore) break;
                }
                this._bundledJars = jars;
            }
            this._bundledJarsLoaded = true;
            this._appendBundledJarsSection();
        } catch (e) {
            console.warn('Failed to load bundled JARs:', e);
        }
    },

    async _loadJarDepMap() {
        if (this._jarDepMapLoaded) return;
        const jarId = JA.app.currentJarId;
        if (!jarId) return;
        try {
            const res = await fetch('/api/jar/jars/' + encodeURIComponent(jarId) + '/jar-dep-map', { cache: 'no-store' });
            if (!res.ok) return;
            this._jarDepMap = await res.json();
            this._jarDepMapLoaded = true;
            this._appendJarDepMapSection();
        } catch (e) {
            console.warn('Failed to load JAR dep map:', e);
        }
    },

    _appendBundledJarsSection() {
        if (!this._bundledJars || !this._bundledJars.length) return;
        const container = document.getElementById('class-tree');
        if (!container) return;
        const existing = container.querySelector('.bundled-jars-section');
        if (existing) existing.remove();


        const esc = JA.utils.escapeHtml;
        const extIcon = fname => {
            const lower = fname.toLowerCase();
            if (lower.endsWith('.properties')) return '📄';
            if (lower.endsWith('.yml') || lower.endsWith('.yaml')) return '📋';
            if (lower.endsWith('.json')) return '📊';
            if (lower.endsWith('.xml')) return '📝';
            return '📃';
        };
        const formatSize = bytes => {
            if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
            if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return bytes + ' B';
        };
        // A leaf carries the JAR and file *name*, and the body is fetched when it is clicked.
        // Previously every body was cached in this array and opened by array position — a
        // positional handle into data the server may reorder, and 2.84 MB held in the tab for the
        // sake of the one file a user might open.
        const leaf = (jarName, filename, icon) => {
            const a = jarName.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            const b = filename.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            return `<div class="tree-node tree-resource-file">
                    <div class="tree-leaf" style="cursor:pointer" onclick="JA.codeTree._openBundledContent('${esc(a)}','${esc(b)}')">
                        <span class="leaf-icon" style="margin-right:4px">${icon}</span>
                        <span class="resource-filename">${esc(filename)}</span>
                    </div>
                </div>`;
        };

        let jarNodes = '';
        for (const j of this._bundledJars) {
            let innerItems = '';
            // Tolerates both response shapes: `hasManifest`/`resourceNames` from the paged
            // projection, `manifest`/`resources` from the legacy full array.
            const hasManifest = ('hasManifest' in j) ? !!j.hasManifest : !!j.manifest;
            const resourceKeys = j.resourceNames || Object.keys(j.resources || {});
            if (hasManifest) innerItems += leaf(j.name, 'MANIFEST.MF', '📋');
            for (const fname of resourceKeys) {
                innerItems += leaf(j.name, fname, extIcon(fname));
            }
            const hasChildren = hasManifest || resourceKeys.length > 0;
            jarNodes += `<div class="tree-node">
                <div class="tree-toggle" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span style="margin-right:4px">📦</span>
                    <strong class="pkg-name">${esc(j.name)}</strong>
                    <span class="tree-count">${formatSize(j.size)}</span>
                </div>
                <div class="tree-children collapsed">${hasChildren ? innerItems : '<span style="padding:4px 8px;color:var(--text-muted,var(--text-muted));font-size:11px">No resources</span>'}</div>
            </div>`;
        }

        const section = document.createElement('div');
        section.className = 'tree-node bundled-jars-section';
        section.innerHTML = `<div class="jar-separator" style="margin-top:12px">Bundled Libraries (${this._bundledJars.length} JARs)</div>
            <div class="tree-node">
                <div class="tree-toggle expanded" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span class="jar-group-icon">📦</span>
                    <strong class="jar-group-name">Bundled Libraries</strong>
                    <span class="tree-count">${this._bundledJars.length}</span>
                </div>
                <div class="tree-children">${jarNodes}</div>
            </div>`;
        container.appendChild(section);
    },

    /** Fetches and shows one bundled file, addressed by JAR name and file name. */
    async _openBundledContent(jarName, filename) {
        // Stale-response guard (§B5). #code-panel is a singleton shared with
        // JA.codeTreePanel.show, which guards only its own _currentFqn and cannot know a
        // bundled-file write is in flight into the same node. Invalidation is made mutual:
        // codeTreePanel.show bumps this same token, and we clear its _currentFqn below.
        const isCurrent = UIBusy.seq(JA.codeTree, '_codePanelSeq');
        if (JA.codeTreePanel) JA.codeTreePanel._currentFqn = null;
        const panel = document.getElementById('code-panel');
        if (!panel) return;
        const esc = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const header = `<div class="cm-info-bar">
            <span class="cm-classname">${esc(jarName)} / ${esc(filename)}</span>
            <span class="cm-src-badge cm-badge-recon">BUNDLED</span>
            <button class="btn-sm cm-copy-btn" onclick="navigator.clipboard.writeText(document.getElementById('bundled-content-pre').textContent)" title="Copy to clipboard">Copy</button>
        </div>`;
        panel.innerHTML = '<div class="cp-loading"><div class="cm-spinner"></div><div>Loading...</div></div>';
        let content;
        try {
            content = await JA.api.getBundledJarContent(JA.app.currentJarId, jarName, filename);
        } catch (e) {
            if (!isCurrent()) return;
            panel.innerHTML = header + '<div style="padding:20px;color:var(--red)">Failed to load: '
                + esc(e.message || String(e)) + '</div>';
            return;
        }
        if (!isCurrent()) return;
        panel.innerHTML = header + `
        <div class="cm-content" style="padding:12px;overflow:auto;height:calc(100% - 40px);background:var(--sidebar-bg)">
            <pre id="bundled-content-pre" style="margin:0;white-space:pre-wrap;font-size:12px;font-family:monospace;tab-size:2;color:var(--sidebar-text)">${esc(content)}</pre>
        </div>`;
    },

    _appendJarDepMapSection() {
        if (!this._jarDepMap || !Object.keys(this._jarDepMap).length) return;
        const container = document.getElementById('class-tree');
        if (!container) return;
        const existing = container.querySelector('.jar-dep-map-section');
        if (existing) existing.remove();

        const esc = JA.utils.escapeHtml;
        const depJars = Object.keys(this._jarDepMap).sort();
        const totalUsed = depJars.length;

        let jarNodes = '';
        for (const jarName of depJars) {
            const appClasses = Array.from(this._jarDepMap[jarName] || []).sort();
            let classItems = '';
            for (const cls of appClasses) {
                const safeCls = cls.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                classItems += `<div class="tree-node tree-resource-file">
                    <div class="tree-leaf" style="cursor:pointer" onclick="JA.codeTree.findAndHighlight('${safeCls}','')">
                        <span class="leaf-icon" style="margin-right:4px;color:var(--text-muted)">&#9632;</span>
                        <span class="resource-filename">${esc(cls)}</span>
                    </div>
                </div>`;
            }
            jarNodes += `<div class="tree-node">
                <div class="tree-toggle" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span style="margin-right:4px">📦</span>
                    <strong class="pkg-name">${esc(jarName)}</strong>
                    <span class="tree-count">${appClasses.length} classes</span>
                </div>
                <div class="tree-children collapsed">${classItems}</div>
            </div>`;
        }

        const section = document.createElement('div');
        section.className = 'tree-node jar-dep-map-section';
        section.innerHTML = `<div class="jar-separator" style="margin-top:12px">JAR Dependencies (${totalUsed} libs used)</div>
            <div class="tree-node">
                <div class="tree-toggle expanded" onclick="JA.codeTree.togglePkg(this)">
                    <span class="arrow">&#9654;</span>
                    <span class="jar-group-icon">&#128279;</span>
                    <strong class="jar-group-name">JAR Dependencies</strong>
                    <span class="tree-count">${totalUsed} libs used</span>
                </div>
                <div class="tree-children">${jarNodes}</div>
            </div>`;
        container.appendChild(section);
    },

    /** Render invocations block — called lazily on expand */
    _renderInvocations(method) {
        const esc = JA.utils.escapeHtml;
        const invocations = (method.invocations || []).filter(inv =>
            inv.methodName !== '<init>' && inv.methodName !== '<clinit>'
        );
        if (invocations.length === 0) return '';

        let lineNum = 1;
        const lines = invocations.map(inv => {
            const ownerFqn = inv.ownerClass || '';
            const ownerShort = ownerFqn.split('.').pop();
            const methName = inv.methodName || '';
            const retType = inv.returnType && inv.returnType !== 'void'
                ? ` <span class="inv-return">: ${esc(inv.returnType)}</span>` : '';
            const num = lineNum++;
            const navIdx = JA.nav.ref(ownerFqn, methName);
            return `<div class="invocation-line inv-clickable" onclick="JA.nav.click(${navIdx},event)" title="Click to navigate to ${ownerShort}.${methName}">
                <span class="inv-linenum">${num}</span>
                <span class="inv-arrow">&#8594;</span>
                <span class="inv-owner">${esc(ownerShort)}</span><span class="inv-dot">.</span><span class="inv-method">${esc(methName)}</span><span class="inv-parens">()</span>${retType}
            </div>`;
        });

        return `<div class="invocations-block">
            <div class="inv-header">Method Body — ${invocations.length} calls</div>
            ${lines.join('')}
        </div>`;
    }
};
