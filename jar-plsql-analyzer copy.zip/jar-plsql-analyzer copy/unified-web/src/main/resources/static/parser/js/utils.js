window.PA = window.PA || {};

PA.esc = function(s) { return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
PA.escAttr = function(s) { return (s || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;'); };
PA.escJs = function(s) { return (s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'"); };

PA.toast = function(msg, type) {
    var el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast visible ' + (type || 'success');
    setTimeout(function() { el.className = 'toast'; }, 4000);
};

PA.getSchemaColor = function(schema) {
    var SCHEMA_COLORS = { 'DEFAULT': { bg: 'var(--bg)', fg: 'var(--text-secondary)' } };
    if (!schema) return SCHEMA_COLORS.DEFAULT;
    var upper = schema.toUpperCase();
    if (SCHEMA_COLORS[upper]) return SCHEMA_COLORS[upper];

    var palettes = [
        { bg: 'var(--badge-blue-bg)', fg: 'var(--badge-blue)' },
        { bg: 'var(--badge-teal-bg)', fg: 'var(--badge-teal)' },
        { bg: 'var(--badge-green-bg)', fg: 'var(--badge-green)' },
        { bg: 'var(--accent-subtle)', fg: 'var(--accent)' },
        { bg: 'var(--badge-red-bg)', fg: 'var(--badge-red)' },
        { bg: 'var(--badge-orange-bg)', fg: 'var(--badge-orange)' },
        { bg: 'var(--badge-yellow-bg)', fg: 'var(--badge-yellow)' },
        { bg: 'var(--badge-purple-bg)', fg: 'var(--badge-purple)' }
    ];
    var hash = 0;
    for (var c = 0; c < upper.length; c++) {
        hash = ((hash << 5) - hash + upper.charCodeAt(c)) | 0;
    }
    return palettes[Math.abs(hash) % palettes.length];
};

PA.formatDuration = function(ms) {
    if (!ms || ms <= 0) return '';
    if (ms < 1000) return ms + 'ms';
    var totalSecs = Math.floor(ms / 1000);
    var remMs = ms % 1000;
    if (totalSecs < 60) return totalSecs + 's ' + remMs + 'ms';
    var totalMins = Math.floor(totalSecs / 60);
    var secs = totalSecs % 60;
    if (totalMins < 60) return totalMins + 'm ' + secs + 's';
    var totalHours = Math.floor(totalMins / 60);
    var mins = totalMins % 60;
    if (totalHours < 24) return totalHours + 'h ' + mins + 'm ' + secs + 's';
    var days = Math.floor(totalHours / 24);
    var hours = totalHours % 24;
    return days + 'd ' + hours + 'h ' + mins + 'm ' + secs + 's';
};

PA.formatDurationShort = function(ms) {
    if (!ms || ms <= 0) return '';
    if (ms < 1000) return ms + 'ms';
    var secs = ms / 1000;
    if (secs < 60) return secs.toFixed(1) + 's';
    var mins = Math.floor(secs / 60);
    var remSecs = Math.round(secs % 60);
    if (mins < 60) return mins + 'm ' + remSecs + 's';
    var hours = Math.floor(mins / 60);
    mins = mins % 60;
    return hours + 'h ' + mins + 'm';
};

PA.context = {
    procId: null,
    procDetail: null,
    scopedTables: [],
    callTreeNodeIds: new Set()
};

// Builds underscore→dollar mapping from package index nodes (detailFile encodes dollar id)
PA._buildNodeIdMap = function() {
    var map = {};
    if (!PA.analysisData || !PA.analysisData.nodes) return map;
    PA.analysisData.nodes.forEach(function(n) {
        var underscoreId = (n.nodeId || '').toUpperCase();
        var detailFile = n.detailFile || '';
        // detailFile: "nodes/CUSTOMER$PKG$PROC.json" → dollar id = "CUSTOMER$PKG$PROC"
        var match = detailFile.match(/nodes\/(.+)\.json$/);
        if (match) {
            var dollarId = match[1].toUpperCase();
            if (dollarId !== underscoreId) map[underscoreId] = dollarId;
        }
    });
    return map;
};

PA._collectTreeNodeIds = function(tree, set, idMap) {
    if (!tree) return set || new Set();
    if (!set) set = new Set();
    if (idMap === undefined) idMap = PA._buildNodeIdMap();
    var rawId = (tree.id || tree.nodeId || '').toUpperCase();
    if (rawId) {
        set.add(rawId);
        // Also add the dollar-format equivalent for package analyses
        var dollId = idMap[rawId];
        if (dollId) set.add(dollId);
    }
    if (tree.children && !tree.circular) {
        for (var i = 0; i < tree.children.length; i++) {
            PA._collectTreeNodeIds(tree.children[i], set, idMap);
        }
    }
    return set;
};
