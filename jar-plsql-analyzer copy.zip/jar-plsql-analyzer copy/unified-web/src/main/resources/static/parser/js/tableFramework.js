/**
 * PA.tf — Shared Table Framework (pagination, filtering, sorting, column filters).
 *
 * Usage:
 *   PA.tf.init(id, data, pageSize, renderRow, opts)
 *   PA.tf.render(id)
 *   PA.tf.filter(id)
 *   PA.tf.sort(id, colIdx)
 *   PA.tf.goPage(id, p)
 *   PA.tf.setPageSize(id, sz)
 *
 * Options (opts):
 *   sortKeys:     { colIdx: { fn: item => comparable, desc?: bool } }
 *   renderDetail: (item, i, esc) => '<tr>...</tr>'  // expandable detail row
 *   domainFn:     item => domainString               // for domain filter dropdown
 *   onFilter:     () => void                         // callback after filter applied
 *   searchFn:     (item, query) => bool              // custom search (default: text match)
 *   extraFilter:  (item) => bool                     // additional filter predicate
 */
window.PA = window.PA || {};

PA.tf = {
    _state: {},

    /**
     * Initialize a paginated table.
     *
     * `data` is either a **materialised array** (the original behaviour, unchanged) or a
     * **page source** built by `PA.pageSource(url, params)`. A page source means only one page is
     * ever in memory, so search and sort have to be answered by the server — a client-side search
     * over one page looks like it worked while missing every other page. A converted call site
     * therefore declares `opts.serverSorts` and its search box is forwarded as `q`.
     *
     * @param {string} id - unique table id (used to find DOM elements: {id}-tbody, {id}-pager, etc.)
     * @param {Array|Object} data - full dataset, or a `PA.pageSource`
     * @param {number} pageSize - items per page
     * @param {Function} renderRow - (item, globalIndex, esc) => HTML string for <tr>
     * @param {Object} opts - see above, plus `serverSorts: { colIdx: {asc, desc} }`
     */
    init(id, data, pageSize, renderRow, opts) {
        opts = opts || {};
        const src = (window.PA && PA.isPageSource && PA.isPageSource(data)) ? data : null;
        const rows = src ? [] : (data || []);
        const s = {
            id,
            data: rows,
            filtered: src ? [] : [...rows],
            page: 0,
            pageSize: pageSize || 50,
            renderRow,
            renderDetail: opts.renderDetail || null,
            sortKeys: opts.sortKeys || {},
            sortCol: -1,
            sortDir: 'asc',
            domainFn: opts.domainFn || null,
            onFilter: opts.onFilter || null,
            searchFn: opts.searchFn || null,
            extraFilter: opts.extraFilter || null,
            searchQuery: '',
            domainFilter: '',
            colFilters: {},
            colFilterDefs: {},

            // --- server-paging state; all null/absent on the array path ---
            src: src,
            serverSorts: opts.serverSorts || null,
            pageCache: src ? {} : null,
            highestPage: 0,
            serverTotal: -1,
            totalIsExact: false,
            hasMore: false,
            loading: false,
            loadError: null
        };
        PA.tf._state[id] = s;
        // Page 1 is fetched here, and the promise is kept so a call site can wait for it. That
        // matters for anything that needs to know how many rows there are before deciding what
        // else to request — see the summary skip in sequences.js / cursors.js.
        if (src) s.firstLoad = PA.tf._fetch(id, 0);
        return s;
    },

    /** True when this table is backed by a page source rather than an array. */
    isServerPaged(id) {
        const s = PA.tf._state[id];
        return !!(s && s.src);
    },

    /**
     * Fetches one page from the source and renders it.
     *
     * Cursor paging only moves forward, so pages already seen are kept in `pageCache`; that is
     * what keeps the existing prev/next buttons working without ever asking the client to
     * construct a cursor.
     */
    _fetch(id, page) {
        const s = PA.tf._state[id];
        if (!s || !s.src || s.loading) return Promise.resolve();
        s.loading = true;
        s.loadError = null;
        PA.tf.render(id);
        return s.src.fetchPage(s.pageSize).then(env => {
            s.pageCache[page] = env.items;
            s.highestPage = Math.max(s.highestPage, page);
            s.hasMore = !!env.page.hasMore;
            s.serverTotal = env.page.total;
            s.totalIsExact = !!env.page.totalIsExact && env.page.total >= 0;
            s.page = page;
            s.filtered = env.items;
            s.loading = false;
            PA.tf.render(id);
            if (s.onFilter) s.onFilter();
            PA.tf._drainPendingRestart(id);
        }).catch(err => {
            s.loading = false;
            if (err && err.resultSetReplaced) {
                // A re-analysis replaced the result set mid-scroll. Restarting is the only correct
                // answer; offset paging would have quietly mixed rows from two runs.
                s.loadError = 'The analysis was re-run; showing the first page again.';
                PA.tf._restart(id);
                return;
            }
            s.loadError = String((err && err.message) || err);
            PA.tf.render(id);
            PA.tf._drainPendingRestart(id);
        });
    },

    /**
     * Runs a restart that arrived while a fetch was in flight.
     *
     * A page source owns a single cursor, so two overlapping fetches would advance it twice and
     * the second response would be a page nobody asked for. Restarts are therefore serialised
     * rather than fired concurrently — the alternative, dropping them, leaves the table showing
     * rows that do not match the filter the user just typed.
     */
    _drainPendingRestart(id) {
        const s = PA.tf._state[id];
        if (s && s._pendingRestart) {
            s._pendingRestart = false;
            PA.tf._restart(id);
        }
    },

    /** Drops every cached page and reloads page 1 — after a search, filter or sort change. */
    _restart(id) {
        const s = PA.tf._state[id];
        if (!s || !s.src) return;
        if (s.loading) { s._pendingRestart = true; return; }
        s.src.reset();
        s.pageCache = {};
        s.filtered = [];
        s.highestPage = 0;
        s.page = 0;
        s.serverTotal = -1;
        s.totalIsExact = false;
        PA.tf._fetch(id, 0);
    },

    /** How many pages the pager may offer; never a fabricated count. */
    _serverTotalPages(s) {
        if (s.totalIsExact) return Math.max(1, Math.ceil(s.serverTotal / s.pageSize));
        return s.highestPage + (s.hasMore ? 2 : 1);
    },

    /** Get state for a table */
    state(id) { return PA.tf._state[id]; },

    /** Set extra filter function (callable from outside, e.g. operation pills) */
    setExtraFilter(id, fn) {
        const s = PA.tf._state[id];
        if (s) { s.extraFilter = fn; }
    },

    /** Set search query programmatically */
    setSearch(id, query) {
        const s = PA.tf._state[id];
        if (s) { s.searchQuery = query; }
    },

    /** Set domain filter programmatically */
    setDomainFilter(id, domain) {
        const s = PA.tf._state[id];
        if (s) { s.domainFilter = domain; }
    },

    /** Replace data and re-render */
    setData(id, data) {
        const s = PA.tf._state[id];
        if (!s) return;
        if (window.PA && PA.isPageSource && PA.isPageSource(data)) {
            s.src = data;
            s.pageCache = {};
            PA.tf._restart(id);
            return;
        }
        // Swapping an array in over a page source would silently go back to client-side paging.
        if (s.src) { console.warn('[PA.tf] setData with an array on server-paged table', id); }
        s.data = data || [];
        s.page = 0;
        PA.tf.filter(id);
    },

    /** Apply all filters (search, domain, column, extra) and re-render */
    filter(id) {
        const s = PA.tf._state[id];
        if (!s) return;
        const esc = PA.esc || (v => v);

        if (s.src) {
            // Search moves to the server with pagination; filtering the one page in memory would
            // look like it worked and quietly miss the rest of the result set.
            //
            // Debounced, because the search box calls this on every keystroke. That cost nothing
            // when the filter ran over an array already in memory; unthrottled it would now be one
            // request per character, and out-of-order responses could leave the wrong page shown.
            clearTimeout(s._filterTimer);
            s._filterTimer = setTimeout(function () {
                s.src.setParam('q', (s.searchQuery || '').trim());
                // Only sent by a table that actually has a domain dropdown; sending it blindly
                // would rely on the server ignoring a parameter it does not know, which is the
                // habit that makes a mistyped filter look like it worked.
                if (s.domainFn) s.src.setParam('domain', s.domainFilter || '');
                PA.tf._restart(id);
            }, 200);
            return;
        }

        let list = s.data;

        // Search filter
        const q = (s.searchQuery || '').trim().toUpperCase();
        if (q) {
            if (s.searchFn) {
                list = list.filter(item => s.searchFn(item, q));
            } else {
                // Default: stringify and match
                list = list.filter(item => {
                    for (const v of Object.values(item)) {
                        if (v != null && String(v).toUpperCase().includes(q)) return true;
                    }
                    return false;
                });
            }
        }

        // Domain filter
        if (s.domainFilter && s.domainFn) {
            list = list.filter(item => s.domainFn(item) === s.domainFilter);
        }

        // Extra filter (operation pills, etc.)
        if (s.extraFilter) {
            list = list.filter(item => s.extraFilter(item));
        }

        // Column filters
        for (const [colIdx, selected] of Object.entries(s.colFilters)) {
            if (!selected || !selected.size) continue;
            const def = s.colFilterDefs[colIdx];
            if (!def) continue;
            list = list.filter(item => {
                const v = def.valueFn(item);
                if (Array.isArray(v)) return v.some(vi => selected.has(String(vi)));
                return selected.has(String(v));
            });
        }

        // Apply sort
        if (s.sortCol >= 0 && s.sortKeys[s.sortCol]) {
            const sk = s.sortKeys[s.sortCol];
            const fn = sk.fn;
            const dir = s.sortDir === 'desc' ? -1 : 1;
            list = [...list].sort((a, b) => {
                const va = fn(a), vb = fn(b);
                if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
                return String(va || '').localeCompare(String(vb || '')) * dir;
            });
        }

        s.filtered = list;

        // Clamp page
        const totalPages = Math.ceil(list.length / s.pageSize) || 1;
        if (s.page >= totalPages) s.page = totalPages - 1;
        if (s.page < 0) s.page = 0;

        PA.tf.render(id);

        if (s.onFilter) s.onFilter();
    },

    /** Sort by column index — toggle asc/desc */
    sort(id, colIdx) {
        const s = PA.tf._state[id];
        if (!s) return;
        if (s.src) {
            // Only through the endpoint's closed enum — a free-form column name would be both an
            // injection surface and an unindexed-scan surface. A column the endpoint cannot sort
            // on is simply not offered, rather than sorting the current page and looking right.
            const names = s.serverSorts && s.serverSorts[colIdx];
            if (!names) {
                console.warn('[PA.tf] no server sort declared for column', colIdx, 'of', id);
                return;
            }
            const dir = s.sortCol === colIdx ? (s.sortDir === 'asc' ? 'desc' : 'asc') : 'asc';
            const enumName = dir === 'asc' ? names.asc : names.desc;
            if (!enumName) return;
            s.sortCol = colIdx;
            s.sortDir = dir;
            s.src.setParam('sort', enumName);
            PA.tf._updateSortIndicators(id);
            PA.tf._restart(id);
            return;
        }
        if (s.sortCol === colIdx) {
            s.sortDir = s.sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            s.sortCol = colIdx;
            s.sortDir = 'asc';
        }
        PA.tf._updateSortIndicators(id);
        PA.tf.filter(id);
    },

    /**
     * Sets the initial server sort without a user click, for a table whose default order differs
     * from the endpoint's natural one. Must be called before the first fetch completes to avoid a
     * wasted request; `init` returns the state so a call site can set it immediately.
     */
    setServerSort(id, colIdx, dir) {
        const s = PA.tf._state[id];
        if (!s || !s.src) return;
        const names = s.serverSorts && s.serverSorts[colIdx];
        const enumName = names && (dir === 'desc' ? names.desc : names.asc);
        if (!enumName) return;
        s.sortCol = colIdx;
        s.sortDir = dir === 'desc' ? 'desc' : 'asc';
        s.src.setParam('sort', enumName);
    },

    /** Navigate to page */
    goPage(id, p) {
        const s = PA.tf._state[id];
        if (!s) return;
        if (s.src) {
            if (p < 0 || s.loading) return;
            if (s.pageCache[p] !== undefined) {
                s.page = p;
                s.filtered = s.pageCache[p];
                PA.tf.render(id);
                if (s.onFilter) s.onFilter();
                return;
            }
            // Only the page directly after the furthest one fetched is addressable — anything
            // beyond it would need a cursor the server has never handed us.
            if (p === s.highestPage + 1 && s.hasMore) PA.tf._fetch(id, p);
            return;
        }
        s.page = Math.max(0, Math.min(p, Math.ceil(s.filtered.length / s.pageSize) - 1));
        PA.tf.render(id);
    },

    /** Change page size */
    setPageSize(id, sz) {
        const s = PA.tf._state[id];
        if (!s) return;
        s.pageSize = sz;
        s.page = 0;
        // The page size is the server's `limit`, so every cached page was cut at the old size.
        if (s.src) { PA.tf._restart(id); return; }
        PA.tf.render(id);
    },

    /** Render current page into DOM */
    render(id) {
        const s = PA.tf._state[id];
        if (!s) return;
        const esc = PA.esc || (v => v);

        const tbody = document.getElementById(id + '-tbody');
        if (!tbody) return;

        // Server-paged: the response IS the page, there is nothing to slice.
        const serverPaged = !!s.src;
        const total = serverPaged ? s.serverTotal : s.filtered.length;
        const totalPages = serverPaged
            ? PA.tf._serverTotalPages(s)
            : (Math.ceil(total / s.pageSize) || 1);
        const start = s.page * s.pageSize;
        const pageData = serverPaged
            ? (s.pageCache[s.page] || [])
            : s.filtered.slice(start, Math.min(start + s.pageSize, total));

        if (serverPaged && s.loading && pageData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="20" class="empty-msg" style="padding:20px;text-align:center">Loading…</td></tr>';
        } else if (serverPaged && s.loadError) {
            tbody.innerHTML = '<tr><td colspan="20" class="empty-msg" style="padding:20px;text-align:center">'
                + (PA.esc ? PA.esc(s.loadError) : s.loadError) + '</td></tr>';
        } else if (pageData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="20" class="empty-msg" style="padding:20px;text-align:center">No data found</td></tr>';
        } else {
            let html = '';
            for (let i = 0; i < pageData.length; i++) {
                const globalIdx = start + i;
                html += s.renderRow(pageData[i], globalIdx, esc);
                // Detail row (lazy placeholder)
                if (s.renderDetail) {
                    html += `<tr class="to-detail-row" id="${id}-detail-${globalIdx}" style="display:none" data-lazy="1"><td colspan="20"></td></tr>`;
                }
            }
            tbody.innerHTML = html;
        }

        // Render pager (bottom)
        PA.tf._renderPager(id, total, totalPages);
        // Render pager (top, if exists)
        PA.tf._renderPager(id + '-top', total, totalPages, id);
    },

    /** Toggle detail row */
    toggleDetail(id, idx) {
        const row = document.getElementById(id + '-detail-' + idx);
        if (!row) return;
        const s = PA.tf._state[id];
        if (!s) return;

        // Lazy render on first open. `idx` is the global row index; in server-paged mode
        // `s.filtered` holds only the current page, so it has to be rebased.
        if (row.dataset.lazy && s.renderDetail) {
            const item = s.src ? s.filtered[idx - s.page * s.pageSize] : s.filtered[idx];
            if (item) {
                const esc = PA.esc || (v => v);
                row.innerHTML = '<td colspan="20">' + s.renderDetail(item, idx, esc) + '</td>';
            }
            delete row.dataset.lazy;
        }

        const visible = row.classList.contains('open');
        row.classList.toggle('open', !visible);
        row.style.display = visible ? 'none' : 'table-row';
        const parentRow = row.previousElementSibling;
        if (parentRow) parentRow.classList.toggle('expanded', !visible);
    },

    // ==================== COLUMN FILTERS ====================

    /**
     * Register column filters for a table.
     * @param {string} id - table id
     * @param {Object} columns - { colIdx: { label, valueFn: item => string|string[] } }
     */
    initColFilters(id, columns, serverValues) {
        const s = PA.tf._state[id];
        if (!s) return;
        if (s.src && !serverValues) {
            // The value list in a popover is collected from the whole dataset, and in server-paged
            // mode only one page is in memory. Showing the icon would offer this page's values and
            // filter to a subset of one page — visibly wrong. A converted call site must pass the
            // `columnValues` map from the facet summary instead; without it, no icon is the honest
            // answer.
            console.warn('[PA.tf] column filters need serverValues on server-paged table', id);
            return;
        }
        s.colFilterValues = serverValues || null;
        s.colFilterDefs = columns;
        s.colFilters = {};

        const FILTER_SVG = '<svg viewBox="0 0 16 16" width="11" height="11" fill="currentColor" style="vertical-align:-1px;margin-left:3px"><path d="M1 2h14l-5 6v5l-4 2V8z"/></svg>';

        // Find the table element
        const tbody = document.getElementById(id + '-tbody');
        const table = tbody?.closest('table');
        if (!table) return;

        // Attach filter icons to headers
        table.querySelectorAll('th').forEach((th, thIdx) => {
            const ci = th.dataset.sortCol != null ? parseInt(th.dataset.sortCol) : thIdx;
            if (!columns[ci]) return;
            if (th.querySelector('.cf-icon')) return;
            th.style.position = 'relative';
            const btn = document.createElement('span');
            btn.className = 'cf-icon';
            btn.title = 'Filter ' + columns[ci].label;
            btn.innerHTML = FILTER_SVG;
            btn.onclick = (e) => { e.stopPropagation(); PA.tf._cfToggle(id, ci, th); };
            th.appendChild(btn);
        });
    },

    _cfToggle(id, colIdx, thEl) {
        PA.tf._cfClose();
        const s = PA.tf._state[id];
        if (!s || !s.colFilterDefs[colIdx]) return;
        const def = s.colFilterDefs[colIdx];

        const allValues = PA.tf._cfValues(s, colIdx);
        if (!allValues.length) return;

        const active = s.colFilters[colIdx];
        const esc = PA.esc || (v => v);

        const rect = thEl.getBoundingClientRect();
        const pop = document.createElement('div');
        pop.className = 'cf-popover';
        pop.id = 'cf-popover';
        pop.style.top = (rect.bottom + window.scrollY + 2) + 'px';
        pop.style.left = Math.max(0, rect.left + window.scrollX - 40) + 'px';

        let html = `<div class="cf-header">${esc(def.label)}</div>`;
        html += '<div class="cf-actions"><button class="cf-btn" onclick="PA.tf._cfSelectAll()">All</button>';
        html += '<button class="cf-btn" onclick="PA.tf._cfSelectNone()">None</button></div>';
        html += '<div class="cf-list">';
        for (const v of allValues) {
            const checked = !active || active.has(v) ? 'checked' : '';
            html += `<label class="cf-item"><input type="checkbox" value="${PA.escAttr ? PA.escAttr(v) : v}" ${checked}><span>${esc(v)}</span></label>`;
        }
        html += '</div>';
        html += `<div class="cf-footer">`;
        html += `<button class="cf-apply" onclick="PA.tf._cfApply('${id}',${colIdx})">Apply</button>`;
        html += `<button class="cf-btn" onclick="PA.tf._cfClear('${id}',${colIdx})">Clear</button>`;
        html += `<button class="cf-cancel" onclick="PA.tf._cfClose()">Cancel</button>`;
        html += '</div>';
        pop.innerHTML = html;
        document.body.appendChild(pop);

        setTimeout(() => {
            PA.tf._cfOutsideHandler = (e) => {
                if (!pop.contains(e.target)) PA.tf._cfClose();
            };
            document.addEventListener('click', PA.tf._cfOutsideHandler, true);
        }, 0);
    },

    _cfClose() {
        const pop = document.getElementById('cf-popover');
        if (pop) pop.remove();
        if (PA.tf._cfOutsideHandler) {
            document.removeEventListener('click', PA.tf._cfOutsideHandler, true);
            PA.tf._cfOutsideHandler = null;
        }
    },

    _cfSelectAll() {
        const pop = document.getElementById('cf-popover');
        if (pop) pop.querySelectorAll('input[type=checkbox]').forEach(cb => { cb.checked = true; });
    },

    _cfSelectNone() {
        const pop = document.getElementById('cf-popover');
        if (pop) pop.querySelectorAll('input[type=checkbox]').forEach(cb => { cb.checked = false; });
    },

    _cfApply(id, colIdx) {
        const pop = document.getElementById('cf-popover');
        if (!pop) return;
        const s = PA.tf._state[id];
        if (!s) return;

        const selected = new Set();
        pop.querySelectorAll('input[type=checkbox]:checked').forEach(cb => selected.add(cb.value));

        // If all selected → remove filter
        if (selected.size >= PA.tf._cfValues(s, colIdx).length) {
            delete s.colFilters[colIdx];
        } else {
            s.colFilters[colIdx] = selected;
        }

        PA.tf._cfClose();
        PA.tf._cfUpdateIcons(id);
        if (s.src) { PA.tf._cfPush(id); return; }
        PA.tf.filter(id);
    },

    /**
     * The values a column's popover offers.
     *
     * Server-paged tables read them from the facet summary; array-backed tables collect them from
     * the dataset they hold. Both the popover and the "everything is ticked, so drop the filter"
     * test go through here, so those two can never disagree about what "all" means.
     */
    _cfValues(s, colIdx) {
        if (s.src) {
            const vals = s.colFilterValues && s.colFilterValues[String(colIdx)];
            return vals ? vals.slice() : [];
        }
        const def = s.colFilterDefs[colIdx];
        if (!def) return [];
        const valSet = new Set();
        for (const item of s.data) {
            const v = def.valueFn(item);
            if (Array.isArray(v)) { for (const vi of v) { if (vi != null && vi !== '') valSet.add(String(vi)); } }
            else if (v != null && v !== '') valSet.add(String(v));
        }
        return [...valSet].sort();
    },

    /** Sends the current column filters as repeated `cf=<col>:<v>|<v>` and reloads page 1. */
    _cfPush(id) {
        const s = PA.tf._state[id];
        if (!s || !s.src) return;
        const cf = [];
        for (const [colIdx, selected] of Object.entries(s.colFilters)) {
            if (!selected || !selected.size) continue;
            cf.push(colIdx + ':' + [...selected].join('|'));
        }
        s.src.setParam('cf', cf);
        PA.tf._restart(id);
    },

    _cfClear(id, colIdx) {
        const s = PA.tf._state[id];
        if (s) delete s.colFilters[colIdx];
        PA.tf._cfClose();
        PA.tf._cfUpdateIcons(id);
        if (s && s.src) { PA.tf._cfPush(id); return; }
        PA.tf.filter(id);
    },

    _cfUpdateIcons(id) {
        const s = PA.tf._state[id];
        if (!s) return;
        const tbody = document.getElementById(id + '-tbody');
        const table = tbody?.closest('table');
        if (!table) return;
        table.querySelectorAll('.cf-icon').forEach(icon => {
            const th = icon.closest('th');
            if (!th) return;
            const ci = th.dataset.sortCol != null ? parseInt(th.dataset.sortCol) : [...th.parentElement.children].indexOf(th);
            icon.classList.toggle('cf-active', !!(s.colFilters[ci] && s.colFilters[ci].size));
        });
    },

    // ==================== SORT INDICATORS ====================

    _updateSortIndicators(id) {
        const s = PA.tf._state[id];
        if (!s) return;
        const tbody = document.getElementById(id + '-tbody');
        const table = tbody?.closest('table');
        if (!table) return;
        table.querySelectorAll('th[data-sort-col]').forEach(th => {
            const ci = parseInt(th.dataset.sortCol);
            th.classList.remove('sort-asc', 'sort-desc');
            if (ci === s.sortCol) {
                th.classList.add(s.sortDir === 'desc' ? 'sort-desc' : 'sort-asc');
            }
        });
    },

    // ==================== PAGINATION ====================

    /**
     * The pager for server-paged mode.
     *
     * Narrower than the array pager on purpose: a cursor cannot jump to page 12, so only pages
     * already fetched plus the next one are offered, and when the server reports the total is not
     * exact we render "Page 3" with a next arrow instead of inventing "Page 3 of 17".
     */
    _serverPagerHtml(id, s) {
        const shown = (s.pageCache[s.page] || []).length;
        const start = s.page * s.pageSize;
        let html = '<div class="page-info">';
        if (s.loading) html += 'Loading…';
        else if (s.totalIsExact) html += s.serverTotal + ' items';
        else html += (shown ? (start + 1) : 0) + '–' + (start + shown);
        html += '</div>';

        html += `<div class="page-size"><select onchange="PA.tf.setPageSize('${id}',+this.value)">`;
        for (const sz of [10, 20, 50, 100]) {
            html += `<option value="${sz}" ${s.pageSize === sz ? 'selected' : ''}>${sz}/page</option>`;
        }
        html += '</select></div>';

        const busy = s.loading;
        html += '<div class="page-btns">';
        html += `<button onclick="PA.tf.goPage('${id}',0)" ${s.page <= 0 || busy ? 'disabled' : ''} title="First page">&laquo;</button>`;
        html += `<button onclick="PA.tf.goPage('${id}',${s.page - 1})" ${s.page <= 0 || busy ? 'disabled' : ''} title="Previous page">&lsaquo;</button>`;
        if (s.totalIsExact) {
            const totalPages = PA.tf._serverTotalPages(s);
            let startP = Math.max(0, s.page - 3), endP = Math.min(totalPages - 1, startP + 6);
            if (endP - startP < 6) startP = Math.max(0, endP - 6);
            for (let i = startP; i <= endP; i++) {
                const reachable = s.pageCache[i] !== undefined || i === s.highestPage + 1;
                html += `<button onclick="PA.tf.goPage('${id}',${i})" class="${i === s.page ? 'active' : ''}" `
                     + `${reachable && !busy ? '' : 'disabled'}>${i + 1}</button>`;
            }
        } else {
            html += `<button class="active" disabled>${s.page + 1}</button>`;
        }
        const canNext = s.hasMore || s.pageCache[s.page + 1] !== undefined;
        html += `<button onclick="PA.tf.goPage('${id}',${s.page + 1})" ${canNext && !busy ? '' : 'disabled'} title="Next page">&rsaquo;</button>`;
        html += '</div>';
        if (s.loadError) {
            html += '<div class="page-info" style="color:var(--red,#c00)">'
                + (PA.esc ? PA.esc(s.loadError) : s.loadError) + '</div>';
        }
        return html;
    },

    _renderPager(pagerId, total, totalPages, tableId) {
        const bar = document.getElementById(pagerId + '-pager') || document.getElementById(pagerId);
        if (!bar) return;
        const id = tableId || pagerId;
        const s = PA.tf._state[id];
        if (!s) return;

        // Show the pager whenever there is data (was: only when > 20 rows). This makes the
        // count + rows-per-page control visible for small lists too; the page nav buttons
        // are shown only when there is more than one page.
        if (total === 0) { bar.style.display = 'none'; return; }
        bar.style.display = '';

        // Show pagination ABOVE the table (user preference): the pager markup sits
        // right after its table container in the HTML — move it to just before the
        // container, once. Generic across every tf table.
        if (!bar.dataset.movedTop) {
            var prev = bar.previousElementSibling;
            if (prev) bar.parentNode.insertBefore(bar, prev);
            bar.dataset.movedTop = '1';
        }

        if (s.src) { bar.innerHTML = PA.tf._serverPagerHtml(id, s); return; }

        const p = s.page;
        let html = '<div class="page-info">' + total + ' items</div>';
        html += `<div class="page-size"><select onchange="PA.tf.setPageSize('${id}',+this.value)">`;
        for (const sz of [10, 20, 50, 100]) {
            html += `<option value="${sz}" ${s.pageSize === sz ? 'selected' : ''}>${sz}/page</option>`;
        }
        html += `<option value="${total}" ${s.pageSize >= total ? 'selected' : ''}>All</option>`;
        html += '</select></div>';

        if (totalPages > 1) {
            html += '<div class="page-btns">';
            html += `<button onclick="PA.tf.goPage('${id}',0)" ${p <= 0 ? 'disabled' : ''} title="First page">&laquo;</button>`;
            html += `<button onclick="PA.tf.goPage('${id}',${p - 1})" ${p <= 0 ? 'disabled' : ''} title="Previous page">&lsaquo;</button>`;

            let startP = Math.max(0, p - 3), endP = Math.min(totalPages - 1, startP + 6);
            if (endP - startP < 6) startP = Math.max(0, endP - 6);
            for (let i = startP; i <= endP; i++) {
                html += `<button onclick="PA.tf.goPage('${id}',${i})" class="${i === p ? 'active' : ''}">${i + 1}</button>`;
            }

            html += `<button onclick="PA.tf.goPage('${id}',${p + 1})" ${p >= totalPages - 1 ? 'disabled' : ''} title="Next page">&rsaquo;</button>`;
            html += `<button onclick="PA.tf.goPage('${id}',${totalPages - 1})" ${p >= totalPages - 1 ? 'disabled' : ''} title="Last page">&raquo;</button>`;
            html += '</div>';
        }
        bar.innerHTML = html;
    }
};
