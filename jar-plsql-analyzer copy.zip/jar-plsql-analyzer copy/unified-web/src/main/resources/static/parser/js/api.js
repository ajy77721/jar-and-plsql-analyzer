window.PA = window.PA || {};

PA.api = {
    _analysisName: null,

    setAnalysis(name) { PA.api._analysisName = name; },

    /** Clear the in-memory analysis cache. Pass a name to clear one analysis, omit for all. */
    async clearCache(name) {
        const url = '/api/parser/cache/clear' + (name ? '?name=' + encodeURIComponent(name) : '');
        const res = await fetch(url, { method: 'POST' });
        if (!res.ok) throw new Error('clear cache failed');
        return res.json();
    },

    async listHistory() {
        const res = await fetch('/api/parser/analyses');
        if (!res.ok) return PA.apiFail(res);
        return res.json();
    },

    /**
     * History as projected rows (Q31): `errorCount` instead of `errors[]`, `dbType` derived by the
     * server, no `jdbcUrl`.
     *
     * @param opts {limit, q, cf} — `cf` is a list of `<column>:<v1>|<v2>` column filters
     */
    async listHistoryPage(opts) {
        var o = opts || {};
        var params = new URLSearchParams();
        params.set('limit', o.limit || 200);
        params.set('sort', o.sort || 'TIME_DESC');
        if (o.q) params.set('q', o.q);
        (o.cf || []).forEach(function (f) { params.append('cf', f); });
        const res = await fetch('/api/parser/analyses?' + params.toString(),
            { headers: { 'Accept': PA.PAGE_MEDIA_TYPE } });
        if (!res.ok) { PA.apiFail(res); return null; }
        return PA.normalizePage(await res.json());
    },

    /**
     * Counts, dropdown values and running totals for the current filter (Q31).
     *
     * These were recomputed in the browser over the whole history on every keystroke, twice — once
     * for the History toolbar and once for the Performance Summary's stat cards.
     */
    async historyFacets(opts) {
        var o = opts || {};
        var params = new URLSearchParams();
        if (o.q) params.set('q', o.q);
        (o.cf || []).forEach(function (f) { params.append('cf', f); });
        const qs = params.toString();
        const res = await fetch('/api/parser/analyses/facets' + (qs ? '?' + qs : ''));
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    /** The error messages of one analysis — fetched only when a detail panel shows them. */
    async analysisErrors(name) {
        const res = await fetch('/api/parser/analyses/' + encodeURIComponent(name) + '/errors');
        if (!res.ok) return PA.apiFail(res);
        return (await res.json()).errors || [];
    },

    async runAnalysis(entryPoint, body) {
        const payload = body || { entryPoint: entryPoint };
        if (!payload.entryPoint) payload.entryPoint = entryPoint;
        const res = await fetch('/api/parser/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return res.json();
    },

    async getIndex() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/index`);
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getProcedures() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/procedures`);
        if (!res.ok) return PA.apiFail(res);
        return res.json();
    },

    async getNodeDetail(nodeFile) {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/node/${encodeURIComponent(nodeFile)}`);
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getTableOperations() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/tables`);
        if (!res.ok) return PA.apiFail(res);
        const data = await res.json();
        return (data.tables || []).filter(t => t.dbValidated !== true || t.dbFound !== false).map(t => ({
            tableName: t.name,
            tableSchema: t.schema || '',
            objectType: t.objectType || 'TABLE',
            triggers: t.triggers || [],
            operations: t.allOperations || [],
            accessCount: (t.usedBy || []).reduce((sum, u) => {
                return sum + Object.values(u.operations || {}).reduce((s, lines) => s + lines.length, 0);
            }, 0),
            accessDetails: (t.usedBy || []).flatMap(u => {
                return Object.entries(u.operations || {}).flatMap(([op, lines]) => {
                    return (lines || []).map(line => ({
                        operation: op,
                        procedureId: u.nodeId || '',
                        procedureName: u.nodeName || '',
                        lineNumber: line,
                        sourceFile: ''
                    }));
                });
            })
        }));
    },

    // Table counts only. The topbar needs one integer; fetching the whole index for it cost
    // 152 KB measured (~307 KB at the largest observed) on every analysis load.
    async getTablesSummary() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/tables/summary`);
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getTablesIndex() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/tables`);
        if (!res.ok) { PA.apiFail(res); return null; }
        const data = await res.json();
        if (data && Array.isArray(data.tables)) {
            data.tables = data.tables.filter(t => t.dbValidated !== true || t.dbFound !== false);
        }
        return data;
    },

    async getJoinOperations() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/joins`);
        if (!res.ok) return PA.apiFail(res);
        const data = await res.json();
        return Array.isArray(data) ? data : (data.joins || data.items || []);
    },

    async getCursorOperations() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/cursors`);
        if (!res.ok) return PA.apiFail(res);
        const data = await res.json();
        return Array.isArray(data) ? data : (data.cursors || data.items || []);
    },

    async getSequenceOperations() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/sequences`);
        if (!res.ok) return PA.apiFail(res);
        const data = await res.json();
        return Array.isArray(data) ? data : (data.sequences || data.items || []);
    },

    /*
     * Paged facets (PLAN-08 §4.3 step 12).
     *
     * A page source hands the pager one page at a time instead of the whole facet. The parameters
     * that used to be applied in the browser — search, sort, filter pills, column filters and the
     * Direct/Subtree/SubFlow scope — travel with the request, because with one page in memory
     * applying any of them client-side would filter that page and look convincing while being
     * wrong.
     */

    /** A `PA.pageSource` over a converted facet endpoint. */
    facetPageSource(facet, params) {
        const name = PA.api._analysisName;
        return PA.pageSource(
            `/api/parser/analyses/${encodeURIComponent(name)}/${facet}`, params || {});
    },

    /**
     * Header counts and filter value lists for a converted facet: `{total, scopedTotal,
     * typeCounts, types, columnValues}`. These came off the full array before; one small request
     * replaces reading a multi-megabyte one.
     */
    async facetSummary(facet, params) {
        const name = PA.api._analysisName;
        const q = new URLSearchParams();
        Object.keys(params || {}).forEach(k => {
            const v = params[k];
            if (v !== null && v !== undefined && v !== '') q.set(k, v);
        });
        const url = `/api/parser/analyses/${encodeURIComponent(name)}/${facet}/summary`
            + (q.toString() ? '?' + q.toString() : '');
        const res = await fetch(url);
        // 204 means the analysis has no such facet at all — a different answer from "zero rows
        // matched", and the caller renders it differently.
        if (res.status === 204) return null;
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getDynamicSql() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/dynamic-sql`);
        if (!res.ok) return PA.apiFail(res);
        const data = await res.json();
        return Array.isArray(data) ? data : (data.items || []);
    },

    async dbTableInfo(tableName, schema) {
        let url = `/api/plsql/db/table-info/${encodeURIComponent(tableName)}`;
        if (schema) url += `?schema=${encodeURIComponent(schema)}`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async getCallTree(nodeId) {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/call-tree/${encodeURIComponent(nodeId)}`);
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getCallerTree(nodeId) {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/call-tree/${encodeURIComponent(nodeId)}/callers`);
        if (!res.ok) return PA.apiFail(res);
        return res.json();
    },

    async getCallGraph() {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/call-graph`);
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getSource(sourceFile) {
        const name = PA.api._analysisName;
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(name)}/source/${encodeURIComponent(sourceFile)}`);
        if (!res.ok) { PA.apiFail(res); return null; }
        const text = await res.text();
        return { content: text, owner: '', objectName: sourceFile };
    },

    async claudeStatus() {
        const res = await fetch('/api/parser/claude/status');
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeVerify(analysisName, resume) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ resume: !!resume })
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeProgress(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/progress`);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    // The seven scalars the verification grids render. The full result document is 138,301 bytes
    // measured; five screens were fetching all of it to show three to seven numbers.
    // Returns null for 204 (never verified) and throws for a real failure, so a caller can tell
    // "no data" from "broken" — conflating the two is what hid a permanently empty grid.
    async claudeVerificationSummary(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/verification-summary`);
        if (res.status === 204) return null;
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeResult(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/result`);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeChunksSummary(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/chunks/summary`);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeChunkDetail(analysisName, chunkId) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/chunks/${encodeURIComponent(chunkId)}`);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeKillSession(analysisName, sessionId) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/sessions/${encodeURIComponent(sessionId)}/kill`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeVersions(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/versions`);
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeLoadStatic(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/versions/load-static`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeLoadClaude(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/versions/load-claude`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeRevert(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/versions/revert`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeReview(analysisName, payload) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/review`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeLoadPrev(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/versions/load-prev`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async claudeApply(analysisName) {
        const res = await fetch(`/api/parser/analyses/${encodeURIComponent(analysisName)}/claude/apply`, {
            method: 'POST'
        });
        if (!res.ok) throw new Error(res.status + '');
        return res.json();
    },

    async getComplexityConfig() {
        const res = await fetch('/api/parser/config/complexity');
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    },

    async getJoinComplexityConfig() {
        const res = await fetch('/api/parser/config/join-complexity');
        if (!res.ok) { PA.apiFail(res); return null; }
        return res.json();
    }
};
