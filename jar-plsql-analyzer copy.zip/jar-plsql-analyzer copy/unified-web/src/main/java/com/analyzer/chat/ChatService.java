package com.analyzer.chat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.plsqlanalyzer.web.service.ClaudeProcessRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.analyzer.storage.ArtifactEntry;
import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

public class ChatService {

    private static final Logger log = LoggerFactory.getLogger(ChatService.class);
    private static final int MAX_CONTEXT_MESSAGES = 20;
    private static final int CLAUDE_TIMEOUT_SECONDS = 300;

    private final ClaudeProcessRunner processRunner;
    /** {@code claude-chatbot/} under the data root. */
    private static final String CHAT_ROOT = "claude-chatbot";
    private final ArtifactStore store;
    private final ObjectMapper mapper;
    private final ConcurrentHashMap<String, ReentrantLock> sessionLocks = new ConcurrentHashMap<>();

    private AnalysisContextProvider jarContextProvider;
    private AnalysisContextProvider plsqlContextProvider;

    private static final List<String> CHAT_TYPES = List.of("classic", "new");

    public ChatService(ClaudeProcessRunner processRunner, ArtifactStore store) {
        this.processRunner = processRunner;
        this.store = Objects.requireNonNull(store, "ArtifactStore is required");
        this.mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        // No directory creation: the store makes parents on write, and an object store has none.
    }

    // ── Locations ─────────────────────────────────────────────────────────────

    private static ArtifactKey chatDir(String chatType) {
        return ArtifactKey.of(CHAT_ROOT, chatType);
    }

    private static ArtifactKey sessionKey(String chatType, String id) {
        return chatDir(chatType).resolve(id + ".json");
    }

    /**
     * Session ids and chat types arrive from REST paths and become key segments. The old
     * {@code Path.resolve} form would have followed a {@code ..}; the guard is explicit now that
     * there is no base path to compare against.
     */
    private static boolean badSegment(String s) {
        return s == null || s.isBlank() || s.contains("..") || s.contains("/") || s.contains("\\");
    }

    private InputStream openRead(ArtifactKey key) throws IOException { return store.read(key); }

    private OutputStream openWrite(ArtifactKey key) throws IOException { return store.write(key); }

    public ChatSession createSession(String name, String scope, String chatType, Map<String, String> scopeContext) {
        ChatSession session = new ChatSession(name, scope, chatType, scopeContext);
        saveSession(session);
        log.info("Created chat session: {} [{}] scope={} type={}", session.getId(), name, scope, session.getChatType());
        return session;
    }

    public List<Map<String, Object>> listSessions(String scopeFilter, String chatType) {
        List<Map<String, Object>> summaries = new ArrayList<>();
        if (chatType != null && badSegment(chatType)) return summaries;
        List<ArtifactKey> dirs = chatType != null
                ? List.of(chatDir(chatType))
                : List.of(chatDir("classic"), chatDir("new"));

        for (ArtifactKey dir : dirs) {
            try (var files = store.list(dir, false)) {
                files.filter(java.util.function.Predicate.not(ArtifactEntry::directory))
                        .map(ArtifactEntry::key)
                        .filter(k -> k.leaf().endsWith(".json"))
                        .forEach(p -> {
                            try (InputStream in = openRead(p)) {
                                ChatSession s = mapper.readValue(in, ChatSession.class);
                                if (scopeFilter != null && !scopeFilter.equalsIgnoreCase(s.getScope())) return;
                                Map<String, Object> summary = new LinkedHashMap<>();
                                summary.put("id", s.getId());
                                summary.put("name", s.getName());
                                summary.put("scope", s.getScope());
                                summary.put("chatType", s.getChatType());
                                summary.put("messageCount", s.getMessages().size());
                                summary.put("createdAt", s.getCreatedAt());
                                summary.put("updatedAt", s.getUpdatedAt());
                                summaries.add(summary);
                            } catch (IOException e) {
                                log.debug("Failed to read session file {}: {}", p, e.getMessage());
                            }
                        });
            } catch (IOException e) {
                log.error("Failed to list sessions in {}: {}", dir, e.getMessage());
            }
        }

        summaries.sort((a, b) -> {
            Instant ua = (Instant) b.get("updatedAt");
            Instant ub = (Instant) a.get("updatedAt");
            if (ua == null || ub == null) return 0;
            return ua.compareTo(ub);
        });
        return summaries;
    }

    public ChatSession getSession(String id) {
        if (badSegment(id)) return null;
        for (String type : CHAT_TYPES) {
            ArtifactKey file = sessionKey(type, id);
            if (store.exists(file)) {
                try (InputStream in = openRead(file)) {
                    return mapper.readValue(in, ChatSession.class);
                } catch (IOException e) {
                    log.error("Failed to read session {}: {}", id, e.getMessage());
                    return null;
                }
            }
        }
        ArtifactKey legacy = ArtifactKey.of(CHAT_ROOT, id + ".json");
        if (store.exists(legacy)) {
            try (InputStream in = openRead(legacy)) {
                return mapper.readValue(in, ChatSession.class);
            } catch (IOException e) {
                log.error("Failed to read legacy session {}: {}", id, e.getMessage());
            }
        }
        return null;
    }

    /**
     * The session document as bytes, or null if there is no such session — Q67's input.
     *
     * <p>Separate from {@link #getSession} because the transcript is paged by streaming the
     * {@code messages} array, and {@code getSession} exists precisely to deserialise all of it.
     * Resolution is the same three-way lookup (typed folder, then the legacy flat file) so a
     * session paged is the same session read.
     */
    InputStream openSessionDocument(String id) throws IOException {
        if (badSegment(id)) return null;
        for (String type : CHAT_TYPES) {
            ArtifactKey file = sessionKey(type, id);
            if (store.exists(file)) return openRead(file);
        }
        ArtifactKey legacy = ArtifactKey.of(CHAT_ROOT, id + ".json");
        return store.exists(legacy) ? openRead(legacy) : null;
    }

    /**
     * One backward page of a session's transcript.
     *
     * @return null when the session does not exist, which the controller answers with 404 —
     *         distinct from an existing session whose filter matched nothing (an empty page)
     */
    public com.analyzer.storage.page.Page<com.fasterxml.jackson.databind.JsonNode> messages(
            String id, Long before, Integer limit, String query) throws IOException {
        if (badSegment(id)) return null;
        boolean exists = false;
        for (String type : CHAT_TYPES) {
            if (store.exists(sessionKey(type, id))) { exists = true; break; }
        }
        if (!exists && !store.exists(ArtifactKey.of(CHAT_ROOT, id + ".json"))) return null;
        return new ChatTranscriptReader(mapper)
                .read(() -> openSessionDocument(id), before, limit, query);
    }

    public boolean deleteSession(String id) {
        if (badSegment(id)) return false;
        sessionLocks.remove(id);
        for (String type : CHAT_TYPES) {
            if (store.delete(sessionKey(type, id))) return true;
        }
        return store.delete(ArtifactKey.of(CHAT_ROOT, id + ".json"));
    }

    public ChatMessage sendMessage(String sessionId, String userMessage, String pageContext) {
        ChatSession session = getSession(sessionId);
        if (session == null) return null;

        ReentrantLock lock = sessionLocks.computeIfAbsent(sessionId, k -> new ReentrantLock());
        if (!lock.tryLock()) {
            return new ChatMessage("assistant", "A message is already being processed for this session. Please wait.");
        }
        try {
            session.getMessages().add(new ChatMessage("user", userMessage));

            String prompt = buildPrompt(session, userMessage, pageContext);
            String response = processRunner.run(prompt, null, CLAUDE_TIMEOUT_SECONDS);

            if (response == null || response.isBlank()) {
                response = "I'm sorry, I couldn't generate a response. Please try again.";
            }

            ChatMessage assistantMsg = new ChatMessage("assistant", response);
            session.getMessages().add(assistantMsg);
            session.setUpdatedAt(Instant.now());
            saveSession(session);

            return assistantMsg;
        } finally {
            lock.unlock();
        }
    }

    public String generateMarkdownReport(String sessionId) {
        ChatSession session = getSession(sessionId);
        if (session == null) return null;

        StringBuilder md = new StringBuilder();
        md.append("# Chat Session: ").append(session.getName()).append("\n\n");
        md.append("**Scope:** ").append(session.getScope()).append("  \n");
        md.append("**Created:** ").append(session.getCreatedAt()).append("  \n");
        md.append("**Messages:** ").append(session.getMessages().size()).append("\n\n");
        md.append("---\n\n");

        for (ChatMessage msg : session.getMessages()) {
            if ("user".equals(msg.getRole())) {
                md.append("## User\n\n").append(msg.getContent()).append("\n\n");
            } else {
                md.append("## Assistant\n\n").append(msg.getContent()).append("\n\n");
            }
            md.append("---\n\n");
        }

        return md.toString();
    }

    public void setJarContextProvider(AnalysisContextProvider provider) {
        this.jarContextProvider = provider;
    }

    public void setPlsqlContextProvider(AnalysisContextProvider provider) {
        this.plsqlContextProvider = provider;
    }

    private static final int MAX_PAGE_CONTEXT_CHARS = 8000;

    private String buildPrompt(ChatSession session, String latestMessage, String pageContext) {
        StringBuilder prompt = new StringBuilder();

        prompt.append("You are an AI assistant for a code analysis platform. ");

        String contextSummary = getContextSummary(session);
        if (contextSummary != null && !contextSummary.isBlank()) {
            prompt.append("\n\nHere is context about the current analysis:\n");
            prompt.append(contextSummary);
        }

        if (pageContext != null && !pageContext.isBlank()) {
            String trimmed = pageContext.length() > MAX_PAGE_CONTEXT_CHARS
                    ? pageContext.substring(0, MAX_PAGE_CONTEXT_CHARS) + "\n...(truncated)"
                    : pageContext;
            prompt.append("\n\nThe user is currently viewing this page context:\n");
            prompt.append(trimmed);
        }

        List<ChatMessage> messages = session.getMessages();
        int start = Math.max(0, messages.size() - MAX_CONTEXT_MESSAGES);
        if (start > 0) {
            prompt.append("\n\n[Earlier conversation messages omitted for brevity]\n");
        }
        for (int i = start; i < messages.size(); i++) {
            ChatMessage m = messages.get(i);
            prompt.append("\n\n").append("user".equals(m.getRole()) ? "Human" : "Assistant")
                    .append(": ").append(m.getContent());
        }

        return prompt.toString();
    }

    private String getContextSummary(ChatSession session) {
        String scope = session.getScope();
        Map<String, String> ctx = session.getScopeContext();

        if ("PLSQL".equalsIgnoreCase(scope) && plsqlContextProvider != null) {
            String analysisName = ctx != null ? ctx.get("analysisName") : null;
            return plsqlContextProvider.getContextSummary(analysisName);
        }
        if ("JAR".equalsIgnoreCase(scope) && jarContextProvider != null) {
            String jarName = ctx != null ? ctx.get("jarName") : null;
            return jarContextProvider.getContextSummary(jarName);
        }
        if ("GLOBAL".equalsIgnoreCase(scope)) {
            StringBuilder global = new StringBuilder();
            if (plsqlContextProvider != null) {
                String plsqlCtx = plsqlContextProvider.getContextSummary(null);
                if (plsqlCtx != null) global.append("## PL/SQL Analysis\n").append(plsqlCtx).append("\n\n");
            }
            if (jarContextProvider != null) {
                String jarCtx = jarContextProvider.getContextSummary(null);
                if (jarCtx != null) global.append("## JAR Analysis\n").append(jarCtx).append("\n\n");
            }
            return global.toString();
        }
        return null;
    }

    private void saveSession(ChatSession session) {
        String type = session.getChatType() != null ? session.getChatType() : "classic";
        if (badSegment(type) || badSegment(session.getId())) {
            log.error("Refusing to save session with an unsafe id/type: {}/{}", type, session.getId());
            return;
        }
        try (OutputStream out = openWrite(sessionKey(type, session.getId()))) {
            mapper.writerWithDefaultPrettyPrinter().writeValue(out, session);
        } catch (IOException e) {
            log.error("Failed to save session {}: {}", session.getId(), e.getMessage());
        }
    }

    @FunctionalInterface
    public interface AnalysisContextProvider {
        String getContextSummary(String identifier);
    }
}
