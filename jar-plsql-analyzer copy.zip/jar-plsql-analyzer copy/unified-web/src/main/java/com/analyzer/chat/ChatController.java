package com.analyzer.chat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    private final ChatService chatService;

    /**
     * Every artifact these endpoints touch is addressed by an {@link ArtifactKey}, which is
     * relative to the data root and cannot express a location outside it.
     *
     * <p>The original guard was a {@code path.contains("..")} substring check, which stops
     * nothing: an ABSOLUTE path such as {@code /etc/passwd} contains no "..", so it passed. The
     * read endpoint would return the file and the write endpoint would overwrite it — arbitrary
     * read and write anywhere the process user can reach, unauthenticated. Keys close that hole
     * structurally: {@link #keyInsideDataRoot} rejects "." / ".." segments outright and drops the
     * leading separator of an absolute path, so the request can only ever name something under
     * the store root.
     */
    private final ArtifactStore store;

    @org.springframework.beans.factory.annotation.Value("${chat.classic.enabled:true}")
    private boolean classicEnabled;

    @org.springframework.beans.factory.annotation.Value("${chat.chatbox.enabled:true}")
    private boolean chatboxEnabled;

    public ChatController(ChatService chatService, ArtifactStore store) {
        this.chatService = chatService;
        this.store = store;
    }

    private InputStream openRead(ArtifactKey key) throws IOException {
        return store.read(key);
    }

    private OutputStream openWrite(ArtifactKey key, long contentLength) throws IOException {
        return store.write(key, contentLength);
    }

    @GetMapping("/config")
    public Map<String, Object> getChatConfig() {
        return Map.of(
                "classicEnabled", classicEnabled,
                "chatboxEnabled", chatboxEnabled
        );
    }

    @PostMapping("/sessions")
    public ResponseEntity<?> createSession(@RequestBody Map<String, Object> body) {
        String name = (String) body.get("name");
        String scope = (String) body.getOrDefault("scope", "GLOBAL");
        String chatType = (String) body.getOrDefault("chatType", "classic");
        @SuppressWarnings("unchecked")
        Map<String, String> scopeContext = (Map<String, String>) body.get("scopeContext");

        if (name == null || name.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Session name is required"));
        }

        ChatSession session = chatService.createSession(name, scope.toUpperCase(), chatType, scopeContext);
        return ResponseEntity.ok(Map.of(
                "id", session.getId(),
                "name", session.getName(),
                "scope", session.getScope(),
                "chatType", session.getChatType(),
                "createdAt", session.getCreatedAt().toString()
        ));
    }

    @GetMapping("/sessions")
    public ResponseEntity<List<Map<String, Object>>> listSessions(
            @RequestParam(required = false) String scope,
            @RequestParam(required = false) String chatType) {
        return ResponseEntity.ok(chatService.listSessions(scope, chatType));
    }

    @GetMapping("/sessions/{id}")
    public ResponseEntity<?> getSession(@PathVariable String id) {
        ChatSession session = chatService.getSession(id);
        if (session == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(session);
    }

    /**
     * A page of one session's transcript — Q67 / L30.
     *
     * <p>A new endpoint, so there is no legacy shape to preserve: it always answers the envelope.
     * That is what lets {@code openSession} stop fetching {@code /sessions/{id}}, whose response
     * carries every message ever exchanged in order to render the last screenful.
     *
     * @param before the {@code seq} to page backwards from — {@code after} under
     *               {@code sort=SEQ_DESC} (PLAN-08 §3.2), spelled the way the UI reads it
     * @param sort   accepted only as {@code SEQ_DESC}; anything else is a 400 rather than a
     *               silently different ordering
     */
    @GetMapping("/sessions/{id}/messages")
    public ResponseEntity<?> getMessages(@PathVariable String id,
                                         @RequestParam(required = false) Long before,
                                         @RequestParam(required = false) Integer limit,
                                         @RequestParam(required = false) String q,
                                         @RequestParam(required = false) String sort) {
        if (sort != null && !sort.isBlank()
                && !ChatTranscriptReader.SORT_SEQ_DESC.equalsIgnoreCase(sort)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "BAD_PAGE_REQUEST",
                    "message", "Unknown sort '" + sort + "'. Allowed: ["
                            + ChatTranscriptReader.SORT_SEQ_DESC + "]"));
        }
        if (limit != null && (limit < 1 || limit > com.analyzer.storage.page.PageRequest.MAX_LIMIT)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "BAD_PAGE_REQUEST",
                    "message", "limit must be between 1 and "
                            + com.analyzer.storage.page.PageRequest.MAX_LIMIT));
        }
        try {
            var page = chatService.messages(id, before, limit, q);
            if (page == null) return ResponseEntity.notFound().build();
            var info = page.page();
            return ResponseEntity.ok(Map.of(
                    "items", page.items(),
                    "page", pageBlock(info)));
        } catch (IOException e) {
            log.error("Failed to page messages for session {}: {}", id, e.getMessage());
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to read transcript"));
        }
    }

    /** The wire shape of the paging block, written out field by field so it is stated once. */
    private static Map<String, Object> pageBlock(com.analyzer.storage.page.PageInfo info) {
        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("nextCursor", info.nextCursor());   // null iff hasMore is false
        out.put("hasMore", info.hasMore());
        out.put("total", info.total());
        out.put("totalIsExact", info.totalIsExact());
        out.put("limit", info.limit());
        out.put("sort", info.sort());
        return out;
    }

    @DeleteMapping("/sessions/{id}")
    public ResponseEntity<?> deleteSession(@PathVariable String id) {
        boolean deleted = chatService.deleteSession(id);
        if (!deleted) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of("deleted", id));
    }

    @PostMapping("/sessions/{id}/messages")
    public ResponseEntity<?> sendMessage(@PathVariable String id, @RequestBody Map<String, String> body) {
        String message = body.get("message");
        if (message == null || message.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Message is required"));
        }

        String pageContext = body.get("pageContext");
        log.info("Chat message to session {}: {} chars, context: {}", id, message.length(),
                pageContext != null ? pageContext.length() + " chars" : "none");
        ChatMessage response = chatService.sendMessage(id, message, pageContext);
        if (response == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(Map.of(
                "role", response.getRole(),
                "content", response.getContent(),
                "timestamp", response.getTimestamp().toString()
        ));
    }

    @GetMapping("/sessions/{id}/report")
    public ResponseEntity<?> downloadReport(@PathVariable String id) {
        String markdown = chatService.generateMarkdownReport(id);
        if (markdown == null) return ResponseEntity.notFound().build();

        ChatSession session = chatService.getSession(id);
        String fileName = (session != null ? session.getName() : id)
                .replaceAll("[^a-zA-Z0-9_-]", "_") + "_report.md";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .contentType(MediaType.TEXT_MARKDOWN)
                .body(markdown);
    }

    private static final long MAX_READ_SIZE = 512 * 1024;

    /**
     * Turns a client-supplied path into a key inside the data root, or throws.
     *
     * <p>There is no base directory to compare against any more, so the {@code startsWith(root)}
     * containment check is replaced by refusing the inputs that could escape in the first place:
     * any "." or ".." segment is rejected rather than normalized away, and a leading separator is
     * simply dropped so an absolute path is read as relative to the root. Every remaining segment
     * is then re-validated by {@link ArtifactKey}, which cannot hold a separator at all.
     */
    private ArtifactKey keyInsideDataRoot(String clientPath) throws IOException {
        if (clientPath.indexOf('\0') >= 0) throw new IOException("Illegal path");
        List<String> segments = new ArrayList<>();
        for (String raw : clientPath.replace("\\", "/").split("/")) {
            if (raw.isBlank()) continue;            // leading "/", or a doubled separator
            if (raw.equals(".") || raw.equals("..")) {
                throw new IOException("Path escapes the data directory");
            }
            segments.add(raw);
        }
        if (segments.isEmpty()) throw new IOException("Path is empty");
        try {
            return ArtifactKey.of(segments.toArray(new String[0]));
        } catch (IllegalArgumentException e) {
            throw new IOException("Illegal path: " + e.getMessage());
        }
    }

    @PostMapping("/files/read")
    public ResponseEntity<?> readFile(@RequestBody Map<String, String> body) {
        String filePath = body.get("path");
        if (filePath == null || filePath.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path is required"));
        }

        ArtifactKey key;
        try {
            key = keyInsideDataRoot(filePath);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path outside the data directory is not allowed"));
        }
        if (!store.exists(key)) {
            return ResponseEntity.ok(Map.of("error", "File not found: " + filePath));
        }

        try {
            // size() is -1 for anything that is not a readable artifact — a directory key
            // included, which is how the old isDirectory() check is preserved without a
            // filesystem-only predicate.
            long size = store.size(key);
            if (size < 0) {
                return ResponseEntity.ok(Map.of("error", "Path is not a readable file"));
            }
            if (size > MAX_READ_SIZE) {
                return ResponseEntity.ok(Map.of("error", "File too large (" + (size / 1024) + "KB). Max: " + (MAX_READ_SIZE / 1024) + "KB"));
            }
            String content;
            try (InputStream in = openRead(key)) {
                content = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            log.info("Chat file read: {} ({} bytes)", filePath, size);
            return ResponseEntity.ok(Map.of("content", content, "path", filePath, "size", size));
        } catch (IOException e) {
            log.error("Failed to read file {}: {}", filePath, e.getMessage());
            return ResponseEntity.ok(Map.of("error", "Failed to read: " + e.getMessage()));
        }
    }

    @PostMapping("/files/write")
    public ResponseEntity<?> writeFile(@RequestBody Map<String, String> body) {
        String filePath = body.get("path");
        String content = body.get("content");

        if (filePath == null || filePath.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path is required"));
        }
        if (content == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Content is required"));
        }

        ArtifactKey key;
        try {
            key = keyInsideDataRoot(filePath);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Path outside the data directory is not allowed"));
        }
        try {
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = openWrite(key, bytes.length)) {
                out.write(bytes);
            }
            log.info("Chat file written: {} ({} bytes)", filePath, content.length());
            return ResponseEntity.ok(Map.of("success", true, "path", filePath, "size", content.length()));
        } catch (IOException e) {
            log.error("Failed to write file {}: {}", filePath, e.getMessage());
            return ResponseEntity.ok(Map.of("error", "Failed to write: " + e.getMessage()));
        }
    }
}
