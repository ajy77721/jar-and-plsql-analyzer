package com.jaranalyzer.crossref;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jaranalyzer.crossref.model.*;
import com.jaranalyzer.service.JarDataPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.analyzer.storage.ArtifactKey;
import com.analyzer.storage.ArtifactStore;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Cross-reference service: maps Java endpoint call tree to Oracle PL/SQL proc call tree.
 *
 * Algorithm — four passes run in order, each filling gaps left by the previous:
 *
 * Pass A — TABLE LINKAGE (ground truth):
 *   Java node has collectionsAccessed[] → look up each table in tables.json referencedBy[]
 *   → directly maps to the Oracle procs that touch that table. No naming convention needed.
 *
 * Pass B — Pg* CLASS NAMING:
 *   Java classes with "Pg" in the name encode the Oracle package name directly.
 *   e.g. ExtensionPolicyPgCnuInterfaceServiceImpl → PG_CNU_INTERFACE.PC_MT_PREV_POL_INFO
 *
 * Pass C — FUZZY PACKAGE SEGMENT MATCH:
 *   Strip Java class name to a core segment, convert to UPPER_SNAKE, check against
 *   known Oracle package names. CnuwBasesService → CNUW → PG_CNUW_INTERFACE.
 *
 * Pass D — @LogParameters ZONE PROPAGATION:
 *   Walk the call tree top-down carrying the current "zone" (last resolved Oracle package).
 *   Rule: if a node is resolved by A/B/C → start new zone. If unresolved → inherit parent zone.
 *   @LogParameters is a strong hint to try harder at that node (it marks facade boundaries).
 *   Result: every node in the tree gets an Oracle attribution, not just naming-convention nodes.
 */
@Service
public class CrossRefService {

    private static final Logger log = LoggerFactory.getLogger(CrossRefService.class);

    private final JarDataPaths jarDataPaths;
    private final CrossRefStore store;
    private final ObjectMapper objectMapper;
    private final ArtifactStore artifacts;
    private final OracleProcNameInferencer inferencer = new OracleProcNameInferencer();

    /**
     * Root of the parser output subtree, as a key. Relative to the data root, so it carries the
     * {@code plsql-parse} segment explicitly — see {@link com.plsqlanalyzer.web.parser.service.AnalysisPaths}.
     */
    private static final ArtifactKey PLSQL_PARSE_ROOT =
            ArtifactKey.of(com.plsqlanalyzer.web.parser.service.AnalysisPaths.PARSE_ROOT);

    // True infrastructure: no Oracle proc equivalent whatsoever.
    // Deliberately narrow — only classes that are purely Java-side plumbing with no Oracle counterpart.
    private static final Set<String> INFRA_CLASS_FRAGMENTS = Set.of(
            "InfLck", "InfSec", "InfDmt", "InfVLck",
            "BatchProcessor", "SequenceService",
            "PgUtilsLog", "OpusInf", "OpuMsg"
    );

    // Logging/error infrastructure — has Oracle equivalents (PG_UTIL_LOG_ERROR) but we keep them separate
    private static final Set<String> LOGGING_CLASS_FRAGMENTS = Set.of(
            "InfGam", "PgUtilsLogError", "PgUtils",
            "ErrorTextService", "ErrorText", "PgUtilGeneral"
    );

    public CrossRefService(JarDataPaths jarDataPaths, CrossRefStore store, ObjectMapper objectMapper,
                           ArtifactStore artifacts) {
        this.jarDataPaths = jarDataPaths;
        this.store = store;
        this.objectMapper = objectMapper;
        this.artifacts = artifacts;
    }

    private InputStream openRead(ArtifactKey key) throws IOException {
        return artifacts.read(key);
    }

    /** Immediate subdirectories of {@code prefix}, newest-name-first order applied by the caller. */
    private List<ArtifactKey> childDirs(ArtifactKey prefix) throws IOException {
        try (var s = artifacts.list(prefix, false)) {
            return s.filter(com.analyzer.storage.ArtifactEntry::directory)
                    .map(com.analyzer.storage.ArtifactEntry::key)
                    .collect(Collectors.toList());
        }
    }

    /**
     * Every PL/SQL parse session in the store, newest-name-first.
     *
     * <p>A session is any prefix under {@code plsql-parse/} that contains {@code api/index.json} —
     * at ANY depth. That covers both the current nested layout
     * ({@code plsql-parse/<DBTYPE>/<PROJECT>/<ENV>/<OBJECT>/}) and the flat legacy one
     * ({@code plsql-parse/<SESSION>/}). Listing only the immediate children of {@code plsql-parse/}
     * found the DBTYPE folders, which have no {@code api/index.json}, so nested sessions were
     * invisible.
     *
     * <p>ONE {@code statPrefix} for the whole subtree, not a stat per candidate — same approach as
     * {@link com.plsqlanalyzer.web.parser.service.AnalysisService}'s {@code indexKeysByName()}.
     */
    /**
     * The session's identity name: {@code DBTYPE~PROJECT~ENV~OBJECT} for a nested session, and the
     * bare directory name for a flat legacy one — the same token the parser REST API uses.
     */
    private static String sessionIdOf(ArtifactKey sessionDir) {
        return com.plsqlanalyzer.web.parser.service.AnalysisPaths.nameOfKey(sessionDir);
    }

    private List<ArtifactKey> sessionDirs() throws IOException {
        List<ArtifactKey> dirs = new ArrayList<>();
        for (ArtifactKey k : artifacts.statPrefix(PLSQL_PARSE_ROOT).keySet()) {
            List<String> segs = k.segments();
            int n = segs.size();
            if (n >= 4 && "index.json".equals(segs.get(n - 1)) && "api".equals(segs.get(n - 2))) {
                dirs.add(k.parent().parent());
            }
        }
        dirs.sort(Comparator.comparing(ArtifactKey::leaf).reversed());
        return dirs;
    }

    private JsonNode readTree(ArtifactKey key) throws IOException {
        try (InputStream in = openRead(key)) {
            return objectMapper.readTree(in);
        }
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public String link(String jarId, String endpointPath, String procName,
                       String schema, Integer endpointIdx) throws IOException {
        String crossRefId = String.valueOf(System.currentTimeMillis());

        JsonNode callTree = loadCallTree(jarId, endpointPath, endpointIdx);
        if (callTree == null) {
            throw new IllegalArgumentException(
                    "No call-tree.json found for endpoint '" + endpointPath + "' in jar '" + jarId + "'");
        }

        PlsqlSessionData plsqlSession = findPlsqlSession(procName, schema);
        CrossRefResult result = buildResult(crossRefId, jarId, endpointPath, procName,
                                            schema, callTree, plsqlSession);

        ArtifactKey runDir = store.createRunDir(jarId, crossRefId);
        store.writeMeta(runDir, crossRefId, jarId, endpointPath, procName, schema, result.getMode());
        store.writeResult(runDir, result);
        store.writeReport(runDir, new CrossRefReportGenerator().generate(result));

        log.info("CrossRef link: jarId={} endpoint={} proc={} mode={} procLinks={} routingNodes={} oracleNodes={} id={}",
                 jarId, endpointPath, procName, result.getMode(),
                 result.getProcLinks().size(), result.getRoutingNodes().size(),
                 result.getOracleNodes().size(), crossRefId);
        return crossRefId;
    }

    public CrossRefResult getResult(String jarId, String crossRefId) {
        return store.readResult(store.runDir(jarId, crossRefId));
    }

    public String getResultRaw(String jarId, String crossRefId) {
        return store.readResultRaw(store.runDir(jarId, crossRefId));
    }

    public byte[] getReport(String jarId, String crossRefId) {
        return store.readReport(store.runDir(jarId, crossRefId));
    }

    public List<Map<String, Object>> listHistory(String jarId) {
        return store.listHistory(jarId);
    }

    public boolean delete(String jarId, String crossRefId) {
        return store.delete(jarId, crossRefId);
    }

    /**
     * Scan data/plsql-parse/ and return all proc names at depth 0–1 across all sessions.
     */
    public List<Map<String, Object>> listAvailableProcs() {
        List<Map<String, Object>> result = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();

        try {
            for (ArtifactKey sessionDir : sessionDirs()) {
                String sessionId = sessionIdOf(sessionDir);
                ArtifactKey indexFile = sessionDir.resolve("api", "index.json");

                try {
                    JsonNode idx = readTree(indexFile);
                    for (JsonNode node : idx.path("nodes")) {
                        int depth = node.path("depth").asInt(-1);
                        if (depth > 1) continue;

                        String pkg    = nullIfBlank(node.path("packageName").asText(""));
                        String proc   = nullIfBlank(node.path("objectName").asText(""));
                        String schema = nullIfBlank(node.path("schema").asText(""));
                        if (proc == null) continue;

                        String procName = (pkg != null) ? pkg + "." + proc : proc;
                        String key = procName.toUpperCase();
                        if (seen.contains(key)) continue;
                        seen.add(key);

                        Map<String, Object> entry = new LinkedHashMap<>();
                        entry.put("procName", procName);
                        entry.put("packageName", pkg);
                        entry.put("proc", proc);
                        entry.put("schema", schema);
                        entry.put("sessionId", sessionId);
                        entry.put("analyzed", true);
                        result.add(entry);
                    }
                } catch (Exception e) {
                    log.debug("listAvailableProcs: error reading {}: {}", indexFile, e.getMessage());
                }
            }
        } catch (IOException e) {
            log.debug("listAvailableProcs: cannot list {}: {}", PLSQL_PARSE_ROOT, e.getMessage());
        }

        return result;
    }

    // ── Call tree loading ─────────────────────────────────────────────────────

    private JsonNode loadCallTree(String jarId, String endpointPath, Integer endpointIdx) throws IOException {
        ArtifactKey endpointsDir = jarDataPaths.endpointsDirKey(jarId);

        if (endpointIdx != null) {
            Optional<ArtifactKey> match = childDirs(endpointsDir).stream()
                    .filter(k -> k.leaf().startsWith(endpointIdx + "_"))
                    .findFirst();
            if (match.isPresent()) {
                ArtifactKey treeFile = match.get().resolve("call-tree.json");
                if (artifacts.exists(treeFile)) {
                    // Sidecars are stored as node dictionaries; expand to the nested tree the
                    // walkers below expect. Legacy sidecars pass through untouched.
                    return com.jaranalyzer.service.CallTreeInflater.expandSidecar(readTree(treeFile), objectMapper);
                }
            }
        }

        if (endpointPath != null && !endpointPath.isBlank()) {
            for (ArtifactKey dir : childDirs(endpointsDir)) {
                ArtifactKey epJson = dir.resolve("endpoint.json");
                if (!artifacts.exists(epJson)) continue;
                JsonNode ep = readTree(epJson);
                String path = ep.path("fullPath").asText(
                        ep.path("path").asText(ep.path("endpointPath").asText("")));
                if (endpointPath.equals(path) || endpointPath.equals("/" + path)) {
                    ArtifactKey treeFile = dir.resolve("call-tree.json");
                    if (artifacts.exists(treeFile)) {
                    // Sidecars are stored as node dictionaries; expand to the nested tree the
                    // walkers below expect. Legacy sidecars pass through untouched.
                    return com.jaranalyzer.service.CallTreeInflater.expandSidecar(readTree(treeFile), objectMapper);
                }
                }
            }
        }
        return null;
    }

    // ── PL/SQL session lookup ─────────────────────────────────────────────────

    private PlsqlSessionData findPlsqlSession(String procName, String schema) {
        if (procName == null || procName.isBlank()) return null;

        String normalProcName = OracleProcNameInferencer.normalise(procName).replace(".", "_");

        try {
            for (ArtifactKey sessionDir : sessionDirs()) {
                // Match on the identity name (DBTYPE~PROJECT~ENV~OBJECT), which contains the leaf,
                // so a nested session matches on its OBJECT segment exactly as a flat one does.
                String dirName = sessionIdOf(sessionDir).toUpperCase();
                if (dirName.contains(normalProcName) ||
                    dirName.contains(procName.toUpperCase().replace(".", "_"))) {
                    return loadPlsqlSession(sessionDir);
                }
            }
        } catch (IOException e) {
            log.debug("CrossRefService: cannot scan plsql dir: {}", e.getMessage());
        }
        return null;
    }

    private PlsqlSessionData loadPlsqlSession(ArtifactKey sessionDir) {
        ArtifactKey indexFile = sessionDir.resolve("api", "index.json");
        if (!artifacts.exists(indexFile)) return null;

        PlsqlSessionData data = new PlsqlSessionData();
        data.sessionId = sessionIdOf(sessionDir);
        data.sessionDir = sessionDir;

        try {
            JsonNode idx = readTree(indexFile);
            for (JsonNode node : idx.path("nodes")) {
                String nodeId = node.path("nodeId").asText("");
                if (nodeId.isBlank()) continue;
                data.nodeIds.add(nodeId);

                // Index by "PACKAGE.PROC" for fast lookup (normalised: no schema prefix)
                String pkg  = nullIfBlank(node.path("packageName").asText(""));
                String proc = nullIfBlank(node.path("objectName").asText(""));
                if (pkg != null && proc != null) {
                    data.procByName.put((pkg + "." + proc).toUpperCase(), node);
                    data.nodesByPackage.computeIfAbsent(pkg.toUpperCase(), k -> new ArrayList<>()).add(node);
                } else if (pkg == null && proc != null) {
                    // standalone proc (no package) — index as bare proc name too
                    data.procByName.put(proc.toUpperCase(), node);
                }
                if (pkg != null) {
                    // Also index by package alone for quick package existence check
                    data.nodesByPackage.computeIfAbsent(pkg.toUpperCase(), k -> new ArrayList<>()).add(node);
                }
                data.nodeList.add(node);
            }

            // Load tables.json for table-based linkage (Pass A)
            // tables.json keys are "SCHEMA.TABLE_NAME"; value has tableName (bare) and referencedBy
            ArtifactKey tablesFile = sessionDir.resolve("tables.json");
            if (artifacts.exists(tablesFile)) {
                JsonNode tables = readTree(tablesFile);
                tables.fields().forEachRemaining(entry -> {
                    String tableName = entry.getValue().path("tableName").asText("");
                    if (tableName.isBlank()) return;
                    List<String> refs = new ArrayList<>();
                    for (JsonNode r : entry.getValue().path("referencedBy")) {
                        String ref = r.asText().trim();
                        if (!ref.isBlank()) refs.add(ref.toUpperCase());
                    }
                    if (refs.isEmpty()) return;
                    String bareKey = tableName.toUpperCase();
                    // Store under bare table name (no schema prefix) for matching against collectionsAccessed
                    data.tableToOracleProcs.merge(bareKey, refs, (existing, newRefs) -> {
                        List<String> merged = new ArrayList<>(existing);
                        for (String r : newRefs) if (!merged.contains(r)) merged.add(r);
                        return merged;
                    });
                    // Also store under full "SCHEMA.TABLE" key in case collectionsAccessed uses schema prefix
                    String schemaKey = entry.getKey().toUpperCase(); // already "SCHEMA.TABLE"
                    if (!schemaKey.equals(bareKey)) {
                        data.tableToOracleProcs.merge(schemaKey, refs, (existing, newRefs) -> {
                            List<String> merged = new ArrayList<>(existing);
                            for (String r : newRefs) if (!merged.contains(r)) merged.add(r);
                            return merged;
                        });
                    }
                });
            }

        } catch (IOException e) {
            log.debug("CrossRefService: error loading session {}: {}", data.sessionId, e.getMessage());
        }

        log.info("CrossRefService: loaded PL/SQL session {} — {} nodes, {} tables",
                 data.sessionId, data.nodeIds.size(), data.tableToOracleProcs.size());
        return data;
    }

    // ── Result builder ────────────────────────────────────────────────────────

    private CrossRefResult buildResult(String crossRefId, String jarId, String endpointPath,
                                        String procName, String schema, JsonNode callTree,
                                        PlsqlSessionData plsqlSession) {
        CrossRefResult result = new CrossRefResult();
        result.setCrossRefId(crossRefId);
        result.setJarId(jarId);
        result.setEndpointPath(endpointPath);
        result.setProcName(procName);
        result.setSchema(schema);
        result.setTimestamp(Long.parseLong(crossRefId));
        result.setMode(plsqlSession != null ? "FULL_COMPARISON" : "STATIC_INFERENCE");
        if (plsqlSession != null) result.setPlsqlSessionId(plsqlSession.sessionId);

        // ── Collect all Java nodes from the call tree (flat, deduped) ─────────
        Map<String, JavaNodeInfo> javaNodes = new LinkedHashMap<>(); // dedupeKey → info
        collectJavaNodes(callTree, javaNodes);

        // ── Pass A: Table-based linkage ───────────────────────────────────────
        // For every Java node: collectionsAccessed[] → tables.json referencedBy[] → Oracle procs
        Map<String, Set<String>> javaKeyToOracleProcs = new LinkedHashMap<>();   // jKey → set of "PKG.PROC"
        Map<String, Set<String>> javaKeyToOraclePkgs  = new LinkedHashMap<>();   // jKey → set of "PKG"
        Map<String, Set<String>> tableToJavaKeys       = new LinkedHashMap<>();   // tableName → set of jKeys
        Map<String, Set<String>> javaKeyToTables       = new LinkedHashMap<>();   // jKey → set of tables

        if (plsqlSession != null && !plsqlSession.tableToOracleProcs.isEmpty()) {
            for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
                String jKey = entry.getKey();
                JavaNodeInfo info = entry.getValue();
                for (String table : info.collectionsAccessed) {
                    String tableUpper = table.toUpperCase();
                    List<String> oracleProcs = plsqlSession.tableToOracleProcs.get(tableUpper);
                    if (oracleProcs == null || oracleProcs.isEmpty()) continue;

                    javaKeyToTables.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(tableUpper);
                    tableToJavaKeys.computeIfAbsent(tableUpper, k -> new LinkedHashSet<>()).add(jKey);

                    for (String oracleProc : oracleProcs) {
                        javaKeyToOracleProcs.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(oracleProc);
                        String pkg = oracleProc.contains(".") ? oracleProc.substring(0, oracleProc.indexOf('.')) : oracleProc;
                        javaKeyToOraclePkgs.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(pkg);
                    }
                }
            }
        }

        // ── Pass B: Pg* class naming convention ───────────────────────────────
        // HIGH confidence (Pg* class) → confirmed procLinks.
        // MEDIUM / LOW → lowConfidenceHints (still visible in UI but not primary).
        List<CrossRefProcLink> links = new ArrayList<>();
        List<CrossRefProcLink> lowConfHints = new ArrayList<>();
        List<CrossRefResult.InfraNode> infraNodes = new ArrayList<>();
        Set<String> seenLinks = new HashSet<>();
        Set<String> seenHints = new HashSet<>();
        // jKey → Pass B link (method-only, no pkg) — for Pass C to retroactively upgrade
        Map<String, CrossRefProcLink> jKeyToPassBLink = new LinkedHashMap<>();
        // Track which pass resolved each jKey
        Map<String, String> jKeyToZoneSource = new LinkedHashMap<>();

        // Mark Pass A resolutions
        for (String jKey : javaKeyToOraclePkgs.keySet()) {
            if (javaKeyToTables.containsKey(jKey)) {
                jKeyToZoneSource.put(jKey, "PASS_A");
            }
        }

        for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
            String jKey = entry.getKey();
            JavaNodeInfo info = entry.getValue();

            if (isStrictInfraNode(info.simpleName)) {
                infraNodes.add(new CrossRefResult.InfraNode(info.className, info.methodName,
                        classifyInfraReason(info.simpleName)));
                continue;
            }

            // Skip noisy nodes with no collections
            if (isNoisyNode(info)) continue;

            OracleProcNameInferencer.MatchConfidence confidence = inferencer.inferenceConfidence(info.simpleName);
            if (confidence == OracleProcNameInferencer.MatchConfidence.NONE) continue;

            String inferredPkg  = inferencer.inferPackageName(info.simpleName);
            String inferredProc = inferencer.inferProcNameFromClass(info.simpleName);
            String inferredMethod = inferencer.inferProcedureName(info.methodName);

            String inferredRef = null;
            if (inferredPkg != null && inferredProc != null) {
                inferredRef = inferredPkg + "." + inferredProc;
            } else if (inferredPkg != null && inferredMethod != null) {
                inferredRef = inferredPkg + "." + inferredMethod;
            } else if (inferredMethod != null) {
                inferredRef = inferredMethod;
            }

            if (inferredRef == null) continue;

            // Validate against Oracle session if available
            boolean plsqlConfirmed = false;
            String resolvedRef = inferredRef;
            if (plsqlSession != null) {
                String normRef = OracleProcNameInferencer.normalise(inferredRef).toUpperCase();
                plsqlConfirmed = plsqlSession.procByName.containsKey(normRef);
                if (!plsqlConfirmed && !normRef.contains(".")) {
                    plsqlConfirmed = plsqlSession.nodesByPackage.containsKey(normRef);
                }
                if (!plsqlConfirmed && normRef.contains(".")) {
                    String pkgPart = normRef.substring(0, normRef.indexOf('.'));
                    plsqlConfirmed = plsqlSession.nodesByPackage.containsKey(pkgPart);
                }
                if (!plsqlConfirmed) {
                    String normRefNoDot = normRef.replace(".", "_");
                    plsqlConfirmed = plsqlSession.nodeIds.stream().anyMatch(nid -> {
                        String normNid = nid.toUpperCase().replace("$", ".").replace("$", "_");
                        return normNid.contains(normRef) || normNid.contains(normRefNoDot);
                    });
                }
            }

            CrossRefProcLink link = new CrossRefProcLink();
            link.setJavaClass(info.className);
            link.setJavaMethod(info.methodName);
            link.setJavaStereotype(info.stereotype);
            link.setJavaOperationType(info.operationType);
            link.setJavaNodeId(info.simpleName + "#" + info.methodName);
            link.setInferredProcRef(inferredRef);
            link.setResolvedProcRef(resolvedRef);
            link.setMatchConfidence(confidence.name());
            link.setPlsqlNodeFound(plsqlConfirmed);
            link.setHasLogParameters(info.hasLogParameters);
            String existingZone = jKeyToZoneSource.get(jKey);
            link.setZoneSource("PASS_A".equals(existingZone) ? "PASS_A+B" : "PASS_B");

            List<CrossRefCollectionEntry> colls = buildCollectionEntries(info);
            link.setJavaCollections(colls);
            if (plsqlSession != null && inferredPkg != null) {
                String pkgUpper = inferredPkg.toUpperCase();
                Set<String> oracleTables = new LinkedHashSet<>();
                for (String t : plsqlSession.tableToOracleProcs.keySet()) {
                    List<String> refs = plsqlSession.tableToOracleProcs.get(t);
                    if (refs.stream().anyMatch(r -> r.toUpperCase().startsWith(pkgUpper))) oracleTables.add(t);
                }
                link.setTableMatches(buildTableMatchesFromSets(colls, oracleTables));
            } else {
                link.setTableMatches(buildTableMatchesInferred(colls));
            }
            link.setParameterMatches(buildParamMatches(info));
            link.setJavaOnlyCollections(link.getTableMatches().stream()
                    .filter(m -> "JAVA_ONLY".equals(m.getMatchStatus()))
                    .map(CrossRefTableMatch::getMongoCollection)
                    .collect(Collectors.toList()));

            // HIGH confidence (Pg* class with explicit package) → main links
            // MEDIUM/LOW (method-only or non-Pg) → hints
            boolean isHighConf = confidence == OracleProcNameInferencer.MatchConfidence.HIGH;
            if (isHighConf) {
                String linkKey = jKey + "→" + resolvedRef;
                if (!seenLinks.contains(linkKey)) {
                    seenLinks.add(linkKey);
                    jKeyToZoneSource.put(jKey, link.getZoneSource());
                    links.add(link);
                    if (inferredPkg == null) jKeyToPassBLink.put(jKey, link);
                    String pkg = inferredPkg != null ? inferredPkg
                            : (resolvedRef.contains(".") ? resolvedRef.substring(0, resolvedRef.indexOf('.')) : resolvedRef);
                    javaKeyToOraclePkgs.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(pkg);
                }
            } else {
                String hintKey = jKey + "→" + resolvedRef;
                if (!seenHints.contains(hintKey)) {
                    seenHints.add(hintKey);
                    lowConfHints.add(link);
                }
            }
        }

        // ── Pass C: Fuzzy package + proc matching ────────────────────────────────
        // For unresolved non-infra nodes: fuzzy-match class segment against Oracle packages.
        // If the Oracle package/proc is confirmed in the PL/SQL session AND the match
        // is strong (exact proc found), promote to MEDIUM (confirmed procLink).
        // Otherwise → lowConfidenceHints only.
        if (plsqlSession != null) {
            Set<String> knownOraclePkgs = new LinkedHashSet<>(plsqlSession.nodesByPackage.keySet());
            for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
                String jKey = entry.getKey();
                JavaNodeInfo info = entry.getValue();
                if (isStrictInfraNode(info.simpleName) || isLoggingNode(info.simpleName)) continue;
                if (isNoisyNode(info)) continue;

                String existingZone = jKeyToZoneSource.get(jKey);
                if ("PASS_A".equals(existingZone) || "PASS_A+B".equals(existingZone)) continue;
                boolean passBHasPackage = "PASS_B".equals(existingZone)
                        && inferencer.inferPackageName(info.simpleName) != null;
                if (passBHasPackage) continue;

                // Try fuzzy package match
                String fuzzyPkg = fuzzyMatchOraclePackage(info.simpleName, knownOraclePkgs);

                // If package-first approach fails, try proc-name-first:
                // scan all procs for objectName match against class segment
                // (handles cases like CorePolicyInvokeNewBusinessImpl → PC_INVOKENEWBUSINESS)
                if (fuzzyPkg == null) {
                    String directProcRef = fuzzyMatchProcDirectly(info.simpleName, info.methodName, plsqlSession);
                    if (directProcRef != null) {
                        String pkg2 = directProcRef.contains(".")
                                ? directProcRef.substring(0, directProcRef.indexOf('.')) : null;
                        if (pkg2 != null) {
                            javaKeyToOraclePkgs.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(pkg2);
                            String hintKey = jKey + "→" + directProcRef;
                            if (!seenLinks.contains(hintKey)) {
                                seenLinks.add(hintKey);
                                CrossRefProcLink link = buildFuzzyLink(info, directProcRef, "MEDIUM", "PASS_C_PROC",
                                        true, plsqlSession, pkg2);
                                links.add(link);
                                jKeyToZoneSource.put(jKey, "PASS_C_PROC");
                            }
                        }
                    }
                    continue;
                }

                // Try to match a specific proc ref within the package
                String specificProcRef = fuzzyMatchOracleProc(info.simpleName, info.methodName,
                        fuzzyPkg, plsqlSession);
                String resolvedRef = specificProcRef != null ? specificProcRef : fuzzyPkg;
                boolean plsqlConfirmed = plsqlSession.nodesByPackage.containsKey(fuzzyPkg.toUpperCase());
                boolean exactProcMatch = specificProcRef != null
                        && plsqlSession.procByName.containsKey(specificProcRef.toUpperCase());

                javaKeyToOraclePkgs.computeIfAbsent(jKey, k -> new LinkedHashSet<>()).add(fuzzyPkg);

                // Upgrade method-only Pass B link if it exists
                CrossRefProcLink passBLink = jKeyToPassBLink.get(jKey);
                if (passBLink != null) {
                    passBLink.setZoneSource("PASS_C");
                    passBLink.setResolvedProcRef(resolvedRef);
                    passBLink.setInferredProcRef(resolvedRef);
                    passBLink.setPlsqlNodeFound(plsqlConfirmed);
                    jKeyToZoneSource.put(jKey, "PASS_C");
                    // If exact proc match, promote to medium confirmed link
                    if (exactProcMatch) {
                        passBLink.setMatchConfidence("MEDIUM");
                        // Move from hints to links if it ended up in hints
                    }
                    continue;
                }

                if (existingZone == null) {
                    String hintKey = jKey + "→" + resolvedRef;
                    // Exact proc match confirmed in session → promote to MEDIUM procLink
                    if (exactProcMatch) {
                        if (!seenLinks.contains(hintKey)) {
                            seenLinks.add(hintKey);
                            CrossRefProcLink link = buildFuzzyLink(info, resolvedRef, "MEDIUM", "PASS_C",
                                    plsqlConfirmed, plsqlSession, fuzzyPkg);
                            links.add(link);
                            jKeyToZoneSource.put(jKey, "PASS_C");
                        }
                    } else {
                        // Unconfirmed proc → hints only
                        if (!seenHints.contains(hintKey)) {
                            seenHints.add(hintKey);
                            CrossRefProcLink hint = buildFuzzyLink(info, resolvedRef, "LOW", "PASS_C",
                                    plsqlConfirmed, plsqlSession, fuzzyPkg);
                            lowConfHints.add(hint);
                            jKeyToZoneSource.put(jKey, "PASS_C");
                        }
                    }
                }
            }
        }

        // ── Pass D: @LogParameters zone propagation (tightened) ──────────────
        // Walk the call tree top-down carrying Oracle zone, but ONLY propagate at
        // @LogParameters boundary nodes. Non-annotated unresolved nodes do NOT inherit.
        // This prevents a single root package from being assigned to every child node.
        propagateZones(callTree, null, javaKeyToOraclePkgs, javaNodes, plsqlSession);

        // Apply Pass D: only for @LogParameters nodes that got a zone from propagation
        for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
            String jKey = entry.getKey();
            JavaNodeInfo info = entry.getValue();
            if (jKeyToZoneSource.get(jKey) == null && info.inheritedZone != null
                    && !isStrictInfraNode(info.simpleName) && info.hasLogParameters) {
                // @LogParameters node inherits zone → add as medium-confidence hint
                javaKeyToOraclePkgs.computeIfAbsent(jKey, k -> new LinkedHashSet<>())
                        .add(info.inheritedZone);
                jKeyToZoneSource.put(jKey, "PASS_D_INHERITED");
                // Add to hints (not main links — inherited, not confirmed)
                String hintKey = jKey + "→" + info.inheritedZone;
                if (!seenHints.contains(hintKey)) {
                    seenHints.add(hintKey);
                    CrossRefProcLink hint = new CrossRefProcLink();
                    hint.setJavaClass(info.className);
                    hint.setJavaMethod(info.methodName);
                    hint.setJavaStereotype(info.stereotype);
                    hint.setJavaOperationType(info.operationType);
                    hint.setJavaNodeId(info.simpleName + "#" + info.methodName);
                    hint.setResolvedProcRef(info.inheritedZone);
                    hint.setInferredProcRef(info.inheritedZone);
                    hint.setMatchConfidence("LOW");
                    hint.setZoneSource("PASS_D_INHERITED");
                    hint.setHasLogParameters(true);
                    hint.setPlsqlNodeFound(plsqlSession != null
                            && plsqlSession.nodesByPackage.containsKey(info.inheritedZone.toUpperCase()));
                    hint.setJavaCollections(buildCollectionEntries(info));
                    hint.setTableMatches(buildTableMatchesInferred(hint.getJavaCollections()));
                    lowConfHints.add(hint);
                }
            }
        }

        // ── Create proc links for Pass A-only nodes ───────────────────────────
        // Pass B already creates links for HIGH-confidence Pg* nodes.
        // Here we only create links for nodes resolved purely via table linkage (Pass A),
        // which are MEDIUM confidence (ground-truth table evidence).
        // Use proc-level refs from javaKeyToOracleProcs (e.g. PG_UWGE_CI.INSERT_COVER),
        // NOT package-only refs from javaKeyToOraclePkgs — Pass A has full PKG.PROC granularity.
        for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
            String jKey = entry.getKey();
            JavaNodeInfo info = entry.getValue();
            if (isStrictInfraNode(info.simpleName) || isNoisyNode(info)) continue;

            String zSrc = jKeyToZoneSource.get(jKey);
            if (!"PASS_A".equals(zSrc)) continue; // only pure Pass A nodes here

            Set<String> procRefs = javaKeyToOracleProcs.getOrDefault(jKey, Set.of());
            if (procRefs.isEmpty()) continue;

            for (String procRef : procRefs) {
                String linkKey = jKey + "→" + procRef;
                if (seenLinks.contains(linkKey)) continue;
                seenLinks.add(linkKey);

                String pkg = procRef.contains(".")
                        ? procRef.substring(0, procRef.indexOf('.')) : procRef;

                CrossRefProcLink link = new CrossRefProcLink();
                link.setJavaClass(info.className);
                link.setJavaMethod(info.methodName);
                link.setJavaStereotype(info.stereotype);
                link.setJavaOperationType(info.operationType);
                link.setJavaNodeId(info.simpleName + "#" + info.methodName);
                link.setResolvedProcRef(procRef);
                link.setInferredProcRef(procRef);
                link.setHasLogParameters(info.hasLogParameters);
                link.setZoneSource("PASS_A");
                link.setMatchConfidence("MEDIUM");

                boolean plsqlConfirmed = plsqlSession != null
                        && (plsqlSession.procByName.containsKey(procRef.toUpperCase())
                            || plsqlSession.nodesByPackage.containsKey(pkg.toUpperCase()));
                link.setPlsqlNodeFound(plsqlConfirmed);

                List<CrossRefCollectionEntry> colls = buildCollectionEntries(info);
                link.setJavaCollections(colls);
                if (plsqlSession != null) {
                    // Prefer proc-level table filter: only tables THIS specific proc touches
                    String procRefUpper = procRef.toUpperCase();
                    Set<String> oracleTables = new LinkedHashSet<>();
                    for (String t : plsqlSession.tableToOracleProcs.keySet()) {
                        List<String> refs = plsqlSession.tableToOracleProcs.get(t);
                        if (refs.stream().anyMatch(r -> r.toUpperCase().equals(procRefUpper))) oracleTables.add(t);
                    }
                    // Fallback to package-level if proc-level yields nothing
                    if (oracleTables.isEmpty()) {
                        String pkgUpper = pkg.toUpperCase();
                        for (String t : plsqlSession.tableToOracleProcs.keySet()) {
                            List<String> refs = plsqlSession.tableToOracleProcs.get(t);
                            if (refs.stream().anyMatch(r -> r.toUpperCase().startsWith(pkgUpper + "."))) oracleTables.add(t);
                        }
                    }
                    link.setTableMatches(buildTableMatchesFromSets(colls, oracleTables));
                } else {
                    link.setTableMatches(buildTableMatchesInferred(colls));
                }
                link.setParameterMatches(buildParamMatches(info));
                link.setJavaOnlyCollections(link.getTableMatches().stream()
                        .filter(m -> "JAVA_ONLY".equals(m.getMatchStatus()))
                        .map(CrossRefTableMatch::getMongoCollection)
                        .collect(Collectors.toList()));
                links.add(link);
            }
        }

        // ── Build routing nodes (non-Pg classes that route to Oracle via children) ──
        List<CrossRefResult.RoutingNode> routingNodes = buildRoutingNodes(
                callTree, javaKeyToOraclePkgs, javaNodes);

        // ── Build two-way adjacency maps ──────────────────────────────────────
        Map<String, List<String>> j2o = new LinkedHashMap<>();
        Map<String, List<String>> o2j = new LinkedHashMap<>();

        for (Map.Entry<String, Set<String>> e : javaKeyToOraclePkgs.entrySet()) {
            String jKey = simpleKeyOf(e.getKey());
            for (String pkg : e.getValue()) {
                j2o.computeIfAbsent(jKey, k -> new ArrayList<>());
                if (!j2o.get(jKey).contains(pkg)) j2o.get(jKey).add(pkg);
                o2j.computeIfAbsent(pkg, k -> new ArrayList<>());
                if (!o2j.get(pkg).contains(jKey)) o2j.get(pkg).add(jKey);
            }
        }

        // ── Build table adjacency maps ────────────────────────────────────────
        Map<String, List<String>> t2j = new LinkedHashMap<>();
        Map<String, List<String>> j2t = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : tableToJavaKeys.entrySet()) {
            t2j.put(e.getKey(), new ArrayList<>(e.getValue().stream()
                    .map(this::simpleKeyOf).collect(Collectors.toList())));
        }
        for (Map.Entry<String, Set<String>> e : javaKeyToTables.entrySet()) {
            j2t.put(simpleKeyOf(e.getKey()), new ArrayList<>(e.getValue()));
        }

        // ── Build Oracle nodes list from PL/SQL session ───────────────────────
        List<CrossRefResult.OracleNode> oracleNodes = buildOracleNodes(plsqlSession, o2j, t2j);

        // ── Pass E: Gap analysis ──────────────────────────────────────────────
        List<CrossRefResult.JavaOnlyProc> javaOnlyProcs = new ArrayList<>();
        List<CrossRefResult.OracleOnlyProc> oracleOnlyProcs = new ArrayList<>();
        List<CrossRefResult.OperationGap> operationGaps = new ArrayList<>();

        // Java-only: nodes with collectionsAccessed that have no Oracle table match at all
        for (Map.Entry<String, JavaNodeInfo> entry : javaNodes.entrySet()) {
            String jKey = entry.getKey();
            JavaNodeInfo info = entry.getValue();
            if (isStrictInfraNode(info.simpleName) || isNoisyNode(info)) continue;
            if (info.collectionsAccessed.isEmpty()) continue;
            // Check if any of this node's tables appear in tables.json
            boolean anyTableMatched = info.collectionsAccessed.stream()
                    .anyMatch(t -> plsqlSession != null
                            && plsqlSession.tableToOracleProcs.containsKey(t.toUpperCase()));
            if (!anyTableMatched) {
                javaOnlyProcs.add(new CrossRefResult.JavaOnlyProc(
                        info.className, info.methodName, info.stereotype, info.operationType,
                        new ArrayList<>(info.collectionsAccessed),
                        "No matching Oracle table found for collections: " + info.collectionsAccessed));
            } else {
                // Some tables matched — check for operation mismatches
                for (String table : info.collectionsAccessed) {
                    String tableUpper = table.toUpperCase();
                    List<String> oracleProcsForTable = plsqlSession != null
                            ? plsqlSession.tableToOracleProcs.getOrDefault(tableUpper, List.of())
                            : List.of();
                    if (oracleProcsForTable.isEmpty()) {
                        operationGaps.add(new CrossRefResult.OperationGap(
                                tableUpper, info.operationType, null,
                                simpleKeyOf(jKey), null, "JAVA_ONLY_TABLE"));
                    }
                }
            }
        }

        // Oracle-only: Oracle nodes (depth 0-2) with no Java callers
        for (CrossRefResult.OracleNode on : oracleNodes) {
            if (on.getDepth() > 2) continue;
            boolean hasJavaCaller = !on.getJavaCallers().isEmpty() || !on.getJavaTableCallers().isEmpty();
            if (!hasJavaCaller) {
                String procRef = (on.getPackageName() != null && on.getObjectName() != null)
                        ? on.getPackageName() + "." + on.getObjectName()
                        : on.getObjectName();
                // Collect tables this Oracle proc accesses (from tables.json referencedBy)
                List<String> oracleProcTables = new ArrayList<>();
                if (plsqlSession != null && procRef != null) {
                    String procRefUpper = procRef.toUpperCase();
                    for (Map.Entry<String, List<String>> te : plsqlSession.tableToOracleProcs.entrySet()) {
                        if (te.getValue().stream().anyMatch(r -> r.toUpperCase().equals(procRefUpper))) {
                            oracleProcTables.add(te.getKey());
                        }
                    }
                }
                oracleOnlyProcs.add(new CrossRefResult.OracleOnlyProc(
                        procRef, on.getPackageName(), on.getObjectName(),
                        on.getDepth(), oracleProcTables));
            }
        }

        result.setProcLinks(links);
        result.setLowConfidenceHints(lowConfHints);
        result.setRoutingNodes(routingNodes);
        result.setInfraNodes(infraNodes);
        result.setJavaToOracleMap(j2o);
        result.setOracleToJavaMap(o2j);
        result.setTableToJavaMap(t2j);
        result.setJavaToTableMap(j2t);
        result.setOracleNodes(oracleNodes);
        result.setJavaOnlyProcs(javaOnlyProcs);
        result.setOracleOnlyProcs(oracleOnlyProcs);
        result.setOperationGaps(operationGaps);
        result.setSummary(buildSummary(links, lowConfHints, infraNodes, routingNodes, oracleNodes,
                j2o, o2j, javaOnlyProcs, oracleOnlyProcs, operationGaps));
        return result;
    }

    // ── Flat Java node collection ─────────────────────────────────────────────

    /** Walk the call tree and collect all unique Java nodes into a flat map (deduped by className#method). */
    private void collectJavaNodes(JsonNode node, Map<String, JavaNodeInfo> out) {
        if (node == null || node.isNull()) return;

        String className  = node.path("className").asText("");
        String simpleName = node.path("simpleClassName").asText(
                className.contains(".") ? className.substring(className.lastIndexOf('.') + 1) : className);
        String methodName = node.path("methodName").asText("");

        if (!simpleName.isBlank() && !methodName.isBlank()) {
            String dedupeKey = simpleName + "#" + methodName;
            if (!out.containsKey(dedupeKey)) {
                JavaNodeInfo info = new JavaNodeInfo();
                info.dedupeKey    = dedupeKey;
                info.className    = className;
                info.simpleName   = simpleName;
                info.methodName   = methodName;
                info.stereotype   = nullIfBlank(node.path("stereotype").asText(""));
                info.operationType = nullIfBlank(node.path("operationType").asText(""));

                for (JsonNode ann : node.path("annotations")) {
                    String a = ann.asText("");
                    if (a.contains("LogParameters") || a.contains("LogParameter")) {
                        info.hasLogParameters = true;
                        break;
                    }
                }

                for (JsonNode c : node.path("collectionsAccessed")) {
                    String col = c.isTextual() ? c.asText() : c.path("name").asText("");
                    if (!col.isBlank()) info.collectionsAccessed.add(col.toUpperCase());
                }
                for (JsonNode lit : node.path("stringLiterals")) {
                    String s = lit.asText("").trim();
                    if (!s.isBlank()) info.stringLiterals.add(s);
                }
                out.put(dedupeKey, info);
            }
        }

        for (JsonNode child : node.path("children")) {
            collectJavaNodes(child, out);
        }
    }

    // ── Pass D: Zone propagation ──────────────────────────────────────────────

    /**
     * Top-down walk: carry the current Oracle zone (package name) downward.
     *
     * TIGHTENED from original: zone only propagates at @LogParameters boundary nodes.
     * Non-annotated unresolved nodes do NOT inherit — this prevents a single root-level
     * Oracle package from flooding every child in a 200-node call tree.
     *
     * At each node:
     *   1. If resolved by Pass A/B/C → that becomes the new zone for this subtree.
     *   2. If unresolved but has @LogParameters → attempt extra resolution, then record
     *      inheritedZone for Pass E assignment. Zone continues into children.
     *   3. If unresolved, no @LogParameters → zone does NOT propagate. inheritedZone stays null.
     */
    private void propagateZones(JsonNode node, String parentZone,
                                 Map<String, Set<String>> javaKeyToOraclePkgs,
                                 Map<String, JavaNodeInfo> javaNodes,
                                 PlsqlSessionData plsqlSession) {
        if (node == null || node.isNull()) return;

        String className  = node.path("className").asText("");
        String simpleName = node.path("simpleClassName").asText(
                className.contains(".") ? className.substring(className.lastIndexOf('.') + 1) : className);
        String methodName = node.path("methodName").asText("");
        String nodeKey    = simpleName + "#" + methodName;

        String currentZone = parentZone;

        if (!simpleName.isBlank() && !methodName.isBlank()) {
            JavaNodeInfo info = javaNodes.get(nodeKey);

            Set<String> resolved = javaKeyToOraclePkgs.get(nodeKey);
            boolean alreadyResolved = resolved != null && !resolved.isEmpty();

            if (alreadyResolved) {
                // Resolved node starts a new zone for its subtree
                currentZone = resolved.iterator().next();
            } else if (info != null && !isStrictInfraNode(simpleName)) {
                if (info.hasLogParameters) {
                    // @LogParameters boundary: try harder, then record inherited zone
                    String attempted = attemptZoneResolution(simpleName, methodName, plsqlSession);
                    if (attempted != null) {
                        javaKeyToOraclePkgs.computeIfAbsent(nodeKey, k -> new LinkedHashSet<>()).add(attempted);
                        currentZone = attempted;
                    } else if (parentZone != null) {
                        info.inheritedZone = parentZone;
                        // currentZone stays as parentZone — propagates to children of this boundary node
                    }
                }
                // No @LogParameters: do NOT propagate zone. currentZone resets to null for children
                // of this unresolved node, breaking the chain.
                else {
                    currentZone = null;
                }
            }
        }

        for (JsonNode child : node.path("children")) {
            propagateZones(child, currentZone, javaKeyToOraclePkgs, javaNodes, plsqlSession);
        }
    }

    /**
     * Extra resolution attempt for @LogParameters nodes that Pass A/B/C missed.
     * Tries Pg-naming first, then fuzzy match. Returns the Oracle package or null.
     */
    private String attemptZoneResolution(String simpleName, String methodName,
                                          PlsqlSessionData plsqlSession) {
        // Pass B: Pg-naming
        String inferredPkg = inferencer.inferPackageName(simpleName);
        if (inferredPkg != null) return inferredPkg;

        // Pass C: fuzzy — only if session available
        if (plsqlSession != null && !plsqlSession.nodesByPackage.isEmpty()) {
            return fuzzyMatchOraclePackage(simpleName, plsqlSession.nodesByPackage.keySet());
        }
        return null;
    }

    // ── Routing node builder ──────────────────────────────────────────────────

    /**
     * Walk the call tree recursively; return the set of Oracle packages reachable from each subtree.
     * Non-Pg nodes with non-empty child packages become RoutingNodes.
     */
    private List<CrossRefResult.RoutingNode> buildRoutingNodes(
            JsonNode callTree,
            Map<String, Set<String>> javaKeyToOraclePkgs,
            Map<String, JavaNodeInfo> javaNodes) {

        List<CrossRefResult.RoutingNode> routingNodes = new ArrayList<>();
        Set<String> seenRouting = new HashSet<>();
        walkForRouting(callTree, javaKeyToOraclePkgs, javaNodes, routingNodes, seenRouting);
        return routingNodes;
    }

    private Set<String> walkForRouting(JsonNode node,
                                        Map<String, Set<String>> javaKeyToOraclePkgs,
                                        Map<String, JavaNodeInfo> javaNodes,
                                        List<CrossRefResult.RoutingNode> routingNodes,
                                        Set<String> seenRouting) {
        if (node == null || node.isNull()) return Set.of();

        String className  = node.path("className").asText("");
        String simpleName = node.path("simpleClassName").asText(
                className.contains(".") ? className.substring(className.lastIndexOf('.') + 1) : className);
        String methodName = node.path("methodName").asText("");
        String nodeKey    = simpleName + "#" + methodName;

        // Collect packages from all children first
        Set<String> childPkgs = new LinkedHashSet<>();
        for (JsonNode child : node.path("children")) {
            childPkgs.addAll(walkForRouting(child, javaKeyToOraclePkgs, javaNodes, routingNodes, seenRouting));
        }

        if (simpleName.isBlank() || methodName.isBlank()) return childPkgs;

        // My own direct Oracle packages (Pass A + B)
        Set<String> myPkgs = new LinkedHashSet<>(javaKeyToOraclePkgs.getOrDefault(nodeKey, Set.of()));
        myPkgs.addAll(childPkgs);

        // If this node has no direct Oracle link but its subtree does → routing node
        boolean hasDirectLink = javaKeyToOraclePkgs.containsKey(nodeKey)
                && !javaKeyToOraclePkgs.get(nodeKey).isEmpty();

        if (!hasDirectLink && !childPkgs.isEmpty() && !isStrictInfraNode(simpleName)
                && !seenRouting.contains(nodeKey)) {
            seenRouting.add(nodeKey);
            CrossRefResult.RoutingNode rn = new CrossRefResult.RoutingNode(
                    className, methodName, nullIfBlank(node.path("stereotype").asText("")));
            rn.setCalledOraclePackages(new ArrayList<>(childPkgs));

            // directProcCallers: immediate children that have direct Oracle links
            List<String> directCallers = new ArrayList<>();
            for (JsonNode child : node.path("children")) {
                String cSimple = child.path("simpleClassName").asText(
                        child.path("className").asText("").replaceAll(".*\\.", ""));
                String cMethod = child.path("methodName").asText("");
                String cKey = cSimple + "#" + cMethod;
                if (javaKeyToOraclePkgs.containsKey(cKey) && !javaKeyToOraclePkgs.get(cKey).isEmpty()
                        && !isStrictInfraNode(cSimple)) {
                    directCallers.add(cSimple + "." + cMethod);
                }
            }
            rn.setDirectProcCallers(directCallers);
            routingNodes.add(rn);
        }

        return myPkgs;
    }

    // ── Oracle nodes builder ──────────────────────────────────────────────────

    private List<CrossRefResult.OracleNode> buildOracleNodes(PlsqlSessionData plsqlSession,
                                                              Map<String, List<String>> o2j,
                                                              Map<String, List<String>> t2j) {
        List<CrossRefResult.OracleNode> result = new ArrayList<>();
        if (plsqlSession == null) return result;

        for (JsonNode node : plsqlSession.nodeList) {
            CrossRefResult.OracleNode on = new CrossRefResult.OracleNode();
            on.setNodeId(node.path("nodeId").asText(""));
            on.setPackageName(nullIfBlank(node.path("packageName").asText("")));
            on.setObjectName(nullIfBlank(node.path("objectName").asText("")));
            on.setSchema(nullIfBlank(node.path("schema").asText("")));
            on.setObjectType(nullIfBlank(node.path("objectType").asText("")));
            on.setDepth(node.path("depth").asInt(0));
            on.setParentNodeId(nullIfBlank(node.path("parentNodeId").asText("")));

            // Java callers via Pg-naming (Pass B)
            String pkgName = on.getPackageName();
            if (pkgName != null) {
                List<String> callers = o2j.getOrDefault(pkgName.toUpperCase(), List.of());
                on.setJavaCallers(new ArrayList<>(callers));
            }

            // Java callers via table linkage (Pass A)
            String procRef = (on.getPackageName() != null && on.getObjectName() != null)
                    ? on.getPackageName() + "." + on.getObjectName() : on.getObjectName();
            if (procRef != null) {
                Set<String> tableCallers = new LinkedHashSet<>();
                for (Map.Entry<String, List<String>> te : t2j.entrySet()) {
                    // Check if this Oracle proc references this table
                    List<String> oracleRefs = plsqlSession.tableToOracleProcs.getOrDefault(te.getKey(), List.of());
                    if (oracleRefs.stream().anyMatch(r -> r.equalsIgnoreCase(procRef)
                            || r.equalsIgnoreCase(procRef.replace(".", ".").toUpperCase()))) {
                        tableCallers.addAll(te.getValue());
                    }
                }
                on.setJavaTableCallers(new ArrayList<>(tableCallers));
            }

            result.add(on);
        }

        // Sort by depth then alphabetical
        result.sort(Comparator.comparingInt(CrossRefResult.OracleNode::getDepth)
                .thenComparing(n -> (n.getPackageName() != null ? n.getPackageName() : "")
                        + "." + (n.getObjectName() != null ? n.getObjectName() : "")));
        return result;
    }

    // ── Table match builders ──────────────────────────────────────────────────

    private List<CrossRefCollectionEntry> buildCollectionEntries(JavaNodeInfo info) {
        List<CrossRefCollectionEntry> entries = new ArrayList<>();
        String seq = info.stringLiterals.stream().filter(s -> s.startsWith("SQ_")).findFirst().orElse(null);
        for (String col : info.collectionsAccessed) {
            entries.add(new CrossRefCollectionEntry(col, info.operationType != null ? info.operationType : "UNKNOWN", seq));
        }
        return entries;
    }

    private List<CrossRefTableMatch> buildTableMatchesFromSets(List<CrossRefCollectionEntry> javaColls,
                                                                 Set<String> oracleTables) {
        List<CrossRefTableMatch> matches = new ArrayList<>();
        for (CrossRefCollectionEntry jc : javaColls) {
            String col = jc.getCollection().toUpperCase();
            CrossRefTableMatch m = new CrossRefTableMatch();
            m.setMongoCollection(col);
            m.setOracleTable(col);
            m.setJavaOperation(jc.getOperation());
            m.setOracleSequence(jc.getSequence());
            m.setMatchStatus(oracleTables.contains(col) ? "MATCHED" : "JAVA_ONLY");
            matches.add(m);
        }
        return matches;
    }

    private List<CrossRefTableMatch> buildTableMatchesInferred(List<CrossRefCollectionEntry> javaColls) {
        return javaColls.stream().map(jc -> {
            CrossRefTableMatch m = new CrossRefTableMatch();
            m.setMongoCollection(jc.getCollection().toUpperCase());
            m.setOracleTable(jc.getCollection().toUpperCase());
            m.setJavaOperation(jc.getOperation());
            m.setOracleSequence(jc.getSequence());
            m.setMatchStatus("INFERRED");
            return m;
        }).collect(Collectors.toList());
    }

    private List<CrossRefParamMatch> buildParamMatches(JavaNodeInfo info) {
        List<CrossRefParamMatch> matches = new ArrayList<>();
        for (String s : info.stringLiterals) {
            s = s.trim();
            if (s.length() < 2 || !s.matches("[A-Z][A-Z0-9_]{1,}")) continue;
            if (s.startsWith("SQ_")) continue;
            matches.add(new CrossRefParamMatch(s, "P_" + s, null));
        }
        return matches;
    }

    // ── Fuzzy package matching (Pass C) ──────────────────────────────────────

    /**
     * Strip Java class name to a segment and check if any known Oracle package
     * name contains that segment (case-insensitive, underscore/camel normalised).
     */
    private String fuzzyMatchOraclePackage(String simpleName, Set<String> knownOraclePkgs) {
        // Strip known Java prefixes/suffixes
        String stripped = simpleName;
        for (String pfx : List.of("ExtensionPolicy", "CorePolicy", "Extension", "Core",
                                   "CustomerExtensionPolicy", "Customer")) {
            if (stripped.startsWith(pfx)) { stripped = stripped.substring(pfx.length()); break; }
        }
        // Strip "Pg" prefix (already handled by Pass B, but strip for Pass C segment extraction)
        if (stripped.startsWith("Pg")) stripped = stripped.substring(2);
        for (String sfx : List.of("RepositoryCustomerExtensionPolicy", "ServiceCustomerExtensionPolicy",
                                   "ServiceCustomer", "RepositoryCustomer", "TriggerService",
                                   "ServiceImpl", "RepositoryImpl", "DaoImpl", "Repository",
                                   "Service", "Impl", "Bean", "DTO", "Mapper", "Utils", "Util",
                                   "Controller", "Facade")) {
            if (stripped.endsWith(sfx)) { stripped = stripped.substring(0, stripped.length() - sfx.length()); break; }
        }
        if (stripped.isBlank()) return null;

        // Convert to UPPER_SNAKE and split into tokens
        String segment = OracleProcNameInferencer.camelToUpperSnake(stripped);
        String[] parts = segment.split("_");
        if (parts.length == 0) return null;

        // Score: weighted token overlap with Oracle package names.
        // Short tokens (≤2 chars) only count if they're a meaningful abbreviation.
        // Tie-break: prefer longer package names (more specific match).
        String bestPkg = null;
        int bestScore = 0;
        for (String pkg : knownOraclePkgs) {
            // Strip PG_ prefix from pkg for scoring (we compare the domain portion)
            String pkgCore = pkg.startsWith("PG_") ? pkg.substring(3) : pkg;
            int score = 0;
            int matchedTokens = 0;
            for (String part : parts) {
                if (part.length() <= 2) {
                    // Short token: only match if it appears as a standalone segment in pkg
                    if (pkgCore.equals(part) || pkgCore.startsWith(part + "_") || pkgCore.endsWith("_" + part)
                            || pkgCore.contains("_" + part + "_")) {
                        score += part.length() * 2; // bonus for exact segment match
                        matchedTokens++;
                    }
                } else if (pkgCore.contains(part)) {
                    score += part.length();
                    matchedTokens++;
                }
            }
            // Require at least 2 tokens matched OR 1 token of length ≥ 5 to avoid noise
            boolean meetsBar = matchedTokens >= 2 || (matchedTokens == 1 && score >= 5);
            if (meetsBar && score > bestScore) {
                bestScore = score;
                bestPkg = pkg;
            }
        }

        return (bestScore >= 4) ? bestPkg : null;
    }

    /**
     * Within a confirmed Oracle package, try to match a specific proc.
     * Strips class name to core segment (e.g. InvokeNewBusiness → INVOKENEWBUSINESS)
     * and compares against each proc's object name (after stripping PC_/FN_ prefixes).
     * Also tries method name as a fallback.
     * Returns "PKG.PROC" if a confident match is found, null otherwise.
     */
    private String fuzzyMatchOracleProc(String simpleName, String methodName,
                                         String fuzzyPkg, PlsqlSessionData plsqlSession) {
        if (plsqlSession == null || fuzzyPkg == null) return null;

        // Extract core segment from class name using same stripping logic as fuzzyMatchOraclePackage
        String stripped = simpleName;
        for (String pfx : List.of("ExtensionPolicy", "CorePolicy", "Extension", "Core",
                                   "CustomerExtensionPolicy", "Customer")) {
            if (stripped.startsWith(pfx)) { stripped = stripped.substring(pfx.length()); break; }
        }
        if (stripped.startsWith("Pg")) stripped = stripped.substring(2);
        for (String sfx : List.of("RepositoryCustomerExtensionPolicy", "ServiceCustomerExtensionPolicy",
                                   "ServiceCustomer", "RepositoryCustomer", "TriggerService",
                                   "ServiceImpl", "RepositoryImpl", "DaoImpl", "Repository",
                                   "Service", "Impl", "Bean", "DTO", "Mapper", "Utils", "Util",
                                   "Controller", "Facade")) {
            if (stripped.endsWith(sfx)) { stripped = stripped.substring(0, stripped.length() - sfx.length()); break; }
        }
        if (stripped.isBlank()) return null;

        String segmentSnake = OracleProcNameInferencer.camelToUpperSnake(stripped);
        String segmentFlat  = segmentSnake.replace("_", "");           // e.g. INVOKENEWBUSINESS
        String methodSnake  = OracleProcNameInferencer.camelToUpperSnake(methodName);
        String methodFlat   = methodSnake.replace("_", "");

        String pkgUpper = fuzzyPkg.toUpperCase();
        String bestProc = null;
        int bestScore = 0;

        for (Map.Entry<String, JsonNode> procEntry : plsqlSession.procByName.entrySet()) {
            String key = procEntry.getKey(); // "PKG.PROC" uppercase
            if (!key.startsWith(pkgUpper + ".")) continue;

            String procFull = key.substring(pkgUpper.length() + 1); // "PC_INVOKENEWBUSINESS"
            // Strip common Oracle proc prefixes to get domain portion
            String procCore = procFull;
            for (String pfx : List.of("PC_", "FN_", "PN_", "SP_", "PG_", "PR_")) {
                if (procCore.startsWith(pfx)) { procCore = procCore.substring(pfx.length()); break; }
            }
            String procFlat = procCore.replace("_", ""); // e.g. INVOKENEWBUSINESS

            int score = 0;
            if (procFlat.equals(segmentFlat) || procFlat.equals(methodFlat)) {
                score = 100; // exact flat match
            } else if (segmentFlat.length() >= 5 && (procFlat.contains(segmentFlat) || segmentFlat.contains(procFlat))) {
                score = 80;  // substring flat match
            } else if (methodFlat.length() >= 5 && procFlat.contains(methodFlat)) {
                score = 70;
            } else {
                // Token-level: count how many SNAKE tokens appear in the proc core
                String[] tokens = segmentSnake.split("_");
                int matched = 0;
                for (String tok : tokens) {
                    if (tok.length() >= 3 && procCore.contains(tok)) matched++;
                }
                if (matched >= 2 || (matched == 1 && tokens.length == 1 && tokens[0].length() >= 6)) {
                    score = matched * 10;
                }
            }

            if (score > bestScore) {
                bestScore = score;
                // Return the original-case proc name from the node JSON if possible
                JsonNode pNode = procEntry.getValue();
                String origPkg  = pNode.path("packageName").asText(fuzzyPkg);
                String origProc = pNode.path("objectName").asText(procFull);
                bestProc = origPkg + "." + origProc;
            }
        }

        return (bestScore >= 70) ? bestProc : null;
    }

    /**
     * Proc-first search: extract class segment → search ALL procs in session for objectName match.
     * Handles classes like CorePolicyInvokeNewBusinessImpl whose name matches the Oracle PROC
     * (PC_INVOKENEWBUSINESS) but NOT the package (PG_UWGE_PME_API).
     * Returns "PKG.PROC" on strong match, null otherwise.
     */
    private String fuzzyMatchProcDirectly(String simpleName, String methodName,
                                           PlsqlSessionData plsqlSession) {
        if (plsqlSession == null) return null;

        // Extract core segment
        String stripped = simpleName;
        for (String pfx : List.of("ExtensionPolicy", "CorePolicy", "Extension", "Core",
                                   "CustomerExtensionPolicy", "Customer")) {
            if (stripped.startsWith(pfx)) { stripped = stripped.substring(pfx.length()); break; }
        }
        if (stripped.startsWith("Pg")) stripped = stripped.substring(2);
        for (String sfx : List.of("RepositoryCustomerExtensionPolicy", "ServiceCustomerExtensionPolicy",
                                   "ServiceCustomer", "RepositoryCustomer", "TriggerService",
                                   "ServiceImpl", "RepositoryImpl", "DaoImpl", "Repository",
                                   "Service", "Impl", "Bean", "DTO", "Mapper", "Utils", "Util",
                                   "Controller", "Facade")) {
            if (stripped.endsWith(sfx)) { stripped = stripped.substring(0, stripped.length() - sfx.length()); break; }
        }
        if (stripped.isBlank() || stripped.length() < 5) return null;

        String segmentFlat  = stripped.toUpperCase().replace("_", "");
        String methodFlat   = OracleProcNameInferencer.camelToUpperSnake(methodName).replace("_", "");

        String bestRef = null;
        int bestScore = 0;

        for (Map.Entry<String, JsonNode> entry : plsqlSession.procByName.entrySet()) {
            String key = entry.getKey(); // "PKG.PROC" uppercase
            if (!key.contains(".")) continue;
            int dot = key.indexOf('.');
            String pkgKey  = key.substring(0, dot);
            String procKey = key.substring(dot + 1);

            // Strip common Oracle proc prefixes
            String procCore = procKey;
            for (String pfx : List.of("PC_", "FN_", "PN_", "SP_", "PG_", "PR_")) {
                if (procCore.startsWith(pfx)) { procCore = procCore.substring(pfx.length()); break; }
            }
            String procFlat = procCore.replace("_", "");
            if (procFlat.length() < 5) continue;

            int score = 0;
            if (procFlat.equals(segmentFlat) || procFlat.equals(methodFlat)) {
                score = 100;
            } else if (segmentFlat.length() >= 6 && procFlat.contains(segmentFlat)) {
                score = 90;
            } else if (segmentFlat.length() >= 6 && segmentFlat.contains(procFlat) && procFlat.length() >= 8) {
                score = 85;
            } else if (methodFlat.length() >= 6 && procFlat.equals(methodFlat)) {
                score = 80;
            }

            if (score > bestScore) {
                bestScore = score;
                JsonNode pNode = entry.getValue();
                String origPkg  = pNode.path("packageName").asText(pkgKey);
                String origProc = pNode.path("objectName").asText(procKey);
                bestRef = origPkg + "." + origProc;
            }
        }

        return (bestScore >= 80) ? bestRef : null;
    }

    /**
     * Construct a CrossRefProcLink for a Pass C fuzzy match.
     * confidence: "MEDIUM" (exact proc found) or "LOW" (package-only match).
     * pkg is used to look up which Oracle tables the package accesses, for table match building.
     */
    private CrossRefProcLink buildFuzzyLink(JavaNodeInfo info, String resolvedRef, String confidence,
                                             String zoneSource, boolean plsqlConfirmed,
                                             PlsqlSessionData plsqlSession, String pkg) {
        CrossRefProcLink link = new CrossRefProcLink();
        link.setJavaClass(info.className);
        link.setJavaMethod(info.methodName);
        link.setJavaStereotype(info.stereotype);
        link.setJavaOperationType(info.operationType);
        link.setJavaNodeId(info.simpleName + "#" + info.methodName);
        link.setInferredProcRef(resolvedRef);
        link.setResolvedProcRef(resolvedRef);
        link.setMatchConfidence(confidence);
        link.setPlsqlNodeFound(plsqlConfirmed);
        link.setHasLogParameters(info.hasLogParameters);
        link.setZoneSource(zoneSource);

        List<CrossRefCollectionEntry> colls = buildCollectionEntries(info);
        link.setJavaCollections(colls);

        if (plsqlSession != null && pkg != null) {
            String pkgUpper = pkg.toUpperCase();
            Set<String> oracleTables = new LinkedHashSet<>();
            for (String t : plsqlSession.tableToOracleProcs.keySet()) {
                List<String> refs = plsqlSession.tableToOracleProcs.get(t);
                if (refs.stream().anyMatch(r -> r.toUpperCase().startsWith(pkgUpper))) oracleTables.add(t);
            }
            link.setTableMatches(buildTableMatchesFromSets(colls, oracleTables));
        } else {
            link.setTableMatches(buildTableMatchesInferred(colls));
        }
        link.setParameterMatches(buildParamMatches(info));
        link.setJavaOnlyCollections(link.getTableMatches().stream()
                .filter(m -> "JAVA_ONLY".equals(m.getMatchStatus()))
                .map(CrossRefTableMatch::getMongoCollection)
                .collect(Collectors.toList()));
        return link;
    }

    // ── Summary builder ───────────────────────────────────────────────────────

    private CrossRefSummary buildSummary(List<CrossRefProcLink> links,
                                          List<CrossRefProcLink> lowConfHints,
                                          List<CrossRefResult.InfraNode> infraNodes,
                                          List<CrossRefResult.RoutingNode> routingNodes,
                                          List<CrossRefResult.OracleNode> oracleNodes,
                                          Map<String, List<String>> j2o,
                                          Map<String, List<String>> o2j,
                                          List<CrossRefResult.JavaOnlyProc> javaOnlyProcs,
                                          List<CrossRefResult.OracleOnlyProc> oracleOnlyProcs,
                                          List<CrossRefResult.OperationGap> operationGaps) {
        CrossRefSummary s = new CrossRefSummary();
        s.setTotalJavaNodes(j2o.size() + infraNodes.size());
        s.setUnmatchedJavaNodes(infraNodes.size());
        s.setHighConfidenceLinks((int) links.stream().filter(l -> "HIGH".equals(l.getMatchConfidence())).count());
        s.setMediumConfidenceLinks((int) links.stream().filter(l -> "MEDIUM".equals(l.getMatchConfidence())).count());
        s.setLowConfidenceLinks((int) links.stream().filter(l -> "LOW".equals(l.getMatchConfidence())).count());

        int plsqlConfirmed = (int) oracleNodes.stream()
                .filter(n -> !n.getJavaCallers().isEmpty() || !n.getJavaTableCallers().isEmpty()).count();
        s.setPlsqlNodesFound(plsqlConfirmed > 0 ? plsqlConfirmed
                : (int) links.stream().filter(CrossRefProcLink::isPlsqlNodeFound).count());

        int totalCols = 0, matched = 0, javaOnly = 0, oracleOnly = 0, opMismatch = 0;
        for (CrossRefProcLink l : links) {
            for (CrossRefTableMatch tm : l.getTableMatches()) {
                totalCols++;
                switch (tm.getMatchStatus() == null ? "" : tm.getMatchStatus()) {
                    case "MATCHED"    -> matched++;
                    case "JAVA_ONLY"  -> javaOnly++;
                    case "ORACLE_ONLY"-> oracleOnly++;
                    case "OP_MISMATCH"-> opMismatch++;
                    case "INFERRED"   -> matched++;
                }
            }
        }
        s.setTotalJavaCollections(totalCols);
        s.setMatchedTables(matched);
        s.setJavaOnlyCollections(javaOnly);
        s.setOracleOnlyTables(oracleOnly);
        s.setOperationMismatches(opMismatch);

        // Gap analysis counts
        s.setJavaOnlyProcCount(javaOnlyProcs.size());
        s.setOracleOnlyProcCount(oracleOnlyProcs.size());
        s.setOperationGapCount(operationGaps.size());
        s.setLowConfidenceHintCount(lowConfHints.size());
        return s;
    }

    // ── Classification helpers ────────────────────────────────────────────────

    /**
     * Returns true for nodes that are analysis noise with no Oracle significance:
     * - Getters/setters/is* with no collectionsAccessed
     * - Lambda methods with no collectionsAccessed
     * - Inner context classes ($InnerClass) with no collectionsAccessed
     */
    private boolean isNoisyNode(JavaNodeInfo info) {
        String m = info.methodName;
        boolean noCollections = info.collectionsAccessed.isEmpty();
        if (noCollections && (m.startsWith("get") || m.startsWith("set") || m.startsWith("is"))) return true;
        if (noCollections && m.startsWith("lambda$")) return true;
        if (noCollections && info.simpleName.contains("$")) return true;
        return false;
    }

    private boolean isStrictInfraNode(String simpleName) {
        return INFRA_CLASS_FRAGMENTS.stream().anyMatch(simpleName::startsWith);
    }

    private boolean isLoggingNode(String simpleName) {
        return LOGGING_CLASS_FRAGMENTS.stream().anyMatch(simpleName::startsWith);
    }

    private String classifyInfraReason(String simpleName) {
        if (simpleName.startsWith("InfLck")) return "LOCK_MANAGEMENT";
        if (simpleName.startsWith("InfGam")) return "LOGGING";
        if (simpleName.startsWith("BatchProcessor")) return "BATCH_INFRA";
        if (simpleName.startsWith("SequenceService")) return "SEQUENCE_SERVICE";
        if (simpleName.startsWith("OpusInf") || simpleName.startsWith("OpuMsg")) return "INFRASTRUCTURE";
        return "INFRASTRUCTURE";
    }

    /** Convert a "SimpleName#method" dedupeKey to "SimpleName.method" for display. */
    private String simpleKeyOf(String dedupeKey) {
        return dedupeKey.replace('#', '.');
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    // ── Internal data holders ─────────────────────────────────────────────────

    private static class JavaNodeInfo {
        String dedupeKey;
        String className;
        String simpleName;
        String methodName;
        String stereotype;
        String operationType;
        boolean hasLogParameters;   // @LogParameters annotation present — facade boundary hint
        String inheritedZone;       // Pass D: Oracle package inherited from nearest @LogParameters ancestor
        List<String> collectionsAccessed = new ArrayList<>();
        List<String> stringLiterals = new ArrayList<>();
    }

    private static class PlsqlSessionData {
        String sessionId;
        ArtifactKey sessionDir;
        List<String> nodeIds = new ArrayList<>();
        List<JsonNode> nodeList = new ArrayList<>();
        Map<String, JsonNode> procByName = new LinkedHashMap<>();           // "PKG.PROC" UPPER → node
        Map<String, List<JsonNode>> nodesByPackage = new LinkedHashMap<>(); // "PKG" UPPER → nodes
        Map<String, List<String>> tableToOracleProcs = new LinkedHashMap<>(); // TABLE UPPER → ["PKG.PROC",...]
    }
}
