#!/usr/bin/env python3
"""
Stamp every local js/css reference with its file's modification time.

Run this after changing any static asset, and before packaging:

    python3 scripts/stamp-assets.py

WHY THIS EXISTS
---------------
A fix was made to jar/js/api.js and shipped with the page still requesting `api.js?v=2` — the same
URL as before. Browsers served the cached old file, so the fix was in the source, in the jar, and
invisible to the user, who quite reasonably reported it as unfixed. Hand-maintained version numbers
fail exactly this way: the edit and the bump are two steps, and the second is easy to forget.

Stamping by mtime makes the URL a function of the file. It changes when, and only when, the file
changes. There is nothing to remember.

CDN URLs are left alone, and so is any path that does not resolve on disk — silently rewriting a
reference this script cannot verify would be worse than leaving it.
"""
import os
import re
import sys
import glob

STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      "..", "unified-web", "src", "main", "resources", "static")
ASSET = re.compile(r'((?:src|href)=")([^"]+?\.(?:js|css))(\?[^"]*)?(")')


def main() -> int:
    root = os.path.normpath(STATIC)
    if not os.path.isdir(root):
        print(f"static root not found: {root}", file=sys.stderr)
        return 1

    os.chdir(root)
    pages = sorted(glob.glob("*.html") + glob.glob("*/index.html"))
    total = 0
    for page in pages:
        d = os.path.dirname(page) or "."
        original = open(page, encoding="utf-8").read()

        def repl(m):
            pre, path, _old, post = m.groups()
            if path.startswith(("http://", "https://", "//")):
                return m.group(0)
            fs = os.path.normpath(os.path.join("" if path.startswith("/") else d,
                                               path.lstrip("/")))
            if not os.path.isfile(fs):
                return m.group(0)
            return f"{pre}{path}?v={int(os.path.getmtime(fs))}{post}"

        stamped = ASSET.sub(repl, original)
        if stamped != original:
            open(page, "w", encoding="utf-8").write(stamped)
            total += 1
            print(f"  stamped {page}")
    print(f"{total} page(s) updated" if total else "all pages already current")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
