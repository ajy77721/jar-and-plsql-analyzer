#!/usr/bin/env bash
# Build, but REFUSE if a packaged instance is running.
#
# Replacing a Spring Boot fat jar while a JVM is running it corrupts that process: Boot resolves
# nested classes lazily, so every not-yet-loaded class becomes unresolvable. The failure is ugly and
# misleading — it surfaces as NoClassDefFoundError on a logback class, because the logging path
# itself needs a class it can no longer load, which means the ORIGINAL error is never printed.
#
# This has happened twice in this repo. The second time there WAS a check, but it only echoed a
# warning and let the build proceed on the next line. A guard that does not exit is not a guard,
# so this one exits non-zero and does nothing else.
set -euo pipefail

JAR_NAME="unified-web-1.0.0-SNAPSHOT.jar"
PIDS="$(pgrep -f "java .*${JAR_NAME}" || true)"

if [ -n "$PIDS" ]; then
    echo "REFUSING TO BUILD — a packaged instance is running:" >&2
    for p in $PIDS; do
        ps -o pid=,lstart=,args= -p "$p" 2>/dev/null | cut -c1-140 | sed 's/^/  /' >&2
    done
    cat >&2 <<'MSG'

Rebuilding now would corrupt that process rather than update it.

  Stop it:   pkill -f 'java .*unified-web-1.0.0-SNAPSHOT.jar'
  Or develop without packaging, which cannot be corrupted by a rebuild:
             mvn -pl unified-web spring-boot:run
MSG
    exit 1
fi

echo "No packaged instance running — building."
exec mvn "$@"
