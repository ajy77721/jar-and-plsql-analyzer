#!/usr/bin/env python3
"""Inventory every direct filesystem access outside analyzer-storage.

The storage migration's hard question is not "how do I convert this call site" but "are any
left, and is each survivor justified". This answers it from source, the same way
DirectFileIoGateTest does, and groups the survivors so they can be judged rather than counted.

Usage:
    scan.py                 # summary by module and category
    scan.py --by-class      # every class, descending
    scan.py --class NAME    # every hit in one class, with line numbers
    scan.py --json          # machine-readable
"""
import argparse
import collections
import json
import os
import re
import sys

SKIP = ("/target/", "_migration-backup", "data_old_", "/scratchpad/", "/.claude/")
STORAGE_MODULE = "analyzer-storage"

# Optional package qualifier, so `new java.io.File` is caught as well as `new File`.
Q = r"(?:[a-zA-Z_][\w.]*\.)?"

PATTERNS = [
    ("Files.*",             rf"\b{Q}Files\s*\.\s*[a-zA-Z]"),
    ("new File",            rf"\bnew\s+{Q}File\s*[(\[]"),
    ("File statics",        rf"\b{Q}File\s*\.\s*(?:createTempFile|separator|separatorChar|listRoots|pathSeparator)"),
    ("File methods",        r"\.\s*(?:listFiles|getParentFile|getAbsoluteFile|getCanonicalFile|mkdirs?|createNewFile|renameTo|deleteOnExit)\s*\("),
    ("File streams",        rf"\bnew\s+{Q}(?:FileInputStream|FileOutputStream|FileReader|FileWriter|RandomAccessFile)\s*\("),
    ("Jar/Zip",             rf"\bnew\s+{Q}(?:JarFile|ZipFile|ZipOutputStream|ZipInputStream|JarOutputStream|JarInputStream)\s*\("),
    ("Path.of/get",         rf"\b{Q}(?:Path\s*\.\s*of|Paths\s*\.\s*get)\s*\("),
    (".toFile()",           r"\.\s*toFile\s*\(\s*\)"),
    (".toPath()",           r"\.\s*toPath\s*\(\s*\)"),
    ("FileSystem/Channel",  rf"\b{Q}FileSystems?\s*\.\s*[a-zA-Z]|\bnew\s+{Q}FileSystemResource\s*\(|\b{Q}FileChannel\s*\.\s*[a-zA-Z]"),
    ("commons-io",          r"\b(?:FileUtils|IOUtils)\s*\.\s*[a-zA-Z]"),
    ("ProcessBuilder dir",  r"\.\s*(?:redirectOutput|redirectError|redirectInput)\s*\("),
]
RX = [(name, re.compile(pat)) for name, pat in PATTERNS]

# Why each class is still allowed to touch the filesystem. Keep in step with
# DirectFileIoGateTest.ALLOWED — that test is what enforces it; this only explains it.
CATEGORY = {
    "config": ("Config bootstrap — read before any store exists (you need config to know the "
               "bucket, so it cannot live in the bucket).",
               ["ConfigDirService", "DirPropertyResolver", "AppConfig", "DomainConfigLoader",
                "ConfigLoader", "ConfigController"]),
    "credentials": ("Credential files — plaintext production DB passwords that must NEVER reach "
                    "shared storage. CredentialGuardStore throws on these names.",
                    ["AnalysisService", "ParserAnalysisExecutor", "DbConnectionManager"]),
    "logging": ("Logging and the traversal guard's base path — local operational concerns. "
                "LogArchiveService reads the log dir in order to EMPTY it: rolled logs are shipped "
                "to the store and deleted locally, leaving only the live file.",
                ["LogController", "SourceController", "LogArchiveService"]),
    "subprocess": ("Subprocess plumbing — ProcessBuilder needs a real working directory.",
                   ["ClaudeProcessRunner", "ClaudeAnalysisService"]),
    "bootstrap": ("Storage bootstrap — the one Path.of that constructs the store root itself.",
                  ["FlowAnalysisMain", "PocRunner", "JarDataPaths", "AnalysisPaths"]),
    "temps": ("Upload temps and seekable-file APIs. A multipart upload arrives as a local temp; "
              "JarFile/CFR need a seekable file. The STORED artifact is always reached via "
              "store.materialize(key), never an assumed path.",
              ["AnalyzerController", "WarAnalyzerController", "JarAnalysisExecutor",
               "WarAnalysisExecutor", "JarTargetedAnalysisExecutor", "ClaudeJobExecutor",
               "JarParserService", "WarParserService", "DecompilerService", "PersistenceService",
               "FlowAnalysisController"]),
    "scratch": ("Process-local scratch in java.io.tmpdir — needs append and seek, which the store "
                "contract deliberately does not offer. Never touches the data tree.",
                ["SubtreeCache", "RepositoryStereotypeResolver"]),
    "outside": ("Outside the data root by design — reads the operator's own filesystem.",
                ["ConversionController", "PlSqlParserMain", "PlSqlParserEngine"]),
}
CLASS_TO_CATEGORY = {cls: key for key, (_, classes) in CATEGORY.items() for cls in classes}


def strip_comments(src):
    """Drop comments so a pattern named in prose is not counted as a call."""
    src = re.sub(r"(?s)/\*.*?\*/", "", src)
    out = []
    for line in src.split("\n"):
        kept, in_string, i = "", False, 0
        while i < len(line):
            c = line[i]
            if c == '"' and (i == 0 or line[i - 1] != "\\"):
                in_string = not in_string
            if not in_string and c == "/" and i + 1 < len(line) and line[i + 1] == "/":
                break
            kept += c
            i += 1
        out.append(kept)
    return out


def scan(root="."):
    hits = collections.defaultdict(list)
    for dirpath, _, filenames in os.walk(root):
        if any(s in dirpath + "/" for s in SKIP):
            continue
        for fname in filenames:
            if not fname.endswith(".java"):
                continue
            path = os.path.join(dirpath, fname)
            if "/src/main/java/" not in path:
                continue
            parts = path.split(os.sep)
            module = parts[1] if len(parts) > 1 else "?"
            if module == STORAGE_MODULE:
                continue
            cls = fname[:-5]
            try:
                src = open(path, encoding="utf-8").read()
            except OSError:
                continue
            for lineno, line in enumerate(strip_comments(src), 1):
                for kind, rx in RX:
                    for _ in rx.finditer(line):
                        hits[(module, cls)].append((path, lineno, kind))
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--by-class", action="store_true")
    ap.add_argument("--class", dest="cls")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--root", default=".")
    args = ap.parse_args()

    hits = scan(args.root)
    total = sum(len(v) for v in hits.values())

    if args.json:
        print(json.dumps({f"{m}/{c}": len(v) for (m, c), v in hits.items()}, indent=1, sort_keys=True))
        return 0

    if args.cls:
        found = False
        for (module, cls), entries in sorted(hits.items()):
            if cls != args.cls:
                continue
            found = True
            print(f"{module}/{cls} — {len(entries)} ops")
            for path, lineno, kind in entries:
                print(f"  {path}:{lineno}  {kind}")
        if not found:
            print(f"{args.cls}: no direct filesystem access. Fully on storage-lib.")
        return 0

    if args.by_class:
        print(f"{'ops':>5}  {'category':<12} class")
        for (module, cls), entries in sorted(hits.items(), key=lambda kv: -len(kv[1])):
            cat = CLASS_TO_CATEGORY.get(cls, "UNCLASSIFIED")
            print(f"{len(entries):5}  {cat:<12} {module}/{cls}")
        print(f"\n{total} ops across {len(hits)} classes")
        return 0

    by_module = collections.Counter()
    by_category = collections.Counter()
    unclassified = []
    for (module, cls), entries in hits.items():
        by_module[module] += len(entries)
        cat = CLASS_TO_CATEGORY.get(cls)
        if cat is None:
            unclassified.append(f"{module}/{cls} ({len(entries)})")
            by_category["UNCLASSIFIED"] += len(entries)
        else:
            by_category[cat] += len(entries)

    print("Direct filesystem access outside analyzer-storage\n")
    print(f"{'module':22}{'ops':>6}")
    for module, n in by_module.most_common():
        print(f"{module:22}{n:6}")
    print(f"{'TOTAL':22}{total:6}\n")

    print("By category — every survivor must have a reason:\n")
    for key, n in by_category.most_common():
        if key == "UNCLASSIFIED":
            continue
        reason = CATEGORY[key][0]
        print(f"  {key:<12} {n:>4}  {reason}")

    if unclassified:
        print("\n*** UNCLASSIFIED — these have no justification recorded and must be triaged:")
        for u in sorted(unclassified):
            print(f"      {u}")
        return 1
    print("\nEvery remaining op is classified. None is an unexplained local write.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
