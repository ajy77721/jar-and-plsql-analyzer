---
name: storage-check
description: Audit, FIX and re-verify the storage-lib migration — proves every file read/write/path goes through ArtifactStore so S3 mode can work with nothing on local disk. Use when asked to check storage, run the storage audit, fix storage issues, verify no local writes, or confirm the storage layer is complete.
---

# Storage layer check

**This skill finds AND fixes.** Auditing without fixing just reproduces the same list next time.
Run the audit (steps 1-5), fix everything it surfaces (step 6), then run the audit again (step 7)
and report the before/after. Do not stop at the findings.

Verifies the one invariant the product depends on: **all file reading, writing, directory creation
and path resolution goes through `com.analyzer.storage.ArtifactStore`**, so that in S3 mode nothing
is written to local disk.

Run every step. Report honestly — a gap found here is cheap, the same gap found after S3 is switched
on is a production outage. Never report a step as passing without having run it.

## 1. Build and full test suite

```bash
mvn -q -o -DskipTests install && mvn -o test
```

Offline (`-o`) always. Baseline is **1071 tests, 0 failures**. Count them:

```bash
awk '/Tests run:.*Skipped: [0-9]+$/{gsub(/,/,"");for(i=1;i<=NF;i++){if($i=="run:")r+=$(i+1);if($i=="Failures:")f+=$(i+1);if($i=="Errors:")e+=$(i+1)}} END{print "tests="r" failures="f" errors="e}' /tmp/t.log
```

## 2. The gate

```bash
mvn -o -pl unified-web -Dtest=DirectFileIoGateTest test
```

`DirectFileIoGateTest` is the enforcement point. It fails on:
- **NOT ALLOWED** — a class does direct I/O with no entry. Migrate it, or add an entry *with a reason*.
- **BUDGET EXCEEDED** — new direct I/O in an existing class. Never raise a budget to go green.
- **RATCHET** — a class improved; lower its budget, or delete the entry if it hit zero.

## 3. Inventory

```bash
python3 .claude/skills/storage-check/scripts/scan.py              # by module + category
python3 .claude/skills/storage-check/scripts/scan.py --by-class   # every class
python3 .claude/skills/storage-check/scripts/scan.py --class Foo  # line-level detail
```

Exits non-zero if any class is **UNCLASSIFIED** — present in the code but with no recorded reason.
Keep its `CATEGORY` map in step with the gate's `ALLOWED` map.

## 4. Judge the survivors

A count is not an answer. For each remaining op ask: **would this still work if the local disk were
read-only?** Legitimate survivors:

| category | why it survives |
|---|---|
| `config` | You need config to know the bucket, so it cannot live in the bucket. |
| `credentials` | `plsql-config.yaml` / `plsql-env-config.yaml` hold plaintext production passwords and must never reach shared storage. |
| `temps` | A multipart upload genuinely arrives as a local temp; `JarFile`/CFR need a seekable file. Valid **only** if the stored artifact is reached via `store.materialize(key)` and never an assumed data-tree path. |
| `scratch` | `java.io.tmpdir` spill needing append/seek, which the store deliberately does not offer. |
| `bootstrap` | The single `Path.of` that constructs the store root. |
| `subprocess`, `logging`, `outside` | Not artifacts. |

Anything else is a genuine gap. The dangerous pattern to grep for is a root rebuilt from a string —
`Path.of(dataDir, ...)` — which compiles, runs, and silently writes to local disk.

## 5. Boot and exercise against real data

A green suite is not proof: the suite has already passed while the application could not start.

```bash
mvn -o -q -DskipTests install
java -jar unified-web/target/unified-web-1.0.0-SNAPSHOT.jar --server.port=8099 > /tmp/boot.log 2>&1 &
grep -E 'Started UnifiedAnalyzerApplication|APPLICATION FAILED' /tmp/boot.log
```

Then exercise real endpoints and require 200 with real content:

```
/api/jar/jars   /api/parser/analyses   /api/docs   /api/conversion/jobs
/api/parser/analyses/{name}/index        .../call-graph   .../tables
/api/parser/analyses/{name}/source/{file}
```

Use a real analysis name from `/api/parser/analyses` — do not invent one. A 404 from a guessed URL
is not a finding. Note the data on disk is the **flat** layout (`ERP_USP_RUN_CYCLE__RQZVED`), source
files may be `.prc`, and `/node/{file}` needs the `.json` extension.

Finally confirm no credentials leak: `curl -s localhost:8099/api/plsql/config | grep -c '"password"'`
must be **0**, while `grep -c 'password:' data/config/plsql-config.yaml` stays **11** — masked over
HTTP, intact on disk.

## 6. Fix what you found

Work `OPEN-ITEMS.md` top-down: S3 blockers first, then known bugs. For each fix, add the test that
would have caught it. Rules that hold for every change here:

- Never route `plsql-config.yaml` / `plsql-env-config.yaml` through the store — plaintext production
  passwords; `CredentialGuardStore` rejects them by exact leaf name.
- Jackson stays streaming. Analysis documents reach multiple GB; never buffer one.
- Never rebuild a data root from a String (`Path.of(dataDir, …)`).
- Add an `ArtifactKey` twin for any new `Path` accessor and extend the parity tests. A key that
  disagrees with its path is the worst failure here: local mode keeps working while S3 writes
  somewhere else. That has already happened three times in this repo.
- Lower a gate budget when a class improves; delete the entry at zero. **Never raise one to go green.**

Parallel agents: give each a disjoint file set, `compile` only (concurrent `mvn install` corrupts
`~/.m2`), and forbid editing the gate test — collect their numbers and sync it centrally.

## 7. Re-run the audit

Repeat steps 1-5. A fix is not done until the suite, the gate, the scan and the boot check all pass
again. Update `OPEN-ITEMS.md`: remove what is *verified* fixed, add anything new.

## 8. Report

State: test count before/after, gate result, total ops with the by-category split and the delta,
boot result, endpoints checked. Then, separately and plainly, **what is still broken or unproven**.
Never describe a step as passing without having run it.

## Notes

- **After `mvn install`, RESTART any running server before measuring.** Replacing the jar under a
  live JVM causes `NoClassDefFoundError: ch/qos/logback/classic/spi/ThrowableProxy` on request
  threads and requests then hang. Three separate agents in one session mistook this for a product
  bug — one reported `/api/jar/jars` as hanging on a 162 MB dataset when it actually returns in
  0.5 s. If an endpoint appears to hang, restart and retry *before* concluding anything.

- `mvn install` from several agents at once corrupts `~/.m2`. Parallel agents must use `compile`
  only, and must not edit `DirectFileIoGateTest` concurrently — collect their numbers and sync centrally.
- The gate's regex has had false positives (`setReadable` is a bean setter; `ArtifactEntry::directory`
  is not `ProcessBuilder.directory`). A false positive creates a permanent budget floor, which is the
  headroom the ratchet exists to remove. Narrow the pattern rather than inflating a budget.
