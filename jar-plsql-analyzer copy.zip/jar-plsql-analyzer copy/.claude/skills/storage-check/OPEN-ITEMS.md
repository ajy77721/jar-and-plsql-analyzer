# Open items — storage layer

Verified state as of the last full run: build clean, **1165 tests / 0 failures**, gate green
(no RATCHET), **217 direct-I/O ops, 0 unclassified**, app boots and serves real data.

Keep this file honest. An item removed because it was fixed must have been *verified* fixed.

## Blocks S3 — must be done first

Nothing. `S3ArtifactStore` exists and `StorageFactory` builds it for `mode=s3`.

## S3 mode — what is verified, and what is not

`com.analyzer.storage.s3.S3ArtifactStore` + `MultipartUploadOutputStream` are wired into
`StorageFactory.createBackend`, still behind `CredentialGuardStore`. Credentials come only from
`DefaultCredentialsProvider`; there is no property for a key and none is logged.

**Verified offline (no bucket, no credential):**

- `S3ArtifactStoreConformanceTest` runs the *entire* `ArtifactStoreConformanceTest` contract — the
  same 25 cases the local backend passes — against the S3 store over real HTTP, using a real
  `S3Client` pointed at `FakeS3Server` (a JDK `com.sun.net.httpserver` S3 stand-in, test scope).
  This is the "callers cannot tell them apart" claim, actually asserted.
- `S3ArtifactStoreWireTest` (23 cases) — real wire path: byte-identical round trip, genuine
  multipart reassembly, Range slices, ListObjectsV2 pagination across pages, prefix boundary,
  `statPrefix` as exactly one listing and zero HEADs, batched `deletePrefix`, `move`,
  `materialize` outside the data root, and abort-on-part-failure observed *at the server*.
  The fake returns real MD5 ETags, so the SDK's own checksum check validates every upload.
- `S3ArtifactStoreTest` (32 cases, Mockito) — request shapes, 404 → false/-1, part-size
  arithmetic (100 GB stays under 10,000 parts).

**NOT verified — needs the live smoke test in the `s3-mode` skill, section 5:**

- Real S3 authentication, SigV4 against the real service, IAM permissions, bucket policy, KMS.
- Real network failure modes: throttling/503, retry behaviour, socket resets mid-multipart, DNS.
- Real S3's own quirks: eventual visibility of a listing after a write, `_prev` rotation under
  concurrency, multi-GB objects, the 5 GiB `CopyObject` ceiling (`copy()` throws above it rather
  than doing a multipart copy — deliberate, and untested against a real 5 GiB object).
- An end-to-end analysis actually running with the bucket as the only store.
- That the local data dir gains nothing during a real run.

## Correct by design — do not "fix" these

- **`plsql-env-config.yaml` is written to local disk inside the analysis output folder.** It holds
  plaintext production database passwords; `CredentialGuardStore` rejects that leaf name outright.
  In S3 mode this means a small local tree still exists purely for credential files. That is
  intended. If a future change makes even that unacceptable, the answer is a dedicated local secrets
  directory — *not* routing credentials into the bucket.
- **`AnalysisService.flowOutputDir`** survives only to locate that credential file. Verified: the
  parser output itself is driven by `opts.outputKey`, and every read in that class uses `resultKey`.
- **Upload temps and `materialize()` temps** live in `java.io.tmpdir`, never in the data root.
  Verified: the only `createTempFile` inside a data directory is `LocalArtifactStore`'s own
  atomic-write temp, which is internal to the local backend.

## Known bugs, not yet fixed

- **`analyzeLocal` / `analyzeTargeted` / `ConversionController.jobReport`** read an operator-supplied
  server path from the request body. Same shape as the flow-poc hole that was closed, but it is the
  documented purpose of those endpoints — a product decision. None can work in S3 mode.

## Fixed and verified

- **`StorageFactory.Settings` can now express S3.** Was `(StorageMode, Path dataRoot)`, which had
  nowhere to put a bucket. Now carries mode-specific fields with `Settings.local(...)` /
  `Settings.s3(bucket, prefix, region, endpoint)`, a `validate()` that refuses an impossible
  combination at startup rather than failing mid-analysis, and `app.storage.s3.*` wired through
  `StorageConfig`. Credentials come from the AWS default provider chain, never from a property, so
  no secret can land in a file this application writes or serves.
- **Provider `Path` constructors** — see below; this closed the last convention-based seam.

- **`CrossRefService` nested-session discovery.** A session is now any prefix under `plsql-parse/`
  containing `api/index.json`, found with one `statPrefix` (same shape as
  `AnalysisService.indexKeysByName()`); `sessionId` is the identity name, not the leaf folder.
  Covered by `CrossRefSessionDiscoveryTest` (nested / flat / both / empty).
- **`ClaudeResultLoader.getProgress` error count.** `_`-prefixed internal sidecars are excluded
  from `errorChunks` — and from the completed-count fallback, which did not exclude them either,
  contrary to the note that said it did. Covered by `ClaudeResultLoaderProgressTest`.
- **`PersistenceService.writeHeaderSidecar` dead parameter** removed, along with the unused 8-arg
  overload it fed.
- **Provider `Path` constructors.** `AbstractAnalysisDataProvider` and both concrete providers take
  an `ArtifactKey`; `getFilePath()` and `getSummaryCachePath()` are gone; `PersistenceService` gained
  the `getXDocumentKey()` twins that the factory and `WarAnalyzerController.resolveProvider` now use.

## Deliberately out of scope

- **`PlSqlParserMain` / `PlSqlParserEngine`** (8 ops) — a standalone developer CLI reading a `.sql`
  path from argv. No key can name an arbitrary operator path; inventing a root for it would be the
  `Path.of(dataDir, …)` anti-pattern in reverse. Never touches the data tree.
