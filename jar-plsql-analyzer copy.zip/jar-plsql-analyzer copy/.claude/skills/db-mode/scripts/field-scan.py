"""Every field path in every analysis JSON, with its OBSERVED types across all files.

Prose cannot answer "is this field ever an array?" — only the data can. A field that is a scalar in
one analysis and an array in another is the case that breaks a schema silently, so it is detected
here rather than assumed away.
"""
import json, os, sys, collections

roots = [p for p in ["data/plsql-parse", "data/jar", "data/plsql"] if os.path.isdir(p)]
# path -> {artifact leaf -> set(types)}
paths = collections.defaultdict(lambda: collections.defaultdict(set))
counts = collections.Counter()
scanned = 0

def kind(v):
    if v is None: return "null"
    if isinstance(v, bool): return "bool"
    if isinstance(v, (int, float)): return "number"
    if isinstance(v, str): return "string"
    if isinstance(v, list):
        if not v: return "array<empty>"
        inner = {kind(x) for x in v[:50]}
        return "array<" + "|".join(sorted(inner)) + ">"
    if isinstance(v, dict): return "object"
    return "?"

def walk(node, prefix, artifact, depth=0):
    if depth > 6: return
    if isinstance(node, dict):
        for k, v in node.items():
            p = f"{prefix}.{k}" if prefix else k
            paths[p][artifact].add(kind(v))
            counts[p] += 1
            if isinstance(v, dict):
                walk(v, p, artifact, depth+1)
            elif isinstance(v, list):
                for item in v[:20]:
                    if isinstance(item, (dict, list)):
                        walk(item, p + "[]", artifact, depth+1)

for root in roots:
    for dirpath, _, files in os.walk(root):
        for f in files:
            if not f.endswith(".json"): continue
            fp = os.path.join(dirpath, f)
            if os.path.getsize(fp) > 60_000_000: continue
            try:
                with open(fp, encoding="utf-8") as fh: doc = json.load(fh)
            except Exception: continue
            scanned += 1
            artifact = f
            if isinstance(doc, list):
                paths["<root>"][artifact].add(kind(doc))
                for item in doc[:20]:
                    if isinstance(item, dict): walk(item, "[]", artifact)
            else:
                walk(doc, "", artifact)

print(f"scanned {scanned} JSON files across {len(roots)} roots")
print(f"distinct field paths: {len(paths)}\n")

# THE finding the plan is missing: fields whose type is not stable
mixed = {}
for p, byart in paths.items():
    alltypes = set()
    for ts in byart.values(): alltypes |= ts
    nonnull = {t for t in alltypes if t != "null"}
    scal = {t for t in nonnull if not t.startswith("array<") and t != "object"}
    arr  = {t for t in nonnull if t.startswith("array<")}
    if scal and arr:
        mixed[p] = (sorted(nonnull), sorted(byart))
print(f"=== FIELDS THAT ARE SOMETIMES SCALAR, SOMETIMES ARRAY: {len(mixed)} ===")
for p, (types, arts) in sorted(mixed.items(), key=lambda kv: -counts[kv[0]])[:25]:
    print(f"  {p}\n      types: {types}\n      in: {arts[:4]}")

shared = {p: sorted(b) for p, b in paths.items() if len(b) > 1}
print(f"\n=== FIELD PATHS APPEARING IN MORE THAN ONE ARTIFACT: {len(shared)} ===")
for p, arts in sorted(shared.items(), key=lambda kv: -len(kv[1]))[:15]:
    print(f"  {p:52} in {len(arts)}: {arts[:5]}")

json.dump({"paths": {p: {a: sorted(t) for a, t in b.items()} for p, b in paths.items()},
           "mixed": {k: v[0] for k, v in mixed.items()}},
          open("/tmp/fieldmap.json", "w"), indent=1)
print("\nwritten: /tmp/fieldmap.json")
