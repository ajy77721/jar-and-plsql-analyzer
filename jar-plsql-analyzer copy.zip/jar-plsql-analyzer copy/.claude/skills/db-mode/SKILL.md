---
name: db-mode
description: Build the mongodb storage mode and the normalised entity layer — implements the plan in docs/plan/, keeping ArtifactStore's public API frozen and every document under 16 MB. Use when asked to run the db workflow, add mongodb mode, build the entity layer, or work through the PLAN documents.
---

# DB mode

Implements `docs/plan/PLAN-00`…`PLAN-10`: MongoDB as a third storage mode, plus a normalised entity
layer the UI can query and page through.

**Read `docs/plan/PLAN-00-OVERVIEW.md` first.** It carries the five hard constraints. A change that
violates one is wrong however well it works, so check against it before writing code, not after.

## The plan documents

~550 KB, all grounded in the real code and real data. Cite them; do not re-derive their findings.

| doc | answers |
|---|---|
| `PLAN-00-OVERVIEW.md` | constraints C1-C5, architecture, sequencing |
| `PLAN-01-ARTIFACTS-JAR.md` | 33 JAR/WAR artifacts, field by field, with measured sizes |
| `PLAN-02-ARTIFACTS-PLSQL.md` | 22 PL/SQL artifacts across 5 dialects |
| `PLAN-03-ARTIFACTS-CLAUDE-CROSSREF-AND-UI.md` | Claude/crossref/chat + **the UI access-pattern table** |
| `PLAN-04-ENTITY-MODEL.md` | 65 entities, fields, keys, row counts at scale |
| `PLAN-05-RELATIONSHIPS-NORMALIZATION.md` | 68 tables of DDL, ER diagram, duplication analysis |
| `PLAN-06-MONGO-16MB-CHUNKING.md` | the per-artifact decision table and the size guard |
| `PLAN-07-STORAGE-MODE-MONGODB.md` | `MongoArtifactStore` + the additive `AnalysisRepository` |
| `PLAN-08-UI-CONTRACT-AND-QUERIES.md` | queries, indexes, cursor pagination, the polling fixes |
| `PLAN-09-MIGRATION-AND-ROLLOUT.md` | backfill, dual-write, cutover, rollback, increments |

## The constraints, in short

- **C1 — `ArtifactStore` is frozen.** 14 methods, 74 dependent classes. Not one signature changes.
  Queries go on the *new* `AnalysisRepository`, never by widening the store.
- **C2 — 16 MB BSON.** Measured: a real `analysis.json` hit **912 MB**. Never assume one document
  per analysis.
- **C3 — the UI must not break**, in every mode, at equal or better latency.
- **C4 — credentials never reach shared storage.** `CredentialGuardStore` wraps every backend.
- **C5 — no data loss**, with a rollback that is not "restore from backup".

## Order of work

Follow `PLAN-09`'s increment table. Each increment ships something a user can see and is revertible
on its own. Broadly:

1. **`MongoArtifactStore`** behind the frozen interface — `ArtifactStoreConformanceTest` must pass
   unmodified against it. That test passing *is* the C1 proof.
2. **`AnalysisRepository`** as a new interface, with the scan-based implementation that serves
   `local` and `s3` by reading today's artifacts. No mode may lose functionality.
3. **The Mongo repository implementation** plus indexes from `PLAN-08`.
4. **UI pagination** (`PLAN-08`). Without it none of this improves page load — no endpoint currently
   accepts `page`/`offset`/`limit`, and all 20+ tables slice client-side.
5. **Backfill and cutover** (`PLAN-09`).

## Rules while building

- Never widen `ArtifactStore`. If something seems to need it, it belongs on `AnalysisRepository`.
- Decompiled source, stored JARs and exports are **artifacts, not entities** — `storage_ref` to
  `ArtifactStore`, never a column. ~2,050 B/node of embedded source is what caused the 912 MB.
- Enforce the size guard on the repository write path, in one place, at the **12 MB soft limit**.
  An oversized element diverts to `ArtifactStore`; nothing is ever silently truncated.
- **Node ordinals are never keys.** The crawl is non-deterministic — re-running renumbers nodes.
- Don't model dead artifacts: `_class-tree.json`, `mongo-catalog.json`, `chatHistoryKey`,
  `q3_reverse_dependencies.json`.
- Append-only data is **one document per entry**, keyed `(scope_id, seq)`. The six current
  append-only artifacts are read-all-then-rewrite-all, i.e. O(n²).
- Jackson streaming stays streaming. Never buffer a whole analysis document.

## Verification — run all of it, every increment

```bash
mvn -q -o -DskipTests install && mvn -o test          # baseline 1078+; never regress
mvn -o -pl unified-web -Dtest=DirectFileIoGateTest test
python3 .claude/skills/storage-check/scripts/scan.py   # must stay 0 unclassified
```

Then the checks specific to this work:

- **C1 proof**: `ArtifactStore.java` unchanged, and the conformance suite passing unmodified against
  the new backend.
- **Size guard**: a synthetic input larger than anything real (2,000 classes / 6,000 nodes) produces
  no document over the soft limit.
- **Boot the app.** A green suite has already hidden a startup failure in this repo once.
- **Zero local writes**: `.claude/skills/s3-mode/scripts/no-local-writes.sh` still passes in `s3`
  and `mongodb` modes.

## Environment facts, already checked

- **After `mvn install`, RESTART any running server before measuring.** Replacing the jar under a
  live JVM causes `NoClassDefFoundError: ch/qos/logback/classic/spi/ThrowableProxy` on request
  threads and requests then hang. Three separate agents in one session mistook this for a product
  bug — one reported `/api/jar/jars` as hanging on a 162 MB dataset when it actually returns in
  0.5 s. If an endpoint appears to hang, restart and retry *before* concluding anything.

- **Offline.** Always `mvn -o`. Mongo driver 4.11.2 is in `~/.m2`; **flapdoodle and Testcontainers
  are not**, and Docker is unavailable — so no embedded or containerised Mongo. `PLAN-07` recommends
  a wire-protocol `FakeMongoServer` mirroring the working 558-line `FakeS3Server`.
- **macOS has no `timeout`** — background the process and `kill` it.
- **Machine sleep has killed three long agent runs.** `caffeinate -dimsu -t 28800` is running; check
  it is still alive before a long task. The default `caffeinate -i -t 300` is not enough.
- **The real bucket uplink is ~0.5 MB/s.** A single 75 MB JAR analysis took 9+ minutes and was still
  uploading. Don't treat a slow S3 run as a hang — check
  `aws s3api list-multipart-uploads --bucket <b>` before concluding anything, and abort orphaned
  uploads afterwards or they are billed indefinitely.
- Parallel agents: disjoint file sets, `compile` only (concurrent `mvn install` corrupts `~/.m2`),
  and never two editing `DirectFileIoGateTest` — collect their numbers and sync centrally.

## Reporting

State what was built, what was verified and how, and — separately and plainly — **what is unproven**.
`PLAN-07` lists twelve things that genuinely need a live Mongo server; four of them should gate
recommending this mode to anyone. Never describe a live check as passing unless it was actually run.
