#!/usr/bin/env bash
# The acceptance test for S3 mode: run the application against a bucket and prove that no analysis
# artifact is written to local disk.
#
# This is the only test that can actually fail the migration. Everything else — unit tests, the
# gate, the inventory — reasons about source code. This observes the filesystem while real work
# happens, so a single missed call site shows up as a file that should not exist.
#
#   snapshot -> run analysis in s3 mode -> snapshot -> diff
#
# Usage:
#   no-local-writes.sh snapshot <file>          # record the current data tree
#   no-local-writes.sh verify   <before> <after>  # compare, and judge each new file
#
# EXPECTED new files (these are correct, see storage-check OPEN-ITEMS.md):
#   logs/**                        operational logging, never an artifact
#   config/**                      read before the store exists; also holds credentials
#   **/plsql-env-config.yaml       plaintext DB passwords, must never reach the bucket
#
# ANY other new file is a FAILURE: an artifact that should have gone to S3 went to disk instead.
set -uo pipefail

DATA_DIR="${DATA_DIR:-data}"

snapshot() {
    # Size is included so an in-place rewrite of an existing file is caught too, not just new paths.
    find "$DATA_DIR" -type f -exec stat -f '%N %z' {} \; 2>/dev/null | sort > "$1"
    echo "snapshot: $(wc -l < "$1" | tr -d ' ') files -> $1"
}

verify() {
    local before="$1" after="$2"
    local added unexpected
    added=$(comm -13 <(cut -d' ' -f1 "$before" | sort -u) <(cut -d' ' -f1 "$after" | sort -u))
    local changed
    changed=$(comm -13 "$before" "$after" | cut -d' ' -f1 | sort -u \
              | comm -12 - <(cut -d' ' -f1 "$before" | sort -u))

    echo "=== files ADDED during the run ==="
    if [ -z "$added" ]; then echo "  (none)"; else echo "$added" | sed 's/^/  /'; fi
    echo "=== existing files MODIFIED during the run ==="
    if [ -z "$changed" ]; then echo "  (none)"; else echo "$changed" | sed 's/^/  /'; fi

    # Judge every change against the allowlist rather than eyeballing it.
    unexpected=$(printf '%s\n%s\n' "$added" "$changed" | grep -v '^$' \
        | grep -vE "/${DATA_DIR}/logs/|^${DATA_DIR}/logs/" \
        | grep -vE "/${DATA_DIR}/config/|^${DATA_DIR}/config/" \
        | grep -vE 'plsql-env-config\.yaml$' \
        | sort -u)

    echo
    if [ -z "$unexpected" ]; then
        echo "PASS — no analysis artifact was written to local disk."
        echo "       Only logs, config and the credential file changed, all of which are"
        echo "       deliberately local. Every artifact went to the bucket."
        return 0
    fi
    echo "FAIL — these local files are analysis artifacts that should have gone to S3:"
    echo "$unexpected" | sed 's/^/  /'
    echo
    echo "Each one is a call site still writing to the filesystem. Find it with:"
    echo "  python3 .claude/skills/storage-check/scripts/scan.py --by-class"
    return 1
}

case "${1:-}" in
    snapshot) shift; snapshot "$@" ;;
    verify)   shift; verify "$@" ;;
    *) echo "usage: $0 {snapshot <file> | verify <before> <after>}" >&2; exit 2 ;;
esac
