---
name: s3-mode
description: Build, wire and verify S3 storage mode — implements S3ArtifactStore behind the existing ArtifactStore interface so analysis data lives in a bucket with nothing written to local disk. Use when asked to add S3 support, run the S3 workflow, implement the S3 store, or switch storage to s3.
---

# S3 mode

Adds object storage as a second `ArtifactStore` backend. Every call site in the application already
goes through that interface — see `/storage-check` — so this is one new class plus verification, not
a migration.

**Precondition.** Run `/storage-check` first and require: gate green, **0 unclassified** ops, app
boots. If the storage layer has drifted, fix that before starting. Building S3 on a leaky layer
produces data written half to the bucket and half to disk, which is worse than not shipping it.

## What already exists — do not rebuild

| piece | state |
|---|---|
| `ArtifactStore` | the interface every caller uses. **Do not change its shape** to suit S3; if S3 cannot satisfy a method, that is a finding to report. |
| `StorageFactory.Settings` | carries `bucket`, `prefix`, `region`, `endpoint`; `validate()` fails fast |
| `StorageFactory.settingsFor(mode, localRoot)` | resolves mode for CLI entry points; system property beats env var |
| `StorageConfig` | binds `app.storage.{mode}` and `app.storage.s3.{bucket,prefix,region,endpoint}` |
| `CredentialGuardStore` | wraps **every** backend; blocks `plsql-config.yaml` / `plsql-env-config.yaml` by exact leaf name |
| `LocalArtifactStore` | reference behaviour — S3 must match it semantically |
| `InMemoryArtifactStore` | non-filesystem store; the offline stand-in for S3 |

Only `StorageFactory.createBackend`'s `case S3` needs to change. **Keep the `CredentialGuardStore`
wrapper** — credentials must never reach the bucket.

Parked work-in-progress: session scratchpad `parked-s3/` (`S3ArtifactStore`,
`MultipartUploadOutputStream`, `CachingArtifactStore`). Written against an **older** interface;
it does not compile. Treat as a sketch, not a starting point to trust.

## 1. Pin the SDK

The AWS SDK is in `~/.m2` at **two** versions, 2.25.60 and 2.29.24. Mixing them has already produced
`NoClassDefFoundError: BusinessMetricFeatureId` at runtime in this repo. Pin one via
`<dependencyManagement>` (prefer the BOM if present in `~/.m2` — check, do not assume) and prove it:

```bash
mvn -o dependency:tree -pl analyzer-storage | grep -i awssdk | sort -u
```

Offline only (`-o`). No downloads are possible.

## 2. Implement `S3ArtifactStore`

Semantics must match `LocalArtifactStore`, because callers cannot tell them apart.

- **`write(key)`** — streaming multipart. S3 allows at most **10,000 parts**, so a fixed small part
  size caps object size; scale the part size with bytes written or start ≥ 8 MB and grow. Analysis
  documents reach multiple GB. Never buffer a whole object.
- **`write(key, contentLength)`** — single PUT when the length is known and small.
- **`read(key, offset, length)`** — ranged GET, not a full download.
- **`list(prefix, recursive)`** — paginate (`ListObjectsV2` caps at 1000/page) and stay lazy; the
  returned `Stream` must page as consumed and close without leaking the paginator. Non-recursive
  uses the `/` delimiter and returns common prefixes as directory entries.
- **`statPrefix(prefix)`** — ONE listing. This is why it exists: a local stat is ~10 µs, an S3 HEAD
  ~25 ms, so a stat-per-file loop is 2,500× slower.
- **`materialize(key)`** — download to a temp file **outside the data root**; `close()` deletes it.
- **`move`** — copy + delete; S3 has no rename. **`deletePrefix`** — batch `DeleteObjects`, 1000 per
  call, not one delete per key.
- **`exists`/`size`/`lastModified`** — `HeadObject`, translating 404 to false/-1 rather than throwing.
- **Atomicity** — local `write` is atomic on close. An S3 PUT is atomic; a multipart upload is only
  visible on `completeMultipartUpload`. Abort the upload on failure or you leave billable orphaned parts.
- **Credentials** — default AWS provider chain only. Never read a secret from a property or log one.

## 3. Prove it offline

There is no network and no valid credential. Do **not** write tests needing a live bucket or a
downloaded mock. Test what is genuinely testable:

- key ↔ object-key mapping, including the prefix and an empty prefix
- multipart arithmetic: assert a 100 GB write stays under 10,000 parts
- range-header construction, pagination assembly across pages, 404 → false
- `CredentialGuardStore` still blocks credential names through the S3 path

Use Mockito against `S3Client` if it is already in `~/.m2` (check existing test deps first),
otherwise hand-write a fake.

**The zero-local-writes proof** is the important one, and it does not need S3 at all. Wire
`InMemoryArtifactStore` in place of the real store, point `app.data-dir` at an empty temp dir,
exercise the analysis and read paths, then assert that directory is **still empty**. Against
`LocalArtifactStore` this test is circular; against a non-filesystem store, any stray `Files.write`
shows up as a file that should not exist.

## 4. Verify

```bash
mvn -o -q -DskipTests install && mvn -o test          # >= 1078 tests, 0 failures
mvn -o -pl unified-web -Dtest=DirectFileIoGateTest test
python3 .claude/skills/storage-check/scripts/scan.py
```

Then confirm both modes behave, remembering **macOS has no `timeout`** — background the process and
`kill` it:

```bash
java -jar unified-web/target/unified-web-1.0.0-SNAPSHOT.jar --server.port=8099 &   # local: must boot
java -jar unified-web/target/unified-web-1.0.0-SNAPSHOT.jar --app.storage.mode=s3 --app.storage.s3.bucket= &
#   must refuse: "Storage mode is s3 but no bucket was given."
```

Note `application.properties` already sets `app.storage.s3.bucket=amp-analyzer`, so to exercise the
missing-bucket path you must override it to empty explicitly.

## 5. Live smoke test — the user runs this

Offline verification cannot prove a real round trip. Hand the user an explicit checklist rather than
implying it is proven:

1. `aws sso login` / export credentials; confirm `aws s3 ls s3://<bucket>` works.
2. Start with `--app.storage.mode=s3 --app.storage.s3.bucket=<bucket>`.
3. Upload a JAR, run an analysis, run a PL/SQL analysis.
4. **Assert the local data dir gained nothing**: `find data -newermt '-10 minutes' -type f`.
5. Confirm objects landed: `aws s3 ls --recursive s3://<bucket>/data/ | head`.
6. **Confirm no credential file was uploaded** —
   `aws s3 ls --recursive s3://<bucket>/ | grep -E 'plsql-(env-)?config\.yaml'` must be empty.
7. Exercise the UI: dashboard, call graph, source view, Claude stats.
8. Re-analyse the same JAR to prove overwrite and the `_prev` rotation.

## 6. Report

State what is verified offline, what passed the gate and scan, and — separately and plainly —
**what remains unproven without a live bucket**. Update `.claude/skills/storage-check/OPEN-ITEMS.md`.
Never describe the live smoke test as passing unless the user ran it and reported back.

## Known traps in this repo

- A green suite has hidden a startup failure here before. **Always boot the app.**
- Parallel agents: disjoint file sets, `compile` only (concurrent `mvn install` corrupts `~/.m2`),
  and never let two edit `DirectFileIoGateTest` — collect numbers and sync centrally.
- An earlier attempt used the AWS NIO filesystem provider (`s3://` paths through `java.nio`). It
  failed on `ProviderNotFoundException` under the Boot classloader and then on an SDK version clash,
  and was rejected. Do not revive it; implement the interface directly.
