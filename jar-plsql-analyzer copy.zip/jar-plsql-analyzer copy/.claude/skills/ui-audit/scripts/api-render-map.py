#!/usr/bin/env python3
"""Maps every HTTP endpoint to the JS that calls it, and what that JS renders.

Answers three questions the UI keeps getting wrong:
  1. which endpoints does the browser actually call, and which are dead?
  2. which responses feed an UNBOUNDED render (the hang risk)?
  3. which displayed counts come from `array.length` rather than a server total —
     the pattern that silently showed 100 instead of 224 (PLAN-12 4.6)?
"""
import re, glob, os, json, sys, collections

# scripts -> ui-audit -> skills -> .claude -> repo root: five levels, not four.
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), *[os.pardir] * 4))
JAVA = os.path.join(ROOT, "unified-web/src/main/java")
STATIC = os.path.join(ROOT, "unified-web/src/main/resources/static")

#: any /api/... literal the client writes, however short
API_LITERAL = re.compile(r"['\"`](/api/[A-Za-z0-9_./-]*)")

def endpoints():
    """Mapped routes, excluding controllers switched off by default.

    A @ConditionalOnProperty(..., matchIfMissing = false) controller contributes no routes unless
    the property is set, so counting them would overstate the surface and, worse, park them in the
    "no JS caller" bucket as if they were dead code needing a decision.
    """
    out = []
    for f in glob.glob(os.path.join(JAVA, "**/*.java"), recursive=True):
        src = open(f).read()
        # Allow the fully-qualified form: the annotation is often written as
        # @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(...)
        if re.search(r'@(?:[\w.]+\.)?ConditionalOnProperty[^)]*matchIfMissing\s*=\s*false', src, re.S):
            continue
        m = re.search(r'@RequestMapping\(\s*"([^"]+)"', src)
        base = m.group(1) if m else ""
        for mm in re.finditer(r'@(Get|Post|Put|Delete|Patch)Mapping\(\s*(?:value\s*=\s*)?"([^"]*)"', src):
            out.append({"verb": mm.group(1).upper(), "path": base + mm.group(2),
                        "controller": os.path.basename(f)})
    return out

def loaded_js():
    """Only JS actually included by an index.html.

    A file left on disk but not in any <script> tag runs nowhere. Scanning it invented callers for
    endpoints nothing reaches, and flagged render sites in code the browser never executes.
    """
    included = set()
    for html in glob.glob(os.path.join(STATIC, "*/index.html")):
        page = os.path.dirname(html)
        body = open(html).read()
        # Comment out a <script> tag and it stops counting, which is how a feature gets retired.
        body = re.sub(r'<!--.*?-->', '', body, flags=re.S)
        for m in re.finditer(r'<script[^>]+src="([^"]+)"', body):
            src = m.group(1).split('?')[0]
            if src.startswith('http'):
                continue
            # An absolute src is served from the static ROOT, not from the page's directory.
            # Joining it onto the page produced paths like static/war/jar/js/api.js, so every WAR
            # file was treated as not-loaded and all 37 WAR endpoints looked uncalled.
            base = STATIC if src.startswith('/') else page
            path = os.path.normpath(os.path.join(base, src.lstrip('/') if src.startswith('/') else src))
            if os.path.isfile(path):
                included.add(os.path.abspath(path))
            else:
                print(f"  warn: <script src={src}> in {os.path.relpath(html, STATIC)} "
                      f"resolves to a missing file", file=sys.stderr)
    return included


def js_calls():
    """Which endpoints each loaded JS file can reach.

    Matching by whole URL literal does not work: the browser builds paths by concatenation, e.g.

        '/api/jar/jars/' + encodeURIComponent(id) + '/summary/header'

    so the only literal in the source is the prefix. An earlier version of this script captured just
    that fragment and required an exact segment-count match, which made EVERY route with a path
    variable look uncalled — 143 false positives, 14 out of 14 wrong on inspection.

    So instead of reconstructing URLs, each endpoint is reduced to its literal segments and a file
    counts as a caller when it contains the leading literal prefix AND every remaining literal
    segment. That over-matches slightly (a file mentioning the right pieces for another reason), so
    it is a "can reach" signal, not proof — which is the honest strength of a text scan.
    """
    live = loaded_js()
    out = {}
    for f in glob.glob(os.path.join(STATIC, "**/*.js"), recursive=True):
        if live and os.path.abspath(f) not in live:
            continue
        src = open(f).read()
        out[os.path.relpath(f, STATIC)] = _strip_comments(src)

    # Inline <script> blocks count too. The conversion screen has no .js file at all — it calls
    # /api/conversion from inline script in its index.html — so ignoring these made all 11 of its
    # endpoints look dead.
    for html in glob.glob(os.path.join(STATIC, "*/index.html")):
        body = open(html).read()
        inline = "\n".join(re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', body, re.S))
        if inline.strip():
            out[os.path.relpath(html, STATIC) + " (inline)"] = _strip_comments(inline)
    return out


def _strip_comments(src):
    """Comments are documentation, not calls. See callers_of."""
    src = re.sub(r'/\*.*?\*/', '', src, flags=re.S)
    return re.sub(r'(?m)^\s*//.*$', '', src)


def literal_segments(path):
    """The parts of a Spring path that must appear verbatim in the client."""
    return [s for s in path.strip("/").split("/") if s and not s.startswith("{")]


def callers_of(path, sources):
    """Files that can reach this endpoint.

    Three assembly styles have to be recognised, all of them present in this codebase:

      1. one literal            '/api/jar/jars/x/summary'
      2. prefix + variable      '/api/jar/jars/' + id + '/summary/header'
      3. a stored base          _BASE: '/api/prompt-config'   then  _BASE + '/templates'

    (3) is why matching on the full literal prefix is not enough: the longest literal in the file
    may be only the base. So any `/api/...` literal in the file that is a prefix of the endpoint
    path counts as the anchor, and the remaining literal segments must then also appear.

    Comments are stripped first. `tableDetail.js` mentions `/table-columns` only in a comment
    saying "if a tab is ever built for it" — counting that would have hidden a genuinely dead
    endpoint behind its own documentation.
    """
    parts = path.strip("/").split("/")
    segs = [s for s in parts if not s.startswith("{")]
    if not segs:
        return []
    hits = []
    for rel, src in sources.items():
        anchors = [a for a in API_LITERAL.findall(src) if path.startswith(a.rstrip("/"))]
        if not anchors:
            continue
        anchor = max(anchors, key=len).rstrip("/")
        covered = set(x for x in anchor.strip("/").split("/") if x)
        tail = [t for t in segs if t not in covered]
        if all(("/" + t) in src or ("'" + t) in src or ('"' + t) in src for t in tail):
            hits.append(rel)
    return sorted(hits)


def render_risks():
    """Unbounded collection -> innerHTML, and counts taken from .length."""
    unbounded, length_counts = [], []
    live = loaded_js()
    for f in glob.glob(os.path.join(STATIC, "**/*.js"), recursive=True):
        if live and os.path.abspath(f) not in live:
            continue          # not loaded by any page; it renders nothing
        rel = os.path.relpath(f, STATIC)
        lines = open(f).read().split("\n")
        for i, l in enumerate(lines):
            win = "\n".join(lines[max(0, i - 30):i + 2])
            if re.search(r'innerHTML\s*\+?=', l):
                iterates = re.search(r'\.(map|forEach)\(|for\s*\(\s*(const|let|var)\s+\w+\s+of\s', win)
                limited = re.search(r'\.slice\(|MAX_|_limit|LIMIT|virtual|chunk|page', win, re.I)
                if iterates and not limited:
                    unbounded.append((rel, i + 1))
            # a count rendered straight from an array length
            for mm in re.finditer(r'\$\{[^}]*\b(\w+)\.length\b[^}]*\}|>\s*\$\{(\w+)\.length\}', l):
                length_counts.append((rel, i + 1, (mm.group(1) or mm.group(2))))
    return unbounded, length_counts

def main():
    eps = endpoints()
    sources = js_calls()
    used, unused = [], []
    for e in eps:
        hits = callers_of(e["path"], sources)
        (used if hits else unused).append({**e, "callers": hits})
    unbounded, length_counts = render_risks()

    print(f"ENDPOINTS                 {len(eps)}")
    print(f"  called from the browser {len(used)}")
    print(f"  no JS caller found      {len(unused)}")
    print()
    print(f"UNBOUNDED RENDER SITES    {len(unbounded)}")
    by = collections.Counter(f for f, _ in unbounded)
    for f, n in by.most_common(10):
        print(f"    {n:>3}  {f}")
    print()
    print(f"COUNTS FROM array.length  {len(length_counts)}   (cannot show a server-side total)")
    by2 = collections.Counter(f for f, _, _ in length_counts)
    for f, n in by2.most_common(10):
        print(f"    {n:>3}  {f}")

    out = os.path.join(ROOT, "docs/api-render-map.json")
    json.dump({"used": used, "unused": unused,
               "unbounded": unbounded, "length_counts": length_counts},
              open(out, "w"), indent=1)
    print(f"\nwritten: {os.path.relpath(out, ROOT)}")

if __name__ == "__main__":
    main()
