-- ============================================================
-- JAR-PLSQL-ANALYZER  — MySQL Comprehensive Test Script
-- ============================================================
-- Covers: Tables, AUTO_INCREMENT, Stored Procedures, Functions,
--         Cursors, Dynamic SQL (PREPARE/EXECUTE), JOINs,
--         Recursion, Cross-procedure calls
-- Run as: mysql -u root -pAdmin@1234 --port=3307 testdb < test_mysql_features.sql
-- ============================================================

USE testdb;

-- ============================================================
-- DROP existing objects (safe re-run)
-- ============================================================
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;

DROP PROCEDURE IF EXISTS utils_log_audit;
DROP PROCEDURE IF EXISTS utils_purge_old_audit;
DROP FUNCTION  IF EXISTS utils_get_date_str;
DROP FUNCTION  IF EXISTS utils_format_amount;
DROP FUNCTION  IF EXISTS utils_is_working_day;

DROP FUNCTION  IF EXISTS emp_get_name;
DROP FUNCTION  IF EXISTS emp_get_dept_budget;
DROP FUNCTION  IF EXISTS emp_get_manager_chain;
DROP FUNCTION  IF EXISTS emp_count_subordinates;
DROP PROCEDURE IF EXISTS emp_hire;
DROP PROCEDURE IF EXISTS emp_terminate;
DROP PROCEDURE IF EXISTS emp_process_department;
DROP PROCEDURE IF EXISTS emp_raise_salary_bulk;

DROP FUNCTION  IF EXISTS ord_calculate_total;
DROP FUNCTION  IF EXISTS ord_apply_tiered_discount;
DROP FUNCTION  IF EXISTS ord_get_emp_order_count;
DROP PROCEDURE IF EXISTS ord_create;
DROP PROCEDURE IF EXISTS ord_add_item;
DROP PROCEDURE IF EXISTS ord_fulfill;
DROP PROCEDURE IF EXISTS ord_cancel;
DROP PROCEDURE IF EXISTS ord_process_all_pending;

DROP FUNCTION  IF EXISTS inv_get_stock_value;
DROP FUNCTION  IF EXISTS inv_get_total_stock_value;
DROP PROCEDURE IF EXISTS inv_restock;
DROP PROCEDURE IF EXISTS inv_deplete_stock;
DROP PROCEDURE IF EXISTS inv_low_stock_report;

DROP PROCEDURE IF EXISTS rpt_dept_summary;
DROP FUNCTION  IF EXISTS rpt_calc_dept_total_budget;
DROP PROCEDURE IF EXISTS rpt_employee_performance;
DROP PROCEDURE IF EXISTS rpt_generate_full;

DROP PROCEDURE IF EXISTS proc_daily_sync;
DROP FUNCTION  IF EXISTS func_get_org_depth;
DROP FUNCTION  IF EXISTS func_employee_score;

-- ============================================================
-- TABLES
-- ============================================================
CREATE TABLE departments (
    dept_id      INT           NOT NULL AUTO_INCREMENT,
    dept_name    VARCHAR(100)  NOT NULL,
    location     VARCHAR(100),
    budget       DECIMAL(15,2) DEFAULT 0,
    parent_dept  INT           DEFAULT NULL,
    created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (dept_id),
    CONSTRAINT fk_dept_parent FOREIGN KEY (parent_dept) REFERENCES departments(dept_id)
);

CREATE TABLE employees (
    emp_id      INT            NOT NULL AUTO_INCREMENT,
    emp_name    VARCHAR(100)   NOT NULL,
    email       VARCHAR(150),
    dept_id     INT,
    salary      DECIMAL(12,2),
    manager_id  INT            DEFAULT NULL,
    hire_date   DATE           DEFAULT (CURRENT_DATE),
    status      VARCHAR(20)    DEFAULT 'ACTIVE',
    PRIMARY KEY (emp_id),
    CONSTRAINT fk_emp_dept FOREIGN KEY (dept_id)    REFERENCES departments(dept_id),
    CONSTRAINT fk_emp_mgr  FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
);

CREATE TABLE products (
    product_id   INT            NOT NULL AUTO_INCREMENT,
    product_name VARCHAR(200)   NOT NULL,
    category     VARCHAR(50),
    unit_price   DECIMAL(12,2)  NOT NULL,
    stock_qty    INT            DEFAULT 0,
    PRIMARY KEY (product_id)
);

CREATE TABLE orders (
    order_id    INT            NOT NULL AUTO_INCREMENT,
    emp_id      INT,
    order_date  DATETIME       DEFAULT CURRENT_TIMESTAMP,
    status      VARCHAR(20)    DEFAULT 'PENDING',
    total_amt   DECIMAL(15,2)  DEFAULT 0,
    notes       VARCHAR(500),
    PRIMARY KEY (order_id),
    CONSTRAINT fk_ord_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
);

CREATE TABLE order_items (
    item_id      INT            NOT NULL AUTO_INCREMENT,
    order_id     INT            NOT NULL,
    product_id   INT            NOT NULL,
    quantity     INT            NOT NULL,
    unit_price   DECIMAL(12,2)  NOT NULL,
    discount_pct DECIMAL(5,2)   DEFAULT 0,
    PRIMARY KEY (item_id),
    CONSTRAINT fk_item_ord FOREIGN KEY (order_id)   REFERENCES orders(order_id),
    CONSTRAINT fk_item_prd FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE audit_log (
    audit_id    INT            NOT NULL AUTO_INCREMENT,
    action      VARCHAR(50)    NOT NULL,
    table_name  VARCHAR(100),
    record_id   INT            DEFAULT NULL,
    changed_by  VARCHAR(100)   DEFAULT (USER()),
    changed_at  DATETIME       DEFAULT CURRENT_TIMESTAMP,
    description VARCHAR(1000),
    PRIMARY KEY (audit_id)
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_emp_dept    ON employees(dept_id);
CREATE INDEX idx_emp_mgr     ON employees(manager_id);
CREATE INDEX idx_ord_emp     ON orders(emp_id, status);
CREATE INDEX idx_item_ord    ON order_items(order_id);
CREATE INDEX idx_audit_table ON audit_log(table_name, changed_at);


-- ============================================================
-- utils_*   Low-level helpers — called by every other proc
-- ============================================================
DELIMITER $$

CREATE FUNCTION utils_get_date_str(p_date DATETIME)
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    RETURN DATE_FORMAT(p_date, '%Y-%m-%d %H:%i:%s');
END$$

CREATE FUNCTION utils_format_amount(p_amount DECIMAL(15,2))
RETURNS VARCHAR(30)
DETERMINISTIC
BEGIN
    RETURN FORMAT(IFNULL(p_amount, 0), 2);
END$$

CREATE FUNCTION utils_is_working_day(p_date DATE)
RETURNS TINYINT(1)
DETERMINISTIC
BEGIN
    DECLARE v_dow INT;
    SET v_dow = DAYOFWEEK(p_date);  -- 1=Sun, 7=Sat
    RETURN v_dow NOT IN (1, 7);
END$$

CREATE PROCEDURE utils_log_audit(
    IN p_action     VARCHAR(50),
    IN p_table_name VARCHAR(100),
    IN p_record_id  INT,
    IN p_desc       VARCHAR(1000)
)
BEGIN
    INSERT INTO audit_log (action, table_name, record_id, description)
    VALUES (p_action, p_table_name, p_record_id, p_desc);
END$$

CREATE PROCEDURE utils_purge_old_audit(
    IN p_days_to_keep INT
)
BEGIN
    DECLARE v_cutoff  DATETIME;
    DECLARE v_deleted INT DEFAULT 0;

    SET v_cutoff = DATE_SUB(NOW(), INTERVAL p_days_to_keep DAY);
    DELETE FROM audit_log WHERE changed_at < v_cutoff;
    SET v_deleted = ROW_COUNT();

    CALL utils_log_audit('PURGE', 'audit_log', NULL,
        CONCAT('Purged ', v_deleted, ' rows older than ', utils_get_date_str(v_cutoff)));
END$$


-- ============================================================
-- emp_*   Employee management
--         emp_get_manager_chain → RECURSIVE
--         emp_count_subordinates → RECURSIVE
--         emp_process_department → CURSOR + JOIN
--         emp_raise_salary_bulk  → dynamic SQL
-- ============================================================

CREATE FUNCTION emp_get_name(p_emp_id INT)
RETURNS VARCHAR(100)
READS SQL DATA
BEGIN
    DECLARE v_name VARCHAR(100);
    SELECT emp_name INTO v_name FROM employees WHERE emp_id = p_emp_id LIMIT 1;
    RETURN IFNULL(v_name, CONCAT('UNKNOWN_', p_emp_id));
END$$

CREATE FUNCTION emp_get_dept_budget(p_dept_id INT)
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_budget DECIMAL(15,2);
    SELECT budget INTO v_budget FROM departments WHERE dept_id = p_dept_id LIMIT 1;
    RETURN IFNULL(v_budget, 0);
END$$

-- manager chain: WHILE loop (MySQL forbids recursive functions; recursive CTEs also work)
CREATE FUNCTION emp_get_manager_chain(p_emp_id INT, p_depth INT)
RETURNS VARCHAR(2000)
READS SQL DATA
BEGIN
    DECLARE v_name    VARCHAR(100);
    DECLARE v_mgr_id  INT;
    DECLARE v_result  VARCHAR(2000) DEFAULT '';
    DECLARE v_curr_id INT;
    DECLARE v_lvl     INT DEFAULT 0;

    SET v_curr_id = p_emp_id;
    WHILE v_curr_id IS NOT NULL AND v_lvl <= 15 DO
        SELECT emp_name, manager_id INTO v_name, v_mgr_id
          FROM employees WHERE emp_id = v_curr_id LIMIT 1;
        IF v_name IS NULL THEN
            SET v_curr_id = NULL;
        ELSE
            SET v_result  = CONCAT(v_result, IF(v_result='','\n',''), REPEAT('  ',v_lvl), v_name);
            SET v_curr_id = v_mgr_id;
            SET v_lvl     = v_lvl + 1;
        END IF;
    END WHILE;
    RETURN v_result;
END$$

-- count subordinates via recursive CTE (MySQL 8.0+)
CREATE FUNCTION emp_count_subordinates(p_emp_id INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    WITH RECURSIVE subs AS (
        SELECT emp_id FROM employees WHERE manager_id = p_emp_id AND status = 'ACTIVE'
        UNION ALL
        SELECT e.emp_id FROM employees e
          JOIN subs s ON s.emp_id = e.manager_id WHERE e.status = 'ACTIVE'
    )
    SELECT COUNT(*) INTO v_count FROM subs;
    RETURN IFNULL(v_count, 0);
END$$

CREATE PROCEDURE emp_hire(
    IN  p_name       VARCHAR(100),
    IN  p_dept_id    INT,
    IN  p_salary     DECIMAL(12,2),
    IN  p_manager_id INT,
    OUT p_new_id     INT
)
BEGIN
    INSERT INTO employees (emp_name, dept_id, salary, manager_id, hire_date, status)
    VALUES (TRIM(p_name), p_dept_id, p_salary, p_manager_id, CURDATE(), 'ACTIVE');

    SET p_new_id = LAST_INSERT_ID();

    CALL utils_log_audit('INSERT', 'employees', p_new_id,
        CONCAT('Hired: ', p_name, ' dept=', p_dept_id));
END$$

CREATE PROCEDURE emp_terminate(IN p_emp_id INT)
BEGIN
    DECLARE v_name VARCHAR(100);
    SET v_name = emp_get_name(p_emp_id);   -- self-group call

    UPDATE employees SET status = 'TERMINATED' WHERE emp_id = p_emp_id;
    CALL utils_log_audit('UPDATE', 'employees', p_emp_id,
                         CONCAT('Terminated: ', v_name));
END$$

-- CURSOR + JOIN + cross-group calls
CREATE PROCEDURE emp_process_department(IN p_dept_id INT)
BEGIN
    DECLARE v_emp_id    INT;
    DECLARE v_emp_name  VARCHAR(100);
    DECLARE v_salary    DECIMAL(12,2);
    DECLARE v_dept_name VARCHAR(100);
    DECLARE v_location  VARCHAR(100);
    DECLARE v_total_sal DECIMAL(15,2) DEFAULT 0;
    DECLARE v_emp_count INT           DEFAULT 0;
    DECLARE v_budget    DECIMAL(15,2);
    DECLARE v_chain     VARCHAR(2000);
    DECLARE v_done      INT DEFAULT FALSE;

    -- explicit cursor with JOIN
    DECLARE cur_active CURSOR FOR
        SELECT e.emp_id, e.emp_name, e.salary, d.dept_name, d.location
          FROM employees   e
          JOIN departments d ON d.dept_id = e.dept_id
         WHERE e.dept_id = p_dept_id
           AND e.status  = 'ACTIVE'
         ORDER BY e.salary DESC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    SET v_budget = emp_get_dept_budget(p_dept_id);   -- self-group call

    OPEN cur_active;
    dept_loop: LOOP
        FETCH cur_active INTO v_emp_id, v_emp_name, v_salary, v_dept_name, v_location;
        IF v_done THEN LEAVE dept_loop; END IF;

        SET v_total_sal = v_total_sal + v_salary;
        SET v_emp_count = v_emp_count + 1;

        -- get manager chain for top earner (first row)
        IF v_emp_count = 1 THEN
            SET v_chain = emp_get_manager_chain(v_emp_id, 0);   -- recursive call
        END IF;
    END LOOP dept_loop;
    CLOSE cur_active;

    CALL utils_log_audit('PROCESS', 'departments', p_dept_id,
        CONCAT('Dept=', p_dept_id,
               ' Emps=', v_emp_count,
               ' TotalSal=', utils_format_amount(v_total_sal),
               ' Budget=',   utils_format_amount(v_budget)));
END$$

-- Dynamic SQL + PREPARE/EXECUTE
CREATE PROCEDURE emp_raise_salary_bulk(
    IN p_dept_id   INT,
    IN p_raise_pct DECIMAL(5,2)
)
BEGIN
    DECLARE v_sql   VARCHAR(500);
    DECLARE v_name  VARCHAR(100);
    DECLARE v_id    INT;
    DECLARE v_done  INT DEFAULT FALSE;

    DECLARE cur_ids CURSOR FOR
        SELECT emp_id FROM employees WHERE dept_id = p_dept_id AND status = 'ACTIVE';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- dynamic UPDATE via PREPARE
    SET v_sql = CONCAT(
        'UPDATE employees SET salary = salary * (1 + ', p_raise_pct, ' / 100) ',
        'WHERE dept_id = ', p_dept_id, ' AND status = ''ACTIVE'''
    );
    SET @dyn_sql = v_sql;
    PREPARE stmt FROM @dyn_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

    -- log each affected employee
    OPEN cur_ids;
    raise_loop: LOOP
        FETCH cur_ids INTO v_id;
        IF v_done THEN LEAVE raise_loop; END IF;
        SET v_name = emp_get_name(v_id);       -- self-group call
        CALL utils_log_audit('UPDATE', 'employees', v_id,
            CONCAT(v_name, ' salary raised ', p_raise_pct, '%'));
    END LOOP raise_loop;
    CLOSE cur_ids;
END$$


-- ============================================================
-- ord_*   Order lifecycle
--         ord_calculate_total → JOIN across 4 tables
--         ord_apply_tiered_discount → RECURSIVE
--         ord_process_all_pending → dynamic SQL cursor
-- ============================================================

-- JOIN across 4 tables
CREATE FUNCTION ord_calculate_total(p_order_id INT)
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(15,2) DEFAULT 0;

    SELECT IFNULL(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct / 100)), 0)
      INTO v_total
      FROM order_items  oi
      JOIN orders       o  ON o.order_id   = oi.order_id
      JOIN products     p  ON p.product_id = oi.product_id
      JOIN employees    e  ON e.emp_id     = o.emp_id
      JOIN departments  d  ON d.dept_id    = e.dept_id
     WHERE oi.order_id = p_order_id;

    RETURN ROUND(v_total, 2);
END$$

-- tiered discount: WHILE loop (MySQL forbids recursive functions)
CREATE FUNCTION ord_apply_tiered_discount(p_amount DECIMAL(15,2), p_tiers INT)
RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN
    DECLARE v_tier_rate DECIMAL(5,4) DEFAULT 0.05;
    DECLARE v_result    DECIMAL(15,2);
    DECLARE i           INT DEFAULT 0;
    SET v_result = p_amount;
    WHILE i < p_tiers AND v_result > 0 DO
        SET v_result = v_result * (1 - v_tier_rate);
        SET i = i + 1;
    END WHILE;
    RETURN ROUND(v_result, 2);
END$$

CREATE FUNCTION ord_get_emp_order_count(p_emp_id INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_cnt INT;
    SELECT COUNT(*) INTO v_cnt
      FROM orders
     WHERE emp_id = p_emp_id AND status != 'CANCELLED';
    RETURN IFNULL(v_cnt, 0);
END$$

CREATE PROCEDURE ord_create(
    IN  p_emp_id     INT,
    IN  p_product_id INT,
    IN  p_qty        INT,
    OUT p_order_id   INT
)
BEGIN
    DECLARE v_price    DECIMAL(12,2);
    DECLARE v_emp_name VARCHAR(100);
    DECLARE v_ord_cnt  INT;

    -- cross-group calls
    SET v_emp_name = emp_get_name(p_emp_id);
    SET v_ord_cnt  = ord_get_emp_order_count(p_emp_id);   -- self-group call

    SELECT unit_price INTO v_price FROM products WHERE product_id = p_product_id LIMIT 1;

    INSERT INTO orders (emp_id, status, order_date)
    VALUES (p_emp_id, 'PENDING', NOW());
    SET p_order_id = LAST_INSERT_ID();

    -- add first item inline
    CALL ord_add_item(p_order_id, p_product_id, p_qty, 0);   -- self-group call

    -- refresh total
    UPDATE orders
       SET total_amt = ord_calculate_total(p_order_id)       -- self-group call
     WHERE order_id  = p_order_id;

    CALL utils_log_audit('INSERT', 'orders', p_order_id,
        CONCAT('Created by ', v_emp_name, ' (order #', v_ord_cnt + 1, ')'));
END$$

CREATE PROCEDURE ord_add_item(
    IN p_order_id   INT,
    IN p_product_id INT,
    IN p_qty        INT,
    IN p_discount   DECIMAL(5,2)
)
BEGIN
    DECLARE v_price DECIMAL(12,2);

    SELECT unit_price INTO v_price FROM products WHERE product_id = p_product_id LIMIT 1;

    INSERT INTO order_items (order_id, product_id, quantity, unit_price, discount_pct)
    VALUES (p_order_id, p_product_id, p_qty, v_price, p_discount);

    UPDATE orders
       SET total_amt = ord_calculate_total(p_order_id)   -- self-group call
     WHERE order_id  = p_order_id;

    CALL utils_log_audit('INSERT', 'order_items', LAST_INSERT_ID(),
        CONCAT('Item added to order ', p_order_id));
END$$

CREATE PROCEDURE ord_fulfill(IN p_order_id INT)
BEGIN
    DECLARE v_emp_id   INT;
    DECLARE v_total    DECIMAL(15,2);
    DECLARE v_final    DECIMAL(15,2);
    DECLARE v_tiers    INT;
    DECLARE v_ord_cnt  INT;
    DECLARE v_emp_name VARCHAR(100);

    SELECT emp_id, total_amt INTO v_emp_id, v_total
      FROM orders WHERE order_id = p_order_id LIMIT 1;

    SET v_emp_name = emp_get_name(v_emp_id);              -- cross-group call
    SET v_ord_cnt  = ord_get_emp_order_count(v_emp_id);   -- self-group call

    -- loyalty discount: 1 tier per 5 orders, max 4
    SET v_tiers = LEAST(FLOOR(v_ord_cnt / 5), 4);
    SET v_final = ord_apply_tiered_discount(v_total, v_tiers);   -- recursive call

    UPDATE orders
       SET status    = 'FULFILLED',
           total_amt = v_final,
           notes     = CONCAT('Discount tiers: ', v_tiers)
     WHERE order_id  = p_order_id;

    CALL utils_log_audit('UPDATE', 'orders', p_order_id,
        CONCAT('Fulfilled for ', v_emp_name,
               ' | Original=', utils_format_amount(v_total),
               ' | Final=',    utils_format_amount(v_final),
               ' | Tiers=',    v_tiers));
END$$

CREATE PROCEDURE ord_cancel(IN p_order_id INT, IN p_reason VARCHAR(500))
BEGIN
    DECLARE v_status VARCHAR(20);
    SELECT status INTO v_status FROM orders WHERE order_id = p_order_id LIMIT 1;

    IF v_status = 'FULFILLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot cancel a fulfilled order';
    END IF;

    UPDATE orders SET status = 'CANCELLED', notes = p_reason WHERE order_id = p_order_id;
    CALL utils_log_audit('UPDATE', 'orders', p_order_id,
                         CONCAT('Cancelled: ', IFNULL(p_reason, '')));
END$$

-- Dynamic SQL + cursor loop
CREATE PROCEDURE ord_process_all_pending()
BEGIN
    DECLARE v_order_id INT;
    DECLARE v_count    INT DEFAULT 0;
    DECLARE v_failed   INT DEFAULT 0;
    DECLARE v_done     INT DEFAULT FALSE;
    DECLARE v_sql      VARCHAR(300);

    DECLARE cur_pending CURSOR FOR
        SELECT order_id FROM orders
         WHERE status = 'PENDING'
         ORDER BY order_date ASC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- demonstrate dynamic table reference
    SET @dyn_count_sql = 'SELECT COUNT(*) INTO @pending_count FROM orders WHERE status = ''PENDING''';
    PREPARE cnt_stmt FROM @dyn_count_sql;
    EXECUTE cnt_stmt;
    DEALLOCATE PREPARE cnt_stmt;

    OPEN cur_pending;
    pending_loop: LOOP
        FETCH cur_pending INTO v_order_id;
        IF v_done THEN LEAVE pending_loop; END IF;

        BEGIN
            DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
            BEGIN
                SET v_failed = v_failed + 1;
                CALL utils_log_audit('ERROR', 'orders', v_order_id,
                    'Fulfill failed');
            END;
            CALL ord_fulfill(v_order_id);   -- self-group call
            SET v_count = v_count + 1;
        END;
    END LOOP pending_loop;
    CLOSE cur_pending;

    CALL utils_log_audit('BATCH', 'orders', NULL,
        CONCAT('ord_process_all_pending: ok=', v_count, ' failed=', v_failed));
END$$


-- ============================================================
-- inv_*   Inventory management
--         inv_deplete_stock  → cursor with JOIN
--         inv_low_stock_report → dynamic SQL
-- ============================================================

CREATE FUNCTION inv_get_stock_value(p_product_id INT)
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_price DECIMAL(12,2);
    DECLARE v_qty   INT;
    SELECT unit_price, stock_qty INTO v_price, v_qty
      FROM products WHERE product_id = p_product_id LIMIT 1;
    RETURN ROUND(IFNULL(v_price, 0) * IFNULL(v_qty, 0), 2);
END$$

CREATE FUNCTION inv_get_total_stock_value(p_category VARCHAR(50))
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_total   DECIMAL(15,2) DEFAULT 0;
    DECLARE v_prod_id INT;
    DECLARE v_done    INT DEFAULT FALSE;

    DECLARE cur_prods CURSOR FOR
        SELECT product_id FROM products
         WHERE p_category IS NULL OR category = p_category;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    OPEN cur_prods;
    prod_loop: LOOP
        FETCH cur_prods INTO v_prod_id;
        IF v_done THEN LEAVE prod_loop; END IF;
        SET v_total = v_total + inv_get_stock_value(v_prod_id);   -- self-group call
    END LOOP prod_loop;
    CLOSE cur_prods;

    RETURN v_total;
END$$

CREATE PROCEDURE inv_restock(IN p_product_id INT, IN p_qty INT)
BEGIN
    DECLARE v_name    VARCHAR(200);
    DECLARE v_new_qty INT;

    UPDATE products SET stock_qty = stock_qty + p_qty WHERE product_id = p_product_id;

    SELECT product_name, stock_qty INTO v_name, v_new_qty
      FROM products WHERE product_id = p_product_id LIMIT 1;

    CALL utils_log_audit('UPDATE', 'products', p_product_id,
        CONCAT('Restocked ', v_name, ' +', p_qty, ' → ', v_new_qty));
END$$

-- cursor with JOIN across order_items + products
CREATE PROCEDURE inv_deplete_stock(IN p_order_id INT)
BEGIN
    DECLARE v_prod_id   INT;
    DECLARE v_qty       INT;
    DECLARE v_prod_name VARCHAR(200);
    DECLARE v_stock     INT;
    DECLARE v_done      INT DEFAULT FALSE;

    DECLARE cur_items CURSOR FOR
        SELECT oi.product_id, oi.quantity, p.product_name, p.stock_qty
          FROM order_items oi
          JOIN products    p ON p.product_id = oi.product_id
         WHERE oi.order_id = p_order_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    OPEN cur_items;
    item_loop: LOOP
        FETCH cur_items INTO v_prod_id, v_qty, v_prod_name, v_stock;
        IF v_done THEN LEAVE item_loop; END IF;

        IF v_stock < v_qty THEN
            CALL utils_log_audit('WARN', 'products', v_prod_id,
                CONCAT('Insufficient stock: need=', v_qty, ' have=', v_stock));
        END IF;

        UPDATE products
           SET stock_qty = GREATEST(0, stock_qty - v_qty)
         WHERE product_id = v_prod_id;

        CALL utils_log_audit('UPDATE', 'products', v_prod_id,
            CONCAT('Stock depleted ', v_qty, ' for order ', p_order_id));
    END LOOP item_loop;
    CLOSE cur_items;
END$$

CREATE PROCEDURE inv_low_stock_report()
BEGIN
    -- All DECLAREs must come first in MySQL
    DECLARE v_id   INT;
    DECLARE v_name VARCHAR(200);
    DECLARE v_qty  INT;
    DECLARE v_val  DECIMAL(15,2);
    DECLARE v_done INT DEFAULT FALSE;

    -- cursor uses hardcoded threshold (MySQL disallows local vars in cursor SELECT)
    DECLARE cur_low CURSOR FOR
        SELECT product_id, product_name, stock_qty
          FROM products
         WHERE stock_qty < 10
         ORDER BY stock_qty ASC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- dynamic SQL shown via PREPARE for demonstration
    SET @dyn_audit_sql = 'CALL utils_log_audit(''SCAN'', ''products'', NULL, ''low-stock scan started'')';
    PREPARE dyn_stmt FROM @dyn_audit_sql;
    EXECUTE dyn_stmt;
    DEALLOCATE PREPARE dyn_stmt;

    OPEN cur_low;
    low_loop: LOOP
        FETCH cur_low INTO v_id, v_name, v_qty;
        IF v_done THEN LEAVE low_loop; END IF;
        SET v_val = inv_get_stock_value(v_id);   -- self-group call
        CALL utils_log_audit('ALERT', 'products', v_id,
            CONCAT('LOW STOCK: ', v_name,
                   ' qty=', v_qty,
                   ' val=', utils_format_amount(v_val)));
    END LOOP low_loop;
    CLOSE cur_low;
END$$


-- ============================================================
-- rpt_*   Reports — top-level orchestrator
--         rpt_calc_dept_total_budget → RECURSIVE
--         rpt_dept_summary → calls emp_*, ord_*, inv_*
--         rpt_generate_full → dynamic CALL + all groups
-- ============================================================

-- budget roll-up via recursive CTE across dept hierarchy
CREATE FUNCTION rpt_calc_dept_total_budget(p_dept_id INT, p_depth INT)
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(15,2);
    WITH RECURSIVE dept_tree AS (
        SELECT dept_id, budget FROM departments WHERE dept_id = p_dept_id
        UNION ALL
        SELECT d.dept_id, d.budget FROM departments d
          JOIN dept_tree dt ON dt.dept_id = d.parent_dept
    )
    SELECT IFNULL(SUM(budget), 0) INTO v_total FROM dept_tree;
    RETURN v_total;
END$$

-- JOIN across 5 tables + cross-group calls
CREATE PROCEDURE rpt_dept_summary(IN p_dept_id INT)
BEGIN
    DECLARE v_total_budget DECIMAL(15,2);
    DECLARE v_stock_val    DECIMAL(15,2);
    DECLARE v_order_total  DECIMAL(15,2) DEFAULT 0;
    DECLARE v_row_count    INT DEFAULT 0;

    DECLARE v_ord_id    INT;
    DECLARE v_status    VARCHAR(20);
    DECLARE v_amt       DECIMAL(15,2);
    DECLARE v_emp_name  VARCHAR(100);
    DECLARE v_dept_name VARCHAR(100);
    DECLARE v_ord_dt    VARCHAR(20);
    DECLARE v_done      INT DEFAULT FALSE;

    DECLARE cur_dept_orders CURSOR FOR
        SELECT o.order_id,
               o.status,
               o.total_amt,
               e.emp_name,
               d.dept_name,
               utils_get_date_str(o.order_date) AS order_dt
          FROM orders       o
          JOIN employees    e  ON e.emp_id    = o.emp_id
          JOIN departments  d  ON d.dept_id   = e.dept_id
          LEFT JOIN order_items oi ON oi.order_id   = o.order_id
          LEFT JOIN products    p  ON p.product_id  = oi.product_id
         WHERE e.dept_id = p_dept_id
         ORDER BY o.order_date DESC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- cross-group calls
    CALL emp_process_department(p_dept_id);

    SET v_total_budget = rpt_calc_dept_total_budget(p_dept_id, 0);   -- recursive call
    SET v_stock_val    = inv_get_total_stock_value(NULL);             -- cross-group call

    OPEN cur_dept_orders;
    ord_loop: LOOP
        FETCH cur_dept_orders INTO v_ord_id, v_status, v_amt, v_emp_name, v_dept_name, v_ord_dt;
        IF v_done THEN LEAVE ord_loop; END IF;
        SET v_order_total = v_order_total + IFNULL(v_amt, 0);
        SET v_row_count   = v_row_count + 1;
    END LOOP ord_loop;
    CLOSE cur_dept_orders;

    CALL utils_log_audit('REPORT', 'departments', p_dept_id,
        CONCAT('Budget=',    utils_format_amount(v_total_budget),
               ' Orders=',   utils_format_amount(v_order_total),
               ' StockVal=', utils_format_amount(v_stock_val)));
END$$

CREATE PROCEDURE rpt_employee_performance(IN p_dept_id INT)
BEGIN
    DECLARE v_emp_id   INT;
    DECLARE v_emp_name VARCHAR(100);
    DECLARE v_salary   DECIMAL(12,2);
    DECLARE v_ord_cnt  INT;
    DECLARE v_subords  INT;
    DECLARE v_chain    VARCHAR(2000);
    DECLARE v_done     INT DEFAULT FALSE;

    DECLARE cur_emps CURSOR FOR
        SELECT emp_id, emp_name, salary
          FROM employees
         WHERE status = 'ACTIVE'
           AND (p_dept_id IS NULL OR dept_id = p_dept_id)
         ORDER BY salary DESC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    OPEN cur_emps;
    perf_loop: LOOP
        FETCH cur_emps INTO v_emp_id, v_emp_name, v_salary;
        IF v_done THEN LEAVE perf_loop; END IF;

        SET v_ord_cnt = ord_get_emp_order_count(v_emp_id);    -- cross-group call
        SET v_subords = emp_count_subordinates(v_emp_id);      -- cross-group (recursive)
        SET v_chain   = emp_get_manager_chain(v_emp_id, 0);    -- cross-group (recursive)

        CALL utils_log_audit('REPORT', 'employees', v_emp_id,
            CONCAT(v_emp_name,
                   ' sal=',    utils_format_amount(v_salary),
                   ' orders=', v_ord_cnt,
                   ' subs=',   v_subords));
    END LOOP perf_loop;
    CLOSE cur_emps;
END$$

CREATE PROCEDURE rpt_generate_full()
BEGIN
    DECLARE v_dept_id INT;
    DECLARE v_done    INT DEFAULT FALSE;

    DECLARE cur_top_depts CURSOR FOR
        SELECT dept_id FROM departments WHERE parent_dept IS NULL ORDER BY dept_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- process all pending orders first (dynamic EXECUTE style)
    SET @full_sql = 'CALL ord_process_all_pending()';
    PREPARE full_stmt FROM @full_sql;
    EXECUTE full_stmt;
    DEALLOCATE PREPARE full_stmt;

    -- inventory check
    CALL inv_low_stock_report();   -- cross-group call

    -- dept reports (recursion happens inside each dept summary)
    OPEN cur_top_depts;
    dept_loop: LOOP
        FETCH cur_top_depts INTO v_dept_id;
        IF v_done THEN LEAVE dept_loop; END IF;
        CALL rpt_dept_summary(v_dept_id);   -- self-group call
    END LOOP dept_loop;
    CLOSE cur_top_depts;

    -- overall employee performance
    CALL rpt_employee_performance(NULL);   -- self-group call

    CALL utils_log_audit('REPORT', 'SYSTEM', NULL,
        CONCAT('rpt_generate_full completed at ', utils_get_date_str(NOW())));
END$$


-- ============================================================
-- Standalone entry-point PROCEDURE
-- ============================================================
CREATE PROCEDURE proc_daily_sync(IN p_run_mode VARCHAR(20))
BEGIN
    DECLARE v_mode  VARCHAR(20);
    DECLARE v_start DATETIME;

    SET v_mode  = UPPER(TRIM(IFNULL(p_run_mode, 'FULL')));
    SET v_start = NOW();

    CALL utils_log_audit('START', 'SYSTEM', NULL,
        CONCAT('proc_daily_sync mode=', v_mode));

    IF v_mode IN ('FULL', 'ORDERS') THEN
        CALL ord_process_all_pending();   -- cross-group call
    END IF;

    IF v_mode IN ('FULL', 'AUDIT') THEN
        CALL utils_purge_old_audit(90);   -- cross-group call
    END IF;

    IF v_mode = 'FULL' THEN
        CALL rpt_generate_full();         -- cross-group (top-level orchestrator)
    END IF;

    CALL utils_log_audit('COMPLETE', 'SYSTEM', NULL,
        CONCAT('proc_daily_sync done in ',
               TIMESTAMPDIFF(SECOND, v_start, NOW()), 's'));
END$$

-- ============================================================
-- Standalone FUNCTION — org depth (WHILE loop; MySQL forbids recursive functions)
-- ============================================================
CREATE FUNCTION func_get_org_depth(p_emp_id INT, p_depth INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_mgr_id  INT;
    DECLARE v_curr_id INT;
    DECLARE v_lvl     INT DEFAULT 0;

    SET v_curr_id = p_emp_id;
    WHILE v_curr_id IS NOT NULL AND v_lvl <= 20 DO
        SELECT manager_id INTO v_mgr_id
          FROM employees WHERE emp_id = v_curr_id LIMIT 1;
        IF v_mgr_id IS NULL THEN
            SET v_curr_id = NULL;
        ELSE
            SET v_curr_id = v_mgr_id;
            SET v_lvl     = v_lvl + 1;
        END IF;
    END WHILE;
    RETURN v_lvl;
END$$

-- ============================================================
-- Standalone FUNCTION — complex JOIN + cross-group calls
-- ============================================================
CREATE FUNCTION func_employee_score(p_emp_id INT)
RETURNS DECIMAL(15,2)
READS SQL DATA
BEGIN
    DECLARE v_order_cnt  INT            DEFAULT 0;
    DECLARE v_total_val  DECIMAL(15,2)  DEFAULT 0;
    DECLARE v_org_depth  INT;
    DECLARE v_subord_cnt INT;
    DECLARE v_score      DECIMAL(15,2);

    SELECT COUNT(DISTINCT o.order_id),
           IFNULL(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct / 100)), 0)
      INTO v_order_cnt, v_total_val
      FROM orders      o
      JOIN order_items oi ON oi.order_id   = o.order_id
      JOIN products     p ON  p.product_id = oi.product_id
     WHERE o.emp_id = p_emp_id AND o.status = 'FULFILLED';

    SET v_org_depth  = func_get_org_depth(p_emp_id, 0);       -- standalone func call (recursive)
    SET v_subord_cnt = emp_count_subordinates(p_emp_id);       -- cross-group (recursive)

    SET v_score = v_total_val  * 0.5
               + v_order_cnt  * 100
               + v_subord_cnt * 250
               - v_org_depth  * 50;

    RETURN ROUND(IFNULL(v_score, 0), 2);
END$$

DELIMITER ;


-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Departments (parent-child for recursive budget roll-up)
INSERT INTO departments (dept_id, dept_name, location, budget, parent_dept) VALUES
(10, 'Engineering',   'New York',  500000, NULL),
(20, 'Backend',       'New York',  200000, 10),
(30, 'Frontend',      'New York',  150000, 10),
(40, 'DevOps',        'Remote',    100000, 10),
(50, 'Sales',         'Chicago',   300000, NULL),
(60, 'Inside Sales',  'Chicago',   120000, 50),
(70, 'Field Sales',   'Dallas',     80000, 50);

-- Employees (deep manager chain: Carol→Bob→Alice for recursion)
INSERT INTO employees (emp_id, emp_name, email, dept_id, salary, manager_id, hire_date, status) VALUES
(1001, 'Alice Johnson', 'alice@co.com',  10, 140000, NULL, '2020-01-15', 'ACTIVE'),
(1002, 'Bob Smith',     'bob@co.com',    20,  98000, 1001, '2020-03-01', 'ACTIVE'),
(1003, 'Carol White',   'carol@co.com',  20,  87000, 1002, '2021-06-01', 'ACTIVE'),
(1004, 'Dave Brown',    'dave@co.com',   30,  76000, 1001, '2021-09-15', 'ACTIVE'),
(1005, 'Eve Davis',     'eve@co.com',    40,  92000, 1001, '2022-02-01', 'ACTIVE'),
(1006, 'Frank Lee',     'frank@co.com',  50, 115000, NULL, '2019-07-01', 'ACTIVE'),
(1007, 'Grace Kim',     'grace@co.com',  60,  68000, 1006, '2022-05-01', 'ACTIVE'),
(1008, 'Henry Patel',   'henry@co.com',  70,  72000, 1006, '2023-01-10', 'ACTIVE');

-- Products
INSERT INTO products (product_id, product_name, category, unit_price, stock_qty) VALUES
(101, 'Enterprise License', 'SOFTWARE',  9999.99,  50),
(102, 'Support Pack',       'SERVICE',   2499.00, 200),
(103, 'Training Bundle',    'TRAINING',  1299.50, 150),
(104, 'Cloud Connector',    'SOFTWARE',  4599.00,  75),
(105, 'Analytics Add-on',   'SOFTWARE',  3299.00,   8);   -- low stock

-- Orders + items
INSERT INTO orders (order_id, emp_id, order_date, status, total_amt) VALUES
(5001, 1002, '2026-04-01', 'PENDING',    0),
(5002, 1003, '2026-04-05', 'PENDING',    0),
(5003, 1007, '2026-04-10', 'FULFILLED',  4599.00);

INSERT INTO order_items (item_id, order_id, product_id, quantity, unit_price, discount_pct) VALUES
(9001, 5001, 101, 2, 9999.99, 0),
(9002, 5001, 102, 1, 2499.00, 5),
(9003, 5002, 103, 3, 1299.50, 0),
(9004, 5003, 104, 1, 4599.00, 0);

-- Refresh totals
UPDATE orders SET total_amt = ord_calculate_total(order_id) WHERE status = 'PENDING';


-- ============================================================
-- SMOKE TEST  (uncomment to run)
-- ============================================================
/*
SELECT utils_get_date_str(NOW())          AS now_str;
SELECT utils_format_amount(123456.78)     AS formatted;
SELECT emp_get_name(1001)                 AS name;
SELECT emp_get_dept_budget(10)            AS budget;
SELECT emp_get_manager_chain(1003, 0)     AS chain;     -- recursive: Carol→Bob→Alice
SELECT emp_count_subordinates(1001)       AS subords;   -- recursive
SELECT ord_calculate_total(5001)          AS total;
SELECT ord_apply_tiered_discount(1000, 4) AS disc;      -- recursive ~814
SELECT inv_get_stock_value(101)           AS val;
SELECT inv_get_total_stock_value(NULL)    AS tot;
SELECT func_get_org_depth(1003, 0)        AS depth;     -- recursive
SELECT func_employee_score(1002)          AS score;

CALL emp_process_department(20);
CALL ord_process_all_pending();
CALL rpt_generate_full();
CALL proc_daily_sync('FULL');
*/
