-- ============================================================
-- JAR-PLSQL-ANALYZER  — Comprehensive Test Script
-- ============================================================
-- Covers: Tables, Sequences, Packages (cross-calls, recursion),
--         Standalone Proc/Func, Cursors, Dynamic SQL, JOINs
-- Schema : DEMO (run as the target user or prefix accordingly)
-- ============================================================

-- ============================================================
-- SEQUENCES
-- ============================================================
CREATE SEQUENCE SEQ_EMPLOYEE_ID  START WITH 1001 INCREMENT BY 1 NOCACHE NOORDER;
CREATE SEQUENCE SEQ_DEPARTMENT_ID START WITH 10  INCREMENT BY 10 NOCACHE NOORDER;
CREATE SEQUENCE SEQ_ORDER_ID     START WITH 5001 INCREMENT BY 1  NOCACHE NOORDER;
CREATE SEQUENCE SEQ_ITEM_ID      START WITH 9001 INCREMENT BY 1  NOCACHE NOORDER;
CREATE SEQUENCE SEQ_PRODUCT_ID   START WITH 101  INCREMENT BY 1  NOCACHE NOORDER;
CREATE SEQUENCE SEQ_AUDIT_ID     START WITH 1    INCREMENT BY 1  NOCACHE NOORDER;

-- ============================================================
-- TABLES
-- ============================================================
CREATE TABLE DEPARTMENTS (
    DEPT_ID      NUMBER         CONSTRAINT PK_DEPT    PRIMARY KEY,
    DEPT_NAME    VARCHAR2(100)  NOT NULL,
    LOCATION     VARCHAR2(100),
    BUDGET       NUMBER(15,2)   DEFAULT 0,
    PARENT_DEPT  NUMBER         CONSTRAINT FK_DEPT_PARENT REFERENCES DEPARTMENTS(DEPT_ID),
    CREATED_AT   DATE           DEFAULT SYSDATE
);

CREATE TABLE EMPLOYEES (
    EMP_ID       NUMBER         CONSTRAINT PK_EMP     PRIMARY KEY,
    EMP_NAME     VARCHAR2(100)  NOT NULL,
    EMAIL        VARCHAR2(150),
    DEPT_ID      NUMBER         CONSTRAINT FK_EMP_DEPT REFERENCES DEPARTMENTS(DEPT_ID),
    SALARY       NUMBER(12,2),
    MANAGER_ID   NUMBER         CONSTRAINT FK_EMP_MGR  REFERENCES EMPLOYEES(EMP_ID),
    HIRE_DATE    DATE           DEFAULT SYSDATE,
    STATUS       VARCHAR2(20)   DEFAULT 'ACTIVE'
);

CREATE TABLE PRODUCTS (
    PRODUCT_ID   NUMBER         CONSTRAINT PK_PROD    PRIMARY KEY,
    PRODUCT_NAME VARCHAR2(200)  NOT NULL,
    CATEGORY     VARCHAR2(50),
    UNIT_PRICE   NUMBER(12,2)   NOT NULL,
    STOCK_QTY    NUMBER         DEFAULT 0
);

CREATE TABLE ORDERS (
    ORDER_ID     NUMBER         CONSTRAINT PK_ORDER   PRIMARY KEY,
    EMP_ID       NUMBER         CONSTRAINT FK_ORD_EMP  REFERENCES EMPLOYEES(EMP_ID),
    ORDER_DATE   DATE           DEFAULT SYSDATE,
    STATUS       VARCHAR2(20)   DEFAULT 'PENDING',
    TOTAL_AMT    NUMBER(15,2)   DEFAULT 0,
    NOTES        VARCHAR2(500)
);

CREATE TABLE ORDER_ITEMS (
    ITEM_ID      NUMBER         CONSTRAINT PK_ITEM    PRIMARY KEY,
    ORDER_ID     NUMBER         CONSTRAINT FK_ITEM_ORD REFERENCES ORDERS(ORDER_ID),
    PRODUCT_ID   NUMBER         CONSTRAINT FK_ITEM_PRD REFERENCES PRODUCTS(PRODUCT_ID),
    QUANTITY     NUMBER         NOT NULL,
    UNIT_PRICE   NUMBER(12,2)   NOT NULL,
    DISCOUNT_PCT NUMBER(5,2)    DEFAULT 0
);

CREATE TABLE AUDIT_LOG (
    AUDIT_ID     NUMBER         CONSTRAINT PK_AUDIT   PRIMARY KEY,
    ACTION       VARCHAR2(50)   NOT NULL,
    TABLE_NAME   VARCHAR2(100),
    RECORD_ID    NUMBER,
    CHANGED_BY   VARCHAR2(100)  DEFAULT USER,
    CHANGED_AT   DATE           DEFAULT SYSDATE,
    DESCRIPTION  VARCHAR2(1000)
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IDX_EMP_DEPT    ON EMPLOYEES(DEPT_ID);
CREATE INDEX IDX_EMP_MGR     ON EMPLOYEES(MANAGER_ID);
CREATE INDEX IDX_ORD_EMP     ON ORDERS(EMP_ID, STATUS);
CREATE INDEX IDX_ITEM_ORD    ON ORDER_ITEMS(ORDER_ID);
CREATE INDEX IDX_AUDIT_TABLE ON AUDIT_LOG(TABLE_NAME, CHANGED_AT);


-- ============================================================
-- PKG_UTILS  ·  Low-level helpers — called by every other pkg
-- ============================================================
CREATE OR REPLACE PACKAGE PKG_UTILS AS

    FUNCTION  GET_DATE_STR(p_date IN DATE) RETURN VARCHAR2;
    FUNCTION  FORMAT_AMOUNT(p_amount IN NUMBER) RETURN VARCHAR2;
    FUNCTION  IS_WORKING_DAY(p_date IN DATE) RETURN BOOLEAN;
    PROCEDURE LOG_AUDIT(
        p_action     IN VARCHAR2,
        p_table_name IN VARCHAR2,
        p_record_id  IN NUMBER      DEFAULT NULL,
        p_desc       IN VARCHAR2    DEFAULT NULL
    );
    PROCEDURE PURGE_OLD_AUDIT(p_days_to_keep IN NUMBER DEFAULT 90);

END PKG_UTILS;
/

CREATE OR REPLACE PACKAGE BODY PKG_UTILS AS

    FUNCTION GET_DATE_STR(p_date IN DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(p_date, 'YYYY-MM-DD HH24:MI:SS');
    END GET_DATE_STR;

    FUNCTION FORMAT_AMOUNT(p_amount IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(NVL(p_amount, 0), 'FM999,999,990.00');
    END FORMAT_AMOUNT;

    FUNCTION IS_WORKING_DAY(p_date IN DATE) RETURN BOOLEAN IS
        v_day VARCHAR2(3);
    BEGIN
        v_day := TO_CHAR(p_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH');
        RETURN v_day NOT IN ('SAT', 'SUN');
    END IS_WORKING_DAY;

    PROCEDURE LOG_AUDIT(
        p_action     IN VARCHAR2,
        p_table_name IN VARCHAR2,
        p_record_id  IN NUMBER   DEFAULT NULL,
        p_desc       IN VARCHAR2 DEFAULT NULL
    ) IS
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        INSERT INTO AUDIT_LOG (AUDIT_ID, ACTION, TABLE_NAME, RECORD_ID, DESCRIPTION)
        VALUES (SEQ_AUDIT_ID.NEXTVAL, p_action, p_table_name, p_record_id, p_desc);
        COMMIT;
    END LOG_AUDIT;

    PROCEDURE PURGE_OLD_AUDIT(p_days_to_keep IN NUMBER DEFAULT 90) IS
        v_cutoff DATE;
        v_deleted NUMBER;
    BEGIN
        v_cutoff := SYSDATE - p_days_to_keep;
        DELETE FROM AUDIT_LOG WHERE CHANGED_AT < v_cutoff;
        v_deleted := SQL%ROWCOUNT;
        LOG_AUDIT('PURGE', 'AUDIT_LOG', NULL,
            'Purged ' || v_deleted || ' rows older than ' || GET_DATE_STR(v_cutoff));
        COMMIT;
    END PURGE_OLD_AUDIT;

END PKG_UTILS;
/


-- ============================================================
-- PKG_EMPLOYEE  ·  Employee management — uses PKG_UTILS
--                  contains RECURSIVE function + CURSOR
-- ============================================================
CREATE OR REPLACE PACKAGE PKG_EMPLOYEE AS

    FUNCTION  GET_EMPLOYEE_NAME(p_emp_id IN NUMBER) RETURN VARCHAR2;
    FUNCTION  GET_DEPT_BUDGET(p_dept_id IN NUMBER) RETURN NUMBER;
    FUNCTION  GET_MANAGER_CHAIN(p_emp_id IN NUMBER, p_depth IN NUMBER DEFAULT 0) RETURN VARCHAR2;
    FUNCTION  COUNT_SUBORDINATES(p_emp_id IN NUMBER) RETURN NUMBER;
    PROCEDURE HIRE_EMPLOYEE(
        p_name       IN VARCHAR2,
        p_dept_id    IN NUMBER,
        p_salary     IN NUMBER,
        p_manager_id IN NUMBER DEFAULT NULL,
        p_new_id     OUT NUMBER
    );
    PROCEDURE TERMINATE_EMPLOYEE(p_emp_id IN NUMBER);
    PROCEDURE PROCESS_DEPARTMENT(p_dept_id IN NUMBER);
    PROCEDURE RAISE_SALARY_BULK(p_dept_id IN NUMBER, p_raise_pct IN NUMBER);

END PKG_EMPLOYEE;
/

CREATE OR REPLACE PACKAGE BODY PKG_EMPLOYEE AS

    FUNCTION GET_EMPLOYEE_NAME(p_emp_id IN NUMBER) RETURN VARCHAR2 IS
        v_name VARCHAR2(100);
    BEGIN
        SELECT EMP_NAME INTO v_name
          FROM EMPLOYEES
         WHERE EMP_ID = p_emp_id;
        RETURN v_name;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN 'UNKNOWN_' || p_emp_id;
    END GET_EMPLOYEE_NAME;

    FUNCTION GET_DEPT_BUDGET(p_dept_id IN NUMBER) RETURN NUMBER IS
        v_budget NUMBER;
    BEGIN
        SELECT BUDGET INTO v_budget
          FROM DEPARTMENTS
         WHERE DEPT_ID = p_dept_id;
        RETURN NVL(v_budget, 0);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN 0;
    END GET_DEPT_BUDGET;

    -- ── RECURSIVE: walks manager chain upward ──────────────
    FUNCTION GET_MANAGER_CHAIN(p_emp_id IN NUMBER, p_depth IN NUMBER DEFAULT 0) RETURN VARCHAR2 IS
        v_name    VARCHAR2(100);
        v_mgr_id  NUMBER;
        v_result  VARCHAR2(2000);
    BEGIN
        IF p_depth > 15 THEN
            RETURN '[MAX DEPTH]';
        END IF;
        BEGIN
            SELECT EMP_NAME, MANAGER_ID
              INTO v_name, v_mgr_id
              FROM EMPLOYEES
             WHERE EMP_ID = p_emp_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN RETURN '[NOT FOUND]';
        END;

        v_result := LPAD(' ', p_depth * 2) || v_name;
        IF v_mgr_id IS NOT NULL THEN
            -- recursive self-call
            v_result := v_result || CHR(10)
                     || GET_MANAGER_CHAIN(v_mgr_id, p_depth + 1);
        END IF;
        RETURN v_result;
    END GET_MANAGER_CHAIN;

    -- ── RECURSIVE: count all reports under an employee ─────
    FUNCTION COUNT_SUBORDINATES(p_emp_id IN NUMBER) RETURN NUMBER IS
        v_count NUMBER := 0;
        CURSOR c_directs IS
            SELECT EMP_ID FROM EMPLOYEES WHERE MANAGER_ID = p_emp_id AND STATUS = 'ACTIVE';
    BEGIN
        FOR rec IN c_directs LOOP
            v_count := v_count + 1 + COUNT_SUBORDINATES(rec.EMP_ID);  -- recursion
        END LOOP;
        RETURN v_count;
    END COUNT_SUBORDINATES;

    PROCEDURE HIRE_EMPLOYEE(
        p_name       IN VARCHAR2,
        p_dept_id    IN NUMBER,
        p_salary     IN NUMBER,
        p_manager_id IN NUMBER DEFAULT NULL,
        p_new_id     OUT NUMBER
    ) IS
    BEGIN
        p_new_id := SEQ_EMPLOYEE_ID.NEXTVAL;
        INSERT INTO EMPLOYEES (EMP_ID, EMP_NAME, DEPT_ID, SALARY, MANAGER_ID, HIRE_DATE, STATUS)
        VALUES (p_new_id, TRIM(p_name), p_dept_id, p_salary, p_manager_id, SYSDATE, 'ACTIVE');

        PKG_UTILS.LOG_AUDIT('INSERT', 'EMPLOYEES', p_new_id,
            'Hired: ' || p_name || ' dept=' || p_dept_id);
        COMMIT;
    END HIRE_EMPLOYEE;

    PROCEDURE TERMINATE_EMPLOYEE(p_emp_id IN NUMBER) IS
        v_name VARCHAR2(100);
    BEGIN
        v_name := GET_EMPLOYEE_NAME(p_emp_id);  -- self-package call
        UPDATE EMPLOYEES SET STATUS = 'TERMINATED' WHERE EMP_ID = p_emp_id;
        PKG_UTILS.LOG_AUDIT('UPDATE', 'EMPLOYEES', p_emp_id, 'Terminated: ' || v_name);
        COMMIT;
    END TERMINATE_EMPLOYEE;

    -- ── CURSOR + JOIN + cross-package call ─────────────────
    PROCEDURE PROCESS_DEPARTMENT(p_dept_id IN NUMBER) IS
        CURSOR c_active_emps IS
            SELECT e.EMP_ID,
                   e.EMP_NAME,
                   e.SALARY,
                   d.DEPT_NAME,
                   d.LOCATION
              FROM EMPLOYEES    e
              JOIN DEPARTMENTS  d ON d.DEPT_ID = e.DEPT_ID
             WHERE e.DEPT_ID = p_dept_id
               AND e.STATUS  = 'ACTIVE'
             ORDER BY e.SALARY DESC;

        v_rec       c_active_emps%ROWTYPE;
        v_total_sal NUMBER := 0;
        v_emp_count NUMBER := 0;
        v_budget    NUMBER;
        v_chain     VARCHAR2(2000);
    BEGIN
        v_budget := GET_DEPT_BUDGET(p_dept_id);  -- self-pkg call

        OPEN c_active_emps;
        LOOP
            FETCH c_active_emps INTO v_rec;
            EXIT WHEN c_active_emps%NOTFOUND;

            v_total_sal := v_total_sal + v_rec.SALARY;
            v_emp_count := v_emp_count + 1;

            -- build manager chain for top earner
            IF c_active_emps%ROWCOUNT = 1 THEN
                v_chain := GET_MANAGER_CHAIN(v_rec.EMP_ID);  -- recursive call
            END IF;
        END LOOP;
        CLOSE c_active_emps;

        PKG_UTILS.LOG_AUDIT('PROCESS', 'DEPARTMENTS', p_dept_id,
            'Dept=' || p_dept_id ||
            ' Emps=' || v_emp_count ||
            ' TotalSal=' || PKG_UTILS.FORMAT_AMOUNT(v_total_sal) ||
            ' Budget='   || PKG_UTILS.FORMAT_AMOUNT(v_budget));
    END PROCESS_DEPARTMENT;

    -- ── Dynamic SQL + BULK COLLECT ──────────────────────────
    PROCEDURE RAISE_SALARY_BULK(p_dept_id IN NUMBER, p_raise_pct IN NUMBER) IS
        TYPE t_emp_tab IS TABLE OF EMPLOYEES%ROWTYPE;
        v_emps  t_emp_tab;
        v_sql   VARCHAR2(500);
        v_name  VARCHAR2(100);
    BEGIN
        v_sql := 'SELECT * FROM EMPLOYEES WHERE DEPT_ID = :d AND STATUS = ''ACTIVE''';
        EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_emps USING p_dept_id;

        FORALL i IN 1..v_emps.COUNT
            UPDATE EMPLOYEES
               SET SALARY = SALARY * (1 + p_raise_pct / 100)
             WHERE EMP_ID = v_emps(i).EMP_ID;

        FOR i IN 1..v_emps.COUNT LOOP
            v_name := GET_EMPLOYEE_NAME(v_emps(i).EMP_ID);  -- self-pkg call
            PKG_UTILS.LOG_AUDIT('UPDATE', 'EMPLOYEES', v_emps(i).EMP_ID,
                v_name || ' salary raised ' || p_raise_pct || '%');
        END LOOP;
        COMMIT;
    END RAISE_SALARY_BULK;

END PKG_EMPLOYEE;
/


-- ============================================================
-- PKG_ORDER  ·  Order lifecycle — calls PKG_EMPLOYEE + PKG_UTILS
--               has RECURSIVE discount function + SYS_REFCURSOR
-- ============================================================
CREATE OR REPLACE PACKAGE PKG_ORDER AS

    FUNCTION  CALCULATE_ORDER_TOTAL(p_order_id IN NUMBER) RETURN NUMBER;
    FUNCTION  APPLY_TIERED_DISCOUNT(p_amount IN NUMBER, p_tiers IN NUMBER) RETURN NUMBER;
    FUNCTION  GET_EMPLOYEE_ORDER_COUNT(p_emp_id IN NUMBER) RETURN NUMBER;
    PROCEDURE CREATE_ORDER(
        p_emp_id    IN NUMBER,
        p_product_id IN NUMBER,
        p_qty        IN NUMBER,
        p_order_id   OUT NUMBER
    );
    PROCEDURE ADD_ORDER_ITEM(
        p_order_id   IN NUMBER,
        p_product_id IN NUMBER,
        p_qty        IN NUMBER,
        p_discount   IN NUMBER DEFAULT 0
    );
    PROCEDURE FULFILL_ORDER(p_order_id IN NUMBER);
    PROCEDURE CANCEL_ORDER(p_order_id IN NUMBER, p_reason IN VARCHAR2 DEFAULT NULL);
    PROCEDURE PROCESS_ALL_PENDING;

END PKG_ORDER;
/

CREATE OR REPLACE PACKAGE BODY PKG_ORDER AS

    -- ── JOIN across 4 tables ────────────────────────────────
    FUNCTION CALCULATE_ORDER_TOTAL(p_order_id IN NUMBER) RETURN NUMBER IS
        v_total NUMBER := 0;
        CURSOR c_items IS
            SELECT oi.QUANTITY,
                   oi.UNIT_PRICE,
                   oi.DISCOUNT_PCT,
                   p.PRODUCT_NAME,
                   e.EMP_NAME,
                   d.DEPT_NAME
              FROM ORDER_ITEMS  oi
              JOIN ORDERS       o  ON o.ORDER_ID   = oi.ORDER_ID
              JOIN PRODUCTS     p  ON p.PRODUCT_ID = oi.PRODUCT_ID
              JOIN EMPLOYEES    e  ON e.EMP_ID     = o.EMP_ID
              JOIN DEPARTMENTS  d  ON d.DEPT_ID    = e.DEPT_ID
             WHERE oi.ORDER_ID = p_order_id;
    BEGIN
        FOR rec IN c_items LOOP
            v_total := v_total + (rec.QUANTITY * rec.UNIT_PRICE
                                  * (1 - rec.DISCOUNT_PCT / 100));
        END LOOP;
        RETURN ROUND(v_total, 2);
    END CALCULATE_ORDER_TOTAL;

    -- ── RECURSIVE: compound discount per tier ───────────────
    FUNCTION APPLY_TIERED_DISCOUNT(p_amount IN NUMBER, p_tiers IN NUMBER) RETURN NUMBER IS
        v_tier_rate CONSTANT NUMBER := 0.05;
    BEGIN
        IF p_tiers <= 0 OR p_amount <= 0 THEN
            RETURN ROUND(p_amount, 2);
        END IF;
        -- recursive self-call
        RETURN APPLY_TIERED_DISCOUNT(p_amount * (1 - v_tier_rate), p_tiers - 1);
    END APPLY_TIERED_DISCOUNT;

    FUNCTION GET_EMPLOYEE_ORDER_COUNT(p_emp_id IN NUMBER) RETURN NUMBER IS
        v_cnt NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_cnt
          FROM ORDERS
         WHERE EMP_ID = p_emp_id AND STATUS != 'CANCELLED';
        RETURN v_cnt;
    END GET_EMPLOYEE_ORDER_COUNT;

    PROCEDURE CREATE_ORDER(
        p_emp_id     IN NUMBER,
        p_product_id IN NUMBER,
        p_qty        IN NUMBER,
        p_order_id   OUT NUMBER
    ) IS
        v_price     NUMBER;
        v_emp_name  VARCHAR2(100);
        v_ord_count NUMBER;
    BEGIN
        -- cross-package call to PKG_EMPLOYEE
        v_emp_name  := PKG_EMPLOYEE.GET_EMPLOYEE_NAME(p_emp_id);
        v_ord_count := GET_EMPLOYEE_ORDER_COUNT(p_emp_id);  -- self-pkg call

        SELECT UNIT_PRICE INTO v_price
          FROM PRODUCTS
         WHERE PRODUCT_ID = p_product_id;

        p_order_id := SEQ_ORDER_ID.NEXTVAL;
        INSERT INTO ORDERS (ORDER_ID, EMP_ID, STATUS, ORDER_DATE)
        VALUES (p_order_id, p_emp_id, 'PENDING', SYSDATE);

        -- add first item inline
        ADD_ORDER_ITEM(p_order_id, p_product_id, p_qty, 0);  -- self-pkg call

        -- recalculate total
        UPDATE ORDERS
           SET TOTAL_AMT = CALCULATE_ORDER_TOTAL(p_order_id)
         WHERE ORDER_ID = p_order_id;

        PKG_UTILS.LOG_AUDIT('INSERT', 'ORDERS', p_order_id,
            'Created by ' || v_emp_name ||
            ' (order #' || v_ord_count + 1 || ')');
        COMMIT;
    END CREATE_ORDER;

    PROCEDURE ADD_ORDER_ITEM(
        p_order_id   IN NUMBER,
        p_product_id IN NUMBER,
        p_qty        IN NUMBER,
        p_discount   IN NUMBER DEFAULT 0
    ) IS
        v_price  NUMBER;
        v_item_id NUMBER;
    BEGIN
        SELECT UNIT_PRICE INTO v_price
          FROM PRODUCTS WHERE PRODUCT_ID = p_product_id;

        v_item_id := SEQ_ITEM_ID.NEXTVAL;
        INSERT INTO ORDER_ITEMS (ITEM_ID, ORDER_ID, PRODUCT_ID, QUANTITY, UNIT_PRICE, DISCOUNT_PCT)
        VALUES (v_item_id, p_order_id, p_product_id, p_qty, v_price, p_discount);

        -- refresh order total
        UPDATE ORDERS
           SET TOTAL_AMT = CALCULATE_ORDER_TOTAL(p_order_id)
         WHERE ORDER_ID = p_order_id;

        PKG_UTILS.LOG_AUDIT('INSERT', 'ORDER_ITEMS', v_item_id,
            'Item added to order ' || p_order_id);
    END ADD_ORDER_ITEM;

    PROCEDURE FULFILL_ORDER(p_order_id IN NUMBER) IS
        v_emp_id   NUMBER;
        v_total    NUMBER;
        v_final    NUMBER;
        v_tiers    NUMBER;
        v_emp_name VARCHAR2(100);
        v_ord_cnt  NUMBER;
    BEGIN
        SELECT EMP_ID, TOTAL_AMT INTO v_emp_id, v_total
          FROM ORDERS WHERE ORDER_ID = p_order_id;

        v_emp_name := PKG_EMPLOYEE.GET_EMPLOYEE_NAME(v_emp_id);   -- cross-pkg
        v_ord_cnt  := GET_EMPLOYEE_ORDER_COUNT(v_emp_id);          -- self-pkg

        -- loyalty tiers: 1 tier per 5 orders (max 4)
        v_tiers := LEAST(TRUNC(v_ord_cnt / 5), 4);
        v_final := APPLY_TIERED_DISCOUNT(v_total, v_tiers);        -- recursive call

        UPDATE ORDERS
           SET STATUS    = 'FULFILLED',
               TOTAL_AMT = v_final,
               NOTES     = 'Discount tiers applied: ' || v_tiers
         WHERE ORDER_ID  = p_order_id;

        PKG_UTILS.LOG_AUDIT('UPDATE', 'ORDERS', p_order_id,
            'Fulfilled for ' || v_emp_name ||
            ' | Original=' || PKG_UTILS.FORMAT_AMOUNT(v_total) ||
            ' | Final='    || PKG_UTILS.FORMAT_AMOUNT(v_final) ||
            ' | Tiers='    || v_tiers);
        COMMIT;
    END FULFILL_ORDER;

    PROCEDURE CANCEL_ORDER(p_order_id IN NUMBER, p_reason IN VARCHAR2 DEFAULT NULL) IS
        v_status VARCHAR2(20);
    BEGIN
        SELECT STATUS INTO v_status FROM ORDERS WHERE ORDER_ID = p_order_id;
        IF v_status = 'FULFILLED' THEN
            RAISE_APPLICATION_ERROR(-20001, 'Cannot cancel fulfilled order ' || p_order_id);
        END IF;
        UPDATE ORDERS SET STATUS = 'CANCELLED', NOTES = p_reason WHERE ORDER_ID = p_order_id;
        PKG_UTILS.LOG_AUDIT('UPDATE', 'ORDERS', p_order_id, 'Cancelled: ' || p_reason);
        COMMIT;
    END CANCEL_ORDER;

    -- ── Dynamic SQL + SYS_REFCURSOR ─────────────────────────
    PROCEDURE PROCESS_ALL_PENDING IS
        v_cur      SYS_REFCURSOR;
        v_order_id NUMBER;
        v_sql      VARCHAR2(300);
        v_count    NUMBER := 0;
        v_failed   NUMBER := 0;
    BEGIN
        -- dynamic query: could come from config at runtime
        v_sql := 'SELECT ORDER_ID FROM ORDERS ' ||
                 'WHERE STATUS = :1 AND ORDER_DATE <= SYSDATE ' ||
                 'ORDER BY ORDER_DATE ASC';

        OPEN v_cur FOR v_sql USING 'PENDING';
        LOOP
            FETCH v_cur INTO v_order_id;
            EXIT WHEN v_cur%NOTFOUND;
            BEGIN
                FULFILL_ORDER(v_order_id);  -- self-pkg call
                v_count := v_count + 1;
            EXCEPTION
                WHEN OTHERS THEN
                    v_failed := v_failed + 1;
                    PKG_UTILS.LOG_AUDIT('ERROR', 'ORDERS', v_order_id,
                        'Fulfill failed: ' || SQLERRM);
            END;
        END LOOP;
        CLOSE v_cur;

        PKG_UTILS.LOG_AUDIT('BATCH', 'ORDERS', NULL,
            'PROCESS_ALL_PENDING: ok=' || v_count || ' failed=' || v_failed);
    END PROCESS_ALL_PENDING;

END PKG_ORDER;
/


-- ============================================================
-- PKG_INVENTORY  ·  Stock management — calls PKG_UTILS,
--                   uses explicit CURSOR + dynamic DDL-style SQL
-- ============================================================
CREATE OR REPLACE PACKAGE PKG_INVENTORY AS

    FUNCTION  GET_STOCK_VALUE(p_product_id IN NUMBER) RETURN NUMBER;
    FUNCTION  GET_TOTAL_STOCK_VALUE(p_category IN VARCHAR2 DEFAULT NULL) RETURN NUMBER;
    PROCEDURE RESTOCK_PRODUCT(p_product_id IN NUMBER, p_qty IN NUMBER);
    PROCEDURE DEPLETE_STOCK(p_order_id IN NUMBER);
    PROCEDURE LOW_STOCK_REPORT;

END PKG_INVENTORY;
/

CREATE OR REPLACE PACKAGE BODY PKG_INVENTORY AS

    FUNCTION GET_STOCK_VALUE(p_product_id IN NUMBER) RETURN NUMBER IS
        v_price NUMBER;
        v_qty   NUMBER;
    BEGIN
        SELECT UNIT_PRICE, STOCK_QTY INTO v_price, v_qty
          FROM PRODUCTS WHERE PRODUCT_ID = p_product_id;
        RETURN ROUND(v_price * v_qty, 2);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN 0;
    END GET_STOCK_VALUE;

    -- ── RECURSIVE-LIKE aggregation (calls self via cursor) ──
    FUNCTION GET_TOTAL_STOCK_VALUE(p_category IN VARCHAR2 DEFAULT NULL) RETURN NUMBER IS
        v_total NUMBER := 0;
        CURSOR c_prods IS
            SELECT PRODUCT_ID FROM PRODUCTS
             WHERE (p_category IS NULL OR CATEGORY = p_category);
    BEGIN
        FOR p IN c_prods LOOP
            v_total := v_total + GET_STOCK_VALUE(p.PRODUCT_ID);  -- self-pkg call
        END LOOP;
        RETURN v_total;
    END GET_TOTAL_STOCK_VALUE;

    PROCEDURE RESTOCK_PRODUCT(p_product_id IN NUMBER, p_qty IN NUMBER) IS
        v_name    VARCHAR2(200);
        v_new_qty NUMBER;
    BEGIN
        UPDATE PRODUCTS
           SET STOCK_QTY = STOCK_QTY + p_qty
         WHERE PRODUCT_ID = p_product_id
        RETURNING PRODUCT_NAME, STOCK_QTY INTO v_name, v_new_qty;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20010, 'Product not found: ' || p_product_id);
        END IF;

        PKG_UTILS.LOG_AUDIT('UPDATE', 'PRODUCTS', p_product_id,
            'Restocked ' || v_name || ' +' || p_qty || ' → ' || v_new_qty);
        COMMIT;
    END RESTOCK_PRODUCT;

    -- ── JOIN: deplete stock for each item in an order ───────
    PROCEDURE DEPLETE_STOCK(p_order_id IN NUMBER) IS
        CURSOR c_items IS
            SELECT oi.PRODUCT_ID, oi.QUANTITY, p.PRODUCT_NAME, p.STOCK_QTY
              FROM ORDER_ITEMS oi
              JOIN PRODUCTS    p ON p.PRODUCT_ID = oi.PRODUCT_ID
             WHERE oi.ORDER_ID = p_order_id
               FOR UPDATE OF p.STOCK_QTY NOWAIT;
    BEGIN
        FOR item IN c_items LOOP
            IF item.STOCK_QTY < item.QUANTITY THEN
                PKG_UTILS.LOG_AUDIT('WARN', 'PRODUCTS', item.PRODUCT_ID,
                    'Insufficient stock: need=' || item.QUANTITY ||
                    ' have=' || item.STOCK_QTY);
            END IF;
            UPDATE PRODUCTS
               SET STOCK_QTY = GREATEST(0, STOCK_QTY - item.QUANTITY)
             WHERE PRODUCT_ID = item.PRODUCT_ID;

            PKG_UTILS.LOG_AUDIT('UPDATE', 'PRODUCTS', item.PRODUCT_ID,
                'Stock depleted ' || item.QUANTITY || ' for order ' || p_order_id);
        END LOOP;
        COMMIT;
    END DEPLETE_STOCK;

    -- ── Dynamic SQL + EXECUTE IMMEDIATE ─────────────────────
    PROCEDURE LOW_STOCK_REPORT IS
        v_threshold NUMBER := 10;
        v_sql       VARCHAR2(500);
        v_cur       SYS_REFCURSOR;
        v_id        NUMBER;
        v_name      VARCHAR2(200);
        v_qty       NUMBER;
        v_val       NUMBER;
    BEGIN
        v_sql := 'SELECT PRODUCT_ID, PRODUCT_NAME, STOCK_QTY ' ||
                 'FROM PRODUCTS ' ||
                 'WHERE STOCK_QTY < :thresh ' ||
                 'ORDER BY STOCK_QTY ASC';

        OPEN v_cur FOR v_sql USING v_threshold;
        LOOP
            FETCH v_cur INTO v_id, v_name, v_qty;
            EXIT WHEN v_cur%NOTFOUND;
            v_val := GET_STOCK_VALUE(v_id);  -- self-pkg call
            PKG_UTILS.LOG_AUDIT('ALERT', 'PRODUCTS', v_id,
                'LOW STOCK: ' || v_name ||
                ' qty=' || v_qty ||
                ' val=' || PKG_UTILS.FORMAT_AMOUNT(v_val));
        END LOOP;
        CLOSE v_cur;
    END LOW_STOCK_REPORT;

END PKG_INVENTORY;
/


-- ============================================================
-- PKG_REPORTS  ·  Top-level orchestrator
--                 calls PKG_EMPLOYEE, PKG_ORDER, PKG_INVENTORY,
--                 PKG_UTILS; has own RECURSIVE function
-- ============================================================
CREATE OR REPLACE PACKAGE PKG_REPORTS AS

    -- Recursive budget roll-up across department hierarchy
    FUNCTION  CALC_DEPT_TOTAL_BUDGET(p_dept_id IN NUMBER, p_depth IN NUMBER DEFAULT 0) RETURN NUMBER;
    PROCEDURE DEPT_SUMMARY_REPORT(p_dept_id IN NUMBER);
    PROCEDURE EMPLOYEE_PERFORMANCE_REPORT(p_dept_id IN NUMBER DEFAULT NULL);
    PROCEDURE GENERATE_FULL_REPORT;

END PKG_REPORTS;
/

CREATE OR REPLACE PACKAGE BODY PKG_REPORTS AS

    -- ── RECURSIVE: rolls up budget through dept hierarchy ───
    FUNCTION CALC_DEPT_TOTAL_BUDGET(p_dept_id IN NUMBER, p_depth IN NUMBER DEFAULT 0) RETURN NUMBER IS
        v_own_budget NUMBER;
        v_total      NUMBER;
        CURSOR c_children IS
            SELECT DEPT_ID FROM DEPARTMENTS WHERE PARENT_DEPT = p_dept_id;
    BEGIN
        IF p_depth > 10 THEN RETURN 0; END IF;

        v_own_budget := PKG_EMPLOYEE.GET_DEPT_BUDGET(p_dept_id);  -- cross-pkg
        v_total      := v_own_budget;

        FOR child IN c_children LOOP
            -- recursive self-call
            v_total := v_total + CALC_DEPT_TOTAL_BUDGET(child.DEPT_ID, p_depth + 1);
        END LOOP;
        RETURN v_total;
    END CALC_DEPT_TOTAL_BUDGET;

    -- ── JOIN across 5 tables + cross-pkg calls ──────────────
    PROCEDURE DEPT_SUMMARY_REPORT(p_dept_id IN NUMBER) IS
        v_total_budget NUMBER;
        v_stock_val    NUMBER;
        v_order_total  NUMBER := 0;
        v_emp_count    NUMBER := 0;

        CURSOR c_dept_orders IS
            SELECT o.ORDER_ID,
                   o.STATUS,
                   o.TOTAL_AMT,
                   e.EMP_NAME,
                   e.SALARY,
                   d.DEPT_NAME,
                   PKG_UTILS.GET_DATE_STR(o.ORDER_DATE) AS ORDER_DT
              FROM ORDERS       o
              JOIN EMPLOYEES    e  ON e.EMP_ID    = o.EMP_ID
              JOIN DEPARTMENTS  d  ON d.DEPT_ID   = e.DEPT_ID
              LEFT JOIN ORDER_ITEMS oi ON oi.ORDER_ID = o.ORDER_ID
              LEFT JOIN PRODUCTS    p  ON p.PRODUCT_ID = oi.PRODUCT_ID
             WHERE e.DEPT_ID = p_dept_id
             ORDER BY o.ORDER_DATE DESC;
    BEGIN
        -- cross-package calls
        PKG_EMPLOYEE.PROCESS_DEPARTMENT(p_dept_id);

        v_total_budget := CALC_DEPT_TOTAL_BUDGET(p_dept_id);     -- recursive call
        v_stock_val    := PKG_INVENTORY.GET_TOTAL_STOCK_VALUE();  -- cross-pkg

        FOR ord IN c_dept_orders LOOP
            v_order_total := v_order_total + NVL(ord.TOTAL_AMT, 0);
            v_emp_count   := v_emp_count + 1;
        END LOOP;

        PKG_UTILS.LOG_AUDIT('REPORT', 'DEPARTMENTS', p_dept_id,
            'Budget='     || PKG_UTILS.FORMAT_AMOUNT(v_total_budget) ||
            ' Orders='    || PKG_UTILS.FORMAT_AMOUNT(v_order_total)  ||
            ' StockVal='  || PKG_UTILS.FORMAT_AMOUNT(v_stock_val));
    END DEPT_SUMMARY_REPORT;

    -- ── Implicit cursor + cross-pkg: employee perf ──────────
    PROCEDURE EMPLOYEE_PERFORMANCE_REPORT(p_dept_id IN NUMBER DEFAULT NULL) IS
        v_ord_cnt  NUMBER;
        v_subords  NUMBER;
        v_chain    VARCHAR2(2000);
        v_dyn_sql  VARCHAR2(500);
        v_cur      SYS_REFCURSOR;
        v_emp_id   NUMBER;
        v_emp_name VARCHAR2(100);
        v_salary   NUMBER;
    BEGIN
        -- dynamic filter: all depts or specific dept
        v_dyn_sql := 'SELECT EMP_ID, EMP_NAME, SALARY FROM EMPLOYEES ' ||
                     'WHERE STATUS = ''ACTIVE'' ' ||
                     CASE WHEN p_dept_id IS NOT NULL
                          THEN 'AND DEPT_ID = :d '
                          ELSE '' END ||
                     'ORDER BY SALARY DESC';

        IF p_dept_id IS NOT NULL THEN
            OPEN v_cur FOR v_dyn_sql USING p_dept_id;
        ELSE
            OPEN v_cur FOR v_dyn_sql;
        END IF;

        LOOP
            FETCH v_cur INTO v_emp_id, v_emp_name, v_salary;
            EXIT WHEN v_cur%NOTFOUND;

            v_ord_cnt := PKG_ORDER.GET_EMPLOYEE_ORDER_COUNT(v_emp_id);    -- cross-pkg
            v_subords := PKG_EMPLOYEE.COUNT_SUBORDINATES(v_emp_id);       -- cross-pkg (recursive)
            v_chain   := PKG_EMPLOYEE.GET_MANAGER_CHAIN(v_emp_id);        -- cross-pkg (recursive)

            PKG_UTILS.LOG_AUDIT('REPORT', 'EMPLOYEES', v_emp_id,
                v_emp_name ||
                ' sal=' || PKG_UTILS.FORMAT_AMOUNT(v_salary) ||
                ' orders=' || v_ord_cnt ||
                ' subs=' || v_subords);
        END LOOP;
        CLOSE v_cur;
    END EMPLOYEE_PERFORMANCE_REPORT;

    -- ── Full orchestration entry point ───────────────────────
    PROCEDURE GENERATE_FULL_REPORT IS
        v_dyn_sql VARCHAR2(200);
        CURSOR c_top_depts IS
            SELECT DEPT_ID FROM DEPARTMENTS WHERE PARENT_DEPT IS NULL ORDER BY DEPT_ID;
    BEGIN
        -- process all pending orders first via dynamic call
        v_dyn_sql := 'BEGIN PKG_ORDER.PROCESS_ALL_PENDING; END;';
        EXECUTE IMMEDIATE v_dyn_sql;

        -- inventory check
        PKG_INVENTORY.LOW_STOCK_REPORT;

        -- dept reports for root departments (children handled recursively via budget)
        FOR dept IN c_top_depts LOOP
            DEPT_SUMMARY_REPORT(dept.DEPT_ID);  -- self-pkg call
        END LOOP;

        -- employee performance across all depts
        EMPLOYEE_PERFORMANCE_REPORT;  -- self-pkg call

        PKG_UTILS.LOG_AUDIT('REPORT', 'SYSTEM', NULL,
            'GENERATE_FULL_REPORT completed at ' || PKG_UTILS.GET_DATE_STR(SYSDATE));
    END GENERATE_FULL_REPORT;

END PKG_REPORTS;
/


-- ============================================================
-- Standalone PROCEDURE — entry point that calls multiple pkgs
-- ============================================================
CREATE OR REPLACE PROCEDURE PROC_DAILY_SYNC(
    p_run_mode IN VARCHAR2 DEFAULT 'FULL'  -- FULL | ORDERS | AUDIT
) IS
    v_mode  VARCHAR2(20);
    v_start DATE := SYSDATE;
BEGIN
    v_mode := UPPER(TRIM(p_run_mode));

    PKG_UTILS.LOG_AUDIT('START', 'SYSTEM', NULL,
        'PROC_DAILY_SYNC mode=' || v_mode);

    IF v_mode IN ('FULL', 'ORDERS') THEN
        PKG_ORDER.PROCESS_ALL_PENDING;   -- cross-pkg call
    END IF;

    IF v_mode IN ('FULL', 'AUDIT') THEN
        PKG_UTILS.PURGE_OLD_AUDIT(90);   -- cross-pkg call
    END IF;

    IF v_mode = 'FULL' THEN
        PKG_REPORTS.GENERATE_FULL_REPORT;  -- cross-pkg (top-level orchestrator)
    END IF;

    PKG_UTILS.LOG_AUDIT('COMPLETE', 'SYSTEM', NULL,
        'PROC_DAILY_SYNC done in ' ||
        ROUND((SYSDATE - v_start) * 86400, 2) || 's');
EXCEPTION
    WHEN OTHERS THEN
        PKG_UTILS.LOG_AUDIT('ERROR', 'SYSTEM', NULL,
            'PROC_DAILY_SYNC FAILED: ' || SQLERRM);
        RAISE;
END PROC_DAILY_SYNC;
/


-- ============================================================
-- Standalone FUNCTION — recursive org-level computation
-- ============================================================
CREATE OR REPLACE FUNCTION FUNC_GET_ORG_DEPTH(
    p_emp_id IN NUMBER,
    p_depth  IN NUMBER DEFAULT 0
) RETURN NUMBER IS
    v_manager_id NUMBER;
BEGIN
    IF p_depth > 20 THEN RETURN p_depth; END IF;

    SELECT MANAGER_ID INTO v_manager_id
      FROM EMPLOYEES WHERE EMP_ID = p_emp_id;

    IF v_manager_id IS NULL THEN
        RETURN p_depth;
    END IF;

    RETURN FUNC_GET_ORG_DEPTH(v_manager_id, p_depth + 1);  -- recursive self-call
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN -1;
END FUNC_GET_ORG_DEPTH;
/


-- ============================================================
-- Standalone FUNCTION — complex JOIN + sequence usage
-- ============================================================
CREATE OR REPLACE FUNCTION FUNC_EMPLOYEE_SCORE(p_emp_id IN NUMBER) RETURN NUMBER IS
    v_order_cnt   NUMBER := 0;
    v_total_val   NUMBER := 0;
    v_org_depth   NUMBER;
    v_subord_cnt  NUMBER;
    v_score       NUMBER;
BEGIN
    -- JOIN across orders + items + products
    SELECT COUNT(DISTINCT o.ORDER_ID),
           SUM(oi.QUANTITY * oi.UNIT_PRICE * (1 - oi.DISCOUNT_PCT / 100))
      INTO v_order_cnt, v_total_val
      FROM ORDERS      o
      JOIN ORDER_ITEMS oi ON oi.ORDER_ID   = o.ORDER_ID
      JOIN PRODUCTS    p  ON p.PRODUCT_ID  = oi.PRODUCT_ID
     WHERE o.EMP_ID = p_emp_id
       AND o.STATUS = 'FULFILLED';

    v_org_depth  := FUNC_GET_ORG_DEPTH(p_emp_id);           -- standalone func call
    v_subord_cnt := PKG_EMPLOYEE.COUNT_SUBORDINATES(p_emp_id); -- cross-pkg recursive

    -- weighted score formula
    v_score := NVL(v_total_val, 0) * 0.5
             + NVL(v_order_cnt, 0) * 100
             + NVL(v_subord_cnt, 0) * 250
             - NVL(v_org_depth, 0) * 50;

    RETURN ROUND(NVL(v_score, 0), 2);
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN 0;
END FUNC_EMPLOYEE_SCORE;
/


-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Departments (parent-child hierarchy for recursive budget tests)
INSERT INTO DEPARTMENTS VALUES (10, 'Engineering',    'New York',   500000, NULL, SYSDATE);
INSERT INTO DEPARTMENTS VALUES (20, 'Backend',        'New York',   200000, 10,   SYSDATE);
INSERT INTO DEPARTMENTS VALUES (30, 'Frontend',       'New York',   150000, 10,   SYSDATE);
INSERT INTO DEPARTMENTS VALUES (40, 'DevOps',         'Remote',     100000, 10,   SYSDATE);
INSERT INTO DEPARTMENTS VALUES (50, 'Sales',          'Chicago',    300000, NULL, SYSDATE);
INSERT INTO DEPARTMENTS VALUES (60, 'Inside Sales',   'Chicago',    120000, 50,   SYSDATE);
INSERT INTO DEPARTMENTS VALUES (70, 'Field Sales',    'Dallas',      80000, 50,   SYSDATE);

-- Employees (manager chain: Alice → Bob → Carol for recursion)
INSERT INTO EMPLOYEES VALUES (1001, 'Alice Johnson', 'alice@co.com',  10, 140000, NULL, DATE '2020-01-15', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1002, 'Bob Smith',     'bob@co.com',    20,  98000, 1001, DATE '2020-03-01', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1003, 'Carol White',   'carol@co.com',  20,  87000, 1002, DATE '2021-06-01', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1004, 'Dave Brown',    'dave@co.com',   30,  76000, 1001, DATE '2021-09-15', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1005, 'Eve Davis',     'eve@co.com',    40,  92000, 1001, DATE '2022-02-01', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1006, 'Frank Lee',     'frank@co.com',  50, 115000, NULL, DATE '2019-07-01', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1007, 'Grace Kim',     'grace@co.com',  60,  68000, 1006, DATE '2022-05-01', 'ACTIVE');
INSERT INTO EMPLOYEES VALUES (1008, 'Henry Patel',   'henry@co.com',  70,  72000, 1006, DATE '2023-01-10', 'ACTIVE');

-- Products
INSERT INTO PRODUCTS VALUES (101, 'Enterprise License', 'SOFTWARE',  9999.99,  50);
INSERT INTO PRODUCTS VALUES (102, 'Support Pack',       'SERVICE',   2499.00, 200);
INSERT INTO PRODUCTS VALUES (103, 'Training Bundle',    'TRAINING',  1299.50, 150);
INSERT INTO PRODUCTS VALUES (104, 'Cloud Connector',    'SOFTWARE',  4599.00,  75);
INSERT INTO PRODUCTS VALUES (105, 'Analytics Add-on',  'SOFTWARE',  3299.00,   8);  -- low stock

-- Orders + Items (to exercise JOINs and order total calculations)
INSERT INTO ORDERS     VALUES (5001, 1002, DATE '2026-04-01', 'PENDING',    0, NULL);
INSERT INTO ORDER_ITEMS VALUES (9001, 5001, 101, 2, 9999.99, 0);
INSERT INTO ORDER_ITEMS VALUES (9002, 5001, 102, 1, 2499.00, 5);

INSERT INTO ORDERS     VALUES (5002, 1003, DATE '2026-04-05', 'PENDING',    0, NULL);
INSERT INTO ORDER_ITEMS VALUES (9003, 5002, 103, 3, 1299.50, 0);

INSERT INTO ORDERS     VALUES (5003, 1007, DATE '2026-04-10', 'FULFILLED', 4599.00, 'Pre-fulfilled');
INSERT INTO ORDER_ITEMS VALUES (9004, 5003, 104, 1, 4599.00, 0);

-- Refresh totals for the pending orders
UPDATE ORDERS SET TOTAL_AMT = (
    SELECT SUM(QUANTITY * UNIT_PRICE * (1 - DISCOUNT_PCT/100))
      FROM ORDER_ITEMS WHERE ORDER_ID = ORDERS.ORDER_ID
) WHERE STATUS = 'PENDING';

COMMIT;


-- ============================================================
-- QUICK SMOKE TEST  (run after setup to validate objects)
-- ============================================================
/*
-- Utility checks
SELECT PKG_UTILS.GET_DATE_STR(SYSDATE)      AS now_str    FROM DUAL;
SELECT PKG_UTILS.FORMAT_AMOUNT(123456.78)   AS formatted  FROM DUAL;

-- Employee functions
SELECT PKG_EMPLOYEE.GET_EMPLOYEE_NAME(1001)  AS name      FROM DUAL;
SELECT PKG_EMPLOYEE.GET_DEPT_BUDGET(10)      AS budget    FROM DUAL;
SELECT PKG_EMPLOYEE.GET_MANAGER_CHAIN(1003)  AS chain     FROM DUAL;  -- 1003→1002→1001 (recursive)
SELECT PKG_EMPLOYEE.COUNT_SUBORDINATES(1001) AS subords   FROM DUAL;  -- recursive

-- Order functions
SELECT PKG_ORDER.CALCULATE_ORDER_TOTAL(5001) AS total     FROM DUAL;
SELECT PKG_ORDER.APPLY_TIERED_DISCOUNT(1000, 4) AS disc   FROM DUAL;  -- recursive: ~814

-- Inventory functions
SELECT PKG_INVENTORY.GET_STOCK_VALUE(101)         AS val  FROM DUAL;
SELECT PKG_INVENTORY.GET_TOTAL_STOCK_VALUE()      AS tot  FROM DUAL;

-- Standalone functions
SELECT FUNC_GET_ORG_DEPTH(1003)           AS depth        FROM DUAL;  -- recursive
SELECT FUNC_EMPLOYEE_SCORE(1002)          AS score        FROM DUAL;  -- cross-pkg

-- Procedure entry points (full call tree)
EXEC PKG_EMPLOYEE.PROCESS_DEPARTMENT(20);
EXEC PKG_ORDER.PROCESS_ALL_PENDING;
EXEC PKG_REPORTS.GENERATE_FULL_REPORT;
EXEC PROC_DAILY_SYNC('FULL');
*/
